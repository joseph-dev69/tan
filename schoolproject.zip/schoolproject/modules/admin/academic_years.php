<?php
/**
 * Admin Academic Calendar Page
 * School Information System
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';

require_role('admin');

function get_next_academic_year_defaults()
{
    $latest_year = get_single_result("
        SELECT year_name, start_date, end_date
        FROM school_years
        ORDER BY start_date DESC, school_year_id DESC
        LIMIT 1
    ");

    $start_year = (int)date('Y');
    if ($latest_year && preg_match('/^(\d{4})-(\d{4})$/', (string)$latest_year['year_name'], $matches)) {
        $start_year = (int)$matches[2];
    } elseif ($latest_year && !empty($latest_year['start_date'])) {
        $start_year = (int)date('Y', strtotime($latest_year['start_date'])) + 1;
    }

    $end_year = $start_year + 1;

    return [
        'year_name' => $start_year . '-' . $end_year,
        'start_date' => $start_year . '-06-01',
        'end_date' => $end_year . '-05-31',
    ];
}

function ensure_academic_calendar_suggestions_table()
{
    static $initialized = false;
    if ($initialized) {
        return;
    }

    $conn = get_db_connection();
    $conn->exec("
        CREATE TABLE IF NOT EXISTS academic_calendar_suggestions (
            suggestion_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            dean_user_id INT NOT NULL,
            school_year_id INT NULL,
            semester_name VARCHAR(50) NULL,
            suggested_start_date DATE NULL,
            suggested_end_date DATE NULL,
            notes TEXT NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            reviewed_by INT NULL,
            reviewed_at DATETIME NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_dean_user_id (dean_user_id),
            INDEX idx_school_year_id (school_year_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");

    $initialized = true;
}

ensure_academic_calendar_suggestions_table();

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    $action = $_POST['action'] ?? '';

    if (!verify_csrf_token($csrf_token)) {
        flash_message('error', 'Invalid request token.');
        redirect('modules/admin/academic_years.php');
    }

    try {
        $conn = get_db_connection();

        if ($action === 'add_year') {
            $next_year_defaults = get_next_academic_year_defaults();
            $year_name = $next_year_defaults['year_name'];
            $start_date = sanitize_input($_POST['start_date'] ?? $next_year_defaults['start_date']);
            $end_date = sanitize_input($_POST['end_date'] ?? $next_year_defaults['end_date']);
            $is_current = isset($_POST['is_current']) ? 1 : 0;

            $duplicate_year = get_single_result("
                SELECT school_year_id
                FROM school_years
                WHERE year_name = ?
                LIMIT 1
            ", [$year_name]);

            if ($year_name === '' || $start_date === '' || $end_date === '') {
                flash_message('error', 'Please complete all academic year fields.');
            } elseif (!preg_match('/^\d{4}-\d{4}$/', $year_name)) {
                flash_message('error', 'Academic year format must be YYYY-YYYY.');
            } elseif ($duplicate_year) {
                flash_message('error', 'Academic year ' . $year_name . ' already exists.');
            } elseif ($end_date < $start_date) {
                flash_message('error', 'Academic year end date must be after the start date.');
            } else {
                $conn->beginTransaction();

                if ($is_current) {
                    $conn->exec("UPDATE school_years SET is_current = 0");
                }

                $stmt = $conn->prepare("
                    INSERT INTO school_years (year_name, start_date, end_date, is_current)
                    VALUES (?, ?, ?, ?)
                ");
                $stmt->execute([$year_name, $start_date, $end_date, $is_current]);

                $conn->commit();
                flash_message('success', 'Academic year added successfully.');
                log_audit('ADD_ACADEMIC_YEAR', 'school_years', (int)$conn->lastInsertId(), null, [
                    'year_name' => $year_name,
                    'start_date' => $start_date,
                    'end_date' => $end_date,
                    'is_current' => $is_current,
                ]);
            }
        } elseif ($action === 'set_current_year') {
            $school_year_id = (int)($_POST['school_year_id'] ?? 0);

            if ($school_year_id <= 0) {
                flash_message('error', 'Invalid academic year.');
            } else {
                $conn->beginTransaction();
                $conn->exec("UPDATE school_years SET is_current = 0");
                $stmt = $conn->prepare("UPDATE school_years SET is_current = 1 WHERE school_year_id = ?");
                $stmt->execute([$school_year_id]);
                $conn->commit();
                flash_message('success', 'Current academic year updated.');
                log_audit('SET_CURRENT_ACADEMIC_YEAR', 'school_years', $school_year_id);
            }
        } elseif ($action === 'save_semester_calendar') {
            $school_year_id = (int)($_POST['school_year_id'] ?? 0);
            $semester_name = sanitize_input($_POST['semester_name'] ?? '');
            $start_date = sanitize_input($_POST['start_date'] ?? '');
            $end_date = sanitize_input($_POST['end_date'] ?? '');
            $is_current = isset($_POST['is_current_semester']) ? 1 : 0;

            $school_year = get_single_result("
                SELECT school_year_id, year_name, start_date, end_date
                FROM school_years
                WHERE school_year_id = ?
            ", [$school_year_id]);

            if ($school_year_id <= 0 || $semester_name === '' || $start_date === '' || $end_date === '') {
                flash_message('error', 'Please complete all semester calendar fields.');
            } elseif (!$school_year) {
                flash_message('error', 'Selected academic year was not found.');
            } elseif ($end_date < $start_date) {
                flash_message('error', 'Semester end date must be after the start date.');
            } elseif ($start_date < $school_year['start_date'] || $end_date > $school_year['end_date']) {
                flash_message('error', 'Semester dates must stay within the selected academic year.');
            } else {
                $existing_semester = get_single_result("
                    SELECT semester_id, start_date, end_date, is_current
                    FROM semesters
                    WHERE school_year_id = ? AND semester_name = ?
                ", [$school_year_id, $semester_name]);

                $conn->beginTransaction();

                if ($is_current) {
                    $conn->exec("UPDATE semesters SET is_current = 0");
                    $conn->exec("UPDATE school_years SET is_current = 0");
                    $stmt = $conn->prepare("UPDATE school_years SET is_current = 1 WHERE school_year_id = ?");
                    $stmt->execute([$school_year_id]);
                }

                if ($existing_semester) {
                    $stmt = $conn->prepare("
                        UPDATE semesters
                        SET start_date = ?, end_date = ?, is_current = ?
                        WHERE semester_id = ?
                    ");
                    $stmt->execute([$start_date, $end_date, $is_current, $existing_semester['semester_id']]);
                    $semester_id = (int)$existing_semester['semester_id'];
                } else {
                    $stmt = $conn->prepare("
                        INSERT INTO semesters (semester_name, school_year_id, start_date, end_date, is_current)
                        VALUES (?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([$semester_name, $school_year_id, $start_date, $end_date, $is_current]);
                    $semester_id = (int)$conn->lastInsertId();
                }

                $conn->commit();

                flash_message('success', 'Semester calendar saved. Exam periods were refreshed from the official dates.');
                log_audit('SAVE_SEMESTER_CALENDAR', 'semesters', $semester_id, $existing_semester, [
                    'semester_name' => $semester_name,
                    'school_year_id' => $school_year_id,
                    'start_date' => $start_date,
                    'end_date' => $end_date,
                    'is_current' => $is_current,
                ]);
            }
        } elseif ($action === 'set_current_semester') {
            $semester_id = (int)($_POST['semester_id'] ?? 0);
            $school_year_id = (int)($_POST['school_year_id'] ?? 0);

            if ($semester_id <= 0 || $school_year_id <= 0) {
                flash_message('error', 'Invalid semester selection.');
            } else {
                $conn->beginTransaction();
                $conn->exec("UPDATE semesters SET is_current = 0");
                $conn->exec("UPDATE school_years SET is_current = 0");

                $stmt = $conn->prepare("UPDATE semesters SET is_current = 1 WHERE semester_id = ?");
                $stmt->execute([$semester_id]);

                $stmt = $conn->prepare("UPDATE school_years SET is_current = 1 WHERE school_year_id = ?");
                $stmt->execute([$school_year_id]);

                $conn->commit();
                flash_message('success', 'Current semester updated.');
                log_audit('SET_CURRENT_SEMESTER', 'semesters', $semester_id);
            }
        } elseif ($action === 'update_suggestion_status') {
            $suggestion_id = (int)($_POST['suggestion_id'] ?? 0);
            $status = sanitize_input($_POST['status'] ?? '');
            $allowed_statuses = ['reviewed', 'applied'];

            if ($suggestion_id <= 0 || !in_array($status, $allowed_statuses, true)) {
                flash_message('error', 'Invalid suggestion update.');
            } else {
                $stmt = $conn->prepare("
                    UPDATE academic_calendar_suggestions
                    SET status = ?, reviewed_by = ?, reviewed_at = NOW()
                    WHERE suggestion_id = ?
                ");
                $stmt->execute([$status, get_logged_in_user()['user_id'], $suggestion_id]);
                flash_message('success', 'Dean suggestion updated.');
                log_audit('UPDATE_CALENDAR_SUGGESTION', 'academic_calendar_suggestions', $suggestion_id, null, [
                    'status' => $status,
                ]);
            }
        }
    } catch (Exception $e) {
        if (isset($conn) && $conn instanceof PDO && $conn->inTransaction()) {
            $conn->rollBack();
        }
        error_log('Academic calendar error: ' . $e->getMessage());
        flash_message('error', 'Action failed. Please try again.');
    }

    redirect('modules/admin/academic_years.php');
}

$school_years = get_multiple_results("
    SELECT school_year_id, year_name, start_date, end_date, is_current, created_at
    FROM school_years
    ORDER BY start_date DESC
");

$next_year_defaults = get_next_academic_year_defaults();

$semester_rows = get_multiple_results("
    SELECT sem.semester_id, sem.semester_name, sem.school_year_id, sem.start_date, sem.end_date, sem.is_current,
           sy.year_name, sy.start_date AS school_year_start, sy.end_date AS school_year_end
    FROM semesters sem
    JOIN school_years sy ON sem.school_year_id = sy.school_year_id
    ORDER BY sy.start_date DESC, sem.start_date ASC, sem.semester_name ASC
");

$semester_groups = [];
foreach ($semester_rows as $semester_row) {
    $semester_row['exam_periods'] = compute_exam_period_schedule($semester_row['start_date'], $semester_row['end_date']);
    $semester_groups[$semester_row['school_year_id']][] = $semester_row;
}

$current_school_year = get_single_result("
    SELECT year_name, start_date, end_date
    FROM school_years
    WHERE is_current = 1
");

$current_semester = get_single_result("
    SELECT sem.semester_name, sem.start_date, sem.end_date, sy.year_name
    FROM semesters sem
    JOIN school_years sy ON sem.school_year_id = sy.school_year_id
    WHERE sem.is_current = 1
    ORDER BY sem.semester_id DESC
    LIMIT 1
");

$dean_suggestions = get_multiple_results("
    SELECT s.suggestion_id, s.school_year_id, s.semester_name, s.suggested_start_date, s.suggested_end_date,
           s.notes, s.status, s.created_at, s.reviewed_at,
           u.first_name, u.last_name,
           sy.year_name
    FROM academic_calendar_suggestions s
    JOIN users u ON s.dean_user_id = u.user_id
    LEFT JOIN school_years sy ON s.school_year_id = sy.school_year_id
    ORDER BY
        CASE WHEN s.status = 'pending' THEN 0 ELSE 1 END,
        s.created_at DESC
");

$flash_messages = get_flash_messages();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <meta name="user-data" content="<?php echo htmlspecialchars(json_encode(get_logged_in_user())); ?>">
    <title>Academic Calendar - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo">
                <a href="<?php echo APP_URL; ?>/modules/admin/dashboard.php">
                    Enchong Dee University Information System
                </a>
            </div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars(get_logged_in_user()['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <aside class="sidebar" id="sidebar">
            <ul class="sidebar-menu">
                <li><a href="<?php echo APP_URL; ?>/modules/admin/dashboard.php"><span class="icon">Dashboard</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/users.php"><span class="icon">Users</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/approvals.php"><span class="icon">Approvals</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/courses.php"><span class="icon">Courses</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/subjects.php"><span class="icon">Subjects</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/departments.php"><span class="icon">Departments</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/academic_years.php" class="active"><span class="icon">Academic Years</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/reports.php"><span class="icon">Reports</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/settings.php"><span class="icon">Settings</span></a></li>
            </ul>
        </aside>

        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Academic Calendar</h1>
                    <p>Only Admin can define the official academic calendar, semester dates, and the exam schedule used by billing and permits.</p>
                </div>

                <?php if ($flash_messages): ?>
                    <div class="flash-messages mb-3">
                        <?php foreach ($flash_messages as $message): ?>
                            <div class="alert alert-<?php echo $message['type']; ?>">
                                <?php echo htmlspecialchars($message['message']); ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-6">
                                <strong>Current School Year:</strong>
                                <?php echo htmlspecialchars($current_school_year['year_name'] ?? 'Not Set'); ?>
                                <?php if (!empty($current_school_year['start_date']) && !empty($current_school_year['end_date'])): ?>
                                    <div class="text-muted"><?php echo htmlspecialchars($current_school_year['start_date']); ?> to <?php echo htmlspecialchars($current_school_year['end_date']); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="col-6">
                                <strong>Current Semester:</strong>
                                <?php echo htmlspecialchars($current_semester['semester_name'] ?? 'Not Set'); ?>
                                <?php if (!empty($current_semester['start_date']) && !empty($current_semester['end_date'])): ?>
                                    <div class="text-muted">
                                        <?php echo htmlspecialchars($current_semester['year_name'] ?? ''); ?> |
                                        <?php echo htmlspecialchars($current_semester['start_date']); ?> to <?php echo htmlspecialchars($current_semester['end_date']); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="alert alert-info mb-4">
                    Billing due dates and permit validations are generated only from this Admin-defined calendar. Dean suggestions are review-only and do not change the system calendar until Admin applies them here.
                </div>

                <div class="card mb-4">
                    <div class="card-header">
                        <h4>Add Academic Year</h4>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="" class="form-row">
                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                            <input type="hidden" name="action" value="add_year">

                            <div class="form-group">
                                <label for="year_name" class="form-label">Year Name</label>
                                <input type="text" id="year_name" name="year_name" class="form-control" value="<?php echo htmlspecialchars($next_year_defaults['year_name']); ?>" readonly required>
                                <small class="text-muted">Automatically generated from the latest academic year.</small>
                            </div>
                            <div class="form-group">
                                <label for="year_start_date" class="form-label">Start Date</label>
                                <input type="date" id="year_start_date" name="start_date" class="form-control" value="<?php echo htmlspecialchars($next_year_defaults['start_date']); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="year_end_date" class="form-label">End Date</label>
                                <input type="date" id="year_end_date" name="end_date" class="form-control" value="<?php echo htmlspecialchars($next_year_defaults['end_date']); ?>" required>
                            </div>
                            <div class="form-group" style="display:flex; align-items:end;">
                                <label class="form-check-label">
                                    <input type="checkbox" name="is_current" class="form-check-input"> Set as current year
                                </label>
                            </div>
                            <div class="form-group" style="display:flex; align-items:end;">
                                <button type="submit" class="btn btn-success">Add Year</button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-header">
                        <h4>Set Semester Calendar</h4>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="" class="form-row">
                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                            <input type="hidden" name="action" value="save_semester_calendar">

                            <div class="form-group">
                                <label for="calendar_school_year_id" class="form-label">Academic Year</label>
                                <select id="calendar_school_year_id" name="school_year_id" class="form-control" required>
                                    <option value="">Select Academic Year</option>
                                    <?php foreach ($school_years as $year): ?>
                                        <option value="<?php echo (int)$year['school_year_id']; ?>">
                                            <?php echo htmlspecialchars($year['year_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="semester_name" class="form-label">Semester</label>
                                <select id="semester_name" name="semester_name" class="form-control" required>
                                    <option value="First Semester">First Semester</option>
                                    <option value="Second Semester">Second Semester</option>
                                    <option value="Summer">Summer</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="semester_start_date" class="form-label">Semester Start</label>
                                <input type="date" id="semester_start_date" name="start_date" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="semester_end_date" class="form-label">Semester End</label>
                                <input type="date" id="semester_end_date" name="end_date" class="form-control" required>
                            </div>
                            <div class="form-group" style="display:flex; align-items:end;">
                                <label class="form-check-label">
                                    <input type="checkbox" name="is_current_semester" class="form-check-input"> Set as current term
                                </label>
                            </div>
                            <div class="form-group" style="display:flex; align-items:end;">
                                <button type="submit" class="btn btn-primary">Save Semester Calendar</button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-header">
                        <h4>Official Academic Calendar</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($school_years): ?>
                            <?php foreach ($school_years as $year): ?>
                                <div class="card mb-3">
                                    <div class="card-header">
                                        <div class="row">
                                            <div class="col-8">
                                                <strong><?php echo htmlspecialchars($year['year_name']); ?></strong>
                                                <div class="text-muted">
                                                    <?php echo htmlspecialchars($year['start_date']); ?> to <?php echo htmlspecialchars($year['end_date']); ?>
                                                </div>
                                            </div>
                                            <div class="col-4 text-right">
                                                <?php if ((int)$year['is_current'] === 1): ?>
                                                    <span class="badge badge-success">Current Year</span>
                                                <?php else: ?>
                                                    <form method="POST" action="" style="display:inline;">
                                                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                                        <input type="hidden" name="action" value="set_current_year">
                                                        <input type="hidden" name="school_year_id" value="<?php echo (int)$year['school_year_id']; ?>">
                                                        <button type="submit" class="btn btn-sm btn-primary">Set Current Year</button>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <?php if (!empty($semester_groups[$year['school_year_id']])): ?>
                                            <div class="table-responsive">
                                                <table class="table table-sm">
                                                    <thead>
                                                        <tr>
                                                            <th>Semester</th>
                                                            <th>Start</th>
                                                            <th>End</th>
                                                            <th>Prelim</th>
                                                            <th>Midterm</th>
                                                            <th>Final</th>
                                                            <th>Status</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php foreach ($semester_groups[$year['school_year_id']] as $semester): ?>
                                                            <tr>
                                                                <td><?php echo htmlspecialchars($semester['semester_name']); ?></td>
                                                                <td><?php echo htmlspecialchars($semester['start_date']); ?></td>
                                                                <td><?php echo htmlspecialchars($semester['end_date']); ?></td>
                                                                <td><?php echo htmlspecialchars($semester['exam_periods']['prelim']['due_date'] ?? 'Schedule Not Set'); ?></td>
                                                                <td><?php echo htmlspecialchars($semester['exam_periods']['midterm']['due_date'] ?? 'Schedule Not Set'); ?></td>
                                                                <td><?php echo htmlspecialchars($semester['exam_periods']['final']['due_date'] ?? 'Schedule Not Set'); ?></td>
                                                                <td>
                                                                    <?php if ((int)$semester['is_current'] === 1): ?>
                                                                        <span class="badge badge-success">Current Semester</span>
                                                                    <?php else: ?>
                                                                        <span class="badge badge-secondary">Official Schedule</span>
                                                                    <?php endif; ?>
                                                                </td>
                                                                <td>
                                                                    <?php if ((int)$semester['is_current'] !== 1): ?>
                                                                        <form method="POST" action="" style="display:inline;">
                                                                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                                                            <input type="hidden" name="action" value="set_current_semester">
                                                                            <input type="hidden" name="semester_id" value="<?php echo (int)$semester['semester_id']; ?>">
                                                                            <input type="hidden" name="school_year_id" value="<?php echo (int)$semester['school_year_id']; ?>">
                                                                            <button type="submit" class="btn btn-sm btn-primary">Set Current Term</button>
                                                                        </form>
                                                                    <?php endif; ?>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        <?php else: ?>
                                            <p class="text-muted">No official semester calendar has been set for this academic year yet.</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p class="text-muted">No academic years yet.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h4>Dean Calendar Suggestions</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($dean_suggestions): ?>
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Dean</th>
                                            <th>Academic Year</th>
                                            <th>Semester</th>
                                            <th>Suggested Start</th>
                                            <th>Suggested End</th>
                                            <th>Notes</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($dean_suggestions as $suggestion): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($suggestion['first_name'] . ' ' . $suggestion['last_name']); ?></td>
                                                <td><?php echo htmlspecialchars($suggestion['year_name'] ?? 'Not specified'); ?></td>
                                                <td><?php echo htmlspecialchars($suggestion['semester_name'] ?? 'Not specified'); ?></td>
                                                <td><?php echo htmlspecialchars($suggestion['suggested_start_date'] ?? 'N/A'); ?></td>
                                                <td><?php echo htmlspecialchars($suggestion['suggested_end_date'] ?? 'N/A'); ?></td>
                                                <td><?php echo nl2br(htmlspecialchars($suggestion['notes'])); ?></td>
                                                <td>
                                                    <span class="badge badge-<?php echo $suggestion['status'] === 'pending' ? 'warning' : 'info'; ?>">
                                                        <?php echo htmlspecialchars(ucfirst($suggestion['status'])); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <?php if ($suggestion['status'] === 'pending'): ?>
                                                        <form method="POST" action="" style="display:inline;">
                                                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                                            <input type="hidden" name="action" value="update_suggestion_status">
                                                            <input type="hidden" name="suggestion_id" value="<?php echo (int)$suggestion['suggestion_id']; ?>">
                                                            <input type="hidden" name="status" value="reviewed">
                                                            <button type="submit" class="btn btn-sm btn-secondary">Mark Reviewed</button>
                                                        </form>
                                                        <form method="POST" action="" style="display:inline;">
                                                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                                            <input type="hidden" name="action" value="update_suggestion_status">
                                                            <input type="hidden" name="suggestion_id" value="<?php echo (int)$suggestion['suggestion_id']; ?>">
                                                            <input type="hidden" name="status" value="applied">
                                                            <button type="submit" class="btn btn-sm btn-success">Mark Applied</button>
                                                        </form>
                                                    <?php else: ?>
                                                        <span class="text-muted">Reviewed by Admin</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">No dean suggestions yet.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
