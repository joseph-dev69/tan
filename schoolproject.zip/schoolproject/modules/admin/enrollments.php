<?php
/**
 * Admin Enrollments
 * School Information System
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';

require_role('admin');

function ensure_enrollment_applications_year_level_column() {
    $conn = get_db_connection();
    $existing_columns = [];

    foreach ($conn->query("SHOW COLUMNS FROM enrollment_applications") as $column) {
        $existing_columns[] = $column['Field'];
    }

    if (!in_array('year_level', $existing_columns, true)) {
        $conn->exec("ALTER TABLE enrollment_applications ADD COLUMN year_level INT NOT NULL DEFAULT 1 AFTER course_id");
    }
}

ensure_enrollment_applications_year_level_column();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    $action = $_POST['action'] ?? '';
    $application_id = (int) ($_POST['application_id'] ?? 0);

    if (!verify_csrf_token($csrf_token)) {
        flash_message('error', 'Invalid request. Please try again.');
    } elseif ($action !== 'officialize_application' || $application_id <= 0) {
        flash_message('error', 'Invalid enrollment action.');
    } else {
        $conn = null;

        try {
            $application = get_single_result("
                SELECT *
                FROM enrollment_applications
                WHERE application_id = ?
                LIMIT 1
            ", [$application_id]);

            if (!$application) {
                flash_message('error', 'Enrollment application not found.');
            } else {
                $application_year_level = max(1, min(4, (int)($application['year_level'] ?? 1)));
                $conn = get_db_connection();
                $conn->beginTransaction();

                $student = get_single_result("
                    SELECT *
                    FROM students
                    WHERE user_id = ?
                    LIMIT 1
                ", [$application['user_id']]);

                if (!$student) {
                    $student_number = generate_student_number();
                    $expected_graduation_date = date('Y-m-d', strtotime('+4 years'));

                    $stmt = $conn->prepare("
                        INSERT INTO students (
                            user_id, student_number, course_id, year_level, admission_date,
                            expected_graduation_date, gpa, academic_status
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([
                        $application['user_id'],
                        $student_number,
                        $application['course_id'],
                        $application_year_level,
                        date('Y-m-d'),
                        $expected_graduation_date,
                        0.00,
                        'regular'
                    ]);

                    $student_id = (int) $conn->lastInsertId();
                } else {
                    $student_id = (int) $student['student_id'];
                    $stmt = $conn->prepare("
                        UPDATE students
                        SET course_id = ?, year_level = ?, updated_at = NOW()
                        WHERE student_id = ?
                    ");
                    $stmt->execute([$application['course_id'], $application_year_level, $student_id]);
                }

                $existing_enrollment = get_single_result("
                    SELECT *
                    FROM enrollments
                    WHERE student_id = ? AND school_year_id = ? AND semester_id = ?
                    LIMIT 1
                ", [$student_id, $application['school_year_id'], $application['semester_id']]);

                if ($existing_enrollment) {
                    $stmt = $conn->prepare("
                        UPDATE enrollments
                        SET status = 'enrolled', updated_at = NOW()
                        WHERE enrollment_id = ?
                    ");
                    $stmt->execute([$existing_enrollment['enrollment_id']]);
                } else {
                    $stmt = $conn->prepare("
                        INSERT INTO enrollments (
                            student_id, semester_id, school_year_id, enrollment_date,
                            status, total_units, total_fee, paid_amount, balance
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([
                        $student_id,
                        $application['semester_id'],
                        $application['school_year_id'],
                        date('Y-m-d'),
                        'enrolled',
                        0.0,
                        0.00,
                        0.00,
                        0.00
                    ]);
                }

                $stmt = $conn->prepare("
                    UPDATE enrollment_applications
                    SET status = 'approved', updated_at = NOW()
                    WHERE application_id = ?
                ");
                $stmt->execute([$application_id]);

                $conn->commit();
                flash_message('success', 'E-form application is now an official enrollment record.');
            }
        } catch (Exception $e) {
            if ($conn instanceof PDO && $conn->inTransaction()) {
                $conn->rollBack();
            }
            error_log('Officialize enrollment error: ' . $e->getMessage());
            flash_message('error', 'Unable to convert the e-form into an official enrollment right now.');
        }
    }

    redirect('modules/admin/enrollments.php');
}

$pending_applications = get_multiple_results("
    SELECT ea.application_id, ea.created_at, ea.status, ea.year_level,
           ea.first_name, ea.last_name, ea.email,
           sy.year_name, sem.semester_name, c.course_code, c.course_name
    FROM enrollment_applications ea
    JOIN school_years sy ON sy.school_year_id = ea.school_year_id
    JOIN semesters sem ON sem.semester_id = ea.semester_id
    LEFT JOIN courses c ON c.course_id = ea.course_id
    WHERE ea.status IN ('submitted', 'reviewed')
    ORDER BY ea.updated_at DESC
    LIMIT 50
");

$enrollments = get_multiple_results("
    SELECT e.enrollment_id, e.enrollment_date, e.status,
           s.student_number, s.year_level, u.first_name, u.last_name,
           c.course_code, c.course_name, sy.year_name, sem.semester_name
    FROM enrollments e
    JOIN students s ON s.student_id = e.student_id
    JOIN users u ON u.user_id = s.user_id
    LEFT JOIN courses c ON c.course_id = s.course_id
    LEFT JOIN school_years sy ON sy.school_year_id = e.school_year_id
    LEFT JOIN semesters sem ON sem.semester_id = e.semester_id
    ORDER BY e.enrollment_date DESC, e.enrollment_id DESC
    LIMIT 100
");

$flash_messages = get_flash_messages();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enrollments - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo">
                <a href="<?php echo APP_URL; ?>/modules/admin/dashboard.php">School Information System</a>
            </div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars(get_logged_in_user()['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <aside class="sidebar" id="sidebar">
            <ul class="sidebar-menu">
                <li><a href="<?php echo APP_URL; ?>/modules/admin/dashboard.php" class="active"><span class="icon">Dashboard</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/users.php"><span class="icon">Users</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/approvals.php"><span class="icon">Approvals</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/courses.php"><span class="icon">Courses</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/subjects.php"><span class="icon">Subjects</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/departments.php"><span class="icon">Departments</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/academic_years.php"><span class="icon">Academic Years</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/reports.php"><span class="icon">Reports</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/settings.php"><span class="icon">Settings</span></a></li>
            </ul>
        </aside>

        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Enrollments</h1>
                    <p>Official enrollment records only. Pending e-forms can be converted below.</p>
                </div>

                <?php if ($flash_messages): ?>
                    <div class="flash-messages mb-3">
                        <?php foreach ($flash_messages as $message): ?>
                            <div class="alert alert-<?php echo $message['type']; ?>">
                                <?php echo htmlspecialchars($message['message']); ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <?php if ($pending_applications): ?>
                    <div class="card mb-4">
                        <div class="card-header">
                            <h4>Pending E-Forms To Convert</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Student</th>
                                            <th>Course</th>
                                            <th>Year Level</th>
                                            <th>School Year</th>
                                            <th>Semester</th>
                                            <th>Submitted</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($pending_applications as $row): ?>
                                            <tr>
                                                <td>
                                                    <?php echo htmlspecialchars($row['last_name'] . ', ' . $row['first_name']); ?>
                                                    <br>
                                                    <small class="text-muted"><?php echo htmlspecialchars($row['email']); ?></small>
                                                </td>
                                                <td><?php echo htmlspecialchars(($row['course_code'] ? $row['course_code'] . ' - ' : '') . ($row['course_name'] ?? 'Not assigned')); ?></td>
                                                <td><?php echo htmlspecialchars((int)$row['year_level'] . ($row['year_level'] == 1 ? 'st' : ($row['year_level'] == 2 ? 'nd' : ($row['year_level'] == 3 ? 'rd' : 'th'))) . ' Year'); ?></td>
                                                <td><?php echo htmlspecialchars($row['year_name']); ?></td>
                                                <td><?php echo htmlspecialchars($row['semester_name']); ?></td>
                                                <td><?php echo htmlspecialchars(format_date($row['created_at'])); ?></td>
                                                <td>
                                                    <form method="POST" action="" onsubmit="return confirm('Make this e-form an official enrollment?');" style="display:inline;">
                                                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                                        <input type="hidden" name="action" value="officialize_application">
                                                        <input type="hidden" name="application_id" value="<?php echo (int) $row['application_id']; ?>">
                                                        <button type="submit" class="btn btn-success btn-sm">Make Official</button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-header">
                        <h4>Official Enrollment Records</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($enrollments): ?>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Student</th>
                                            <th>Student Number</th>
                                            <th>Course</th>
                                            <th>Year Level</th>
                                            <th>School Year</th>
                                            <th>Semester</th>
                                            <th>Status</th>
                                            <th>Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($enrollments as $row): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($row['last_name'] . ', ' . $row['first_name']); ?></td>
                                                <td><?php echo htmlspecialchars($row['student_number']); ?></td>
                                                <td><?php echo htmlspecialchars(($row['course_code'] ? $row['course_code'] . ' - ' : '') . ($row['course_name'] ?? 'Not assigned')); ?></td>
                                                <td><?php echo htmlspecialchars((int)$row['year_level'] . ($row['year_level'] == 1 ? 'st' : ($row['year_level'] == 2 ? 'nd' : ($row['year_level'] == 3 ? 'rd' : 'th'))) . ' Year'); ?></td>
                                                <td><?php echo htmlspecialchars($row['year_name'] ?? 'Not set'); ?></td>
                                                <td><?php echo htmlspecialchars($row['semester_name'] ?? 'Not set'); ?></td>
                                                <td><?php echo htmlspecialchars(ucfirst($row['status'])); ?></td>
                                                <td><?php echo format_date($row['enrollment_date']); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">No official enrollment records found yet.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
