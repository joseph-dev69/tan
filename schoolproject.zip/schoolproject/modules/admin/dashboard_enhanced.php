<?php
/**
 * Enhanced Admin Dashboard
 * School Information System - Modern & User-Friendly Design
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';

// Require admin role
require_role('admin');

// Get dashboard statistics with enhanced calculations
$stats = [
    'total_users' => get_single_result("SELECT COUNT(*) as count FROM users")['count'],
    'pending_users' => get_single_result("SELECT COUNT(*) as count FROM users WHERE status = 'pending'")['count'],
    'total_students' => get_single_result("SELECT COUNT(*) as count FROM students")['count'],
    'total_teachers' => get_single_result("SELECT COUNT(*) as count FROM teachers")['count'],
    'active_enrollments' => get_single_result("SELECT COUNT(*) as count FROM enrollments WHERE status = 'enrolled'")['count'],
    'total_courses' => get_single_result("SELECT COUNT(*) as count FROM courses")['count'],
    'total_subjects' => get_single_result("SELECT COUNT(*) as count FROM subjects")['count'],
    'pending_payments' => get_single_result("SELECT COUNT(*) as count FROM billings WHERE status = 'pending'")['count'],
    'total_revenue' => get_single_result("SELECT COALESCE(SUM(amount), 0) as total FROM payments WHERE payment_date >= DATE_SUB(NOW(), INTERVAL 30 DAY)")['total'],
    'approval_rate' => get_single_result("
        SELECT ROUND(
            (SELECT COUNT(*) FROM users WHERE status = 'approved') * 100.0 / 
            (SELECT COUNT(*) FROM users WHERE status IN ('approved', 'rejected', 'pending'))
        , 2) as rate
    ")['rate']
];

// Get recent pending users with enhanced details
$pending_users = get_multiple_results("
    SELECT u.user_id, u.username, u.email, u.first_name, u.last_name, u.created_at, r.role_name,
           TIMESTAMPDIFF(HOUR, u.created_at, NOW()) as hours_ago
    FROM users u
    JOIN roles r ON u.role_id = r.role_id
    WHERE u.status = 'pending'
    ORDER BY u.created_at DESC
    LIMIT 5
");

// Get recent enrollments with enhanced details
$recent_enrollments = get_multiple_results("
    SELECT e.enrollment_id, e.enrollment_date, e.total_units, e.total_fee, e.status,
           s.student_number, u.first_name, u.last_name, c.course_name, c.course_code,
           TIMESTAMPDIFF(HOUR, e.enrollment_date, NOW()) as hours_ago
    FROM enrollments e
    JOIN students s ON e.student_id = s.student_id
    JOIN users u ON s.user_id = u.user_id
    JOIN courses c ON s.course_id = c.course_id
    ORDER BY e.enrollment_date DESC
    LIMIT 5
");

// Get recent payments with enhanced details
$recent_payments = get_multiple_results("
    SELECT p.payment_id, p.amount, p.payment_date, p.payment_method,
           s.student_number, u.first_name, u.last_name,
           TIMESTAMPDIFF(HOUR, p.payment_date, NOW()) as hours_ago
    FROM payments p
    JOIN billings b ON p.billing_id = b.billing_id
    JOIN students s ON b.student_id = s.student_id
    JOIN users u ON s.user_id = u.user_id
    ORDER BY p.payment_date DESC
    LIMIT 5
");

// Get system activity
$system_activity = get_multiple_results("
    SELECT action, COUNT(*) as count, MAX(timestamp) as last_activity
    FROM audit_logs
    WHERE timestamp >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    GROUP BY action
    ORDER BY count DESC
    LIMIT 10
");

// Get current academic year and semester
$current_school_year = get_single_result("SELECT year_name FROM school_years WHERE is_current = TRUE")['year_name'] ?? 'Not Set';
$current_semester = get_single_result("SELECT semester_name FROM semesters WHERE is_current = TRUE")['semester_name'] ?? 'Not Set';

// Get flash messages
$flash_messages = get_flash_messages();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <meta name="user-data" content="<?php echo htmlspecialchars(json_encode(get_logged_in_user())); ?>">
    <title>Admin Dashboard - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/enhanced.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Enhanced Header -->
    <header class="header">
        <div class="container">
            <div class="logo">
                <a href="<?php echo APP_URL; ?>/modules/admin/dashboard.php">
                    <span class="logo-icon">🎓</span>
                    Enchong Dee University Information System
                </a>
            </div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle" data-tooltip="Toggle navigation">☰</a></li>
                    <li><a href="#" data-tooltip="User profile">
                        <span class="user-avatar">👤</span>
                        <?php echo htmlspecialchars(get_logged_in_user()['first_name']); ?>
                    </a></li>
                    <li>
                        <a href="#" class="notification-toggle" data-tooltip="Notifications">
                            <span class="notification-icon">🔔</span>
                            <span class="notification-badge"><?php echo $stats['pending_users']; ?></span>
                        </a>
                    </li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php" data-tooltip="Logout">🚪</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <!-- Enhanced Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="user-profile">
                    <div class="user-avatar-large">👤</div>
                    <div class="user-info">
                        <div class="user-name"><?php echo htmlspecialchars(get_logged_in_user()['first_name'] . ' ' . get_logged_in_user()['last_name']); ?></div>
                        <div class="user-role">System Administrator</div>
                    </div>
                </div>
            </div>
            <ul class="sidebar-menu">
                <li><a href="<?php echo APP_URL; ?>/modules/admin/dashboard.php" class="active" data-tooltip="Dashboard">
                    <span class="menu-icon">📊</span>
                    <span class="menu-text">Dashboard</span>
                </a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/users.php" data-tooltip="User Management">
                    <span class="menu-icon">👥</span>
                    <span class="menu-text">Users</span>
                </a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/approvals.php" data-tooltip="Pending Approvals">
                    <span class="menu-icon">✅</span>
                    <span class="menu-text">Approvals</span>
                    <?php if ($stats['pending_users'] > 0): ?>
                        <span class="menu-badge"><?php echo $stats['pending_users']; ?></span>
                    <?php endif; ?>
                </a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/courses.php" data-tooltip="Course Management">
                    <span class="menu-icon">📚</span>
                    <span class="menu-text">Courses</span>
                </a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/subjects.php" data-tooltip="Subject Management">
                    <span class="menu-icon">📖</span>
                    <span class="menu-text">Subjects</span>
                </a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/departments.php" data-tooltip="Department Management">
                    <span class="menu-icon">🏢</span>
                    <span class="menu-text">Departments</span>
                </a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/academic_years.php" data-tooltip="Academic Calendar">
                    <span class="menu-icon">📅</span>
                    <span class="menu-text">Academic Years</span>
                </a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/reports.php" data-tooltip="Reports & Analytics">
                    <span class="menu-icon">📈</span>
                    <span class="menu-text">Reports</span>
                </a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/settings.php" data-tooltip="System Settings">
                    <span class="menu-icon">⚙️</span>
                    <span class="menu-text">Settings</span>
                </a></li>
            </ul>
        </aside>

        <!-- Enhanced Main Content -->
        <main class="main-content" id="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Admin Dashboard</h1>
                    <p>System overview and management</p>
                    <div class="page-actions">
                        <button class="btn btn-primary" onclick="openQuickActions()">
                            <span class="btn-icon">⚡</span>
                            Quick Actions
                        </button>
                        <button class="btn btn-secondary" onclick="exportDashboardData()">
                            <span class="btn-icon">📊</span>
                            Export Data
                        </button>
                    </div>
                </div>

                <?php if ($flash_messages): ?>
                    <div class="flash-messages mb-3">
                        <?php foreach ($flash_messages as $message): ?>
                            <div class="alert alert-<?php echo $message['type']; ?> fade-in">
                                <div class="alert-icon">
                                    <?php
                                    $icons = ['success' => '✓', 'error' => '✕', 'warning' => '⚠', 'info' => 'ℹ'];
                                    echo $icons[$message['type']] ?? 'ℹ';
                                    ?>
                                </div>
                                <div class="alert-content">
                                    <?php echo htmlspecialchars($message['message']); ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <!-- Academic Year Info -->
                <div class="card mb-4 animate-on-scroll">
                    <div class="card-header">
                        <h4>Current Academic Period</h4>
                        <div class="card-actions">
                            <button class="btn btn-sm btn-secondary" onclick="showAcademicSettings()">
                                <span class="btn-icon">⚙️</span>
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="academic-info">
                            <div class="academic-item">
                                <div class="academic-label">School Year</div>
                                <div class="academic-value"><?php echo htmlspecialchars($current_school_year); ?></div>
                            </div>
                            <div class="academic-item">
                                <div class="academic-label">Semester</div>
                                <div class="academic-value"><?php echo htmlspecialchars($current_semester); ?></div>
                            </div>
                            <div class="academic-item">
                                <div class="academic-label">System Status</div>
                                <div class="academic-value">
                                    <span class="status-indicator status-online"></span>
                                    Online
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Enhanced Statistics Cards -->
                <div class="stats-grid mb-4">
                    <div class="stat-card stat-primary animate-on-scroll">
                        <div class="stat-icon">👥</div>
                        <div class="stat-content">
                            <div class="stat-number"><?php echo number_format($stats['total_users']); ?></div>
                            <div class="stat-label">Total Users</div>
                            <div class="stat-change">
                                <span class="change-indicator change-positive">+12%</span>
                                <span class="change-text">from last month</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="stat-card stat-warning animate-on-scroll">
                        <div class="stat-icon">⏳</div>
                        <div class="stat-content">
                            <div class="stat-number"><?php echo number_format($stats['pending_users']); ?></div>
                            <div class="stat-label">Pending Approvals</div>
                            <div class="stat-change">
                                <span class="change-indicator change-neutral">0%</span>
                                <span class="change-text">from last week</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="stat-card stat-info animate-on-scroll">
                        <div class="stat-icon">🎓</div>
                        <div class="stat-content">
                            <div class="stat-number"><?php echo number_format($stats['total_students']); ?></div>
                            <div class="stat-label">Total Students</div>
                            <div class="stat-change">
                                <span class="change-indicator change-positive">+8%</span>
                                <span class="change-text">from last month</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="stat-card stat-success animate-on-scroll">
                        <div class="stat-icon">👨‍🏫</div>
                        <div class="stat-content">
                            <div class="stat-number"><?php echo number_format($stats['total_teachers']); ?></div>
                            <div class="stat-label">Total Teachers</div>
                            <div class="stat-change">
                                <span class="change-indicator change-positive">+5%</span>
                                <span class="change-text">from last month</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="stats-grid mb-4">
                    <div class="stat-card stat-secondary animate-on-scroll">
                        <div class="stat-icon">📝</div>
                        <div class="stat-content">
                            <div class="stat-number"><?php echo number_format($stats['active_enrollments']); ?></div>
                            <div class="stat-label">Active Enrollments</div>
                            <div class="stat-change">
                                <span class="change-indicator change-positive">+15%</span>
                                <span class="change-text">from last month</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="stat-card stat-info animate-on-scroll">
                        <div class="stat-icon">📚</div>
                        <div class="stat-content">
                            <div class="stat-number"><?php echo number_format($stats['total_courses']); ?></div>
                            <div class="stat-label">Total Courses</div>
                            <div class="stat-change">
                                <span class="change-indicator change-neutral">0%</span>
                                <span class="change-text">no change</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="stat-card stat-purple animate-on-scroll">
                        <div class="stat-icon">📖</div>
                        <div class="stat-content">
                            <div class="stat-number"><?php echo number_format($stats['total_subjects']); ?></div>
                            <div class="stat-label">Total Subjects</div>
                            <div class="stat-change">
                                <span class="change-indicator change-positive">+3%</span>
                                <span class="change-text">from last month</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="stat-card stat-warning animate-on-scroll">
                        <div class="stat-icon">💰</div>
                        <div class="stat-content">
                            <div class="stat-number"><?php echo format_currency($stats['total_revenue']); ?></div>
                            <div class="stat-label">Revenue (30 days)</div>
                            <div class="stat-change">
                                <span class="change-indicator change-positive">+22%</span>
                                <span class="change-text">from last month</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Recent Activity Grid -->
                <div class="activity-grid mb-4">
                    <div class="card animate-on-scroll">
                        <div class="card-header">
                            <h4>Pending User Approvals</h4>
                            <div class="card-actions">
                                <a href="<?php echo APP_URL; ?>/modules/admin/approvals.php" class="btn btn-sm btn-primary">
                                    View All
                                </a>
                            </div>
                        </div>
                        <div class="card-body">
                            <?php if ($pending_users): ?>
                                <div class="recent-list">
                                    <?php foreach ($pending_users as $user): ?>
                                        <div class="recent-item">
                                            <div class="recent-avatar">👤</div>
                                            <div class="recent-content">
                                                <div class="recent-title">
                                                    <?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?>
                                                    <span class="recent-badge badge-warning"><?php echo htmlspecialchars($user['role_name']); ?></span>
                                                </div>
                                                <div class="recent-meta">
                                                    <span class="recent-email"><?php echo htmlspecialchars($user['email']); ?></span>
                                                    <span class="recent-time">
                                                        <?php
                                                        if ($user['hours_ago'] < 1) {
                                                            echo 'Just now';
                                                        } elseif ($user['hours_ago'] < 24) {
                                                            echo floor($user['hours_ago']) . ' hours ago';
                                                        } else {
                                                            echo floor($user['hours_ago'] / 24) . ' days ago';
                                                        }
                                                        ?>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="recent-actions">
                                                <button class="btn btn-sm btn-success" onclick="approveUser(<?php echo $user['user_id']; ?>)">
                                                    Approve
                                                </button>
                                                <button class="btn btn-sm btn-secondary" onclick="viewUserDetails(<?php echo $user['user_id']; ?>)">
                                                    View
                                                </button>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php else: ?>
                                <div class="empty-state">
                                    <div class="empty-icon">✅</div>
                                    <div class="empty-title">No Pending Approvals</div>
                                    <div class="empty-description">All user registrations have been processed</div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="card animate-on-scroll">
                        <div class="card-header">
                            <h4>Recent Enrollments</h4>
                            <div class="card-actions">
                                <a href="<?php echo APP_URL; ?>/modules/admin/enrollments.php" class="btn btn-sm btn-primary">
                                    View All
                                </a>
                            </div>
                        </div>
                        <div class="card-body">
                            <?php if ($recent_enrollments): ?>
                                <div class="recent-list">
                                    <?php foreach ($recent_enrollments as $enrollment): ?>
                                        <div class="recent-item">
                                            <div class="recent-avatar">🎓</div>
                                            <div class="recent-content">
                                                <div class="recent-title">
                                                    <?php echo htmlspecialchars($enrollment['first_name'] . ' ' . $enrollment['last_name']); ?>
                                                    <span class="recent-badge badge-info"><?php echo htmlspecialchars($enrollment['course_code']); ?></span>
                                                </div>
                                                <div class="recent-meta">
                                                    <span class="recent-email"><?php echo htmlspecialchars($enrollment['student_number']); ?></span>
                                                    <span class="recent-time">
                                                        <?php
                                                        if ($enrollment['hours_ago'] < 1) {
                                                            echo 'Just now';
                                                        } elseif ($enrollment['hours_ago'] < 24) {
                                                            echo floor($enrollment['hours_ago']) . ' hours ago';
                                                        } else {
                                                            echo floor($enrollment['hours_ago'] / 24) . ' days ago';
                                                        }
                                                        ?>
                                                    </span>
                                                    <span class="recent-amount"><?php echo format_currency($enrollment['total_fee']); ?></span>
                                                </div>
                                            </div>
                                            <div class="recent-actions">
                                                <button class="btn btn-sm btn-secondary" onclick="viewEnrollment(<?php echo $enrollment['enrollment_id']; ?>)">
                                                    View Details
                                                </button>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php else: ?>
                                <div class="empty-state">
                                    <div class="empty-icon">📝</div>
                                    <div class="empty-title">No Recent Enrollments</div>
                                    <div class="empty-description">No student enrollments in the last 30 days</div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="card animate-on-scroll">
                        <div class="card-header">
                            <h4>Recent Payments</h4>
                            <div class="card-actions">
                                <a href="<?php echo APP_URL; ?>/modules/admin/payments.php" class="btn btn-sm btn-primary">
                                    View All
                                </a>
                            </div>
                        </div>
                        <div class="card-body">
                            <?php if ($recent_payments): ?>
                                <div class="recent-list">
                                    <?php foreach ($recent_payments as $payment): ?>
                                        <div class="recent-item">
                                            <div class="recent-avatar">💰</div>
                                            <div class="recent-content">
                                                <div class="recent-title">
                                                    <?php echo htmlspecialchars($payment['first_name'] . ' ' . $payment['last_name']); ?>
                                                    <span class="recent-badge badge-success"><?php echo htmlspecialchars($payment['payment_method']); ?></span>
                                                </div>
                                                <div class="recent-meta">
                                                    <span class="recent-email"><?php echo htmlspecialchars($payment['student_number']); ?></span>
                                                    <span class="recent-time">
                                                        <?php
                                                        if ($payment['hours_ago'] < 1) {
                                                            echo 'Just now';
                                                        } elseif ($payment['hours_ago'] < 24) {
                                                            echo floor($payment['hours_ago']) . ' hours ago';
                                                        } else {
                                                            echo floor($payment['hours_ago'] / 24) . ' days ago';
                                                        }
                                                        ?>
                                                    </span>
                                                    <span class="recent-amount"><?php echo format_currency($payment['amount']); ?></span>
                                                </div>
                                            </div>
                                            <div class="recent-actions">
                                                <button class="btn btn-sm btn-secondary" onclick="viewPayment(<?php echo $payment['payment_id']; ?>)">
                                                    View Receipt
                                                </button>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php else: ?>
                                <div class="empty-state">
                                    <div class="empty-icon">💰</div>
                                    <div class="empty-title">No Recent Payments</div>
                                    <div class="empty-description">No payments recorded in the last 30 days</div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- System Activity -->
                <div class="card animate-on-scroll">
                    <div class="card-header">
                        <h4>System Activity (Last 7 Days)</h4>
                        <div class="card-actions">
                            <button class="btn btn-sm btn-secondary" onclick="viewFullActivity()">
                                View Full Log
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="activity-list">
                            <?php if ($system_activity): ?>
                                <?php foreach ($system_activity as $activity): ?>
                                    <div class="activity-item">
                                        <div class="activity-icon">
                                            <?php
                                            $icons = [
                                                'USER_LOGIN' => '🔐',
                                                'USER_LOGOUT' => '🚪',
                                                'USER_REGISTER' => '👥',
                                                'USER_APPROVED' => '✅',
                                                'USER_REJECTED' => '❌',
                                                'STUDENT_ENROLLMENT' => '📝',
                                                'GRADE_SUBMITTED' => '📊',
                                                'PAYMENT_PROCESSED' => '💰'
                                            ];
                                            echo $icons[$activity['action']] ?? '📄';
                                            ?>
                                        </div>
                                        <div class="activity-content">
                                            <div class="activity-title"><?php echo htmlspecialchars($activity['action']); ?></div>
                                            <div class="activity-meta">
                                                <span class="activity-count"><?php echo number_format($activity['count']); ?> times</span>
                                                <span class="activity-time">Last: <?php echo format_date($activity['last_activity'], 'M d, Y H:i'); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <div class="empty-state">
                                    <div class="empty-icon">📊</div>
                                    <div class="empty-title">No Recent Activity</div>
                                    <div class="empty-description">No system activity recorded in the last 7 days</div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- Quick Actions Modal -->
    <div id="quickActionsModal" class="modal">
        <div class="modal-dialog">
            <div class="modal-header">
                <h3 class="modal-title">Quick Actions</h3>
                <button class="modal-close">&times;</button>
            </div>
            <div class="modal-body">
                <div class="quick-actions-grid">
                    <button class="quick-action-btn" onclick="createNewUser()">
                        <span class="action-icon">👥</span>
                        <span class="action-title">Add New User</span>
                        <span class="action-description">Create a new user account</span>
                    </button>
                    <button class="quick-action-btn" onclick="createNewCourse()">
                        <span class="action-icon">📚</span>
                        <span class="action-title">Add New Course</span>
                        <span class="action-description">Create a new academic course</span>
                    </button>
                    <button class="quick-action-btn" onclick="createNewSubject()">
                        <span class="action-icon">📖</span>
                        <span class="action-title">Add New Subject</span>
                        <span class="action-description">Create a new subject offering</span>
                    </button>
                    <button class="quick-action-btn" onclick="viewReports()">
                        <span class="action-icon">📈</span>
                        <span class="action-title">Generate Reports</span>
                        <span class="action-description">View system analytics</span>
                    </button>
                    <button class="quick-action-btn" onclick="systemBackup()">
                        <span class="action-icon">💾</span>
                        <span class="action-title">System Backup</span>
                        <span class="action-description">Create system backup</span>
                    </button>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary modal-cancel">Close</button>
            </div>
        </div>
    </div>

    <style>
        /* Enhanced Dashboard Styles */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .activity-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: var(--shadow);
            border: 1px solid rgba(0, 0, 0, 0.05);
            transition: var(--transition);
            position: relative;
            overflow: hidden;
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--secondary-color), var(--accent-color));
            transform: scaleX(0);
            transition: transform 0.3s;
        }
        
        .stat-card:hover::before {
            transform: scaleX(1);
        }
        
        .stat-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-lg);
        }
        
        .stat-primary { border-left: 4px solid var(--primary-color); }
        .stat-secondary { border-left: 4px solid var(--secondary-color); }
        .stat-success { border-left: 4px solid var(--success-color); }
        .stat-warning { border-left: 4px solid var(--warning-color); }
        .stat-info { border-left: 4px solid var(--info-color); }
        .stat-purple { border-left: 4px solid #9b59b6; }
        
        .stat-icon {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            display: block;
            text-align: center;
        }
        
        .stat-content {
            text-align: center;
        }
        
        .stat-number {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--dark-color);
            margin-bottom: 0.5rem;
            line-height: 1;
        }
        
        .stat-label {
            font-size: 1rem;
            color: var(--gray-color);
            margin-bottom: 0.75rem;
            font-weight: 500;
        }
        
        .stat-change {
            display: flex;
            flex-direction: column;
            gap: 0.25rem;
            align-items: center;
        }
        
        .change-indicator {
            font-size: 0.875rem;
            font-weight: 600;
            padding: 0.25rem 0.5rem;
            border-radius: 20px;
        }
        
        .change-positive {
            background: rgba(39, 174, 96, 0.1);
            color: var(--success-color);
        }
        
        .change-negative {
            background: rgba(231, 76, 60, 0.1);
            color: var(--accent-color);
        }
        
        .change-neutral {
            background: rgba(149, 165, 166, 0.1);
            color: var(--gray-color);
        }
        
        .change-text {
            font-size: 0.8rem;
            color: var(--gray-color);
        }
        
        .recent-list {
            max-height: 400px;
            overflow-y: auto;
        }
        
        .recent-item {
            display: flex;
            align-items: flex-start;
            padding: 1rem 0;
            border-bottom: 1px solid var(--light-color);
            transition: var(--transition);
        }
        
        .recent-item:hover {
            background: rgba(52, 152, 219, 0.05);
        }
        
        .recent-item:last-child {
            border-bottom: none;
        }
        
        .recent-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--light-color);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.25rem;
            margin-right: 1rem;
            flex-shrink: 0;
        }
        
        .recent-content {
            flex: 1;
            min-width: 0;
        }
        
        .recent-title {
            font-weight: 600;
            color: var(--dark-color);
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .recent-badge {
            font-size: 0.75rem;
            padding: 0.25rem 0.5rem;
        }
        
        .recent-meta {
            display: flex;
            flex-direction: column;
            gap: 0.25rem;
            font-size: 0.875rem;
            color: var(--gray-color);
        }
        
        .recent-time {
            font-weight: 500;
        }
        
        .recent-amount {
            font-weight: 600;
            color: var(--success-color);
        }
        
        .recent-actions {
            display: flex;
            gap: 0.5rem;
            margin-left: auto;
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem 2rem;
        }
        
        .empty-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
            opacity: 0.5;
        }
        
        .empty-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--gray-color);
            margin-bottom: 0.5rem;
        }
        
        .empty-description {
            color: var(--gray-color);
            font-size: 0.9rem;
        }
        
        .academic-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
        }
        
        .academic-item {
            text-align: center;
            padding: 1rem;
            background: var(--light-color);
            border-radius: 8px;
        }
        
        .academic-label {
            font-size: 0.875rem;
            color: var(--gray-color);
            margin-bottom: 0.5rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .academic-value {
            font-size: 1.1rem;
            font-weight: 600;
            color: var(--dark-color);
        }
        
        .status-indicator {
            display: inline-block;
            width: 8px;
            height: 8px;
            border-radius: 50%;
            margin-right: 0.5rem;
        }
        
        .status-online {
            background: var(--success-color);
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.5; }
            100% { opacity: 1; }
        }
        
        .activity-list {
            max-height: 300px;
            overflow-y: auto;
        }
        
        .activity-item {
            display: flex;
            align-items: center;
            padding: 1rem;
            border-bottom: 1px solid var(--light-color);
            transition: var(--transition);
        }
        
        .activity-item:hover {
            background: rgba(52, 152, 219, 0.05);
        }
        
        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--light-color);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.25rem;
            margin-right: 1rem;
        }
        
        .activity-content {
            flex: 1;
        }
        
        .activity-title {
            font-weight: 600;
            color: var(--dark-color);
            margin-bottom: 0.25rem;
        }
        
        .activity-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.875rem;
            color: var(--gray-color);
        }
        
        .activity-count {
            background: var(--secondary-color);
            color: white;
            padding: 0.25rem 0.5rem;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        .page-actions {
            display: flex;
            gap: 1rem;
            align-items: center;
        }
        
        .btn-icon {
            margin-right: 0.5rem;
        }
        
        .sidebar-header {
            padding: 2rem;
            border-bottom: 1px solid var(--border-color);
            margin-bottom: 1rem;
        }
        
        .user-profile {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .user-avatar-large {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: var(--secondary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
        }
        
        .user-info {
            flex: 1;
        }
        
        .user-name {
            font-weight: 600;
            color: var(--dark-color);
            margin-bottom: 0.25rem;
        }
        
        .user-role {
            font-size: 0.875rem;
            color: var(--gray-color);
        }
        
        .menu-icon {
            margin-right: 0.75rem;
            font-size: 1.1rem;
        }
        
        .menu-text {
            flex: 1;
        }
        
        .menu-badge {
            background: var(--accent-color);
            color: white;
            font-size: 0.75rem;
            padding: 0.125rem 0.375rem;
            border-radius: 10px;
            margin-left: auto;
        }
        
        .notification-toggle {
            position: relative;
        }
        
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--accent-color);
            color: white;
            font-size: 0.75rem;
            padding: 0.125rem 0.375rem;
            border-radius: 10px;
            min-width: 18px;
            text-align: center;
        }
        
        .quick-actions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
        }
        
        .quick-action-btn {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 1.5rem;
            background: white;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            cursor: pointer;
            transition: var(--transition);
        }
        
        .quick-action-btn:hover {
            background: var(--light-color);
            transform: translateY(-2px);
            box-shadow: var(--shadow);
        }
        
        .action-icon {
            font-size: 2rem;
            margin-bottom: 1rem;
        }
        
        .action-title {
            font-weight: 600;
            color: var(--dark-color);
            margin-bottom: 0.5rem;
        }
        
        .action-description {
            font-size: 0.875rem;
            color: var(--gray-color);
            text-align: center;
        }
        
        @media (max-width: 1200px) {
            .stats-grid {
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            }
            
            .activity-grid {
                grid-template-columns: 1fr;
            }
        }
        
        @media (max-width: 768px) {
            .stats-grid {
                grid-template-columns: 1fr;
                gap: 1rem;
            }
            
            .activity-grid {
                grid-template-columns: 1fr;
            }
            
            .page-actions {
                flex-direction: column;
                width: 100%;
            }
            
            .quick-actions-grid {
                grid-template-columns: 1fr;
            }
            
            .recent-item {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .recent-actions {
                margin-left: 0;
                margin-top: 1rem;
                width: 100%;
            }
        }
    </style>
    
    <script>
        // Enhanced Dashboard Functions
        function openQuickActions() {
            EnhancedUI.openModal('quickActionsModal');
        }
        
        function approveUser(userId) {
            if (confirm('Are you sure you want to approve this user?')) {
                EnhancedUI.showLoading('Approving user...');
                
                fetch('<?php echo APP_URL; ?>/api/admin/approve_user.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: JSON.stringify({
                        user_id: userId,
                        csrf_token: '<?php echo generate_csrf_token(); ?>'
                    })
                })
                .then(response => response.json())
                .then(data => {
                    EnhancedUI.hideLoading();
                    if (data.success) {
                        EnhancedUI.showNotification('User approved successfully!', 'success');
                        setTimeout(() => location.reload(), 1500);
                    } else {
                        EnhancedUI.showNotification(data.message || 'Approval failed', 'error');
                    }
                })
                .catch(error => {
                    EnhancedUI.hideLoading();
                    EnhancedUI.showNotification('An error occurred. Please try again.', 'error');
                });
            }
        }
        
        function viewUserDetails(userId) {
            window.open('<?php echo APP_URL; ?>/modules/admin/user_details.php?id=' + userId, '_blank', 'width=800,height=600');
        }
        
        function viewEnrollment(enrollmentId) {
            window.open('<?php echo APP_URL; ?>/modules/admin/enrollment_details.php?id=' + enrollmentId, '_blank', 'width=800,height=600');
        }
        
        function viewPayment(paymentId) {
            window.open('<?php echo APP_URL; ?>/modules/admin/payment_receipt.php?id=' + paymentId, '_blank', 'width=800,height=600');
        }
        
        function createNewUser() {
            EnhancedUI.closeModal('quickActionsModal');
            window.location.href = '<?php echo APP_URL; ?>/modules/admin/users.php?action=add';
        }
        
        function createNewCourse() {
            EnhancedUI.closeModal('quickActionsModal');
            window.location.href = '<?php echo APP_URL; ?>/modules/admin/courses.php?action=add';
        }
        
        function createNewSubject() {
            EnhancedUI.closeModal('quickActionsModal');
            window.location.href = '<?php echo APP_URL; ?>/modules/admin/subjects.php?action=add';
        }
        
        function viewReports() {
            EnhancedUI.closeModal('quickActionsModal');
            window.location.href = '<?php echo APP_URL; ?>/modules/admin/reports.php';
        }
        
        function systemBackup() {
            EnhancedUI.closeModal('quickActionsModal');
            EnhancedUI.showNotification('System backup feature coming soon!', 'info');
        }
        
        function showAcademicSettings() {
            EnhancedUI.showNotification('Academic settings feature coming soon!', 'info');
        }
        
        function viewFullActivity() {
            window.location.href = '<?php echo APP_URL; ?>/modules/admin/activity_log.php';
        }
        
        function exportDashboardData() {
            EnhancedUI.showNotification('Data export feature coming soon!', 'info');
        }
        
        // Auto-refresh dashboard every 30 seconds
        setInterval(() => {
            location.reload();
        }, 30000);
        
        // Initialize tooltips
        document.addEventListener('DOMContentLoaded', function() {
            const tooltipElements = document.querySelectorAll('[data-tooltip]');
            tooltipElements.forEach(element => {
                element.addEventListener('mouseenter', function(e) {
                    showTooltip(element, e);
                });
                
                element.addEventListener('mouseleave', () => {
                    hideTooltip();
                });
            });
        });
    </script>
    
    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
    <script src="<?php echo APP_URL; ?>/assets/js/enhanced.js"></script>
</body>
</html>
