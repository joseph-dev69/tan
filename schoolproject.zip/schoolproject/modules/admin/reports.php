<?php
/**
 * Admin Reports
 * School Information System
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';

require_role('admin');

$summary = [
    'users' => get_single_result("SELECT COUNT(*) AS count FROM users")['count'] ?? 0,
    'students' => get_single_result("SELECT COUNT(*) AS count FROM students")['count'] ?? 0,
    'teachers' => get_single_result("SELECT COUNT(*) AS count FROM teachers")['count'] ?? 0,
    'payments' => get_single_result("SELECT COUNT(*) AS count FROM payments")['count'] ?? 0,
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo">
                <a href="<?php echo APP_URL; ?>/modules/admin/dashboard.php">School Information System</a>
            </div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars(get_logged_in_user()['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <aside class="sidebar" id="sidebar">
            <ul class="sidebar-menu">
                <li><a href="<?php echo APP_URL; ?>/modules/admin/dashboard.php"><span class="icon">Dashboard</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/users.php"><span class="icon">Users</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/approvals.php"><span class="icon">Approvals</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/courses.php"><span class="icon">Courses</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/subjects.php"><span class="icon">Subjects</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/departments.php"><span class="icon">Departments</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/academic_years.php"><span class="icon">Academic Years</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/reports.php" class="active"><span class="icon">Reports</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/settings.php"><span class="icon">Settings</span></a></li>
            </ul>
        </aside>

        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Reports</h1>
                    <p>Quick system totals and report placeholders.</p>
                </div>

                <div class="row mb-4">
                    <div class="col-3">
                        <div class="card"><div class="card-body text-center"><h3 class="text-primary"><?php echo (int) $summary['users']; ?></h3><p>Total Users</p></div></div>
                    </div>
                    <div class="col-3">
                        <div class="card"><div class="card-body text-center"><h3 class="text-info"><?php echo (int) $summary['students']; ?></h3><p>Total Students</p></div></div>
                    </div>
                    <div class="col-3">
                        <div class="card"><div class="card-body text-center"><h3 class="text-success"><?php echo (int) $summary['teachers']; ?></h3><p>Total Teachers</p></div></div>
                    </div>
                    <div class="col-3">
                        <div class="card"><div class="card-body text-center"><h3 class="text-warning"><?php echo (int) $summary['payments']; ?></h3><p>Total Payments</p></div></div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h4>Available Reports</h4>
                    </div>
                    <div class="card-body">
                        <p>Use this page as the report landing page. It now exists so the sidebar no longer leads to a missing page.</p>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
