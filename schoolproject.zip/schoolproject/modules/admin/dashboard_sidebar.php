<?php
/**
 * Admin Dashboard with Enhanced Sidebar
 * School Information System - Professional Admin Interface
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';

// Require admin role
require_role('admin');

// Get dashboard statistics
$stats = [
    'total_users' => get_single_result("SELECT COUNT(*) as count FROM users")['count'],
    'pending_users' => get_single_result("SELECT COUNT(*) as count FROM users WHERE status = 'pending'")['count'],
    'total_students' => get_single_result("SELECT COUNT(*) as count FROM students")['count'],
    'total_teachers' => get_single_result("SELECT COUNT(*) as count FROM teachers")['count'],
    'active_enrollments' => get_single_result("SELECT COUNT(*) as count FROM enrollments WHERE status = 'enrolled'")['count'],
    'total_courses' => get_single_result("SELECT COUNT(*) as count FROM courses")['count'],
    'total_subjects' => get_single_result("SELECT COUNT(*) as count FROM subjects")['count'],
    'pending_payments' => get_single_result("SELECT COUNT(*) as count FROM billings WHERE status = 'pending'")['count'],
    'total_revenue' => get_single_result("SELECT COALESCE(SUM(amount), 0) as total FROM payments WHERE payment_date >= DATE_SUB(NOW(), INTERVAL 30 DAY)")['total'],
    'system_uptime' => '99.9%',
    'server_load' => '45%',
    'database_size' => '125 MB',
    'active_sessions' => get_single_result("SELECT COUNT(DISTINCT session_id) as count FROM audit_logs WHERE timestamp >= DATE_SUB(NOW(), INTERVAL 1 HOUR)")['count']
];

// Get recent activities
$recent_activities = get_multiple_results("
    SELECT action, table_name, record_id, timestamp, user_id
    FROM audit_logs
    WHERE timestamp >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
    ORDER BY timestamp DESC
    LIMIT 10
");

// Get system alerts
$system_alerts = [
    ['type' => 'warning', 'message' => 'Database backup scheduled in 2 hours', 'time' => '2 hours ago'],
    ['type' => 'info', 'message' => 'New software update available', 'time' => '5 hours ago'],
    ['type' => 'success', 'message' => 'System health check passed', 'time' => '1 day ago']
];

// Get flash messages
$flash_messages = get_flash_messages();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <meta name="user-data" content="<?php echo htmlspecialchars(json_encode(get_logged_in_user())); ?>">
    <title>Admin Dashboard - Enchong Dee University System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/enhanced.css">
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/admin_sidebar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Enhanced Admin Sidebar -->
    <aside class="admin-sidebar" id="adminSidebar">
        <!-- Sidebar Header -->
        <div class="sidebar-header">
            <a href="<?php echo APP_URL; ?>/modules/admin/dashboard.php" class="sidebar-logo">
                <div class="sidebar-logo-icon">🎓</div>
                <div class="sidebar-logo-text">
                    School System<br>
                    <small style="font-size: 0.8rem; opacity: 0.8;">Admin Panel</small>
                </div>
            </a>
            <button class="sidebar-toggle" aria-label="Toggle sidebar">◀</button>
        </div>

        <!-- User Profile -->
        <div class="sidebar-user">
            <div class="sidebar-user-profile">
                <div class="sidebar-user-avatar">👤</div>
                <div class="sidebar-user-info">
                    <div class="sidebar-user-name"><?php echo htmlspecialchars(get_logged_in_user()['first_name'] . ' ' . get_logged_in_user()['last_name']); ?></div>
                    <div class="sidebar-user-role">System Administrator</div>
                </div>
                <div class="sidebar-user-status"></div>
            </div>
        </div>

        <!-- Search -->
        <div class="sidebar-search">
            <div class="sidebar-search-box">
                <span class="sidebar-search-icon">🔍</span>
                <input type="text" class="sidebar-search-input" placeholder="Search menu...">
            </div>
        </div>

        <!-- Navigation Menu -->
        <nav class="sidebar-nav">
            <!-- Main Menu -->
            <div class="sidebar-section">
                <div class="sidebar-section-title">Main</div>
                <ul class="sidebar-menu">
                    <li class="sidebar-menu-item">
                        <a href="<?php echo APP_URL; ?>/modules/admin/dashboard.php" class="sidebar-menu-link active">
                            <span class="sidebar-menu-icon">📊</span>
                            <span class="sidebar-menu-text">Dashboard</span>
                        </a>
                    </li>
                    <li class="sidebar-menu-item" data-submenu>
                        <a href="#" class="sidebar-menu-link">
                            <span class="sidebar-menu-icon">👥</span>
                            <span class="sidebar-menu-text">User Management</span>
                            <span class="sidebar-menu-arrow">▼</span>
                        </a>
                        <div class="sidebar-submenu">
                            <div class="sidebar-submenu-item">
                                <a href="<?php echo APP_URL; ?>/modules/admin/users.php" class="sidebar-submenu-link">All Users</a>
                            </div>
                            <div class="sidebar-submenu-item">
                                <a href="<?php echo APP_URL; ?>/modules/admin/approvals.php" class="sidebar-submenu-link">Pending Approvals</a>
                            </div>
                            <div class="sidebar-submenu-item">
                                <a href="<?php echo APP_URL; ?>/modules/admin/roles.php" class="sidebar-submenu-link">Role Management</a>
                            </div>
                        </div>
                    </li>
                    <li class="sidebar-menu-item">
                        <a href="<?php echo APP_URL; ?>/modules/admin/approvals.php" class="sidebar-menu-link">
                            <span class="sidebar-menu-icon">✅</span>
                            <span class="sidebar-menu-text">Approvals</span>
                            <?php if ($stats['pending_users'] > 0): ?>
                                <span class="sidebar-menu-badge"><?php echo $stats['pending_users']; ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Academic Management -->
            <div class="sidebar-section">
                <div class="sidebar-section-title">Academic</div>
                <ul class="sidebar-menu">
                    <li class="sidebar-menu-item" data-submenu>
                        <a href="#" class="sidebar-menu-link">
                            <span class="sidebar-menu-icon">📚</span>
                            <span class="sidebar-menu-text">Academic Setup</span>
                            <span class="sidebar-menu-arrow">▼</span>
                        </a>
                        <div class="sidebar-submenu">
                            <div class="sidebar-submenu-item">
                                <a href="<?php echo APP_URL; ?>/modules/admin/departments.php" class="sidebar-submenu-link">Departments</a>
                            </div>
                            <div class="sidebar-submenu-item">
                                <a href="<?php echo APP_URL; ?>/modules/admin/courses.php" class="sidebar-submenu-link">Courses</a>
                            </div>
                            <div class="sidebar-submenu-item">
                                <a href="<?php echo APP_URL; ?>/modules/admin/subjects.php" class="sidebar-submenu-link">Subjects</a>
                            </div>
                            <div class="sidebar-submenu-item">
                                <a href="<?php echo APP_URL; ?>/modules/admin/academic_years.php" class="sidebar-submenu-link">Academic Years</a>
                            </div>
                        </div>
                    </li>
                    <li class="sidebar-menu-item" data-submenu>
                        <a href="#" class="sidebar-menu-link">
                            <span class="sidebar-menu-icon">📝</span>
                            <span class="sidebar-menu-text">Enrollment</span>
                            <span class="sidebar-menu-arrow">▼</span>
                        </a>
                        <div class="sidebar-submenu">
                            <div class="sidebar-submenu-item">
                                <a href="<?php echo APP_URL; ?>/modules/admin/enrollments.php" class="sidebar-submenu-link">All Enrollments</a>
                            </div>
                            <div class="sidebar-submenu-item">
                                <a href="<?php echo APP_URL; ?>/modules/admin/subject_offerings.php" class="sidebar-submenu-link">Subject Offerings</a>
                            </div>
                            <div class="sidebar-submenu-item">
                                <a href="<?php echo APP_URL; ?>/modules/admin/schedules.php" class="sidebar-submenu-link">Class Schedules</a>
                            </div>
                        </div>
                    </li>
                    <li class="sidebar-menu-item" data-submenu>
                        <a href="#" class="sidebar-menu-link">
                            <span class="sidebar-menu-icon">📊</span>
                            <span class="sidebar-menu-text">Grades</span>
                            <span class="sidebar-menu-arrow">▼</span>
                        </a>
                        <div class="sidebar-submenu">
                            <div class="sidebar-submenu-item">
                                <a href="<?php echo APP_URL; ?>/modules/admin/grades.php" class="sidebar-submenu-link">Grade Management</a>
                            </div>
                            <div class="sidebar-submenu-item">
                                <a href="<?php echo APP_URL; ?>/modules/admin/transcripts.php" class="sidebar-submenu-link">Transcripts</a>
                            </div>
                            <div class="sidebar-submenu-item">
                                <a href="<?php echo APP_URL; ?>/modules/admin/academic_records.php" class="sidebar-submenu-link">Academic Records</a>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>

            <!-- Financial Management -->
            <div class="sidebar-section">
                <div class="sidebar-section-title">Financial</div>
                <ul class="sidebar-menu">
                    <li class="sidebar-menu-item" data-submenu>
                        <a href="#" class="sidebar-menu-link">
                            <span class="sidebar-menu-icon">💰</span>
                            <span class="sidebar-menu-text">Billing</span>
                            <span class="sidebar-menu-arrow">▼</span>
                        </a>
                        <div class="sidebar-submenu">
                            <div class="sidebar-submenu-item">
                                <a href="<?php echo APP_URL; ?>/modules/admin/billings.php" class="sidebar-submenu-link">Student Billings</a>
                            </div>
                            <div class="sidebar-submenu-item">
                                <a href="<?php echo APP_URL; ?>/modules/admin/fee_schedules.php" class="sidebar-submenu-link">Fee Schedules</a>
                            </div>
                            <div class="sidebar-submenu-item">
                                <a href="<?php echo APP_URL; ?>/modules/admin/payments.php" class="sidebar-submenu-link">Payment Records</a>
                            </div>
                        </div>
                    </li>
                    <li class="sidebar-menu-item">
                        <a href="<?php echo APP_URL; ?>/modules/admin/financial_reports.php" class="sidebar-menu-link">
                            <span class="sidebar-menu-icon">📈</span>
                            <span class="sidebar-menu-text">Financial Reports</span>
                        </a>
                    </li>
                </ul>
            </div>

            <!-- System Management -->
            <div class="sidebar-section">
                <div class="sidebar-section-title">System</div>
                <ul class="sidebar-menu">
                    <li class="sidebar-menu-item" data-submenu>
                        <a href="#" class="sidebar-menu-link">
                            <span class="sidebar-menu-icon">📋</span>
                            <span class="sidebar-menu-text">Reports</span>
                            <span class="sidebar-menu-arrow">▼</span>
                        </a>
                        <div class="sidebar-submenu">
                            <div class="sidebar-submenu-item">
                                <a href="<?php echo APP_URL; ?>/modules/admin/reports.php" class="sidebar-submenu-link">System Reports</a>
                            </div>
                            <div class="sidebar-submenu-item">
                                <a href="<?php echo APP_URL; ?>/modules/admin/analytics.php" class="sidebar-submenu-link">Analytics</a>
                            </div>
                            <div class="sidebar-submenu-item">
                                <a href="<?php echo APP_URL; ?>/modules/admin/exports.php" class="sidebar-submenu-link">Data Export</a>
                            </div>
                        </div>
                    </li>
                    <li class="sidebar-menu-item" data-submenu>
                        <a href="#" class="sidebar-menu-link">
                            <span class="sidebar-menu-icon">⚙️</span>
                            <span class="sidebar-menu-text">Settings</span>
                            <span class="sidebar-menu-arrow">▼</span>
                        </a>
                        <div class="sidebar-submenu">
                            <div class="sidebar-submenu-item">
                                <a href="<?php echo APP_URL; ?>/modules/admin/settings.php" class="sidebar-submenu-link">System Settings</a>
                            </div>
                            <div class="sidebar-submenu-item">
                                <a href="<?php echo APP_URL; ?>/modules/admin/email_settings.php" class="sidebar-submenu-link">Email Settings</a>
                            </div>
                            <div class="sidebar-submenu-item">
                                <a href="<?php echo APP_URL; ?>/modules/admin/security_settings.php" class="sidebar-submenu-link">Security</a>
                            </div>
                        </div>
                    </li>
                    <li class="sidebar-menu-item">
                        <a href="<?php echo APP_URL; ?>/modules/admin/logs.php" class="sidebar-menu-link">
                            <span class="sidebar-menu-icon">📝</span>
                            <span class="sidebar-menu-text">System Logs</span>
                        </a>
                    </li>
                    <li class="sidebar-menu-item">
                        <a href="<?php echo APP_URL; ?>/modules/admin/backup.php" class="sidebar-menu-link">
                            <span class="sidebar-menu-icon">💾</span>
                            <span class="sidebar-menu-text">Backup & Restore</span>
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <!-- Quick Actions -->
        <div class="sidebar-quick-actions">
            <button class="sidebar-quick-action-btn" data-action="add-user">
                <span class="btn-icon">➕</span> Add User
            </button>
            <button class="sidebar-quick-action-btn" data-action="backup">
                <span class="btn-icon">💾</span> Quick Backup
            </button>
            <button class="sidebar-quick-action-btn" data-action="reports">
                <span class="btn-icon">📊</span> Generate Report
            </button>
        </div>

        <!-- System Status -->
        <div class="sidebar-system-status">
            <div class="sidebar-status-item">
                <span class="sidebar-status-label">System Status</span>
                <span class="sidebar-status-value">
                    <span class="sidebar-status-indicator status-online"></span>
                    Online
                </span>
            </div>
            <div class="sidebar-status-item">
                <span class="sidebar-status-label">Server Load</span>
                <span class="sidebar-status-value"><?php echo $stats['server_load']; ?></span>
            </div>
            <div class="sidebar-status-item">
                <span class="sidebar-status-label">Active Sessions</span>
                <span class="sidebar-status-value"><?php echo $stats['active_sessions']; ?></span>
            </div>
        </div>

        <!-- Footer Menu -->
        <div class="sidebar-footer">
            <ul class="sidebar-footer-menu">
                <li class="sidebar-footer-item">
                    <a href="#" class="sidebar-footer-link">
                        <span class="sidebar-footer-icon">📖</span>
                        <span>Help</span>
                    </a>
                </li>
                <li class="sidebar-footer-item">
                    <a href="#" class="sidebar-footer-link">
                        <span class="sidebar-footer-icon">💬</span>
                        <span>Support</span>
                    </a>
                </li>
                <li class="sidebar-footer-item">
                    <a href="<?php echo APP_URL; ?>/modules/auth/logout.php" class="sidebar-footer-link">
                        <span class="sidebar-footer-icon">🚪</span>
                        <span>Logout</span>
                    </a>
                </li>
            </ul>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="main-content" id="main-content">
        <div class="content-wrapper">
            <!-- Page Header -->
            <div class="page-header">
                <h1>Admin Dashboard</h1>
                <p>Welcome back, <?php echo htmlspecialchars(get_logged_in_user()['first_name']); ?>! Here's your system overview.</p>
                <div class="page-actions">
                    <button class="btn btn-primary" onclick="adminSidebar.toggle()">
                        <span class="btn-icon">☰</span>
                        Toggle Sidebar
                    </button>
                    <button class="btn btn-secondary" onclick="refreshDashboard()">
                        <span class="btn-icon">🔄</span>
                        Refresh
                    </button>
                </div>
            </div>

            <?php if ($flash_messages): ?>
                <div class="flash-messages mb-3">
                    <?php foreach ($flash_messages as $message): ?>
                        <div class="alert alert-<?php echo $message['type']; ?> fade-in">
                            <div class="alert-icon">
                                <?php
                                $icons = ['success' => '✓', 'error' => '✕', 'warning' => '⚠', 'info' => 'ℹ'];
                                echo $icons[$message['type']] ?? 'ℹ';
                                ?>
                            </div>
                            <div class="alert-content">
                                <?php echo htmlspecialchars($message['message']); ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <!-- System Alerts -->
            <div class="system-alerts mb-4">
                <?php foreach ($system_alerts as $alert): ?>
                    <div class="alert alert-<?php echo $alert['type']; ?> alert-dismissible">
                        <div class="alert-content">
                            <strong><?php echo ucfirst($alert['type']); ?>:</strong> <?php echo htmlspecialchars($alert['message']); ?>
                            <small class="alert-time"><?php echo $alert['time']; ?></small>
                        </div>
                        <button type="button" class="alert-close">&times;</button>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Statistics Grid -->
            <div class="stats-grid mb-4">
                <div class="stat-card stat-primary">
                    <div class="stat-icon">👥</div>
                    <div class="stat-content">
                        <div class="stat-number"><?php echo number_format($stats['total_users']); ?></div>
                        <div class="stat-label">Total Users</div>
                        <div class="stat-change">
                            <span class="change-indicator change-positive">+12%</span>
                            <span class="change-text">from last month</span>
                        </div>
                    </div>
                </div>
                
                <div class="stat-card stat-warning">
                    <div class="stat-icon">⏳</div>
                    <div class="stat-content">
                        <div class="stat-number"><?php echo number_format($stats['pending_users']); ?></div>
                        <div class="stat-label">Pending Approvals</div>
                        <div class="stat-change">
                            <span class="change-indicator change-neutral">0%</span>
                            <span class="change-text">from last week</span>
                        </div>
                    </div>
                </div>
                
                <div class="stat-card stat-info">
                    <div class="stat-icon">🎓</div>
                    <div class="stat-content">
                        <div class="stat-number"><?php echo number_format($stats['total_students']); ?></div>
                        <div class="stat-label">Total Students</div>
                        <div class="stat-change">
                            <span class="change-indicator change-positive">+8%</span>
                            <span class="change-text">from last month</span>
                        </div>
                    </div>
                </div>
                
                <div class="stat-card stat-success">
                    <div class="stat-icon">👨‍🏫</div>
                    <div class="stat-content">
                        <div class="stat-number"><?php echo number_format($stats['total_teachers']); ?></div>
                        <div class="stat-label">Total Teachers</div>
                        <div class="stat-change">
                            <span class="change-indicator change-positive">+5%</span>
                            <span class="change-text">from last month</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="stats-grid mb-4">
                <div class="stat-card stat-secondary">
                    <div class="stat-icon">📝</div>
                    <div class="stat-content">
                        <div class="stat-number"><?php echo number_format($stats['active_enrollments']); ?></div>
                        <div class="stat-label">Active Enrollments</div>
                        <div class="stat-change">
                            <span class="change-indicator change-positive">+15%</span>
                            <span class="change-text">from last month</span>
                        </div>
                    </div>
                </div>
                
                <div class="stat-card stat-purple">
                    <div class="stat-icon">📚</div>
                    <div class="stat-content">
                        <div class="stat-number"><?php echo number_format($stats['total_courses']); ?></div>
                        <div class="stat-label">Total Courses</div>
                        <div class="stat-change">
                            <span class="change-indicator change-neutral">0%</span>
                            <span class="change-text">no change</span>
                        </div>
                    </div>
                </div>
                
                <div class="stat-card stat-info">
                    <div class="stat-icon">📖</div>
                    <div class="stat-content">
                        <div class="stat-number"><?php echo number_format($stats['total_subjects']); ?></div>
                        <div class="stat-label">Total Subjects</div>
                        <div class="stat-change">
                            <span class="change-indicator change-positive">+3%</span>
                            <span class="change-text">from last month</span>
                        </div>
                    </div>
                </div>
                
                <div class="stat-card stat-warning">
                    <div class="stat-icon">💰</div>
                    <div class="stat-content">
                        <div class="stat-number"><?php echo format_currency($stats['total_revenue']); ?></div>
                        <div class="stat-label">Revenue (30 days)</div>
                        <div class="stat-change">
                            <span class="change-indicator change-positive">+22%</span>
                            <span class="change-text">from last month</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Activity -->
            <div class="card">
                <div class="card-header">
                    <h4>Recent System Activity</h4>
                    <div class="card-actions">
                        <a href="<?php echo APP_URL; ?>/modules/admin/logs.php" class="btn btn-sm btn-primary">View All</a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="activity-list">
                        <?php if ($recent_activities): ?>
                            <?php foreach ($recent_activities as $activity): ?>
                                <div class="activity-item">
                                    <div class="activity-icon">
                                        <?php
                                        $icons = [
                                            'USER_LOGIN' => '🔐',
                                            'USER_LOGOUT' => '🚪',
                                            'USER_REGISTER' => '👥',
                                            'USER_APPROVED' => '✅',
                                            'USER_REJECTED' => '❌',
                                            'STUDENT_ENROLLMENT' => '📝',
                                            'GRADE_SUBMITTED' => '📊',
                                            'PAYMENT_PROCESSED' => '💰'
                                        ];
                                        echo $icons[$activity['action']] ?? '📄';
                                        ?>
                                    </div>
                                    <div class="activity-content">
                                        <div class="activity-title"><?php echo htmlspecialchars($activity['action']); ?></div>
                                        <div class="activity-meta">
                                            <span class="activity-time"><?php echo format_date($activity['timestamp'], 'M d, Y H:i'); ?></span>
                                            <?php if ($activity['table_name']): ?>
                                                <span class="activity-table">Table: <?php echo htmlspecialchars($activity['table_name']); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="empty-state">
                                <div class="empty-icon">📊</div>
                                <div class="empty-title">No Recent Activity</div>
                                <div class="empty-description">No system activity recorded in the last 24 hours</div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <style>
        /* Statistics Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: white;
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 1.5rem;
            display: flex;
            align-items: center;
            gap: 1rem;
            transition: var(--transition);
            box-shadow: var(--shadow);
        }
        
        .stat-card:hover {
            box-shadow: var(--shadow-hover);
            transform: translateY(-2px);
        }
        
        .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: var(--border-radius);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            flex-shrink: 0;
        }
        
        .stat-primary .stat-icon { background: #dbeafe; color: #1e40af; }
        .stat-success .stat-icon { background: #d1fae5; color: #065f46; }
        .stat-warning .stat-icon { background: #fed7aa; color: #92400e; }
        .stat-info .stat-icon { background: #e0f2fe; color: #0c4a6e; }
        .stat-secondary .stat-icon { background: #f3f4f6; color: #374151; }
        .stat-purple .stat-icon { background: #ede9fe; color: #5b21b6; }
        
        .stat-content {
            flex: 1;
            min-width: 0;
        }
        
        .stat-number {
            font-size: 1.875rem;
            font-weight: 700;
            color: var(--primary-color);
            line-height: 1;
            margin-bottom: 0.25rem;
        }
        
        .stat-label {
            font-size: 0.875rem;
            color: var(--gray-color);
            font-weight: 500;
            margin-bottom: 0.5rem;
        }
        
        .stat-change {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.75rem;
        }
        
        .change-indicator {
            padding: 0.125rem 0.375rem;
            border-radius: 12px;
            font-weight: 600;
        }
        
        .change-positive {
            background: #d1fae5;
            color: #065f46;
        }
        
        .change-neutral {
            background: #f3f4f6;
            color: #374151;
        }
        
        .change-negative {
            background: #fee2e2;
            color: #991b1b;
        }
        
        .change-text {
            color: var(--gray-color);
        }
        
        /* Activity List */
        .activity-list {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }
        
        .activity-item {
            display: flex;
            align-items: flex-start;
            gap: 0.75rem;
            padding: 1rem;
            background: var(--light-color);
            border-radius: var(--border-radius);
            transition: var(--transition);
        }
        
        .activity-item:hover {
            background: #f1f5f9;
        }
        
        .activity-icon {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1rem;
            flex-shrink: 0;
            border: 1px solid var(--border-color);
        }
        
        .activity-content {
            flex: 1;
            min-width: 0;
        }
        
        .activity-title {
            font-weight: 600;
            color: var(--primary-color);
            margin-bottom: 0.25rem;
            font-size: 0.9rem;
        }
        
        .activity-meta {
            display: flex;
            align-items: center;
            gap: 1rem;
            font-size: 0.8rem;
            color: var(--gray-color);
        }
        
        .activity-time {
            display: flex;
            align-items: center;
            gap: 0.25rem;
        }
        
        .activity-table {
            background: white;
            padding: 0.125rem 0.5rem;
            border-radius: 12px;
            font-size: 0.75rem;
            border: 1px solid var(--border-color);
        }
        
        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 3rem 1rem;
        }
        
        .empty-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
            opacity: 0.5;
        }
        
        .empty-title {
            font-weight: 600;
            color: var(--primary-color);
            margin-bottom: 0.5rem;
        }
        
        .empty-description {
            color: var(--gray-color);
            font-size: 0.9rem;
        }
    </style>

    <script>
        // Enhanced dashboard functionality
        function refreshDashboard() {
            location.reload();
        }
        
        // Initialize sidebar when DOM is ready
        document.addEventListener('DOMContentLoaded', function() {
            // Auto-refresh dashboard every 30 seconds
            setInterval(() => {
                if (document.visibilityState === 'visible') {
                    refreshDashboard();
                }
            }, 30000);
            
            // Setup alert dismiss functionality
            document.querySelectorAll('.alert-close').forEach(btn => {
                btn.addEventListener('click', function() {
                    const alert = this.closest('.alert');
                    alert.style.opacity = '0';
                    setTimeout(() => alert.remove(), 300);
                });
            });
            
            // Auto-dismiss alerts after 10 seconds
            document.querySelectorAll('.alert').forEach(alert => {
                setTimeout(() => {
                    if (alert.parentElement) {
                        alert.style.opacity = '0';
                        setTimeout(() => alert.remove(), 300);
                    }
                }, 10000);
            });
        });
    </script>
    
    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
    <script src="<?php echo APP_URL; ?>/assets/js/enhanced.js"></script>
    <script src="<?php echo APP_URL; ?>/assets/js/admin_sidebar.js"></script>
</body>
</html>
