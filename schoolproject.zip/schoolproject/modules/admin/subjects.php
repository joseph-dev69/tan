<?php
/**
 * Admin Subjects Page
 * School Information System
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';

require_role('admin');

$subject_rows = [];
$courses = [];
$error_message = '';
$selected_course = trim((string)($_GET['course'] ?? ''));

try {
    // Load ALL courses for filter
    $courses = get_multiple_results("
        SELECT course_code, course_name
        FROM courses
        ORDER BY course_code ASC
    ");

    $where_sql = '';
    $params = [];

    if ($selected_course !== '') {
        $where_sql = 'WHERE c.course_code = ?';
        $params[] = $selected_course;
    }

    $subject_rows = get_multiple_results("
        SELECT s.subject_code,
               s.subject_name,
               c.course_code,
               c.course_name,
               s.units,
               s.year_level,
               s.semester_type
        FROM subjects s
        LEFT JOIN courses c ON c.course_id = s.course_id
        $where_sql
        ORDER BY c.course_code ASC, s.year_level ASC, s.semester_type ASC, s.subject_code ASC
    ", $params);

} catch (Exception $e) {
    $error_message = 'Unable to load subject list right now.';
    error_log('Admin subjects page error: ' . $e->getMessage());
}

$course_counts = [];
foreach ($subject_rows as $row) {
    $code = $row['course_code'] ?? 'UNKNOWN';
    if (!isset($course_counts[$code])) {
        $course_counts[$code] = 0;
    }
    $course_counts[$code]++;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <meta name="user-data" content="<?php echo htmlspecialchars(json_encode(get_logged_in_user())); ?>">
    <title>Subjects - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo">
                <a href="<?php echo APP_URL; ?>/modules/admin/dashboard.php">School Information System</a>
            </div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars(get_logged_in_user()['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <aside class="sidebar" id="sidebar">
            <ul class="sidebar-menu">
                <li><a href="<?php echo APP_URL; ?>/modules/admin/dashboard.php"><span class="icon">Dashboard</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/users.php"><span class="icon">Users</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/approvals.php"><span class="icon">Approvals</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/courses.php"><span class="icon">Courses</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/subjects.php" class="active"><span class="icon">Subjects</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/departments.php"><span class="icon">Departments</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/academic_years.php"><span class="icon">Academic Years</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/reports.php"><span class="icon">Reports</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/settings.php"><span class="icon">Settings</span></a></li>
            </ul>
        </aside>

        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Subjects</h1>
                    <p>Showing All Subject</p>
                </div>

                <?php if ($error_message): ?>
                    <div class="alert alert-danger mb-3"><?php echo htmlspecialchars($error_message); ?></div>
                <?php endif; ?>

                <div class="row mb-4">
    <div class="col-4">
        <div class="card subject-stat-card">
            <div class="card-body text-center">
                <p class="subject-stat-label">Total Subjects</p>
                <h3 class="text-primary"><?php echo count($subject_rows); ?></h3>
            </div>
        </div>
    </div>

    <?php foreach ($course_counts as $course_code => $count): ?>
        <div class="col-4">
            <div class="card subject-stat-card">
                <div class="card-body text-center">
                    <p class="subject-stat-label">
                        <?php echo htmlspecialchars($course_code); ?> Subjects
                    </p>
                    <h3 class="text-success"><?php echo (int)$count; ?></h3>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>
                <div class="card mb-4">
                    <div class="card-header">
                        <h4>Filter Subjects</h4>
                    </div>
                    <div class="card-body">
                        <form method="GET" class="row">
                            <div class="col-4">
                                <label for="course">Course</label>
                                <select id="course" name="course">
    <option value="">All Courses</option>

    <?php foreach ($courses as $course): ?>
        <option value="<?php echo htmlspecialchars($course['course_code']); ?>"
            <?php echo $selected_course === $course['course_code'] ? 'selected' : ''; ?>>
            <?php echo htmlspecialchars($course['course_code'] . ' - ' . $course['course_name']); ?>
        </option>
    <?php endforeach; ?>
</select>
                            </div>
                            <div class="col-4" style="display:flex;align-items:flex-end;">
                                <button type="submit" class="btn btn-primary">Apply Filter</button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h4>Subjects</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($subject_rows): ?>
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Code</th>
                                            <th>Title</th>
                                            <th>Course</th>
                                            <th>Units</th>
                                            <th>Year Level</th>
                                            <th>Semester</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($subject_rows as $row): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars((string)$row['subject_code']); ?></td>
                                                <td><?php echo htmlspecialchars((string)$row['subject_name']); ?></td>
                                                <td><?php echo htmlspecialchars((string)$row['course_code']); ?></td>
                                                <td><?php echo htmlspecialchars((string)$row['units']); ?></td>
                                                <td><?php echo htmlspecialchars((string)$row['year_level']); ?></td>
                                                <td><?php echo htmlspecialchars(ucfirst((string)$row['semester_type'])); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">No subject data found.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <style>
        .subject-stat-card {
            min-height: 130px;
        }

        .subject-stat-label {
            color: var(--gray-color);
            font-size: .9rem;
            text-transform: uppercase;
            letter-spacing: .04em;
            margin-bottom: .5rem;
        }
    </style>

    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
