<?php
/**
 * Admin Users Page
 * School Information System
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';

require_role('admin');

$current_user = get_logged_in_user();
$search = trim($_GET['search'] ?? '');
$role_filter = trim($_GET['role'] ?? '');
$status_filter = trim($_GET['status'] ?? '');

$filters = [];
$params = [];

if ($search !== '') {
    $filters[] = "(u.username LIKE ? OR u.email LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ?)";
    $like = '%' . $search . '%';
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
}

if ($role_filter !== '') {
    $filters[] = "r.role_name = ?";
    $params[] = $role_filter;
}

if ($status_filter !== '') {
    $filters[] = "u.status = ?";
    $params[] = $status_filter;
}

$where_sql = $filters ? ('WHERE ' . implode(' AND ', $filters)) : '';

$users = get_multiple_results("
    SELECT
        u.user_id,
        u.username,
        u.email,
        u.first_name,
        u.last_name,
        u.middle_name,
        u.status,
        u.created_at,
        u.updated_at,
        u.last_login,
        r.role_name,
        s.student_number,
        c.course_code,
        c.course_name,
        t.employee_number AS teacher_employee_number,
        dt.department_code AS teacher_department_code,
        dt.department_name AS teacher_department_name,
        ro.employee_number AS records_employee_number,
        fo.employee_number AS finance_employee_number,
        ca.employee_number AS cashier_employee_number
    FROM users u
    JOIN roles r ON u.role_id = r.role_id
    LEFT JOIN students s ON u.user_id = s.user_id
    LEFT JOIN courses c ON s.course_id = c.course_id
    LEFT JOIN teachers t ON u.user_id = t.user_id
    LEFT JOIN departments dt ON t.department_id = dt.department_id
    LEFT JOIN records_officers ro ON u.user_id = ro.user_id
    LEFT JOIN finance_officers fo ON u.user_id = fo.user_id
    LEFT JOIN cashiers ca ON u.user_id = ca.user_id
    $where_sql
    ORDER BY u.created_at DESC, u.last_name ASC, u.first_name ASC
", $params);

$roles = get_multiple_results("SELECT role_name FROM roles ORDER BY role_name ASC");
$status_options = ['pending', 'approved', 'rejected', 'inactive'];
$flash_messages = get_flash_messages();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <meta name="user-data" content="<?php echo htmlspecialchars(json_encode($current_user)); ?>">
    <title>Users - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo">
                <a href="<?php echo APP_URL; ?>/modules/admin/dashboard.php">Enchong Dee University Information System</a>
            </div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <aside class="sidebar" id="sidebar">
            <ul class="sidebar-menu">
                <li><a href="<?php echo APP_URL; ?>/modules/admin/dashboard.php"><span class="icon">Dashboard</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/users.php" class="active"><span class="icon">Users</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/approvals.php"><span class="icon">Approvals</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/courses.php"><span class="icon">Courses</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/subjects.php"><span class="icon">Subjects</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/departments.php"><span class="icon">Departments</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/academic_years.php"><span class="icon">Academic Years</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/reports.php"><span class="icon">Reports</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/settings.php"><span class="icon">Settings</span></a></li>
            </ul>
        </aside>

        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Users</h1>
                    <p>View registered users and their profile information.</p>
                </div>

                <?php if ($flash_messages): ?>
                    <div class="flash-messages mb-3">
                        <?php foreach ($flash_messages as $message): ?>
                            <div class="alert alert-<?php echo $message['type']; ?>">
                                <?php echo htmlspecialchars($message['message']); ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <div class="card mb-4">
                    <div class="card-header">
                        <h4>Filter Users</h4>
                    </div>
                    <div class="card-body">
                        <form method="GET" action="" class="form-row">
                            <div class="form-group">
                                <label for="search" class="form-label">Search</label>
                                <input type="text" id="search" name="search" class="form-control" value="<?php echo htmlspecialchars($search); ?>" placeholder="Name, username, or email">
                            </div>
                            <div class="form-group">
                                <label for="role" class="form-label">Role</label>
                                <select id="role" name="role" class="form-control">
                                    <option value="">All Roles</option>
                                    <?php foreach ($roles as $role): ?>
                                        <option value="<?php echo htmlspecialchars($role['role_name']); ?>" <?php echo $role_filter === $role['role_name'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($role['role_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="status" class="form-label">Status</label>
                                <select id="status" name="status" class="form-control">
                                    <option value="">All Status</option>
                                    <?php foreach ($status_options as $status): ?>
                                        <option value="<?php echo htmlspecialchars($status); ?>" <?php echo $status_filter === $status ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars(ucfirst($status)); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group" style="align-self: end;">
                                <button type="submit" class="btn btn-primary">Apply Filter</button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h4>User List</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($users): ?>
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Username / Email</th>
                                            <th>Role</th>
                                            <th>Status</th>
                                            <th>Related Info</th>
                                            <th>Registered</th>
                                            <th>Last Login</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($users as $user): ?>
                                            <tr>
                                                <td>
                                                    <?php echo htmlspecialchars(format_full_name($user['first_name'], $user['last_name'], $user['middle_name'] ?? '')); ?><br>
                                                    <small class="text-muted">User ID: <?php echo (int)$user['user_id']; ?></small>
                                                </td>
                                                <td>
                                                    <?php echo htmlspecialchars($user['username']); ?><br>
                                                    <small class="text-muted"><?php echo htmlspecialchars($user['email']); ?></small>
                                                </td>
                                                <td>
                                                    <span class="badge badge-info"><?php echo htmlspecialchars($user['role_name']); ?></span>
                                                </td>
                                                <td>
                                                    <span class="badge badge-<?php echo $user['status'] === 'approved' ? 'success' : ($user['status'] === 'pending' ? 'warning' : 'danger'); ?>">
                                                        <?php echo htmlspecialchars(ucfirst($user['status'])); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <?php if ($user['role_name'] === 'student'): ?>
                                                        <?php echo htmlspecialchars($user['student_number'] ?: 'No student number'); ?><br>
                                                        <small class="text-muted"><?php echo htmlspecialchars(trim(($user['course_code'] ?? '') . ' ' . (($user['course_name'] ?? '') ? '- ' . $user['course_name'] : ''))); ?></small>
                                                    <?php elseif ($user['role_name'] === 'teacher'): ?>
                                                        <?php echo htmlspecialchars($user['teacher_employee_number'] ?: 'No employee number'); ?><br>
                                                        <small class="text-muted"><?php echo htmlspecialchars(trim(($user['teacher_department_code'] ?? '') . ' ' . (($user['teacher_department_name'] ?? '') ? '- ' . $user['teacher_department_name'] : ''))); ?></small>
                                                    <?php elseif ($user['role_name'] === 'records_officer'): ?>
                                                        <?php echo htmlspecialchars($user['records_employee_number'] ?: 'No employee number'); ?>
                                                    <?php elseif ($user['role_name'] === 'finance_officer'): ?>
                                                        <?php echo htmlspecialchars($user['finance_employee_number'] ?: 'No employee number'); ?>
                                                    <?php elseif ($user['role_name'] === 'cashier'): ?>
                                                        <?php echo htmlspecialchars($user['cashier_employee_number'] ?: 'No employee number'); ?>
                                                    <?php else: ?>
                                                        <span class="text-muted">No additional info</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo format_date($user['created_at'], 'M d, Y H:i'); ?></td>
                                                <td>
                                                    <?php if ($user['last_login']): ?>
                                                        <?php echo format_date($user['last_login'], 'M d, Y H:i'); ?>
                                                    <?php else: ?>
                                                        <span class="text-muted">Never logged in</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">No users found for the selected filters.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
