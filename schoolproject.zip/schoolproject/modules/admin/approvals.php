<?php
/**
 * Admin Approvals Page
 * School Information System
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';

// Require admin role
require_role('admin');

// Handle approval/rejection actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    $action = $_POST['action'] ?? '';
    $user_id = (int)($_POST['user_id'] ?? 0);
    $reason = sanitize_input($_POST['reason'] ?? '');
    
    if (!verify_csrf_token($csrf_token)) {
        flash_message('error', 'Invalid request. Please try again.');
    } elseif ($user_id <= 0 || !in_array($action, ['approve', 'reject'])) {
        flash_message('error', 'Invalid request parameters.');
    } else {
        $conn = null;
        try {
            $conn = (new Database())->getConnection();

            // Use the same connection for all work (avoid mixing with get_single_result / second PDO).
            // A second connection with persistent PDO can implicitly end the first transaction.
            $user_stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ? LIMIT 1");
            $user_stmt->execute([$user_id]);
            $user = $user_stmt->fetch(PDO::FETCH_ASSOC);

            if (!$user) {
                flash_message('error', 'User not found.');
            } else {
                $conn->beginTransaction();
                $role_name = '';

                if ($action === 'approve') {
                    $stmt = $conn->prepare("UPDATE users SET status = 'approved', updated_at = NOW() WHERE user_id = ?");
                    $stmt->execute([$user_id]);

                    $role_stmt = $conn->prepare("SELECT role_name FROM roles WHERE role_id = ? LIMIT 1");
                    $role_stmt->execute([(int)$user['role_id']]);
                    $role_row = $role_stmt->fetch(PDO::FETCH_ASSOC);
                    $role_name = (string)($role_row['role_name'] ?? '');

                    switch ($role_name) {
                        case 'student':
                            $student_stmt = $conn->prepare("SELECT * FROM students WHERE user_id = ? LIMIT 1");
                            $student_stmt->execute([$user_id]);
                            $student = $student_stmt->fetch(PDO::FETCH_ASSOC);
                            if (!$student) {
                                $course_id = (int)($_POST['course_id'] ?? 0);
                                if ($course_id <= 0) {
                                    throw new RuntimeException('Course is required to approve a student.');
                                }
                                $student_number = generate_student_number();
                                $stmt = $conn->prepare("
                                    INSERT INTO students (user_id, student_number, course_id, year_level, admission_date)
                                    VALUES (?, ?, ?, 1, ?)
                                ");
                                $stmt->execute([$user_id, $student_number, $course_id, date(DATE_FORMAT)]);
                            }
                            break;

                        case 'teacher':
                            $teacher_stmt = $conn->prepare("SELECT * FROM teachers WHERE user_id = ? LIMIT 1");
                            $teacher_stmt->execute([$user_id]);
                            $teacher = $teacher_stmt->fetch(PDO::FETCH_ASSOC);
                            if (!$teacher) {
                                $department_id = (int)($_POST['department_id'] ?? 0);
                                $employee_number = 'EMP-' . date('Y') . '-' . str_pad((string)$user_id, 5, '0', STR_PAD_LEFT);

                                if ($department_id > 0) {
                                    $stmt = $conn->prepare("
                                        INSERT INTO teachers (user_id, employee_number, department_id, hire_date)
                                        VALUES (?, ?, ?, ?)
                                    ");
                                    $stmt->execute([$user_id, $employee_number, $department_id, date(DATE_FORMAT)]);
                                }
                            }
                            break;

                        case 'records_officer':
                            $ro_stmt = $conn->prepare("SELECT * FROM records_officers WHERE user_id = ? LIMIT 1");
                            $ro_stmt->execute([$user_id]);
                            $records_officer = $ro_stmt->fetch(PDO::FETCH_ASSOC);
                            if (!$records_officer) {
                                $employee_number = 'REC-' . date('Y') . '-' . str_pad((string)$user_id, 5, '0', STR_PAD_LEFT);
                                $stmt = $conn->prepare("
                                    INSERT INTO records_officers (user_id, employee_number)
                                    VALUES (?, ?)
                                ");
                                $stmt->execute([$user_id, $employee_number]);
                            }
                            break;

                        case 'finance_officer':
                            $fo_stmt = $conn->prepare("SELECT * FROM finance_officers WHERE user_id = ? LIMIT 1");
                            $fo_stmt->execute([$user_id]);
                            $finance_officer = $fo_stmt->fetch(PDO::FETCH_ASSOC);
                            if (!$finance_officer) {
                                $employee_number = 'FIN-' . date('Y') . '-' . str_pad((string)$user_id, 5, '0', STR_PAD_LEFT);
                                $stmt = $conn->prepare("
                                    INSERT INTO finance_officers (user_id, employee_number)
                                    VALUES (?, ?)
                                ");
                                $stmt->execute([$user_id, $employee_number]);
                            }
                            break;

                        case 'cashier':
                            $cash_stmt = $conn->prepare("SELECT * FROM cashiers WHERE user_id = ? LIMIT 1");
                            $cash_stmt->execute([$user_id]);
                            $cashier = $cash_stmt->fetch(PDO::FETCH_ASSOC);
                            if (!$cashier) {
                                $employee_number = 'CAS-' . date('Y') . '-' . str_pad((string)$user_id, 5, '0', STR_PAD_LEFT);
                                $stmt = $conn->prepare("
                                    INSERT INTO cashiers (user_id, employee_number)
                                    VALUES (?, ?)
                                ");
                                $stmt->execute([$user_id, $employee_number]);
                            }
                            break;
                    }

                    if ($conn->inTransaction()) {
                        $conn->commit();
                    }

                    send_notification($user_id, 'account_approved', 'Your account has been approved', [
                        'username' => $user['username'],
                        'role' => $role_name
                    ]);

                    flash_message('success', 'User approved successfully.');
                    log_audit('USER_APPROVED', 'users', $user_id, ['status' => 'pending'], ['status' => 'approved']);

                } elseif ($action === 'reject') {
                    if (empty($reason)) {
                        if ($conn->inTransaction()) {
                            $conn->rollBack();
                        }
                        flash_message('error', 'Rejection reason is required.');
                    } else {
                        $stmt = $conn->prepare("UPDATE users SET status = 'rejected', updated_at = NOW() WHERE user_id = ?");
                        $stmt->execute([$user_id]);

                        if ($conn->inTransaction()) {
                            $conn->commit();
                        }

                        send_notification($user_id, 'account_rejected', 'Your account has been rejected', [
                            'username' => $user['username'],
                            'reason' => $reason
                        ]);

                        flash_message('success', 'User rejected successfully.');
                        log_audit('USER_REJECTED', 'users', $user_id, ['status' => 'pending'], ['status' => 'rejected', 'reason' => $reason]);
                    }
                }
            }
        } catch (Exception $e) {
            if ($conn instanceof PDO && $conn->inTransaction()) {
                $conn->rollBack();
            }
            error_log("Approval error: " . $e->getMessage());
            if ($e instanceof RuntimeException && strpos($e->getMessage(), 'Course is required') !== false) {
                flash_message('error', $e->getMessage());
            } else {
                flash_message('error', 'An error occurred. Please try again.');
            }
        }
        
        redirect('modules/admin/approvals.php');
    }
}

// Get pending users
$pending_users = get_multiple_results("
    SELECT u.*, r.role_name
    FROM users u
    JOIN roles r ON u.role_id = r.role_id
    WHERE u.status = 'pending'
    ORDER BY u.created_at DESC
");

// Get recently approved users
$recently_approved = get_multiple_results("
    SELECT u.*, r.role_name
    FROM users u
    JOIN roles r ON u.role_id = r.role_id
    WHERE u.status = 'approved' AND u.updated_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    ORDER BY u.updated_at DESC
    LIMIT 10
");

// Get recently rejected users
$recently_rejected = get_multiple_results("
    SELECT u.*, r.role_name
    FROM users u
    JOIN roles r ON u.role_id = r.role_id
    WHERE u.status = 'rejected' AND u.updated_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    ORDER BY u.updated_at DESC
    LIMIT 10
");

// Get courses and departments for approval forms
$courses = get_multiple_results("SELECT course_id, course_name, course_code FROM courses ORDER BY course_name");
$departments = get_multiple_results("SELECT department_id, department_name, department_code FROM departments ORDER BY department_name");

// Get flash messages
$flash_messages = get_flash_messages();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <meta name="user-data" content="<?php echo htmlspecialchars(json_encode(get_logged_in_user())); ?>">
    <title>User Approvals - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="logo">
                <a href="<?php echo APP_URL; ?>/modules/admin/dashboard.php">
                    Enchong Dee University Information System
                </a>
            </div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars(get_logged_in_user()['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <ul class="sidebar-menu">
                <li><a href="<?php echo APP_URL; ?>/modules/admin/dashboard.php">
                    <span class="icon">Dashboard</span>
                </a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/users.php">
                    <span class="icon">Users</span>
                </a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/approvals.php" class="active">
                    <span class="icon">Approvals</span>
                </a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/courses.php">
                    <span class="icon">Courses</span>
                </a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/subjects.php">
                    <span class="icon">Subjects</span>
                </a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/departments.php">
                    <span class="icon">Departments</span>
                </a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/academic_years.php">
                    <span class="icon">Academic Years</span>
                </a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/reports.php">
                    <span class="icon">Reports</span>
                </a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/settings.php">
                    <span class="icon">Settings</span>
                </a></li>
            </ul>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>User Approvals</h1>
                    <p>Manage user registration approvals</p>
                </div>

                <?php if ($flash_messages): ?>
                    <div class="flash-messages mb-3">
                        <?php foreach ($flash_messages as $message): ?>
                            <div class="alert alert-<?php echo $message['type']; ?>">
                                <?php echo htmlspecialchars($message['message']); ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <!-- Statistics -->
                <div class="row mb-4">
                    <div class="col-4">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-warning"><?php echo count($pending_users); ?></h3>
                                <p>Pending Approvals</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-success"><?php echo count($recently_approved); ?></h3>
                                <p>Approved This Week</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-danger"><?php echo count($recently_rejected); ?></h3>
                                <p>Rejected This Week</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Pending Approvals -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h4>Pending User Approvals</h4>
                        <?php if ($pending_users): ?>
                            <div class="card-actions">
                                <button class="btn btn-sm btn-success" onclick="approveAll()">Approve All</button>
                                <button class="btn btn-sm btn-danger" onclick="rejectAll()">Reject All</button>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <?php if ($pending_users): ?>
                            <div class="table-responsive">
                                <table class="table data-table">
                                    <thead>
                                        <tr>
                                            <th><input type="checkbox" id="selectAll" onchange="toggleSelectAll()"></th>
                                            <th data-sortable>Name</th>
                                            <th data-sortable>Username</th>
                                            <th data-sortable>Email</th>
                                            <th data-sortable>Role</th>
                                            <th data-sortable>Registration Date</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($pending_users as $user): ?>
                                            <tr>
                                                <td><input type="checkbox" class="user-checkbox" value="<?php echo $user['user_id']; ?>"></td>
                                                <td>
                                                    <?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?>
                                                    <?php if ($user['middle_name']): ?>
                                                        <?php echo ' ' . htmlspecialchars($user['middle_name']); ?>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo htmlspecialchars($user['username']); ?></td>
                                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                                <td>
                                                    <span class="badge badge-info"><?php echo htmlspecialchars($user['role_name']); ?></span>
                                                </td>
                                                <td><?php echo format_date($user['created_at'], 'M d, Y H:i'); ?></td>
                                                <td>
                                                    <div class="btn-group">
                                                        <button class="btn btn-sm btn-success" onclick="showApproveModal(<?php echo $user['user_id']; ?>, '<?php echo htmlspecialchars($user['role_name']); ?>')">
                                                            Approve
                                                        </button>
                                                        <button class="btn btn-sm btn-danger" onclick="showRejectModal(<?php echo $user['user_id']; ?>)">
                                                            Reject
                                                        </button>
                                                        <button class="btn btn-sm btn-info" onclick="viewDetails(<?php echo $user['user_id']; ?>)">
                                                            Details
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-4">
                                <p class="text-muted">No pending approvals</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Recently Approved -->
                <?php if ($recently_approved): ?>
                    <div class="card mb-4">
                        <div class="card-header">
                            <h4>Recently Approved (Last 7 Days)</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Username</th>
                                            <th>Role</th>
                                            <th>Approved Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($recently_approved as $user): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></td>
                                                <td><?php echo htmlspecialchars($user['username']); ?></td>
                                                <td><span class="badge badge-success"><?php echo htmlspecialchars($user['role_name']); ?></span></td>
                                                <td><?php echo format_date($user['updated_at'], 'M d, Y H:i'); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Recently Rejected -->
                <?php if ($recently_rejected): ?>
                    <div class="card">
                        <div class="card-header">
                            <h4>Recently Rejected (Last 7 Days)</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Username</th>
                                            <th>Role</th>
                                            <th>Rejected Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($recently_rejected as $user): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></td>
                                                <td><?php echo htmlspecialchars($user['username']); ?></td>
                                                <td><span class="badge badge-danger"><?php echo htmlspecialchars($user['role_name']); ?></span></td>
                                                <td><?php echo format_date($user['updated_at'], 'M d, Y H:i'); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <!-- Approve Modal -->
    <div id="approveModal" class="modal">
        <div class="modal-dialog">
            <div class="modal-header">
                <h3 class="modal-title">Approve User</h3>
                <button class="modal-close">&times;</button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                    <input type="hidden" name="action" value="approve">
                    <input type="hidden" name="user_id" id="approveUserId">
                    
                    <div class="form-group" id="studentCourseGroup" style="display: none;">
                        <label for="course_id" class="form-label">Course *</label>
                        <select id="course_id" name="course_id" class="form-control">
                            <option value="">Select Course</option>
                            <?php foreach ($courses as $course): ?>
                                <option value="<?php echo $course['course_id']; ?>">
                                    <?php echo htmlspecialchars($course['course_name']); ?> (<?php echo htmlspecialchars($course['course_code']); ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <div class="invalid-feedback"></div>
                    </div>
                    
                    <div class="form-group" id="teacherDepartmentGroup" style="display: none;">
                        <label for="department_id" class="form-label">Department *</label>
                        <select id="department_id" name="department_id" class="form-control">
                            <option value="">Select Department</option>
                            <?php foreach ($departments as $department): ?>
                                <option value="<?php echo $department['department_id']; ?>">
                                    <?php echo htmlspecialchars($department['department_name']); ?> (<?php echo htmlspecialchars($department['department_code']); ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <div class="invalid-feedback"></div>
                    </div>
                    
                    <p>Are you sure you want to approve this user?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary modal-cancel">Cancel</button>
                    <button type="submit" class="btn btn-success">Approve</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Reject Modal -->
    <div id="rejectModal" class="modal">
        <div class="modal-dialog">
            <div class="modal-header">
                <h3 class="modal-title">Reject User</h3>
                <button class="modal-close">&times;</button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                    <input type="hidden" name="action" value="reject">
                    <input type="hidden" name="user_id" id="rejectUserId">
                    
                    <div class="form-group">
                        <label for="reason" class="form-label">Rejection Reason *</label>
                        <textarea id="reason" name="reason" class="form-control" rows="4" required></textarea>
                        <div class="invalid-feedback"></div>
                    </div>
                    
                    <p>Are you sure you want to reject this user? The user will be notified of the rejection.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary modal-cancel">Cancel</button>
                    <button type="submit" class="btn btn-danger">Reject</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function showApproveModal(userId, roleName) {
            document.getElementById('approveUserId').value = userId;
            
            // Show/hide role-specific fields
            document.getElementById('studentCourseGroup').style.display = 
                roleName.toLowerCase().includes('student') ? 'block' : 'none';
            document.getElementById('teacherDepartmentGroup').style.display = 
                roleName.toLowerCase().includes('teacher') ? 'block' : 'none';
            
            SIS.openModal('approveModal');
        }
        
        function showRejectModal(userId) {
            document.getElementById('rejectUserId').value = userId;
            SIS.openModal('rejectModal');
        }
        
        function viewDetails(userId) {
            // This would open a detailed view of the user
            window.open('<?php echo APP_URL; ?>/modules/admin/user_details.php?id=' + userId, '_blank', 'width=800,height=600');
        }
        
        function toggleSelectAll() {
            const selectAll = document.getElementById('selectAll');
            const checkboxes = document.querySelectorAll('.user-checkbox');
            
            checkboxes.forEach(checkbox => {
                checkbox.checked = selectAll.checked;
            });
        }
        
        function getSelectedUsers() {
            const checkboxes = document.querySelectorAll('.user-checkbox:checked');
            return Array.from(checkboxes).map(cb => cb.value);
        }
        
        function approveAll() {
            const selectedUsers = getSelectedUsers();
            if (selectedUsers.length === 0) {
                SIS.showAlert('warning', 'Please select users to approve');
                return;
            }
            
            if (confirm(`Are you sure you want to approve ${selectedUsers.length} user(s)?`)) {
                // This would implement bulk approval
                SIS.showAlert('info', 'Bulk approval feature coming soon');
            }
        }
        
        function rejectAll() {
            const selectedUsers = getSelectedUsers();
            if (selectedUsers.length === 0) {
                SIS.showAlert('warning', 'Please select users to reject');
                return;
            }
            
            const reason = prompt('Please enter rejection reason:');
            if (reason) {
                // This would implement bulk rejection
                SIS.showAlert('info', 'Bulk rejection feature coming soon');
            }
        }
    </script>

    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
