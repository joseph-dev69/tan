<?php
/**
 * Admin Dashboard
 * School Information System
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';

require_role('admin');

$stats = [
    'total_users' => get_single_result("SELECT COUNT(*) as count FROM users")['count'],
    'pending_users' => get_single_result("SELECT COUNT(*) as count FROM users WHERE status = 'pending'")['count'],
    'total_students' => get_single_result("SELECT COUNT(*) as count FROM students")['count'],
    'total_teachers' => get_single_result("SELECT COUNT(*) as count FROM teachers")['count'],
    'active_enrollments' => get_single_result("SELECT COUNT(*) as count FROM enrollments WHERE status = 'enrolled'")['count'],
    'total_courses' => get_single_result("SELECT COUNT(*) as count FROM courses")['count'],
    'total_subjects' => get_single_result("SELECT COUNT(*) as count FROM subjects")['count'],
    'pending_payments' => get_single_result("SELECT COUNT(*) as count FROM billings WHERE status = 'pending'")['count']
];

$pending_users = get_multiple_results("
    SELECT u.user_id, u.username, u.email, u.first_name, u.last_name, r.role_name, u.created_at
    FROM users u
    JOIN roles r ON u.role_id = r.role_id
    WHERE u.status = 'pending'
    ORDER BY u.created_at DESC
    LIMIT 5
");

$recent_enrollments = get_multiple_results("
    SELECT e.enrollment_id, s.student_number, u.first_name, u.last_name, c.course_name, e.enrollment_date
    FROM enrollments e
    JOIN students s ON e.student_id = s.student_id
    JOIN users u ON s.user_id = u.user_id
    JOIN courses c ON s.course_id = c.course_id
    ORDER BY e.enrollment_date DESC
    LIMIT 5
");

$recent_payments = get_multiple_results("
    SELECT p.payment_id, p.amount, p.payment_date, p.payment_method, s.student_number, u.first_name, u.last_name
    FROM payments p
    JOIN billings b ON p.billing_id = b.billing_id
    JOIN students s ON b.student_id = s.student_id
    JOIN users u ON s.user_id = u.user_id
    ORDER BY p.payment_date DESC
    LIMIT 5
");

$current_school_year = get_single_result("SELECT year_name FROM school_years WHERE is_current = TRUE")['year_name'] ?? 'Not Set';
$current_semester = get_single_result("SELECT semester_name FROM semesters WHERE is_current = TRUE")['semester_name'] ?? 'Not Set';
$flash_messages = get_flash_messages();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <meta name="user-data" content="<?php echo htmlspecialchars(json_encode(get_logged_in_user())); ?>">
    <title>Admin Dashboard - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo">
                <a href="<?php echo APP_URL; ?>/modules/admin/dashboard.php">
                    School Information System
                </a>
            </div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars(get_logged_in_user()['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <aside class="sidebar" id="sidebar">
            <ul class="sidebar-menu">
                <li><a href="<?php echo APP_URL; ?>/modules/admin/dashboard.php" class="active">
                    <span class="icon">Dashboard</span>
                </a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/users.php">
                    <span class="icon">Users</span>
                </a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/approvals.php">
                    <span class="icon">Approvals</span>
                </a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/courses.php">
                    <span class="icon">Courses</span>
                </a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/subjects.php">
                    <span class="icon">Subjects</span>
                </a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/departments.php">
                    <span class="icon">Departments</span>
                </a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/academic_years.php">
                    <span class="icon">Academic Years</span>
                </a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/reports.php">
                    <span class="icon">Reports</span>
                </a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/settings.php">
                    <span class="icon">Settings</span>
                </a></li>
            </ul>
        </aside>

        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Admin Dashboard</h1>
                    <p>System overview and management</p>
                </div>

                <?php if ($flash_messages): ?>
                    <div class="flash-messages mb-3">
                        <?php foreach ($flash_messages as $message): ?>
                            <div class="alert alert-<?php echo $message['type']; ?>">
                                <?php echo htmlspecialchars($message['message']); ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-6">
                                <strong>Current School Year:</strong> <?php echo htmlspecialchars($current_school_year); ?>
                            </div>
                            <div class="col-6">
                                <strong>Current Semester:</strong> <?php echo htmlspecialchars($current_semester); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mb-4">
                    <div class="col-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-primary"><?php echo $stats['total_users']; ?></h3>
                                <p>Total Users</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-warning"><?php echo $stats['pending_users']; ?></h3>
                                <p>Pending Approvals</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-info"><?php echo $stats['total_students']; ?></h3>
                                <p>Total Students</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-success"><?php echo $stats['total_teachers']; ?></h3>
                                <p>Total Teachers</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mb-4">
                    <div class="col-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-primary"><?php echo $stats['active_enrollments']; ?></h3>
                                <p>Active Enrollments</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-info"><?php echo $stats['total_courses']; ?></h3>
                                <p>Total Courses</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-success"><?php echo $stats['total_subjects']; ?></h3>
                                <p>Total Subjects</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-warning"><?php echo $stats['pending_payments']; ?></h3>
                                <p>Pending Payments</p>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </main>
    </div>

    <div id="quickActionsModal" class="modal">
        <div class="modal-dialog">
            <div class="modal-header">
                <h3 class="modal-title">Quick Actions</h3>
                <button class="modal-close">&times;</button>
            </div>
            <div class="modal-body">
                <div class="quick-actions">
                    <a href="<?php echo APP_URL; ?>/modules/admin/users.php?action=add" class="btn btn-primary btn-block mb-2">
                        Add New User
                    </a>
                    <a href="<?php echo APP_URL; ?>/modules/admin/courses.php?action=add" class="btn btn-info btn-block mb-2">
                        Add New Course
                    </a>
                    <a href="<?php echo APP_URL; ?>/modules/admin/subjects.php?action=add" class="btn btn-success btn-block mb-2">
                        Add New Subject
                    </a>
                    <a href="<?php echo APP_URL; ?>/modules/admin/approvals.php" class="btn btn-warning btn-block">
                        Review Pending Approvals
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script>
        function approveUser(userId) {
            if (confirm('Are you sure you want to approve this user?')) {
                fetch('<?php echo APP_URL; ?>/api/admin/approve_user.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: JSON.stringify({
                        user_id: userId,
                        action: 'approve',
                        csrf_token: '<?php echo generate_csrf_token(); ?>'
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        SIS.showAlert('success', data.message);
                        setTimeout(() => location.reload(), 1000);
                    } else {
                        SIS.showAlert('error', data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    SIS.showAlert('error', 'An error occurred. Please try again.');
                });
            }
        }

        function declineUser(userId) {
            const reason = prompt('Enter decline reason (optional):', '');
            if (reason === null) {
                return;
            }

            fetch('<?php echo APP_URL; ?>/api/admin/approve_user.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({
                    user_id: userId,
                    action: 'reject',
                    reason: reason,
                    csrf_token: '<?php echo generate_csrf_token(); ?>'
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    SIS.showAlert('success', data.message);
                    setTimeout(() => location.reload(), 1000);
                } else {
                    SIS.showAlert('error', data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                SIS.showAlert('error', 'An error occurred. Please try again.');
            });
        }

        setInterval(() => {
            location.reload();
        }, 30000);
    </script>

    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
