<?php
/**
 * Admin Courses Page
 * School Information System
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';

require_role('admin');

$courses = [];
$error_message = '';

try {
    $courses = get_multiple_results("
        SELECT c.course_code,
               c.course_name,
               d.department_name,
               c.description,
               c.duration_years
        FROM courses c
        LEFT JOIN departments d ON c.department_id = d.department_id
        ORDER BY c.course_code ASC
    ");
} catch (Exception $e) {
    $error_message = 'Unable to load courses right now.';
    error_log('Admin courses page error: ' . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <meta name="user-data" content="<?php echo htmlspecialchars(json_encode(get_logged_in_user())); ?>">
    <title>Courses - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo">
                <a href="<?php echo APP_URL; ?>/modules/admin/dashboard.php">School Information System</a>
            </div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars(get_logged_in_user()['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <aside class="sidebar" id="sidebar">
            <ul class="sidebar-menu">
                <li><a href="<?php echo APP_URL; ?>/modules/admin/dashboard.php"><span class="icon">Dashboard</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/users.php"><span class="icon">Users</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/approvals.php"><span class="icon">Approvals</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/courses.php" class="active"><span class="icon">Courses</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/subjects.php"><span class="icon">Subjects</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/departments.php"><span class="icon">Departments</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/academic_years.php"><span class="icon">Academic Years</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/reports.php"><span class="icon">Reports</span></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/admin/settings.php"><span class="icon">Settings</span></a></li>
            </ul>
        </aside>

        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Courses</h1>
                    <p>Showing All The Courses.</p>
                </div>

                <?php if ($error_message): ?>
                    <div class="alert alert-danger mb-3"><?php echo htmlspecialchars($error_message); ?></div>
                <?php endif; ?>

                <div class="row mb-4">
                   <div class="col-12">
                        <div class="card course-stat-card">
                            <div class="card-body text-center">
                                <p class="course-stat-label">Total Courses</p>
                                <h3 class="text-primary"><?php echo count($courses); ?></h3>
						        </div>
                               </div>
                          </div>
                     </div>

                <div class="card">
                    <div class="card-header">
                        <h4>Current Database Courses</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($courses): ?>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Course Code</th>
                                            <th>Course Name</th>
                                            <th>Department</th>
                                            <th>Description</th>
                                            <th>Duration</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($courses as $course): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars((string)$course['course_code']); ?></td>
                                                <td><?php echo htmlspecialchars((string)$course['course_name']); ?></td>
                                                <td><?php echo htmlspecialchars((string)($course['department_name'] ?? '')); ?></td>
                                                <td><?php echo htmlspecialchars((string)($course['description'] ?? '')); ?></td>
                                                <td><?php echo htmlspecialchars((string)($course['duration_years'] ?? '')); ?> Years</td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">No course data found.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <style>
        .course-stat-card {
            min-height: 130px;
        }

        .course-stat-label {
            color: var(--gray-color);
            font-size: .9rem;
            text-transform: uppercase;
            letter-spacing: .04em;
            margin-bottom: .5rem;
        }
    </style>

    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
