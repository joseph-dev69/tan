<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';

require_role('dean');
$current_user = get_logged_in_user();

function dean_teacher_assignment_fixed_semester_options($school_year_id)
{
    $fixed_semesters = ['First Semester', 'Second Semester', 'Summer'];
    $options = [];

    foreach ($fixed_semesters as $semester_name) {
        $semester = get_single_result("
            SELECT semester_id, semester_name
            FROM semesters
            WHERE school_year_id = ? AND semester_name = ?
            ORDER BY semester_id DESC
            LIMIT 1
        ", [$school_year_id, $semester_name]);

        if (!$semester) {
            $semester = get_single_result("
                SELECT semester_id, semester_name
                FROM semesters
                WHERE semester_name = ?
                ORDER BY is_current DESC, semester_id DESC
                LIMIT 1
            ", [$semester_name]);
        }

        if ($semester) {
            $options[] = [
                'semester_id' => (int)$semester['semester_id'],
                'semester_name' => $semester_name,
            ];
        }
    }

    return $options;
}

$school_year_id = (int)($_GET['school_year_id'] ?? ($_POST['school_year_id'] ?? 0));
$semester_id = (int)($_GET['semester_id'] ?? ($_POST['semester_id'] ?? 0));
$course_id = (int)($_GET['course_id'] ?? ($_POST['course_id'] ?? 0));

$school_years = get_multiple_results("SELECT school_year_id, year_name FROM school_years ORDER BY school_year_id DESC");
$courses = get_multiple_results("SELECT course_id, course_code, course_name FROM courses ORDER BY course_code ASC");
$current_school_year = get_single_result("SELECT school_year_id FROM school_years WHERE is_current = TRUE LIMIT 1");
$current_semester = get_single_result("SELECT semester_id, semester_name FROM semesters WHERE is_current = TRUE LIMIT 1");

if ($school_year_id <= 0) {
    $school_year_id = (int)($current_school_year['school_year_id'] ?? ($school_years[0]['school_year_id'] ?? 0));
}

$semesters = dean_teacher_assignment_fixed_semester_options($school_year_id);
$selected_semester_name_from_id = '';
if ($semester_id > 0) {
    $semester_lookup = get_single_result("SELECT semester_name FROM semesters WHERE semester_id = ? LIMIT 1", [$semester_id]);
    $selected_semester_name_from_id = trim((string)($semester_lookup['semester_name'] ?? ''));
}

if ($semester_id <= 0 && $current_semester) {
    $selected_semester_name_from_id = trim((string)$current_semester['semester_name']);
}

if ($selected_semester_name_from_id !== '') {
    foreach ($semesters as $semester_option) {
        if ($semester_option['semester_name'] === $selected_semester_name_from_id) {
            $semester_id = (int)$semester_option['semester_id'];
            break;
        }
    }
}

if ($semester_id <= 0 && !empty($semesters)) {
    $semester_id = (int)$semesters[0]['semester_id'];
}
if ($course_id <= 0 && !empty($courses)) {
    $course_id = (int) $courses[0]['course_id'];
}

$selected_semester = null;
foreach ($semesters as $semester_option) {
    if ((int)$semester_option['semester_id'] === $semester_id) {
        $selected_semester = $semester_option;
        break;
    }
}
$selected_semester_name = trim((string)($selected_semester['semester_name'] ?? ''));

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    if (!verify_csrf_token($csrf_token)) {
        flash_message('error', 'Invalid request token.');
        redirect('modules/dean/teacher_assignments.php?school_year_id=' . $school_year_id . '&semester_id=' . $semester_id . '&course_id=' . $course_id);
    }

    try {
        $action = $_POST['action'] ?? 'remove_assignment';
        $offering_id = (int) ($_POST['offering_id'] ?? 0);

        if ($action === 'assign_teacher') {
            $teacher_id = (int) ($_POST['teacher_id'] ?? 0);
            if ($offering_id <= 0 || $teacher_id <= 0) {
                flash_message('error', 'Please select both subject offering and teacher.');
            } else {
                $conn = get_db_connection();
                $conn->prepare("
                    UPDATE subject_offerings
                    SET teacher_id = ?
                    WHERE offering_id = ?
                      AND school_year_id = ?
                      AND semester_id IN (
                          SELECT semester_id FROM semesters WHERE semester_name = ?
                      )
                ")->execute([$teacher_id, $offering_id, $school_year_id, $selected_semester_name]);
                flash_message('success', 'Teacher assigned successfully.');
            }
        } elseif ($offering_id <= 0) {
            flash_message('error', 'Invalid assignment selected.');
        } else {
            $conn = get_db_connection();
            $conn->beginTransaction();
            $conn->prepare("DELETE FROM schedules WHERE offering_id = ?")->execute([$offering_id]);
            $conn->prepare("DELETE FROM subject_offerings WHERE offering_id = ?")->execute([$offering_id]);
            $conn->commit();
            flash_message('success', 'Assignment removed successfully.');
        }
    } catch (Exception $e) {
        if (isset($conn) && $conn instanceof PDO && $conn->inTransaction()) {
            $conn->rollBack();
        }
        error_log('Dean teacher assignment error: ' . $e->getMessage());
        flash_message('error', 'Unable to complete teacher assignment action.');
    }

    redirect('modules/dean/teacher_assignments.php?school_year_id=' . $school_year_id . '&semester_id=' . $semester_id . '&course_id=' . $course_id);
}

$teachers = get_multiple_results("
    SELECT t.teacher_id, CONCAT(u.last_name, ', ', u.first_name) AS teacher_name
    FROM teachers t
    JOIN users u ON u.user_id = t.user_id
    ORDER BY u.last_name, u.first_name
");
$offering_options = get_multiple_results("
    SELECT so.offering_id, sub.subject_code, sub.subject_name, c.course_code, so.section,
           CONCAT(COALESCE(u.last_name, 'No'), ', ', COALESCE(u.first_name, 'Teacher')) AS teacher_name
    FROM subject_offerings so
    JOIN subjects sub ON sub.subject_id = so.subject_id
    JOIN courses c ON c.course_id = sub.course_id
    LEFT JOIN teachers t ON t.teacher_id = so.teacher_id
    LEFT JOIN users u ON u.user_id = t.user_id
    JOIN semesters sem ON sem.semester_id = so.semester_id
    WHERE so.school_year_id = ? AND sem.semester_name = ?
      AND (? <= 0 OR c.course_id = ?)
    ORDER BY c.course_code, sub.subject_code, so.section
", [$school_year_id, $selected_semester_name, $course_id, $course_id]);
$teacher_assignments = get_multiple_results("
    SELECT so.offering_id, c.course_code, sub.subject_code, sub.subject_name, so.section,
           CONCAT(u.last_name, ', ', u.first_name) AS teacher_name,
           sch.day_of_week, sch.start_time, sch.end_time, sch.room
    FROM subject_offerings so
    JOIN subjects sub ON sub.subject_id = so.subject_id
    JOIN courses c ON c.course_id = sub.course_id
    LEFT JOIN teachers t ON t.teacher_id = so.teacher_id
    LEFT JOIN users u ON u.user_id = t.user_id
    LEFT JOIN schedules sch ON sch.offering_id = so.offering_id
    JOIN semesters sem ON sem.semester_id = so.semester_id
    WHERE so.school_year_id = ? AND sem.semester_name = ?
      AND (? <= 0 OR c.course_id = ?)
    ORDER BY teacher_name, sub.subject_code, so.section
", [$school_year_id, $selected_semester_name, $course_id, $course_id]);

$flash_messages = get_flash_messages();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <title>Dean Teacher Assignments - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo"><a href="<?php echo APP_URL; ?>/modules/dean/dashboard.php">School Information System</a></div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <?php render_dean_sidebar('teacher_assignments'); ?>
        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Teacher Assignment</h1>
                    <p>Review and manage teacher-subject assignments.</p>
                </div>

                <?php if ($flash_messages): ?>
                    <div class="flash-messages mb-3">
                        <?php foreach ($flash_messages as $message): ?>
                            <div class="alert alert-<?php echo $message['type']; ?>">
                                <?php echo htmlspecialchars($message['message']); ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <div class="card mb-4">
                    <div class="card-body">
                        <form method="GET" action="" class="form-row">
                            <div class="form-group">
                                <label class="form-label" for="school_year_id">School Year</label>
                                <select id="school_year_id" name="school_year_id" class="form-control" required>
                                    <?php foreach ($school_years as $sy): ?>
                                        <option value="<?php echo (int) $sy['school_year_id']; ?>" <?php echo (int) $sy['school_year_id'] === $school_year_id ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($sy['year_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="semester_id">Semester</label>
                                <select id="semester_id" name="semester_id" class="form-control" required>
                                    <?php foreach ($semesters as $sem): ?>
                                        <option value="<?php echo (int) $sem['semester_id']; ?>" <?php echo (int) $sem['semester_id'] === $semester_id ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($sem['semester_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="course_id">Course</label>
                                <select id="course_id" name="course_id" class="form-control" required>
                                    <?php foreach ($courses as $course): ?>
                                        <option value="<?php echo (int) $course['course_id']; ?>" <?php echo (int) $course['course_id'] === $course_id ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($course['course_code'] . ' - ' . $course['course_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group" style="align-self:end;">
                                <button type="submit" class="btn btn-primary">Apply Filter</button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-header"><h4>Assign / Reassign Teacher</h4></div>
                    <div class="card-body">
                        <form method="POST" action="" class="form-row">
                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                            <input type="hidden" name="action" value="assign_teacher">
                            <input type="hidden" name="school_year_id" value="<?php echo $school_year_id; ?>">
                            <input type="hidden" name="semester_id" value="<?php echo $semester_id; ?>">
                            <input type="hidden" name="course_id" value="<?php echo $course_id; ?>">

                            <div class="form-group">
                                <label class="form-label" for="offering_id">Subject Offering</label>
                                <select id="offering_id" name="offering_id" class="form-control" required>
                                    <option value="">Select Subject Offering</option>
                                    <?php foreach ($offering_options as $offering): ?>
                                        <option value="<?php echo (int) $offering['offering_id']; ?>">
                                            <?php echo htmlspecialchars($offering['course_code'] . ' / ' . $offering['subject_code'] . ' - ' . $offering['subject_name'] . ' / Section ' . $offering['section'] . ' / Current: ' . $offering['teacher_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label class="form-label" for="teacher_id">Teacher</label>
                                <select id="teacher_id" name="teacher_id" class="form-control" required>
                                    <option value="">Select Teacher</option>
                                    <?php foreach ($teachers as $teacher): ?>
                                        <option value="<?php echo (int) $teacher['teacher_id']; ?>">
                                            <?php echo htmlspecialchars($teacher['teacher_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group" style="align-self:end;">
                                <button type="submit" class="btn btn-success">Assign Teacher</button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header"><h4>Teacher - Subject Assignments</h4></div>
                    <div class="card-body">
                        <?php if ($teacher_assignments): ?>
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Teacher</th>
                                            <th>Subject</th>
                                            <th>Course</th>
                                            <th>Section</th>
                                            <th>Schedule</th>
                                            <th>Room</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($teacher_assignments as $row): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($row['teacher_name']); ?></td>
                                                <td><?php echo htmlspecialchars($row['subject_code'] . ' - ' . $row['subject_name']); ?></td>
                                                <td><?php echo htmlspecialchars($row['course_code']); ?></td>
                                                <td><?php echo htmlspecialchars($row['section']); ?></td>
                                                <td>
                                                    <?php
                                                    $sched_text = '';
                                                    if (!empty($row['day_of_week'])) {
                                                        $sched_text = ucfirst($row['day_of_week']) . ' ' . substr((string) $row['start_time'], 0, 5) . '-' . substr((string) $row['end_time'], 0, 5);
                                                    }
                                                    echo htmlspecialchars($sched_text);
                                                    ?>
                                                </td>
                                                <td><?php echo htmlspecialchars((string) ($row['room'] ?? '')); ?></td>
                                                <td>
                                                    <form method="POST" action="" onsubmit="return confirm('Remove this assignment?');" style="display:inline;">
                                                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                                        <input type="hidden" name="action" value="remove_assignment">
                                                        <input type="hidden" name="offering_id" value="<?php echo (int) $row['offering_id']; ?>">
                                                        <input type="hidden" name="school_year_id" value="<?php echo $school_year_id; ?>">
                                                        <input type="hidden" name="semester_id" value="<?php echo $semester_id; ?>">
                                                        <input type="hidden" name="course_id" value="<?php echo $course_id; ?>">
                                                        <button type="submit" class="btn btn-sm btn-danger">Remove</button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">No teacher-subject assignments for the selected term.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>
    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
