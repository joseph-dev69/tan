<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';

require_role('dean');
$current_user = get_logged_in_user();

function dean_enrollment_summary_fixed_semester_options($school_year_id)
{
    $fixed_semesters = ['First Semester', 'Second Semester', 'Summer'];
    $options = [];

    foreach ($fixed_semesters as $semester_name) {
        $semester = get_single_result("
            SELECT semester_id, semester_name
            FROM semesters
            WHERE school_year_id = ? AND semester_name = ?
            ORDER BY semester_id DESC
            LIMIT 1
        ", [$school_year_id, $semester_name]);

        if (!$semester) {
            $semester = get_single_result("
                SELECT semester_id, semester_name
                FROM semesters
                WHERE semester_name = ?
                ORDER BY is_current DESC, semester_id DESC
                LIMIT 1
            ", [$semester_name]);
        }

        if ($semester) {
            $options[] = [
                'semester_id' => (int)$semester['semester_id'],
                'semester_name' => $semester_name,
            ];
        }
    }

    return $options;
}

$school_year_id = (int)($_GET['school_year_id'] ?? 0);
$semester_id = (int)($_GET['semester_id'] ?? 0);

$school_years = get_multiple_results("SELECT school_year_id, year_name FROM school_years ORDER BY school_year_id DESC");
$current_school_year = get_single_result("SELECT school_year_id FROM school_years WHERE is_current = TRUE LIMIT 1");
$current_semester = get_single_result("SELECT semester_id, semester_name FROM semesters WHERE is_current = TRUE LIMIT 1");

if ($school_year_id <= 0) {
    $school_year_id = (int)($current_school_year['school_year_id'] ?? ($school_years[0]['school_year_id'] ?? 0));
}

$semesters = dean_enrollment_summary_fixed_semester_options($school_year_id);
$selected_semester_name_from_id = '';
if ($semester_id > 0) {
    $semester_lookup = get_single_result("SELECT semester_name FROM semesters WHERE semester_id = ? LIMIT 1", [$semester_id]);
    $selected_semester_name_from_id = trim((string)($semester_lookup['semester_name'] ?? ''));
}

if ($semester_id <= 0 && $current_semester) {
    $selected_semester_name_from_id = trim((string)$current_semester['semester_name']);
}

if ($selected_semester_name_from_id !== '') {
    foreach ($semesters as $semester_option) {
        if ($semester_option['semester_name'] === $selected_semester_name_from_id) {
            $semester_id = (int)$semester_option['semester_id'];
            break;
        }
    }
}

if ($semester_id <= 0 && !empty($semesters)) {
    $semester_id = (int)$semesters[0]['semester_id'];
}

$selected_semester = null;
foreach ($semesters as $semester_option) {
    if ((int)$semester_option['semester_id'] === $semester_id) {
        $selected_semester = $semester_option;
        break;
    }
}
$selected_semester_name = trim((string)($selected_semester['semester_name'] ?? ''));

$enrolled_summary = get_multiple_results("
    SELECT c.course_code, c.course_name, s.year_level, COUNT(e.enrollment_id) AS enrolled_count
    FROM enrollments e
    JOIN students s ON s.student_id = e.student_id
    JOIN courses c ON c.course_id = s.course_id
    JOIN semesters sem ON sem.semester_id = e.semester_id
    WHERE e.school_year_id = ? AND sem.semester_name = ? AND e.status = 'enrolled'
    GROUP BY c.course_code, c.course_name, s.year_level
    ORDER BY c.course_code, s.year_level
", [$school_year_id, $selected_semester_name]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <title>Dean Enrollment Summary - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo"><a href="<?php echo APP_URL; ?>/modules/dean/dashboard.php">School Information System</a></div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <?php render_dean_sidebar('enrollment_summary'); ?>
        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Enrollment Summary</h1>
                    <p>Review enrolled students by course and year level.</p>
                </div>

                <div class="card mb-4">
                    <div class="card-body">
                        <form method="GET" action="" class="form-row">
                            <div class="form-group">
                                <label class="form-label" for="school_year_id">School Year</label>
                                <select id="school_year_id" name="school_year_id" class="form-control" required>
                                    <?php foreach ($school_years as $sy): ?>
                                        <option value="<?php echo (int) $sy['school_year_id']; ?>" <?php echo (int) $sy['school_year_id'] === $school_year_id ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($sy['year_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="semester_id">Semester</label>
                                <select id="semester_id" name="semester_id" class="form-control" required>
                                    <?php foreach ($semesters as $sem): ?>
                                        <option value="<?php echo (int) $sem['semester_id']; ?>" <?php echo (int) $sem['semester_id'] === $semester_id ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($sem['semester_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group" style="align-self:end;">
                                <button type="submit" class="btn btn-primary">Apply Filter</button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header"><h4>Enrolled Student Totals</h4></div>
                    <div class="card-body">
                        <?php if ($enrolled_summary): ?>
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Course</th>
                                            <th>Year Level</th>
                                            <th>Enrolled Students</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($enrolled_summary as $row): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($row['course_code'] . ' - ' . $row['course_name']); ?></td>
                                                <td><?php echo htmlspecialchars((string) $row['year_level']); ?></td>
                                                <td><?php echo htmlspecialchars((string) $row['enrolled_count']); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">No enrolled student data for the selected term.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>
    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
