<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';

require_role('dean');
$current_user = get_logged_in_user();

$current_school_year = get_single_result("SELECT year_name FROM school_years WHERE is_current = TRUE")['year_name'] ?? 'Not Set';
$current_semester = get_single_result("SELECT semester_name FROM semesters WHERE is_current = TRUE")['semester_name'] ?? 'Not Set';

$summary = [
    'courses' => get_single_result("SELECT COUNT(*) AS count FROM courses")['count'] ?? 0,
    'teachers' => get_single_result("SELECT COUNT(*) AS count FROM teachers")['count'] ?? 0,
    'enrolled' => get_single_result("SELECT COUNT(*) AS count FROM enrollments WHERE status = 'enrolled'")['count'] ?? 0,
    'subjects' => get_single_result("SELECT COUNT(*) AS count FROM subjects")['count'] ?? 0,
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <title>Dean Dashboard - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo"><a href="<?php echo APP_URL; ?>/modules/dean/dashboard.php">Enchong Dee University Information System</a></div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <?php render_dean_sidebar('dashboard'); ?>
        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Dean / Program Head Dashboard</h1>
                    <p>Overview of course offerings, enrollment, schedules, and assignments.</p>
                </div>

                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-6">
                                <strong>Current School Year:</strong> <?php echo htmlspecialchars($current_school_year); ?>
                            </div>
                            <div class="col-6">
                                <strong>Current Semester:</strong> <?php echo htmlspecialchars($current_semester); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mb-4">
                    <div class="col-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-primary"><?php echo (int) $summary['courses']; ?></h3>
                                <p>Total Courses</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-success"><?php echo (int) $summary['teachers']; ?></h3>
                                <p>Teachers</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-info"><?php echo (int) $summary['enrolled']; ?></h3>
                                <p>Enrolled Students</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-warning"><?php echo (int) $summary['subjects']; ?></h3>
                                <p>Total Subjects</p>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </main>
    </div>
    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
