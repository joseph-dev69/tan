<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';

require_role('dean');

$current_user = get_logged_in_user();
$flash_messages = get_flash_messages();
$conn = get_db_connection();

function has_legacy_column(PDO $conn, $table, $column) {
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table) || !preg_match('/^[A-Za-z0-9_]+$/', $column)) {
        return false;
    }
    $sql = "SHOW COLUMNS FROM `{$table}` LIKE " . $conn->quote($column);
    $stmt = $conn->query($sql);
    return $stmt ? (bool)$stmt->fetch() : false;
}

function has_table(PDO $conn, $table) {
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) {
        return false;
    }
    $sql = "SHOW TABLES LIKE " . $conn->quote($table);
    $stmt = $conn->query($sql);
    return $stmt ? (bool)$stmt->fetch() : false;
}

function next_cn(PDO $conn) {
    $row = $conn->query("SELECT MAX(CAST(`CN` AS UNSIGNED)) AS max_cn FROM `subjectssem120182019`")->fetch();
    return (int)($row['max_cn'] ?? 0) + 1;
}

function normalize_key($text) {
    $text = strtoupper((string)$text);
    $text = preg_replace('/[^A-Z0-9]+/', ' ', $text);
    return trim($text);
}

function make_unique_subject_code(PDO $conn, $course_code, $raw_subject_code) {
    $base = strtoupper(preg_replace('/[^A-Z0-9]/', '', (string)$raw_subject_code));
    if ($base === '') {
        $base = strtoupper(preg_replace('/[^A-Z0-9]/', '', (string)$course_code)) . 'SUBJ';
    }

    $candidate = substr($base, 0, 20);
    $exists = get_single_result("SELECT subject_id FROM subjects WHERE subject_code = ? LIMIT 1", [$candidate]);
    if (!$exists) {
        return $candidate;
    }

    $prefix = strtoupper(preg_replace('/[^A-Z0-9]/', '', (string)$course_code));
    $prefix = substr($prefix, 0, 6);
    if ($prefix === '') {
        $prefix = 'CRS';
    }

    $suffix = 1;
    while (true) {
        $tail = (string)$suffix;
        $max_base_len = 20 - strlen($prefix) - 1 - strlen($tail);
        $max_base_len = max(1, $max_base_len);
        $rebased = substr($base, 0, $max_base_len);
        $candidate = $prefix . '-' . $rebased . $tail;
        $exists = get_single_result("SELECT subject_id FROM subjects WHERE subject_code = ? LIMIT 1", [$candidate]);
        if (!$exists) {
            return $candidate;
        }
        $suffix++;
    }
}

function normalize_school_year_range($raw_value) {
    $value = trim((string)$raw_value);
    if ($value === '') {
        return '2018-2019';
    }

    if (preg_match('/^(\d{4})\s*-\s*(\d{4})$/', $value, $m)) {
        return $m[1] . '-' . $m[2];
    }

    if (preg_match('/^\d{4}$/', $value)) {
        $start = (int)$value;
        return $start . '-' . ($start + 1);
    }

    return '2018-2019';
}

function school_year_options($start_year = 2018, $count = 25) {
    $start_year = (int)$start_year;
    $count = (int)$count;
    if ($count < 1) {
        $count = 1;
    }

    $options = [];
    for ($i = 0; $i < $count; $i++) {
        $from = $start_year + $i;
        $to = $from + 1;
        $options[] = $from . '-' . $to;
    }

    return $options;
}

function format_department_label(array $department) {
    $code = strtoupper(trim((string)($department['department_code'] ?? '')));
    $name = trim((string)($department['department_name'] ?? ''));
    if ($code !== '' && $name !== '') {
        return $code . ' - ' . $name;
    }
    return $name !== '' ? $name : $code;
}

function curriculum_template($course_code, $course_desc, $major = '') {
    $k = normalize_key($course_code . ' ' . $course_desc . ' ' . $major);
    $ge1 = [
        ['subject' => 'GE101', 'desc' => 'Purposive Communication', 'unit' => 3],
        ['subject' => 'GE201', 'desc' => 'Understanding the Self', 'unit' => 3],
        ['subject' => 'GE301', 'desc' => 'Art Appreciation', 'unit' => 3],
        ['subject' => 'PE1', 'desc' => 'Movement Enhancement', 'unit' => 2],
        ['subject' => 'NSTP1', 'desc' => 'National Service Training Program 1', 'unit' => 3]
    ];
    $ge2 = [
        ['subject' => 'GE204', 'desc' => 'Ethics', 'unit' => 3],
        ['subject' => 'GE502', 'desc' => 'Environmental Science', 'unit' => 3],
        ['subject' => 'RIZAL', 'desc' => 'Life and Works of Rizal', 'unit' => 3],
        ['subject' => 'PE2', 'desc' => 'Fitness Exercise', 'unit' => 2],
        ['subject' => 'NSTP2', 'desc' => 'National Service Training Program 2', 'unit' => 3]
    ];

    $prefix = strtoupper(preg_replace('/[^A-Z0-9]/', '', (string)$course_code));
    if ($prefix === '') {
        $prefix = 'CRS';
    }

    $major_map = [
        [1, 1, $prefix . '101', 'Introduction to ' . $course_desc, 3],
        [1, 1, $prefix . '102', 'Fundamentals of ' . $course_desc, 3],
        [1, 2, $prefix . '103', 'Intermediate ' . $course_desc, 3],
        [1, 2, $prefix . '104', 'Applied Concepts in ' . $course_desc, 3],
        [2, 1, $prefix . '201', 'Professional Subjects 1', 3],
        [2, 1, $prefix . '202', 'Professional Subjects 2', 3],
        [2, 1, $prefix . '203', 'Research Methods', 3],
        [2, 1, $prefix . '204', 'Data Analysis', 3],
        [2, 1, $prefix . '205', 'Field Applications 1', 3],
        [2, 1, $prefix . '206', 'Elective 1', 3],
        [2, 1, $prefix . '207', 'Seminar 1', 2],
        [2, 2, $prefix . '208', 'Professional Subjects 3', 3],
        [2, 2, $prefix . '209', 'Professional Subjects 4', 3],
        [2, 2, $prefix . '210', 'Systems and Process Design', 3],
        [2, 2, $prefix . '211', 'Field Applications 2', 3],
        [2, 2, $prefix . '212', 'Elective 2', 3],
        [2, 2, $prefix . '213', 'Seminar 2', 2],
        [2, 2, $prefix . '214', 'Integrative Practice', 3],
        [3, 1, $prefix . '301', 'Advanced Topics 1', 3],
        [3, 1, $prefix . '302', 'Advanced Topics 2', 3],
        [3, 1, $prefix . '303', 'Methods and Standards', 3],
        [3, 1, $prefix . '304', 'Practicum Preparation', 3],
        [3, 1, $prefix . '305', 'Elective 3', 3],
        [3, 1, $prefix . '306', 'Project Design 1', 3],
        [3, 1, $prefix . '307', 'Innovation and Leadership', 3],
        [3, 2, $prefix . '308', 'Advanced Topics 3', 3],
        [3, 2, $prefix . '309', 'Advanced Topics 4', 3],
        [3, 2, $prefix . '310', 'Professional Ethics in Practice', 3],
        [3, 2, $prefix . '311', 'Elective 4', 3],
        [3, 2, $prefix . '312', 'Project Design 2', 3],
        [3, 2, $prefix . '313', 'Industry Tools and Trends', 3],
        [3, 2, $prefix . '314', 'Community Extension', 2],
        [4, 1, $prefix . '401', 'Internship / OJT 1', 6],
        [4, 1, $prefix . '402', 'Capstone Project 1', 3],
        [4, 1, $prefix . '403', 'Policy, Governance, and Law', 3],
        [4, 1, $prefix . '404', 'Professional Elective 5', 3],
        [4, 1, $prefix . '405', 'Special Topics 1', 3],
        [4, 1, $prefix . '406', 'Quality Assurance and Evaluation', 3],
        [4, 1, $prefix . '407', 'Comprehensive Review 1', 2],
        [4, 2, $prefix . '408', 'Internship / OJT 2', 6],
        [4, 2, $prefix . '409', 'Capstone Project 2', 3],
        [4, 2, $prefix . '410', 'Professional Elective 6', 3],
        [4, 2, $prefix . '411', 'Special Topics 2', 3],
        [4, 2, $prefix . '412', 'Technopreneurship', 3],
        [4, 2, $prefix . '413', 'Comprehensive Review 2', 2],
        [4, 2, $prefix . '414', 'Career Development and Placement', 2]
    ];

    if (strpos($k, 'INFORMATION TECHNOLOGY') !== false || strpos($k, ' BSIT ') !== false || strpos($k, ' ITE ') !== false) {
        $major_map[0] = [1, 1, 'IT101', 'Introduction to Computing', 3];
        $major_map[1] = [1, 1, 'IT102', 'Computer Programming 1', 4];
        $major_map[2] = [1, 2, 'IT103', 'Data Structures and Algorithms', 4];
        $major_map[3] = [1, 2, 'IT104', 'Database Management Systems', 3];
    } elseif (strpos($k, 'COMPUTER SCIENCE') !== false || strpos($k, ' BSCS ') !== false) {
        $major_map[0] = [1, 1, 'CS101', 'Computer Programming 1', 4];
        $major_map[1] = [1, 1, 'CS102', 'Discrete Structures', 3];
        $major_map[2] = [1, 2, 'CS103', 'Computer Programming 2', 4];
        $major_map[3] = [1, 2, 'CS104', 'Data Structures and Algorithms', 4];
    } elseif (strpos($k, 'BUSINESS ADMINISTRATION') !== false || strpos($k, ' BSBA ') !== false) {
        $major_map[0] = [1, 1, 'BA101', 'Principles of Management', 3];
        $major_map[1] = [1, 1, 'ACCT101', 'Fundamentals of Accounting', 3];
        $major_map[2] = [1, 2, 'BA102', 'Principles of Marketing', 3];
        $major_map[3] = [1, 2, 'ECON101', 'Microeconomics', 3];
    } elseif (strpos($k, 'SOCIAL WORK') !== false || strpos($k, ' BSSW ') !== false) {
        $major_map[0] = [1, 1, 'SW101', 'Introduction to Social Work', 3];
        $major_map[1] = [1, 1, 'SW102', 'Human Behavior and Social Environment 1', 3];
        $major_map[2] = [1, 2, 'SW103', 'Social Welfare Policies and Programs', 3];
        $major_map[3] = [1, 2, 'SW104', 'Social Work Practice with Individuals', 3];
    }

    $template = [];
    for ($year = 1; $year <= 4; $year++) {
        for ($term = 1; $term <= 2; $term++) {
            $template[$year][$term] = [];
        }
    }

    foreach ($major_map as $item) {
        [$year, $term, $subject, $desc, $unit] = $item;
        $template[$year][$term][] = ['subject' => $subject, 'desc' => $desc, 'unit' => $unit];
    }

    for ($year = 1; $year <= 4; $year++) {
        for ($term = 1; $term <= 2; $term++) {
            while (count($template[$year][$term]) < 7) {
                $seq = count($template[$year][$term]) + 1;
                $template[$year][$term][] = [
                    'subject' => $prefix . $year . $term . str_pad((string)$seq, 2, '0', STR_PAD_LEFT),
                    'desc' => 'Course Core ' . $year . '-' . $term . ' (' . $seq . ')',
                    'unit' => 3
                ];
            }
        }
    }

    $template[1][1] = array_slice(array_merge($ge1, $template[1][1]), 0, 7);
    $template[1][2] = array_slice(array_merge($ge2, $template[1][2]), 0, 7);

    return $template;
}

function build_suggestions(PDO $conn, $course_code, $course_desc, $major, $sy, $sem) {
    $template = curriculum_template($course_code, $course_desc, $major);
    $stmt = $conn->prepare("
        SELECT `SUBJECT`, `DESC`, `UNIT`, `TERM`
        FROM `subjectssem120182019`
        WHERE `COURSE` = ?
    ");
    $stmt->execute([$course_code]);
    $existing_rows = $stmt->fetchAll();

    $existing_by_subject = [];
    foreach ($existing_rows as $row) {
        $existing_by_subject[strtoupper(trim((string)$row['SUBJECT']))] = $row;
    }

    $out = [];
    for ($year = 1; $year <= 4; $year++) {
        $out[$year] = [];
        foreach ([1, 2] as $term) {
            $out[$year][$term] = [];
            $used = [];
            foreach ($template[$year][$term] as $item) {
                if (count($out[$year][$term]) >= 7) {
                    break;
                }
            $skey = strtoupper(trim($item['subject']));
            if (isset($used[$skey])) {
                continue;
            }
            $used[$skey] = true;

            $action = 'insert';
            if (isset($existing_by_subject[$skey])) {
                $existing = $existing_by_subject[$skey];
                $same = strtoupper(trim((string)$existing['DESC'])) === strtoupper(trim((string)$item['desc']))
                    && (float)$existing['UNIT'] === (float)$item['unit']
                    && (int)$existing['TERM'] === (int)$term;
                if ($same) {
                    continue;
                }
                $action = 'update';
            }

                $out[$year][$term][] = [
                'subject' => $item['subject'],
                'desc' => $item['desc'],
                'unit' => $item['unit'],
                'year' => $year,
                'term' => $term,
                'tstart' => $term === 1 ? '08:00' : '09:00',
                'tend' => $term === 1 ? '09:30' : '10:30',
                'room' => $term === 1 ? 'RM101' : 'RM201',
                'sk' => in_array($item['subject'], ['PE1', 'PE2', 'NSTP1', 'NSTP2'], true) ? 'S' : 'D',
                'limit' => in_array($item['subject'], ['PE1', 'PE2', 'NSTP1', 'NSTP2'], true) ? 50 : 40,
                'action' => $action,
                'sy' => $sy,
                'sem' => $sem,
                'course' => $course_code,
                'major' => $major
            ];
            }
            while (count($out[$year][$term]) < 7) {
                $seq = count($out[$year][$term]) + 1;
                $fallback_code = strtoupper($course_code) . $year . $term . str_pad((string)$seq, 2, '0', STR_PAD_LEFT);
            $skey = strtoupper($fallback_code);
            if (isset($existing_by_subject[$skey])) {
                continue;
            }
                $out[$year][$term][] = [
                'subject' => $fallback_code,
                'desc' => 'Core Year ' . $year . ' Sem ' . $term . ' - ' . $seq,
                'unit' => 3,
                'year' => $year,
                'term' => $term,
                'tstart' => $term === 1 ? '08:00' : '09:00',
                'tend' => $term === 1 ? '09:30' : '10:30',
                'room' => $term === 1 ? 'RM101' : 'RM201',
                'sk' => 'D',
                'limit' => 40,
                'action' => 'insert',
                'sy' => $sy,
                'sem' => $sem,
                'course' => $course_code,
                'major' => $major
            ];
            }
        }
    }
    return $out;
}

$legacy_ready = has_table($conn, 'courses')
    && has_table($conn, 'subjectssem120182019')
    && has_legacy_column($conn, 'courses', 'COURSE')
    && has_legacy_column($conn, 'subjectssem120182019', 'SUBJECT');
$modern_ready = has_table($conn, 'courses')
    && has_table($conn, 'subjects')
    && has_legacy_column($conn, 'courses', 'course_code')
    && has_legacy_column($conn, 'subjects', 'subject_code');
$builder_ready = $legacy_ready || $modern_ready;
$builder_state = null;
$departments = get_multiple_results("SELECT department_id, department_code, department_name FROM departments ORDER BY department_name ASC");
$selected_department_id = (int)($_GET['department_id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $builder_ready) {
    $csrf_token = $_POST['csrf_token'] ?? '';
    $action = $_POST['action'] ?? '';
    if (!verify_csrf_token($csrf_token)) {
        flash_message('error', 'Invalid request token.');
        redirect('modules/dean/course_curriculum_builder.php');
    }

    $course_code = strtoupper(trim(sanitize_input($_POST['course_code'] ?? '')));
    $course_desc = trim(sanitize_input($_POST['course_desc'] ?? ''));
    $major = trim(sanitize_input($_POST['major'] ?? ''));
    $sy = normalize_school_year_range(sanitize_input($_POST['sy'] ?? '2018-2019'));
    $sem = trim(sanitize_input($_POST['sem'] ?? '1'));
    $department_id = (int)($_POST['department_id'] ?? 0);

    if ($action === 'create_department') {
        $department_name = trim(sanitize_input($_POST['department_name'] ?? ''));
        $department_code = strtoupper(trim(sanitize_input($_POST['department_code'] ?? '')));
        $department_description = trim(sanitize_input($_POST['department_description'] ?? ''));

        if ($department_name === '' || $department_code === '') {
            flash_message('error', 'Department name and code are required.');
            redirect('modules/dean/course_curriculum_builder.php');
        }

        $duplicate_department = get_single_result("
            SELECT department_id
            FROM departments
            WHERE UPPER(department_name) = UPPER(?) OR UPPER(department_code) = UPPER(?)
            LIMIT 1
        ", [$department_name, $department_code]);

        if ($duplicate_department) {
            flash_message('error', 'Department name or code already exists.');
            redirect('modules/dean/course_curriculum_builder.php');
        }

        insert_record('departments', [
            'department_name' => $department_name,
            'department_code' => $department_code,
            'description' => $department_description !== '' ? $department_description : null
        ]);
        $new_department_id = (int)$conn->lastInsertId();

        flash_message('success', 'Department added successfully.');
        redirect('modules/dean/course_curriculum_builder.php?department_id=' . urlencode((string)$new_department_id));
    }

    if ($action === 'save_course') {
        if ($course_code === '' || $course_desc === '' || $department_id <= 0) {
            flash_message('error', 'Course code, description, and department are required.');
            redirect('modules/dean/course_curriculum_builder.php');
        }

        $department_exists = get_single_result("SELECT department_id FROM departments WHERE department_id = ? LIMIT 1", [$department_id]);
        if (!$department_exists) {
            flash_message('error', 'Selected department is invalid.');
            redirect('modules/dean/course_curriculum_builder.php');
        }

        if ($legacy_ready) {
            $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM `courses` WHERE `COURSE` = ? AND `MAJOR` = ?");
            $stmt->execute([$course_code, $major]);
            $exists = (int)($stmt->fetch()['total'] ?? 0) > 0;
            if ($exists) {
                $conn->prepare("UPDATE `courses` SET `DESC` = ?, `SY` = ?, `SEM` = ? WHERE `COURSE` = ? AND `MAJOR` = ?")
                    ->execute([$course_desc, $sy, $sem, $course_code, $major]);
            } else {
                $conn->prepare("INSERT INTO `courses` (`COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`) VALUES (?, ?, ?, ?, ?)")
                    ->execute([$course_code, $course_desc, $major, $sy, $sem]);
            }
        } else {
            $stmt = $conn->prepare("SELECT course_id FROM `courses` WHERE `course_code` = ? LIMIT 1");
            $stmt->execute([$course_code]);
            $existing_course = $stmt->fetch();
            if ($existing_course) {
                $conn->prepare("UPDATE `courses` SET `course_name` = ?, `department_id` = ?, `description` = ? WHERE `course_id` = ?")
                    ->execute([$course_desc, $department_id, $major !== '' ? $major : null, $existing_course['course_id']]);
            } else {
                $conn->prepare("
                    INSERT INTO `courses` (`course_name`, `course_code`, `department_id`, `description`, `duration_years`)
                    VALUES (?, ?, ?, ?, 4)
                ")->execute([$course_desc, $course_code, $department_id, $major !== '' ? $major : null]);
            }
        }
        flash_message('success', 'Course saved. You can now generate curriculum suggestions.');
        redirect(
            'modules/dean/course_curriculum_builder.php?course_code=' . urlencode($course_code)
            . '&major=' . urlencode($major)
            . '&sy=' . urlencode($sy)
            . '&sem=' . urlencode($sem)
            . '&department_id=' . urlencode((string)$department_id)
        );
    }

    if ($action === 'generate_curriculum') {
        if (!$legacy_ready) {
            $stmt = $conn->prepare("SELECT subject_code AS SUBJECT, subject_name AS `DESC`, units AS UNIT, semester_type FROM subjects WHERE course_id = (SELECT course_id FROM courses WHERE course_code = ? LIMIT 1)");
            $stmt->execute([$course_code]);
        }
        $builder_state = [
            'course_code' => $course_code,
            'course_desc' => $course_desc,
            'major' => $major,
            'sy' => $sy,
            'sem' => $sem,
            'department_id' => $department_id,
            'suggestions' => build_suggestions($conn, $course_code, $course_desc, $major, $sy, $sem)
        ];
    }

    if ($action === 'save_curriculum') {
        $rows = json_decode($_POST['curriculum_payload'] ?? '[]', true);
        if (!is_array($rows)) {
            $rows = [];
        }
        try {
    if (!$conn->inTransaction()) {
        $conn->beginTransaction();
    }
            $inserted = 0;
            $updated = 0;
            foreach ($rows as $row) {
                $subject = strtoupper(trim((string)($row['subject'] ?? '')));
                $desc = trim((string)($row['desc'] ?? ''));
                if ($subject === '' || $desc === '') {
                    continue;
                }
                $year_level = max(1, min(4, (int)($row['year'] ?? 1)));
                $term = (string)((int)($row['term'] ?? 1));
                $unit = (float)($row['unit'] ?? 3);
                $tstart = trim((string)($row['tstart'] ?? '08:00'));
                $tend = trim((string)($row['tend'] ?? '09:30'));
                $room = trim((string)($row['room'] ?? 'RM101'));
                $sk = strtoupper(trim((string)($row['sk'] ?? 'D')));
                $limit = (int)($row['limit'] ?? 40);

                if ($legacy_ready) {
                    $lookup = $conn->prepare("
                        SELECT `CN`
                        FROM `subjectssem120182019`
                        WHERE `COURSE` = ? AND `SUBJECT` = ? AND `TERM` = ? AND `SY` = ? AND `SEM` = ?
                        ORDER BY CAST(`CN` AS UNSIGNED) ASC
                        LIMIT 1
                    ");
                    $lookup->execute([$course_code, $subject, $term, $sy, $sem]);
                    $existing = $lookup->fetch();

                    if ($existing) {
                        $conn->prepare("
                            UPDATE `subjectssem120182019`
                            SET `DESC` = ?, `UNIT` = ?, `TSTART` = ?, `TEND` = ?, `ROOM` = ?, `SK` = ?, `LIMIT` = ?, `MAJOR` = ?, `STP` = ?
                            WHERE `CN` = ?
                        ")->execute([$desc, $unit, $tstart, $tend, $room, $sk, $limit, $major, (string)$year_level, $existing['CN']]);
                        $updated++;
                    } else {
                        $cn = (string)next_cn($conn);
                        $conn->prepare("
                            INSERT INTO `subjectssem120182019`
                            (`OPEN`,`BLOCK`,`DISSOLVED`,`TERM`,`CN`,`SEM`,`SY`,`COURSE`,`SUBJECT`,`DESC`,`UNIT`,`CREDIT`,`TSTART`,`TEND`,`ROOM`,`SK`,`LIMIT`,`ENROLLED`,`CLOSED`,`CDATE`,`CTIME`,`LAB`,`AIR`,`MOD`,`C1`,`C2`,`C3`,`C4`,`PRN`,`AFLAG`,`DEPT`,`DEPARTMENT`,`PROGRAM`,`MAJOR`,`EMP_DP`,`EMP_NO`,`INSTRUCTOR`,`SSERVICE`,`SFCODE`,`STYPE`,`STP`,`NRLD`)
                            VALUES
                            (1,0,NULL,?,?,?,?,?,?,?,?,'',?,?,?, ?,?,NULL,NULL,NULL,'',0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,'','','',?, 'U','','UNASSIGNED',NULL,'','S',?,NULL)
                        ")->execute([$term, $cn, $sem, $sy, $course_code, $subject, $desc, $unit, $tstart, $tend, $room, $sk, $limit, $major, (string)$year_level]);
                        $inserted++;
                    }
                } else {
                    $course_row = get_single_result("SELECT course_id FROM courses WHERE course_code = ? LIMIT 1", [$course_code]);
                    $course_id = (int)($course_row['course_id'] ?? 0);
                    if ($course_id <= 0) {
                        continue;
                    }
                    $semester_type = ((int)$term === 1) ? 'first' : 'second';
                    $existing = get_single_result("SELECT subject_id FROM subjects WHERE course_id = ? AND subject_code = ? LIMIT 1", [$course_id, $subject]);
                    if ($existing) {
                        $conn->prepare("UPDATE subjects SET subject_name = ?, units = ?, lecture_hours = 2, lab_hours = 2, year_level = ?, semester_type = ? WHERE subject_id = ?")
                            ->execute([$desc, $unit, $year_level, $semester_type, $existing['subject_id']]);
                        $updated++;
                    } else {
                        $safe_subject_code = make_unique_subject_code($conn, $course_code, $subject);
                        $conn->prepare("INSERT INTO subjects (subject_code, subject_name, description, units, lecture_hours, lab_hours, course_id, year_level, semester_type) VALUES (?, ?, ?, ?, 2, 2, ?, ?, ?)")
                            ->execute([$safe_subject_code, $desc, 'Generated by curriculum builder', $unit, $course_id, $year_level, $semester_type]);
                        $inserted++;
                    }
                }
            }
            if ($conn->inTransaction()) {
    $conn->commit();
}
            flash_message('success', "Curriculum saved. Inserted: {$inserted}, Updated: {$updated}.");
            redirect(
                'modules/dean/course_curriculum_builder.php?course_code=' . urlencode($course_code)
                . '&major=' . urlencode($major)
                . '&sy=' . urlencode($sy)
                . '&sem=' . urlencode($sem)
                . '&department_id=' . urlencode((string)$department_id)
            );
        } catch (Exception $e) {
            if ($conn->inTransaction()) {
                $conn->rollBack();
            }
            error_log('Curriculum save error: ' . $e->getMessage());
            flash_message('error', 'Failed to save curriculum: ' . $e->getMessage());
            redirect('modules/dean/course_curriculum_builder.php');
        }
    }
}

$selected_course_code = strtoupper(trim($_GET['course_code'] ?? ''));
$selected_major = trim($_GET['major'] ?? '');
$selected_sy = normalize_school_year_range($_GET['sy'] ?? '2018-2019');
$selected_sem_value = trim((string)($_GET['sem'] ?? '1'));
$school_year_choices = school_year_options(2018, 40);
$selected_course = null;
if ($builder_ready && $selected_course_code !== '') {
    if ($legacy_ready) {
        $stmt = $conn->prepare("SELECT `COURSE`,`DESC`,`MAJOR`,`SY`,`SEM` FROM `courses` WHERE `COURSE` = ? AND `MAJOR` = ? LIMIT 1");
        $stmt->execute([$selected_course_code, $selected_major]);
        $selected_course = $stmt->fetch();
    } else {
        $stmt = $conn->prepare("SELECT course_code AS `COURSE`, course_name AS `DESC`, COALESCE(description,'') AS `MAJOR`, department_id FROM courses WHERE course_code = ? LIMIT 1");
        $stmt->execute([$selected_course_code]);
        $selected_course = $stmt->fetch();
        if ($selected_course) {
            $selected_course['SY'] = $selected_sy;
            $selected_course['SEM'] = $selected_sem_value;
            $selected_department_id = (int)($selected_course['department_id'] ?? $selected_department_id);
        }
    }
}

if (!is_array($selected_course)) {
    $selected_course = [];
}
if (!isset($selected_course['SY']) || trim((string)$selected_course['SY']) === '') {
    $selected_course['SY'] = $selected_sy;
}
if (!isset($selected_course['SEM']) || trim((string)$selected_course['SEM']) === '') {
    $selected_course['SEM'] = $selected_sem_value;
}
if (!isset($selected_course['department_id'])) {
    $selected_course['department_id'] = $selected_department_id;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <title>Course + Curriculum Builder - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
    <style>
        .builder-grid { display: grid; grid-template-columns: 1fr; gap: 1rem; }
        .term-card { border: 1px solid #e2e8f0; padding: 0.75rem; }
        .table-sm input { width: 100%; }
        .row-action { font-size: 0.8rem; font-weight: 600; }
    </style>
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo"><a href="<?php echo APP_URL; ?>/modules/dean/dashboard.php">School Information System</a></div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <?php render_dean_sidebar('course_curriculum_builder'); ?>
        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Add New Course </h1>
                    <p>Create a course and subjects </p>
                </div>

                <?php if ($flash_messages): ?>
                    <div class="flash-messages mb-3">
                        <?php foreach ($flash_messages as $message): ?>
                            <div class="alert alert-<?php echo $message['type']; ?>">
                                <?php echo htmlspecialchars($message['message']); ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <?php if (!$builder_ready): ?>
                    <div class="alert alert-danger">
                        Required course/subject tables were not found in this database.
                    </div>
                <?php endif; ?>

                <div class="card mb-4">
                    <div class="card-header"><h4>Main Interface</h4></div>
                    <div class="card-body">
                        <form method="POST" action="" class="form-row">
                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                            <input type="hidden" name="action" value="save_course">
                            <div class="form-group form-col-xs">
                                <label class="form-label">Course Code *</label>
                                <input class="form-control" name="course_code" required value="<?php echo htmlspecialchars($selected_course['COURSE'] ?? ''); ?>" placeholder="BSIT">
                            </div>
                            <div class="form-group form-col-md">
                                <label class="form-label">Full Description *</label>
                                <input class="form-control" name="course_desc" required value="<?php echo htmlspecialchars($selected_course['DESC'] ?? ''); ?>" placeholder="Bachelor of Science in Information Technology">
                            </div>
                            <div class="form-group form-col-sm">
                                <label class="form-label">Major (optional)</label>
                                <input class="form-control" name="major" value="<?php echo htmlspecialchars($selected_course['MAJOR'] ?? ''); ?>" placeholder="Software Development">
                            </div>
                            <div class="form-group form-col-sm">
                                <label class="form-label">Department / College *</label>
                                <div style="display:flex; gap:.5rem; align-items:center;">
                                    <select class="form-control" name="department_id" id="department_id" required>
                                        <option value="">Select Department / College</option>
                                        <?php foreach ($departments as $department): ?>
                                            <option value="<?php echo (int)$department['department_id']; ?>" <?php echo (int)($selected_course['department_id'] ?? 0) === (int)$department['department_id'] ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars(format_department_label($department)); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <button type="button" class="btn btn-secondary" onclick="openDepartmentModal()">+ Add Department</button>
                                </div>
                            </div>
                            <div class="form-group form-col-sm">
                                <label class="form-label">SY</label>
                                <select class="form-control" name="sy" required>
                                    <?php foreach ($school_year_choices as $sy_option): ?>
                                        <option value="<?php echo htmlspecialchars($sy_option); ?>" <?php echo ($selected_course['SY'] ?? '2018-2019') === $sy_option ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($sy_option); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group form-col-xs">
                                <label class="form-label">SEM</label>
                                <input class="form-control" name="sem" value="<?php echo htmlspecialchars($selected_course['SEM'] ?? '1'); ?>">
                            </div>
                            <div class="form-group">
                                <button class="btn btn-success" type="submit">Save Course</button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-header"><h4>Generate Subject</h4></div>
                    <div class="card-body">
                        <form method="POST" action="" class="form-row">
                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                            <input type="hidden" name="action" value="generate_curriculum">
                            <div class="form-group form-col-xs">
                                <label class="form-label">Course Code</label>
                                <input class="form-control" name="course_code" required value="<?php echo htmlspecialchars($selected_course['COURSE'] ?? ''); ?>">
                            </div>
                            <div class="form-group form-col-md">
                                <label class="form-label">Description</label>
                                <input class="form-control" name="course_desc" required value="<?php echo htmlspecialchars($selected_course['DESC'] ?? ''); ?>">
                            </div>
                            <div class="form-group form-col-sm">
                                <label class="form-label">Major</label>
                                <input class="form-control" name="major" value="<?php echo htmlspecialchars($selected_course['MAJOR'] ?? ''); ?>">
                            </div>
                            <input type="hidden" name="department_id" value="<?php echo (int)($selected_course['department_id'] ?? 0); ?>">
                            <div class="form-group form-col-sm">
                                <label class="form-label">SY</label>
                                <select class="form-control" name="sy" required>
                                    <?php foreach ($school_year_choices as $sy_option): ?>
                                        <option value="<?php echo htmlspecialchars($sy_option); ?>" <?php echo ($selected_course['SY'] ?? '2018-2019') === $sy_option ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($sy_option); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group form-col-xs">
                                <label class="form-label">SEM</label>
                                <input class="form-control" name="sem" value="<?php echo htmlspecialchars($selected_course['SEM'] ?? '1'); ?>">
                            </div>
                            <div class="form-group">
                                <button class="btn btn-primary" type="submit">Generate Subjects per Semester</button>
                            </div>
                        </form>
                    </div>
                </div>

                <?php if ($builder_state): ?>
                    <div class="card">
                        <div class="card-header"><h4>Subject (Editable)</h4></div>
                        <div class="card-body">
                            <p class="mb-3"> You can edit, reorder, add, or remove before final save.</p>
                            <form method="POST" action="" id="curriculumSaveForm">
                                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                <input type="hidden" name="action" value="save_curriculum">
                                <input type="hidden" name="course_code" value="<?php echo htmlspecialchars($builder_state['course_code']); ?>">
                                <input type="hidden" name="course_desc" value="<?php echo htmlspecialchars($builder_state['course_desc']); ?>">
                                <input type="hidden" name="major" value="<?php echo htmlspecialchars($builder_state['major']); ?>">
                                <input type="hidden" name="sy" value="<?php echo htmlspecialchars($builder_state['sy']); ?>">
                                <input type="hidden" name="sem" value="<?php echo htmlspecialchars($builder_state['sem']); ?>">
                                <input type="hidden" name="curriculum_payload" id="curriculumPayload">

                                <div class="builder-grid">
                                    <?php for ($year = 1; $year <= 4; $year++): ?>
                                        <?php foreach ([1, 2] as $term): ?>
                                            <div class="term-card">
                                                <h5><?php echo $year; ?><?php echo $year === 1 ? 'st' : ($year === 2 ? 'nd' : ($year === 3 ? 'rd' : 'th')); ?> Year - <?php echo $term === 1 ? '1st Semester' : '2nd Semester'; ?></h5>
                                                <div class="table-responsive">
                                                    <table class="table table-sm" id="termTableY<?php echo $year; ?>T<?php echo $term; ?>">
                                                        <thead>
                                                            <tr>
                                                                <th>Subject</th><th>Description</th><th>Unit</th><th>Start</th><th>End</th><th>Room</th><th>SK</th><th>Limit</th><th>Action</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php foreach ($builder_state['suggestions'][$year][$term] as $row): ?>
                                                                <tr data-year="<?php echo $year; ?>" data-term="<?php echo $term; ?>">
                                                                    <td><input class="form-control subject" value="<?php echo htmlspecialchars($row['subject']); ?>"></td>
                                                                    <td><input class="form-control desc" value="<?php echo htmlspecialchars($row['desc']); ?>"></td>
                                                                    <td><input class="form-control unit" type="number" step="0.5" value="<?php echo htmlspecialchars((string)$row['unit']); ?>"></td>
                                                                    <td><input class="form-control tstart" value="<?php echo htmlspecialchars($row['tstart']); ?>"></td>
                                                                    <td><input class="form-control tend" value="<?php echo htmlspecialchars($row['tend']); ?>"></td>
                                                                    <td><input class="form-control room" value="<?php echo htmlspecialchars($row['room']); ?>"></td>
                                                                    <td><input class="form-control sk" value="<?php echo htmlspecialchars($row['sk']); ?>"></td>
                                                                    <td><input class="form-control slimit" type="number" value="<?php echo htmlspecialchars((string)$row['limit']); ?>"></td>
                                                                    <td>
                                                                        <span class="row-action"><?php echo htmlspecialchars($row['action']); ?></span><br>
                                                                        <button type="button" class="btn btn-sm btn-danger mt-1" onclick="removeRow(this)">X</button>
                                                                    </td>
                                                                </tr>
                                                            <?php endforeach; ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                                <button type="button" class="btn btn-sm btn-secondary" onclick="addRow(<?php echo $year; ?>, <?php echo $term; ?>)">Add Row</button>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php endfor; ?>
                                </div>

                                <div class="mt-3">
                                    <button class="btn btn-success" type="button" onclick="submitCurriculum()">SAVE</button>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>

                <div id="departmentModal" style="display:none; position:fixed; inset:0; background:rgba(15,23,42,.45); z-index:999; align-items:center; justify-content:center; padding:1rem;">
                    <div class="card" style="width:min(500px, 100%); margin:0;">
                        <div class="card-header" style="display:flex; justify-content:space-between; align-items:center;">
                            <h4 style="margin:0;">Add Department / College</h4>
                            <button type="button" class="btn btn-sm btn-secondary" onclick="closeDepartmentModal()">Close</button>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="" class="form-row">
                                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                <input type="hidden" name="action" value="create_department">
                                <div class="form-group form-col-xs">
                                    <label class="form-label">Department Code *</label>
                                    <input class="form-control" name="department_code" maxlength="20" required placeholder="e.g. COE">
                                </div>
                                <div class="form-group form-col-md">
                                    <label class="form-label">Department Name *</label>
                                    <input class="form-control" name="department_name" maxlength="100" required placeholder="e.g. College of Education">
                                </div>
                                <div class="form-group form-col-full">
                                    <label class="form-label">Description</label>
                                    <input class="form-control" name="department_description" maxlength="255" placeholder="e.g. Handles teacher education and training programs">
                                </div>
                                <div class="form-group">
                                    <button class="btn btn-success" type="submit">Save Department</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        function openDepartmentModal() {
            const modal = document.getElementById('departmentModal');
            if (modal) {
                modal.style.display = 'flex';
            }
        }

        function closeDepartmentModal() {
            const modal = document.getElementById('departmentModal');
            if (modal) {
                modal.style.display = 'none';
            }
        }

        function addRow(year, term) {
            const tbody = document.querySelector('#termTableY' + year + 'T' + term + ' tbody');
            const tr = document.createElement('tr');
            tr.setAttribute('data-year', year);
            tr.setAttribute('data-term', term);
            tr.innerHTML = `
                <td><input class="form-control subject"></td>
                <td><input class="form-control desc"></td>
                <td><input class="form-control unit" type="number" step="0.5" value="3"></td>
                <td><input class="form-control tstart" value="08:00"></td>
                <td><input class="form-control tend" value="09:30"></td>
                <td><input class="form-control room" value="RM10${term}"></td>
                <td><input class="form-control sk" value="D"></td>
                <td><input class="form-control slimit" type="number" value="40"></td>
                <td><span class="row-action">insert</span><br><button type="button" class="btn btn-sm btn-danger mt-1" onclick="removeRow(this)">X</button></td>
            `;
            tbody.appendChild(tr);
        }

        function removeRow(btn) {
            const tr = btn.closest('tr');
            tr.remove();
        }

        function submitCurriculum() {
            const rows = [];
            document.querySelectorAll('table tbody tr').forEach((tr) => {
                rows.push({
                    year: parseInt(tr.getAttribute('data-year'), 10),
                    term: parseInt(tr.getAttribute('data-term'), 10),
                    subject: tr.querySelector('.subject').value.trim(),
                    desc: tr.querySelector('.desc').value.trim(),
                    unit: parseFloat(tr.querySelector('.unit').value || '3'),
                    tstart: tr.querySelector('.tstart').value.trim(),
                    tend: tr.querySelector('.tend').value.trim(),
                    room: tr.querySelector('.room').value.trim(),
                    sk: tr.querySelector('.sk').value.trim(),
                    limit: parseInt(tr.querySelector('.slimit').value || '40', 10)
                });
            });

            for (let year = 1; year <= 4; year++) {
                for (let term = 1; term <= 2; term++) {
                    const items = rows.filter(r => r.year === year && r.term === term && r.subject && r.desc);
                    if (items.length !== 7) {
                        alert(`Each year/semester must contain exactly 7 valid subjects. Missing in Year ${year} Term ${term}.`);
                        return;
                    }
                }
            }

            document.getElementById('curriculumPayload').value = JSON.stringify(rows);
            document.getElementById('curriculumSaveForm').submit();
        }
    </script>
    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
