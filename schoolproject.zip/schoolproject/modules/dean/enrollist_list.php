<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';

require_role('dean');
$current_user = get_logged_in_user();
$flash_messages = get_flash_messages();

$school_years = get_multiple_results("SELECT school_year_id, year_name FROM school_years ORDER BY school_year_id DESC");
$courses = get_multiple_results("SELECT course_id, course_code, course_name FROM courses ORDER BY course_code ASC");

$current_school_year = get_single_result("SELECT school_year_id FROM school_years WHERE is_current = TRUE LIMIT 1");
$current_semester = get_single_result("SELECT semester_id, semester_name FROM semesters WHERE is_current = TRUE LIMIT 1");

$school_year_id = (int)($_GET['school_year_id'] ?? (int)($current_school_year['school_year_id'] ?? 0));
$requested_semester_id = (int)($_GET['semester_id'] ?? 0);
$course_filter_id = (int)($_GET['course_id'] ?? 0);
$year_level_raw = $_GET['year_level'] ?? 0;
if (is_numeric($year_level_raw)) {
    $year_level_filter = (int)$year_level_raw;
} else {
    $year_level_filter = (int)preg_replace('/\D+/', '', (string)$year_level_raw);
}
if ($year_level_filter < 1 || $year_level_filter > 10) {
    $year_level_filter = 0;
}
// Support legacy/bookmarked URLs that used student_name instead of search_name
$search_name = trim((string)($_GET['search_name'] ?? $_GET['student_name'] ?? ''));

$semester_selection = resolve_fixed_semester_selection(
    $school_year_id,
    $requested_semester_id,
    (string)($current_semester['semester_name'] ?? '')
);
$semesters = $semester_selection['options'];
$semester_id = (int)$semester_selection['semester_id'];
$selected_semester_name = trim((string)($semester_selection['semester_name'] ?? ''));

/** Semester IDs for this school year + semester name (applications must match one of these, not a stale semester_id). */
$semester_ids_for_year_term = [];
if ($school_year_id > 0 && $selected_semester_name !== '') {
    $semester_ids_for_year_term = array_values(array_unique(array_map('intval', array_column(
        get_multiple_results(
            'SELECT semester_id FROM semesters WHERE school_year_id = ? AND semester_name = ? ORDER BY semester_id ASC',
            [$school_year_id, $selected_semester_name]
        ),
        'semester_id'
    ))));
}
if (empty($semester_ids_for_year_term) && $semester_id > 0) {
    $semester_ids_for_year_term = [$semester_id];
}

function enrollist_enrollment_applications_table_exists() {
    static $cache = null;
    if ($cache === null) {
        $row = get_single_result("
            SELECT COUNT(*) AS c
            FROM information_schema.tables
            WHERE table_schema = DATABASE() AND table_name = 'enrollment_applications'
        ");
        $cache = ((int)($row['c'] ?? 0)) > 0;
    }
    return $cache;
}

$enrollist_params = [];
$enrollist_where = ["e.status = 'enrolled'"];
$has_search_filters = $course_filter_id > 0 || $year_level_filter > 0 || $search_name !== '';

if ($school_year_id > 0) {
    $enrollist_where[] = "e.school_year_id = ?";
    $enrollist_params[] = $school_year_id;
}

if ($selected_semester_name !== '') {
    $enrollist_where[] = "sem.semester_name = ?";
    $enrollist_params[] = $selected_semester_name;
}

if ($course_filter_id > 0) {
    $enrollist_where[] = "c.course_id = ?";
    $enrollist_params[] = $course_filter_id;
}

$enrollist_rows = [];
if ($has_search_filters) {
    if ($year_level_filter > 0) {
        $enrollist_where[] = "s.year_level = ?";
        $enrollist_params[] = $year_level_filter;
    }
    if ($search_name !== '') {
        $enrollist_where[] = "(u.first_name LIKE ? OR u.last_name LIKE ? OR CONCAT(u.first_name, ' ', u.last_name) LIKE ? OR CONCAT(u.last_name, ', ', u.first_name) LIKE ?)";
        $like = '%' . $search_name . '%';
        $enrollist_params[] = $like;
        $enrollist_params[] = $like;
        $enrollist_params[] = $like;
        $enrollist_params[] = $like;
    }

    $enrollist_rows = get_multiple_results("
        SELECT c.course_id, c.course_code, c.course_name,
               s.student_id, s.student_number, s.year_level,
               u.first_name, u.last_name
        FROM enrollments e
        JOIN students s ON s.student_id = e.student_id
        JOIN users u ON u.user_id = s.user_id
        JOIN courses c ON c.course_id = s.course_id
        JOIN semesters sem ON sem.semester_id = e.semester_id
        WHERE " . implode(' AND ', $enrollist_where) . "
        ORDER BY c.course_code ASC, s.year_level ASC, u.last_name ASC, u.first_name ASC
    ", $enrollist_params);

    // E-Form rows: tie applications to the selected term using semester rows for THIS school year + name
    // (avoids dropping rows when ea.semester_id pointed at another year's semester).
    if (enrollist_enrollment_applications_table_exists()
        && $school_year_id > 0
        && $selected_semester_name !== ''
        && !empty($semester_ids_for_year_term)
    ) {
        $sem_place = implode(',', array_fill(0, count($semester_ids_for_year_term), '?'));
        $app_where = [
            'ea.school_year_id = ?',
            "ea.semester_id IN ($sem_place)",
            "ea.status IN ('submitted', 'reviewed', 'approved')",
            "u_app.status IN ('pending', 'approved')",
            "NOT EXISTS (
                SELECT 1 FROM enrollments e_chk
                JOIN students s_chk ON s_chk.student_id = e_chk.student_id AND s_chk.user_id = ea.user_id
                JOIN semesters sem_chk ON sem_chk.semester_id = e_chk.semester_id
                WHERE e_chk.school_year_id = ea.school_year_id
                  AND sem_chk.semester_name = ?
                  AND e_chk.status = 'enrolled'
            )",
        ];
        $app_params = array_merge([$school_year_id], $semester_ids_for_year_term, [$selected_semester_name]);

        if ($course_filter_id > 0) {
            $app_where[] = 'ea.course_id = ?';
            $app_params[] = $course_filter_id;
        }
        if ($year_level_filter > 0) {
            $app_where[] = 'ea.year_level = ?';
            $app_params[] = $year_level_filter;
        }
        if ($search_name !== '') {
            $app_where[] = "(ea.first_name LIKE ? OR ea.last_name LIKE ? OR CONCAT(ea.first_name, ' ', ea.last_name) LIKE ? OR CONCAT(ea.last_name, ', ', ea.first_name) LIKE ?)";
            $like = '%' . $search_name . '%';
            $app_params[] = $like;
            $app_params[] = $like;
            $app_params[] = $like;
            $app_params[] = $like;
        }

        $pending_rows = get_multiple_results('
            SELECT c.course_id, c.course_code, c.course_name,
                   COALESCE(s_app.student_id, 0) AS student_id,
                   COALESCE(NULLIF(TRIM(s_app.student_number), \'\'), CONCAT(\'Pending-\', ea.application_id)) AS student_number,
                   ea.year_level,
                   ea.first_name,
                   ea.last_name
            FROM enrollment_applications ea
            JOIN users u_app ON u_app.user_id = ea.user_id
            JOIN courses c ON c.course_id = ea.course_id
            LEFT JOIN students s_app ON s_app.user_id = ea.user_id
            WHERE ' . implode(' AND ', $app_where) . '
            ORDER BY c.course_code ASC, ea.year_level ASC, ea.last_name ASC, ea.first_name ASC
        ', $app_params);

        if ($pending_rows) {
            $enrollist_rows = array_merge($enrollist_rows, $pending_rows);
        }
    }

    // Student records (approved account + setup) with no enrollment row for this SY + semester name — still show under filters
    if ($school_year_id > 0 && $selected_semester_name !== '') {
        $stu_where = [
            'u_stu.status IN (\'pending\', \'approved\')',
        ];
        $stu_params = [];

        if ($course_filter_id > 0) {
            $stu_where[] = 's_stu.course_id = ?';
            $stu_params[] = $course_filter_id;
        }
        if ($year_level_filter > 0) {
            $stu_where[] = 's_stu.year_level = ?';
            $stu_params[] = $year_level_filter;
        }
        if ($search_name !== '') {
            $stu_where[] = '(u_stu.first_name LIKE ? OR u_stu.last_name LIKE ? OR CONCAT(u_stu.first_name, \' \', u_stu.last_name) LIKE ? OR CONCAT(u_stu.last_name, \', \', u_stu.first_name) LIKE ?)';
            $like = '%' . $search_name . '%';
            $stu_params[] = $like;
            $stu_params[] = $like;
            $stu_params[] = $like;
            $stu_params[] = $like;
        }

        $stu_where[] = 'NOT EXISTS (
            SELECT 1 FROM enrollments e_st
            JOIN semesters sem_st ON sem_st.semester_id = e_st.semester_id
            WHERE e_st.student_id = s_stu.student_id
              AND e_st.school_year_id = ?
              AND sem_st.semester_name = ?
              AND e_st.status = \'enrolled\'
        )';
        $stu_params[] = $school_year_id;
        $stu_params[] = $selected_semester_name;

        $stu_where[] = 'NOT EXISTS (
            SELECT 1 FROM enrollment_applications ea_d
            JOIN semesters sem_d ON sem_d.semester_id = ea_d.semester_id
                AND sem_d.school_year_id = ea_d.school_year_id
            WHERE ea_d.user_id = u_stu.user_id
              AND ea_d.school_year_id = ?
              AND sem_d.semester_name = ?
        )';
        $stu_params[] = $school_year_id;
        $stu_params[] = $selected_semester_name;

        $student_only_rows = get_multiple_results('
            SELECT c.course_id, c.course_code, c.course_name,
                   s_stu.student_id, s_stu.student_number, s_stu.year_level,
                   u_stu.first_name, u_stu.last_name
            FROM students s_stu
            JOIN users u_stu ON u_stu.user_id = s_stu.user_id
            JOIN roles r_stu ON r_stu.role_id = u_stu.role_id AND r_stu.role_name = \'student\'
            JOIN courses c ON c.course_id = s_stu.course_id
            WHERE ' . implode(' AND ', $stu_where) . '
            ORDER BY c.course_code ASC, s_stu.year_level ASC, u_stu.last_name ASC, u_stu.first_name ASC
        ', $stu_params);

        if ($student_only_rows) {
            $enrollist_rows = array_merge($enrollist_rows, $student_only_rows);
        }
    }
}

// Avoid duplicates when the same person appears from enrollment + E-Form + student record logic
$enrollist_seen_keys = [];
$enrollist_rows_unique = [];
foreach ($enrollist_rows as $row) {
    $sid_key = (string)((int)($row['student_id'] ?? 0));
    $num_key = strtolower(trim((string)($row['student_number'] ?? '')));
    $name_key = strtolower(trim((string)($row['last_name'] ?? '') . '|' . trim((string)($row['first_name'] ?? ''))));
    $dedupe_key = (int)($row['course_id']) . '|' . $sid_key . '|' . $num_key . '|' . $name_key;
    if (isset($enrollist_seen_keys[$dedupe_key])) {
        continue;
    }
    $enrollist_seen_keys[$dedupe_key] = true;
    $enrollist_rows_unique[] = $row;
}
$enrollist_rows = $enrollist_rows_unique;

$enrollist_by_course = [];
foreach ($enrollist_rows as $row) {
    $course_key = (int)$row['course_id'];
    if (!isset($enrollist_by_course[$course_key])) {
        $enrollist_by_course[$course_key] = [
            'course_code' => $row['course_code'],
            'course_name' => $row['course_name'],
            'students' => []
        ];
    }
    $enrollist_by_course[$course_key]['students'][] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <meta name="user-data" content="<?php echo htmlspecialchars(json_encode($current_user)); ?>">
    <title>Course Enrollist List - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo"><a href="<?php echo APP_URL; ?>/modules/dean/dashboard.php">Enchong Dee University Information System</a></div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <?php render_dean_sidebar('enrollist_list'); ?>
        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Enrollist List</h1>
                    <p>Shows students for the filters below: officially enrolled, submitted E-Form for that school year and semester, or registered student accounts not yet enrolled for that term.</p>
                </div>

                <?php if ($flash_messages): ?>
                    <div class="flash-messages mb-3">
                        <?php foreach ($flash_messages as $message): ?>
                            <div class="alert alert-<?php echo $message['type']; ?>">
                                <?php echo htmlspecialchars($message['message']); ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <div class="card mb-4">
                    <div class="card-body">
                        <form method="GET" action="" class="form-row">
                            <div class="form-group">
                                <label class="form-label" for="school_year_id">School Year</label>
                                <select id="school_year_id" name="school_year_id" class="form-control">
                                    <?php foreach ($school_years as $sy): ?>
                                        <option value="<?php echo (int)$sy['school_year_id']; ?>" <?php echo (int)$sy['school_year_id'] === $school_year_id ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($sy['year_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="semester_id">Semester</label>
                                <select id="semester_id" name="semester_id" class="form-control">
                                    <?php foreach ($semesters as $sem): ?>
                                        <option value="<?php echo (int)$sem['semester_id']; ?>" <?php echo (int)$sem['semester_id'] === $semester_id ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($sem['semester_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="course_id">Course</label>
                                <select id="course_id" name="course_id" class="form-control">
                                    <option value="0">All Courses</option>
                                    <?php foreach ($courses as $course): ?>
                                        <option value="<?php echo (int)$course['course_id']; ?>" <?php echo (int)$course['course_id'] === $course_filter_id ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($course['course_code'] . ' - ' . $course['course_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="year_level">Year Level</label>
                                <select id="year_level" name="year_level" class="form-control">
                                    <option value="0">All Year Levels</option>
                                    <?php for ($lvl = 1; $lvl <= 4; $lvl++): ?>
                                        <option value="<?php echo $lvl; ?>" <?php echo $year_level_filter === $lvl ? 'selected' : ''; ?>>
                                            <?php echo $lvl; ?><?php echo $lvl === 1 ? 'st' : ($lvl === 2 ? 'nd' : ($lvl === 3 ? 'rd' : 'th')); ?> Year
                                        </option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="search_name">Student Name</label>
                                <input id="search_name" name="search_name" class="form-control" value="<?php echo htmlspecialchars($search_name); ?>" placeholder="Type first/last name">
                            </div>
                            <div class="form-group" style="align-self:end;">
                                <button type="submit" class="btn btn-primary">Apply Filter</button>
                            </div>
                        </form>
                    </div>
                </div>

                <?php if (!$has_search_filters): ?>
                    <div class="card">
                        <div class="card-body">
                            <p class="text-muted">Use search first (Name, Course, or Year Level) before student enrollist is shown.</p>
                        </div>
                    </div>
                <?php elseif ($enrollist_by_course): ?>
                    <?php foreach ($enrollist_by_course as $course_data): ?>
                        <div class="card mb-4">
                            <div class="card-header">
                                <h4><?php echo htmlspecialchars($course_data['course_code'] . ' - ' . $course_data['course_name']); ?></h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-sm">
                                        <thead>
                                            <tr>
                                                <th>Student Name</th>
                                                <th>Student ID</th>
                                                <th>Year Level</th>
                                                <th>Course Enrolled</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($course_data['students'] as $student): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($student['last_name'] . ', ' . $student['first_name']); ?></td>
                                                    <td><?php echo htmlspecialchars($student['student_number']); ?></td>
                                                    <td><?php echo htmlspecialchars((string)$student['year_level']); ?></td>
                                                    <td><?php echo htmlspecialchars($course_data['course_code']); ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="card">
                        <div class="card-body">
                            <p class="text-muted">No enrolled students.</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
