<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';

require_role('dean');
$current_user = get_logged_in_user();

function dean_semester_type_from_name($semester_name)
{
    $normalized = strtolower(trim((string)$semester_name));
    if (strpos($normalized, 'first') !== false) {
        return 'first';
    }
    if (strpos($normalized, 'second') !== false) {
        return 'second';
    }
    if (strpos($normalized, 'summer') !== false) {
        return 'summer';
    }
    return '';
}

function dean_year_level_label($year_level)
{
    $year_level = (int)$year_level;
    $labels = [
        1 => 'First Year',
        2 => 'Second Year',
        3 => 'Third Year',
        4 => 'Fourth Year',
    ];
    return $labels[$year_level] ?? ($year_level > 0 ? $year_level . ' Year' : 'Year Level Not Set');
}

function dean_fixed_semester_options($school_year_id)
{
    $fixed_semesters = ['First Semester', 'Second Semester', 'Summer'];
    $options = [];

    foreach ($fixed_semesters as $semester_name) {
        $semester = get_single_result("
            SELECT semester_id, semester_name
            FROM semesters
            WHERE school_year_id = ? AND semester_name = ?
            ORDER BY semester_id DESC
            LIMIT 1
        ", [$school_year_id, $semester_name]);

        if (!$semester) {
            $semester = get_single_result("
                SELECT semester_id, semester_name
                FROM semesters
                WHERE semester_name = ?
                ORDER BY is_current DESC, semester_id DESC
                LIMIT 1
            ", [$semester_name]);
        }

        if ($semester) {
            $options[] = [
                'semester_id' => (int)$semester['semester_id'],
                'semester_name' => $semester_name,
            ];
        }
    }

    return $options;
}

$school_year_id = (int)($_GET['school_year_id'] ?? ($_POST['school_year_id'] ?? 0));
$semester_id = (int)($_GET['semester_id'] ?? ($_POST['semester_id'] ?? 0));
$course_id = (int)($_GET['course_id'] ?? ($_POST['course_id'] ?? 0));

$school_years = get_multiple_results("SELECT school_year_id, year_name FROM school_years ORDER BY school_year_id DESC");
$courses = get_multiple_results("SELECT course_id, course_code, course_name FROM courses ORDER BY course_code ASC");
$current_school_year = get_single_result("SELECT school_year_id FROM school_years WHERE is_current = TRUE LIMIT 1");
$current_semester = get_single_result("SELECT semester_id, semester_name FROM semesters WHERE is_current = TRUE LIMIT 1");

if ($school_year_id <= 0) {
    $school_year_id = (int)($current_school_year['school_year_id'] ?? ($school_years[0]['school_year_id'] ?? 0));
}

$semesters = dean_fixed_semester_options($school_year_id);
$selected_semester_name_from_id = '';
if ($semester_id > 0) {
    $semester_lookup = get_single_result("SELECT semester_name FROM semesters WHERE semester_id = ? LIMIT 1", [$semester_id]);
    $selected_semester_name_from_id = trim((string)($semester_lookup['semester_name'] ?? ''));
}

if ($semester_id <= 0 && $current_semester) {
    $selected_semester_name_from_id = trim((string)$current_semester['semester_name']);
}

if ($selected_semester_name_from_id !== '') {
    foreach ($semesters as $semester_option) {
        if ($semester_option['semester_name'] === $selected_semester_name_from_id) {
            $semester_id = (int)$semester_option['semester_id'];
            break;
        }
    }
}

if ($semester_id <= 0 && !empty($semesters)) {
    $semester_id = (int)$semesters[0]['semester_id'];
}
if ($course_id <= 0 && !empty($courses)) {
    foreach ($courses as $course_option) {
        if (($course_option['course_code'] ?? '') === 'BSIT') {
            $course_id = (int) $course_option['course_id'];
            break;
        }
    }
    if ($course_id <= 0) {
        $course_id = (int) $courses[0]['course_id'];
    }
}

$selected_school_year = null;
$selected_semester = null;
foreach ($school_years as $sy_option) {
    if ((int)$sy_option['school_year_id'] === $school_year_id) {
        $selected_school_year = $sy_option;
        break;
    }
}
foreach ($semesters as $sem_option) {
    if ((int)$sem_option['semester_id'] === $semester_id) {
        $selected_semester = $sem_option;
        break;
    }
}
$selected_semester_name = trim((string)($selected_semester['semester_name'] ?? ''));
$selected_semester_type = dean_semester_type_from_name($selected_semester_name);

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    if (!verify_csrf_token($csrf_token)) {
        flash_message('error', 'Invalid request token.');
        redirect('modules/dean/add_schedule.php?school_year_id=' . $school_year_id . '&semester_id=' . $semester_id . '&course_id=' . $course_id);
    }

    try {
        $conn = get_db_connection();
        $action = $_POST['action'] ?? 'add_schedule';

        if ($action === 'add_schedule') {
            $subject_id = (int) ($_POST['subject_id'] ?? 0);
            $teacher_id = (int) ($_POST['teacher_id'] ?? 0);
            $section = sanitize_input($_POST['section'] ?? '');
            $max_students = (int) ($_POST['max_students'] ?? 40);
            $day_of_week = sanitize_input($_POST['day_of_week'] ?? '');
            $start_time = sanitize_input($_POST['start_time'] ?? '');
            $end_time = sanitize_input($_POST['end_time'] ?? '');
            $room = sanitize_input($_POST['room'] ?? '');

            if ($subject_id <= 0 || $teacher_id <= 0 || $school_year_id <= 0 || $semester_id <= 0 || $section === '' || $day_of_week === '' || $start_time === '' || $end_time === '') {
                flash_message('error', 'Please complete all required assignment fields.');
            } else {
                $conn->beginTransaction();
                $stmt = $conn->prepare("
                    INSERT INTO subject_offerings (subject_id, teacher_id, semester_id, school_year_id, section, max_students, current_students, status)
                    VALUES (?, ?, ?, ?, ?, ?, 0, 'open')
                ");
                $stmt->execute([$subject_id, $teacher_id, $semester_id, $school_year_id, $section, max(1, $max_students)]);
                $offering_id = (int) $conn->lastInsertId();

                $sched_stmt = $conn->prepare("
                    INSERT INTO schedules (offering_id, day_of_week, start_time, end_time, room)
                    VALUES (?, ?, ?, ?, ?)
                ");
                $sched_stmt->execute([$offering_id, $day_of_week, $start_time, $end_time, $room ?: null]);
                if ($conn->inTransaction()) {
                    $conn->commit();
                }
                flash_message('success', 'Teacher-subject schedule assigned successfully.');
            }
        } elseif ($action === 'enroll_student_subject') {
            $enrollment_id = (int) ($_POST['enrollment_id'] ?? 0);
            $offering_id = (int) ($_POST['offering_id'] ?? 0);

            if ($enrollment_id <= 0 || $offering_id <= 0 || $school_year_id <= 0 || $semester_id <= 0) {
                flash_message('error', 'Please select a student and subject offering.');
            } else {
                $conn->beginTransaction();

                $enrollment_stmt = $conn->prepare("
                    SELECT e.enrollment_id, e.student_id, e.school_year_id, e.semester_id, e.total_units,
                           s.course_id, s.year_level
                    FROM enrollments e
                    JOIN students s ON s.student_id = e.student_id
                    JOIN semesters sem ON sem.semester_id = e.semester_id
                    WHERE (
                            e.enrollment_id = ? AND e.school_year_id = ? AND e.semester_id = ? AND e.status = 'enrolled'
                       )
                       OR (
                            e.enrollment_id = ?
                            AND e.school_year_id = ?
                            AND sem.semester_name = ?
                            AND e.status = 'enrolled'
                        )
                ");
                $enrollment_stmt->execute([$enrollment_id, $school_year_id, $semester_id, $enrollment_id, $school_year_id, $selected_semester_name]);
                $enrollment = $enrollment_stmt->fetch(PDO::FETCH_ASSOC);

                $offering_stmt = $conn->prepare("
                    SELECT so.offering_id, so.teacher_id, so.max_students, so.current_students, so.status,
                           sub.units, sub.subject_code, sub.subject_name, sub.course_id, sub.year_level, sub.semester_type
                    FROM subject_offerings so
                    JOIN subjects sub ON so.subject_id = sub.subject_id
                    JOIN semesters sem ON sem.semester_id = so.semester_id
                    WHERE so.offering_id = ? AND so.school_year_id = ?
                      AND (so.semester_id = ? OR sem.semester_name = ?)
                ");
                $offering_stmt->execute([$offering_id, $school_year_id, $semester_id, $selected_semester_name]);
                $offering = $offering_stmt->fetch(PDO::FETCH_ASSOC);

                if (!$enrollment) {
                    throw new Exception('Official enrollment record not found for the selected student and term.');
                }

                if (!$offering) {
                    throw new Exception('Subject offering not found for the selected term.');
                }

                if ((int)$offering['course_id'] !== (int)$enrollment['course_id'] || (int)$offering['year_level'] !== (int)$enrollment['year_level']) {
                    throw new Exception('This subject does not match the selected student course and year level.');
                }

                if ($selected_semester_type !== '' && $offering['semester_type'] !== $selected_semester_type) {
                    throw new Exception('This subject does not belong to the selected semester.');
                }

                if ($offering['status'] !== 'open') {
                    throw new Exception('Selected subject offering is not open.');
                }

                if (empty($offering['teacher_id'])) {
                    throw new Exception('Please assign a teacher first before enrolling the student.');
                }

                if ((int) $offering['current_students'] >= (int) $offering['max_students']) {
                    throw new Exception('Selected subject offering is already full.');
                }

                $existing_load_stmt = $conn->prepare("
                    SELECT load_id
                    FROM student_subject_loads
                    WHERE enrollment_id = ? AND offering_id = ?
                    LIMIT 1
                ");
                $existing_load_stmt->execute([$enrollment_id, $offering_id]);
                $existing_load = $existing_load_stmt->fetch(PDO::FETCH_ASSOC);

                if ($existing_load) {
                    throw new Exception('Student is already enrolled in this subject offering.');
                }

                $insert_load = $conn->prepare("
                    INSERT INTO student_subject_loads (enrollment_id, offering_id, status, final_grade, remarks)
                    VALUES (?, ?, 'enrolled', NULL, NULL)
                ");
                $insert_load->execute([$enrollment_id, $offering_id]);

                $conn->prepare("
                    UPDATE subject_offerings
                    SET current_students = current_students + 1
                    WHERE offering_id = ?
                ")->execute([$offering_id]);

                $conn->prepare("
                    UPDATE enrollments
                    SET total_units = COALESCE(total_units, 0) + ?, updated_at = NOW()
                    WHERE enrollment_id = ?
                ")->execute([(float) $offering['units'], $enrollment_id]);

                if ($conn->inTransaction()) {
                    $conn->commit();
                }
                flash_message('success', 'Student enrolled in subject successfully.');
            }
        }
    } catch (Exception $e) {
        if (isset($conn) && $conn instanceof PDO && $conn->inTransaction()) {
            $conn->rollBack();
        }
        error_log('Dean add schedule error: ' . $e->getMessage());
        flash_message('error', $e->getMessage());
    }

    redirect('modules/dean/add_schedule.php?school_year_id=' . $school_year_id . '&semester_id=' . $semester_id . '&course_id=' . $course_id);
}

$subjects = get_multiple_results("
    SELECT subject_id, subject_code, subject_name, units, year_level, semester_type
    FROM subjects
    WHERE (? <= 0 OR course_id = ?)
      AND (? = '' OR semester_type = ?)
    ORDER BY year_level ASC, FIELD(semester_type, 'first', 'second', 'summer'), subject_code ASC
", [$course_id, $course_id, $selected_semester_type, $selected_semester_type]);
$teachers = get_multiple_results("
    SELECT t.teacher_id, u.first_name, u.last_name
    FROM teachers t
    JOIN users u ON u.user_id = t.user_id
    ORDER BY u.last_name, u.first_name
");
$official_enrollments = get_multiple_results("
    SELECT e.enrollment_id, s.student_number, u.first_name, u.last_name, s.course_id, s.year_level,
           c.course_code, c.course_name, e.total_units,
           sy.year_name, sem.semester_name,
           CASE
               WHEN e.school_year_id = ?
                    AND sem.semester_name = ?
                    AND (? <= 0 OR s.course_id = ?)
               THEN 1 ELSE 0
           END AS matches_filter
    FROM enrollments e
    JOIN students s ON s.student_id = e.student_id
    JOIN users u ON u.user_id = s.user_id
    LEFT JOIN courses c ON c.course_id = s.course_id
    JOIN school_years sy ON sy.school_year_id = e.school_year_id
    JOIN semesters sem ON sem.semester_id = e.semester_id
    WHERE e.status = 'enrolled'
    ORDER BY matches_filter DESC, u.last_name, u.first_name
", [$school_year_id, $selected_semester_name, $course_id, $course_id]);
$available_offerings = get_multiple_results("
    SELECT so.offering_id, so.section, so.max_students, so.current_students, sub.subject_code, sub.subject_name,
           sub.units, sub.year_level, sub.semester_type,
           c.course_code, CONCAT(u.last_name, ', ', u.first_name) AS teacher_name
    FROM subject_offerings so
    JOIN subjects sub ON sub.subject_id = so.subject_id
    JOIN semesters sem ON sem.semester_id = so.semester_id
    LEFT JOIN courses c ON c.course_id = sub.course_id
    JOIN teachers t ON t.teacher_id = so.teacher_id
    JOIN users u ON u.user_id = t.user_id
    WHERE so.school_year_id = ? AND so.status = 'open'
      AND (so.semester_id = ? OR sem.semester_name = ?)
      AND (? <= 0 OR sub.course_id = ?)
      AND (? = '' OR sub.semester_type = ?)
    ORDER BY sub.year_level ASC, sub.subject_code, so.section
", [$school_year_id, $semester_id, $selected_semester_name, $course_id, $course_id, $selected_semester_type, $selected_semester_type]);
$subject_offering_options = get_multiple_results("
    SELECT
        sub.subject_id,
        sub.subject_code,
        sub.subject_name,
        sub.units,
        sub.course_id,
        sub.year_level,
        sub.semester_type,
        so.offering_id,
        so.teacher_id,
        so.section,
        so.max_students,
        so.current_students,
        so.status AS offering_status,
        CONCAT(u.last_name, ', ', u.first_name) AS teacher_name
    FROM subjects sub
    LEFT JOIN subject_offerings so
        ON so.subject_id = sub.subject_id
       AND so.school_year_id = ?
       AND so.status = 'open'
       AND so.semester_id IN (
            SELECT semester_id
            FROM semesters
            WHERE semester_name = ?
       )
    LEFT JOIN teachers t ON t.teacher_id = so.teacher_id
    LEFT JOIN users u ON u.user_id = t.user_id
    WHERE (? <= 0 OR sub.course_id = ?)
      AND (? = '' OR sub.semester_type = ?)
    ORDER BY sub.year_level ASC, sub.subject_code, so.section
", [$school_year_id, $selected_semester_name, $course_id, $course_id, $selected_semester_type, $selected_semester_type]);
$subject_load_rows = get_multiple_results("
    SELECT e.enrollment_id, s.student_number, CONCAT(u.last_name, ', ', u.first_name) AS student_name,
           c.course_code, sub.subject_code, sub.subject_name, so.section, loadrec.status
    FROM student_subject_loads loadrec
    JOIN enrollments e ON e.enrollment_id = loadrec.enrollment_id
    JOIN students s ON s.student_id = e.student_id
    JOIN users u ON u.user_id = s.user_id
    LEFT JOIN courses c ON c.course_id = s.course_id
    JOIN subject_offerings so ON so.offering_id = loadrec.offering_id
    JOIN subjects sub ON sub.subject_id = so.subject_id
    JOIN semesters sem ON sem.semester_id = e.semester_id
    WHERE e.school_year_id = ?
      AND sem.semester_name = ?
      AND (? <= 0 OR s.course_id = ?)
    ORDER BY student_name, sub.subject_code
", [$school_year_id, $selected_semester_name, $course_id, $course_id]);
$flash_messages = get_flash_messages();
$selected_course = null;
$selectable_offerings = [];
$unavailable_subjects = [];
$official_enrollment_debug = get_multiple_results("
    SELECT s.student_number, CONCAT(u.last_name, ', ', u.first_name) AS student_name,
           c.course_code, sy.year_name, sem.semester_name
    FROM enrollments e
    JOIN students s ON s.student_id = e.student_id
    JOIN users u ON u.user_id = s.user_id
    LEFT JOIN courses c ON c.course_id = s.course_id
    JOIN school_years sy ON sy.school_year_id = e.school_year_id
    JOIN semesters sem ON sem.semester_id = e.semester_id
    WHERE e.status = 'enrolled'
    ORDER BY sy.school_year_id DESC, sem.semester_id ASC, u.last_name, u.first_name
");
$matching_official_enrollments = [];
$other_official_enrollments = [];
foreach ($courses as $course_option) {
    if ((int) $course_option['course_id'] === $course_id) {
        $selected_course = $course_option;
        break;
    }
}
foreach ($subject_offering_options as $offering_option) {
    if (!empty($offering_option['offering_id']) && !empty($offering_option['teacher_id'])) {
        $selectable_offerings[] = $offering_option;
    } else {
        $unavailable_subjects[] = $offering_option;
    }
}
foreach ($official_enrollments as $enrollment_option) {
    if (!empty($enrollment_option['matches_filter'])) {
        $matching_official_enrollments[] = $enrollment_option;
    } else {
        $other_official_enrollments[] = $enrollment_option;
    }
}

$subjects_by_year = [];
foreach ($subject_offering_options as $subject_row) {
    $year_key = (int)$subject_row['year_level'];
    $semester_key = $subject_row['semester_type'] ?: 'other';
    if (!isset($subjects_by_year[$year_key])) {
        $subjects_by_year[$year_key] = [];
    }
    if (!isset($subjects_by_year[$year_key][$semester_key])) {
        $subjects_by_year[$year_key][$semester_key] = [];
    }
    $subjects_by_year[$year_key][$semester_key][] = $subject_row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <title>Dean Add Schedule - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo"><a href="<?php echo APP_URL; ?>/modules/dean/dashboard.php">Enchong Dee University Information System</a></div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <?php render_dean_sidebar('add_schedule'); ?>
        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Add Schedule</h1>
                    <p>Assign teacher-subject schedules for the selected term.</p>
                </div>

                <?php if ($flash_messages): ?>
                    <div class="flash-messages mb-3">
                        <?php foreach ($flash_messages as $message): ?>
                            <div class="alert alert-<?php echo $message['type']; ?>">
                                <?php echo htmlspecialchars($message['message']); ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <div class="card mb-4">
                    <div class="card-body">
                        <form method="GET" action="" class="form-row">
                            <div class="form-group">
                                <label class="form-label" for="school_year_id">School Year</label>
                                <select id="school_year_id" name="school_year_id" class="form-control" required>
                                    <?php foreach ($school_years as $sy): ?>
                                        <option value="<?php echo (int) $sy['school_year_id']; ?>" <?php echo (int) $sy['school_year_id'] === $school_year_id ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($sy['year_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="semester_id">Semester</label>
                                <select id="semester_id" name="semester_id" class="form-control" required>
                                    <?php foreach ($semesters as $sem): ?>
                                        <option value="<?php echo (int) $sem['semester_id']; ?>" <?php echo (int) $sem['semester_id'] === $semester_id ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($sem['semester_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="course_id">Course</label>
                                <select id="course_id" name="course_id" class="form-control" required>
                                    <?php foreach ($courses as $course): ?>
                                        <option value="<?php echo (int) $course['course_id']; ?>" <?php echo (int) $course['course_id'] === $course_id ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($course['course_code'] . ' - ' . $course['course_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group" style="align-self:end;">
                                <button type="submit" class="btn btn-primary">Apply Filter</button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-header"><h4>Teacher-Subject Schedule Form</h4></div>
                    <div class="card-body">
                        <form method="POST" action="" class="form-row">
                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                            <input type="hidden" name="action" value="add_schedule">
                            <input type="hidden" name="school_year_id" value="<?php echo $school_year_id; ?>">
                            <input type="hidden" name="semester_id" value="<?php echo $semester_id; ?>">
                            <input type="hidden" name="course_id" value="<?php echo $course_id; ?>">

                            <div class="form-group">
                                <label for="subject_id" class="form-label">Subject</label>
                                <select id="subject_id" name="subject_id" class="form-control" required>
                                    <option value="">Select Subject</option>
                                    <?php
                                    $current_subject_group = '';
                                    foreach ($subjects as $sub):
                                        $group_label = dean_year_level_label($sub['year_level']) . ' - ' . ucfirst($sub['semester_type']) . ' Semester';
                                        if ($group_label !== $current_subject_group):
                                            if ($current_subject_group !== '') {
                                                echo '</optgroup>';
                                            }
                                            $current_subject_group = $group_label;
                                            echo '<optgroup label="' . htmlspecialchars($group_label) . '">';
                                        endif;
                                    ?>
                                        <option value="<?php echo (int) $sub['subject_id']; ?>">
                                            <?php echo htmlspecialchars($sub['subject_code'] . ' - ' . $sub['subject_name'] . ' (' . rtrim(rtrim((string)$sub['units'], '0'), '.') . ' units)'); ?>
                                        </option>
                                    <?php endforeach; ?>
                                    <?php if ($current_subject_group !== ''): ?></optgroup><?php endif; ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="teacher_id" class="form-label">Teacher</label>
                                <select id="teacher_id" name="teacher_id" class="form-control" required>
                                    <option value="">Select Teacher</option>
                                    <?php foreach ($teachers as $teacher): ?>
                                        <option value="<?php echo (int) $teacher['teacher_id']; ?>">
                                            <?php echo htmlspecialchars($teacher['last_name'] . ', ' . $teacher['first_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="section" class="form-label">Section</label>
                                <input type="text" id="section" name="section" class="form-control" placeholder="e.g. A" required>
                            </div>

                            <div class="form-group">
                                <label for="max_students" class="form-label">Max Students</label>
                                <input type="number" id="max_students" name="max_students" class="form-control" min="1" value="40" required>
                            </div>

                            <div class="form-group">
                                <label for="day_of_week" class="form-label">Day</label>
                                <select id="day_of_week" name="day_of_week" class="form-control" required>
                                    <option value="">Select Day</option>
                                    <option value="monday">Monday</option>
                                    <option value="tuesday">Tuesday</option>
                                    <option value="wednesday">Wednesday</option>
                                    <option value="thursday">Thursday</option>
                                    <option value="friday">Friday</option>
                                    <option value="saturday">Saturday</option>
                                    <option value="sunday">Sunday</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="start_time" class="form-label">Start</label>
                                <input type="time" id="start_time" name="start_time" class="form-control" required>
                            </div>

                            <div class="form-group">
                                <label for="end_time" class="form-label">End</label>
                                <input type="time" id="end_time" name="end_time" class="form-control" required>
                            </div>

                            <div class="form-group">
                                <label for="room" class="form-label">Room</label>
                                <input type="text" id="room" name="room" class="form-control" placeholder="e.g. AG208">
                            </div>

                            <div class="form-group" style="align-self:end;">
                                <button type="submit" class="btn btn-success">Add Schedule</button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-header"><h4>Enroll Student in Subject</h4></div>
                    <div class="card-body">
                        <?php if (!$matching_official_enrollments): ?>
                            <div class="alert alert-warning mb-3">
                                No official student enrollment matches the selected filters.
                                Current filter:
                                <?php echo htmlspecialchars(($selected_course['course_code'] ?? 'Course') . ' / ' . ($school_year_id ? ($school_years[array_search($school_year_id, array_column($school_years, 'school_year_id'))]['year_name'] ?? 'Unknown SY') : 'No SY') . ' / ' . ($semester_id ? ($semesters[array_search($semester_id, array_column($semesters, 'semester_id'))]['semester_name'] ?? 'Unknown Semester') : 'No Semester')); ?>.
                            </div>
                            <?php if ($official_enrollment_debug): ?>
                                <div class="alert alert-info mb-3">
                                    Official students currently in the database:
                                    <?php
                                    $debug_labels = [];
                                    foreach ($official_enrollment_debug as $debug_row) {
                                        $debug_labels[] = $debug_row['student_number'] . ' - ' . $debug_row['student_name'] . ' / ' . ($debug_row['course_code'] ?: 'No Course') . ' / ' . $debug_row['year_name'] . ' / ' . $debug_row['semester_name'];
                                    }
                                    echo htmlspecialchars(implode('; ', $debug_labels));
                                    ?>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                        <form method="POST" action="" class="form-row">
                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                            <input type="hidden" name="action" value="enroll_student_subject">
                            <input type="hidden" name="school_year_id" value="<?php echo $school_year_id; ?>">
                            <input type="hidden" name="semester_id" value="<?php echo $semester_id; ?>">
                            <input type="hidden" name="course_id" value="<?php echo $course_id; ?>">

                            <div class="form-group">
                                <label for="enrollment_id" class="form-label">Official Student Enrollment</label>
                                <select id="enrollment_id" name="enrollment_id" class="form-control" required>
                                    <option value="">Select Student</option>
                                    <?php if ($matching_official_enrollments): ?>
                                        <optgroup label="Matches Current Filter">
                                            <?php foreach ($matching_official_enrollments as $enrollment): ?>
                                                <option
                                                    value="<?php echo (int) $enrollment['enrollment_id']; ?>"
                                                    data-course-id="<?php echo (int)$enrollment['course_id']; ?>"
                                                    data-year-level="<?php echo (int)$enrollment['year_level']; ?>"
                                                >
                                                    <?php echo htmlspecialchars($enrollment['student_number'] . ' - ' . $enrollment['last_name'] . ', ' . $enrollment['first_name'] . ' / ' . ($enrollment['course_code'] ?: 'No Course') . ' / ' . dean_year_level_label($enrollment['year_level'])); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </optgroup>
                                    <?php endif; ?>
                                    <?php if ($other_official_enrollments): ?>
                                        <optgroup label="Other Official Students">
                                            <?php foreach ($other_official_enrollments as $enrollment): ?>
                                                <option value="" disabled>
                                                    <?php echo htmlspecialchars($enrollment['student_number'] . ' - ' . $enrollment['last_name'] . ', ' . $enrollment['first_name'] . ' / ' . ($enrollment['course_code'] ?: 'No Course') . ' / ' . $enrollment['year_name'] . ' / ' . $enrollment['semester_name']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </optgroup>
                                    <?php endif; ?>
                                </select>
                                <small class="text-muted">
                                    Students from other school year / semester combinations are shown for reference, but only matching official enrollments can be selected.
                                </small>
                            </div>

                            <div class="form-group">
                                <label for="offering_id" class="form-label">Subject Offering</label>
                                <select id="offering_id" name="offering_id" class="form-control" required>
                                    <option value="">Select Offering</option>
                                    <?php
                                    $current_offering_group = '';
                                    foreach ($selectable_offerings as $offering):
                                        $group_label = dean_year_level_label($offering['year_level']) . ' - ' . ucfirst($offering['semester_type']) . ' Semester';
                                        if ($group_label !== $current_offering_group):
                                            if ($current_offering_group !== '') {
                                                echo '</optgroup>';
                                            }
                                            $current_offering_group = $group_label;
                                            echo '<optgroup label="' . htmlspecialchars($group_label) . '">';
                                        endif;
                                    ?>
                                        <option
                                            value="<?php echo (int) $offering['offering_id']; ?>"
                                            data-course-id="<?php echo (int)$offering['course_id']; ?>"
                                            data-year-level="<?php echo (int)$offering['year_level']; ?>"
                                        >
                                            <?php echo htmlspecialchars(
                                                $offering['subject_code'] . ' - ' . $offering['subject_name'] .
                                                ' / Section ' . $offering['section'] .
                                                ' / ' . ($offering['teacher_name'] ?: 'No Teacher')
                                            ); ?>
                                        </option>
                                    <?php endforeach; ?>
                                    <?php if ($current_offering_group !== ''): ?></optgroup><?php endif; ?>
                                </select>
                                <small class="text-muted">
                                    Select a student first to show only subjects for that student's course and year level.
                                </small>
                            </div>

                            <div class="form-group" style="align-self:end;">
                                <button type="submit" class="btn btn-success">Enroll Student</button>
                            </div>
                        </form>
                        <div id="year-level-filter-note" class="alert alert-info mt-3" style="display:none;"></div>

                        <div class="mt-4">
                            <?php if ($subjects_by_year): ?>
                                <div class="card mb-3">
                                    <div class="card-header">
                                        <h4>Subjects by Year Level and Semester</h4>
                                    </div>
                                    <div class="card-body">
                                        <p class="text-muted">Choose a student above to focus this list on that student's year level.</p>
                                        <?php foreach ($subjects_by_year as $year_level => $semester_groups): ?>
                                            <div class="subject-year-block" data-year-level="<?php echo (int)$year_level; ?>">
                                                <h4><?php echo htmlspecialchars(dean_year_level_label($year_level)); ?></h4>
                                                <?php foreach (['first' => 'First Semester', 'second' => 'Second Semester', 'summer' => 'Summer'] as $semester_type => $semester_label): ?>
                                                    <?php if (empty($semester_groups[$semester_type])) { continue; } ?>
                                                    <h5><?php echo htmlspecialchars($semester_label); ?></h5>
                                                    <div class="table-responsive mb-3">
                                                        <table class="table table-sm">
                                                            <thead>
                                                                <tr>
                                                                    <th>Subject Code</th>
                                                                    <th>Subject Description</th>
                                                                    <th>Units</th>
                                                                    <th>Section</th>
                                                                    <th>Teacher</th>
                                                                    <th>Status</th>
                                                                    <th>Action</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php foreach ($semester_groups[$semester_type] as $subject_row): ?>
                                                                    <?php
                                                                    $can_enroll = !empty($subject_row['offering_id']) && !empty($subject_row['teacher_id']);
                                                                    $status_text = $can_enroll
                                                                        ? ucfirst($subject_row['offering_status'])
                                                                        : (!empty($subject_row['offering_id']) ? 'Teacher not assigned' : 'Not yet offered');
                                                                    ?>
                                                                    <tr data-course-id="<?php echo (int)$subject_row['course_id']; ?>" data-year-level="<?php echo (int)$subject_row['year_level']; ?>">
                                                                        <td><?php echo htmlspecialchars($subject_row['subject_code']); ?></td>
                                                                        <td><?php echo htmlspecialchars($subject_row['subject_name']); ?></td>
                                                                        <td><?php echo htmlspecialchars((string)$subject_row['units']); ?></td>
                                                                        <td><?php echo htmlspecialchars($subject_row['section'] ?: 'Not yet assigned'); ?></td>
                                                                        <td><?php echo htmlspecialchars($subject_row['teacher_name'] ?: 'Not yet assigned'); ?></td>
                                                                        <td><?php echo htmlspecialchars($status_text); ?></td>
                                                                        <td>
                                                                            <?php if ($can_enroll): ?>
                                                                                <button type="button" class="btn btn-sm btn-primary choose-offering-btn" data-offering-id="<?php echo (int)$subject_row['offering_id']; ?>">Select</button>
                                                                            <?php else: ?>
                                                                                <span class="text-muted">Add schedule first</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                <?php endforeach; ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <?php if ($unavailable_subjects): ?>
                                <div class="alert alert-warning mb-3">
                                    The following <?php echo htmlspecialchars($selected_course['course_code'] ?? 'selected'); ?> subjects still need a schedule or teacher before they can be enrolled:
                                    <?php
                                    $subject_labels = [];
                                    foreach ($unavailable_subjects as $missing_subject) {
                                        $reason = !empty($missing_subject['offering_id']) ? 'teacher not assigned' : 'no schedule yet';
                                        $subject_labels[] = $missing_subject['subject_code'] . ' - ' . $missing_subject['subject_name'] . ' (' . $reason . ')';
                                    }
                                    echo htmlspecialchars(implode(', ', $subject_labels));
                                    ?>
                                </div>
                            <?php endif; ?>
                            <?php if ($subject_load_rows): ?>
                                <div class="table-responsive">
                                    <table class="table table-sm">
                                        <thead>
                                            <tr>
                                                <th>Student</th>
                                                <th>Course</th>
                                                <th>Subject</th>
                                                <th>Section</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($subject_load_rows as $row): ?>
                                                <tr>
                                                    <td>
                                                        <?php echo htmlspecialchars($row['student_name']); ?><br>
                                                        <small class="text-muted"><?php echo htmlspecialchars($row['student_number']); ?></small>
                                                    </td>
                                                    <td><?php echo htmlspecialchars($row['course_code'] ?: 'Not assigned'); ?></td>
                                                    <td><?php echo htmlspecialchars($row['subject_code'] . ' - ' . $row['subject_name']); ?></td>
                                                    <td><?php echo htmlspecialchars($row['section']); ?></td>
                                                    <td><?php echo htmlspecialchars(ucfirst($row['status'])); ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php else: ?>
                                <p class="text-muted">No student subject loads for the selected term yet.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
    <script>
        (function () {
            const enrollmentSelect = document.getElementById('enrollment_id');
            const offeringSelect = document.getElementById('offering_id');
            const filterNote = document.getElementById('year-level-filter-note');
            const yearBlocks = Array.from(document.querySelectorAll('.subject-year-block'));
            const offeringOptions = offeringSelect ? Array.from(offeringSelect.querySelectorAll('option[data-year-level]')) : [];

            function filterSubjectsForStudent() {
                if (!enrollmentSelect || !offeringSelect) {
                    return;
                }

                const selected = enrollmentSelect.options[enrollmentSelect.selectedIndex];
                const yearLevel = selected ? selected.getAttribute('data-year-level') : '';
                const courseId = selected ? selected.getAttribute('data-course-id') : '';

                offeringSelect.value = '';

                if (!yearLevel || !courseId) {
                    offeringOptions.forEach(option => {
                        option.hidden = true;
                        option.disabled = true;
                    });
                    yearBlocks.forEach(block => {
                        block.style.display = '';
                    });
                    if (filterNote) {
                        filterNote.style.display = 'none';
                    }
                    return;
                }

                let visibleOfferings = 0;
                offeringOptions.forEach(option => {
                    const matches = option.getAttribute('data-year-level') === yearLevel
                        && option.getAttribute('data-course-id') === courseId;
                    option.hidden = !matches;
                    option.disabled = !matches;
                    if (matches) {
                        visibleOfferings += 1;
                    }
                });

                yearBlocks.forEach(block => {
                    block.style.display = block.getAttribute('data-year-level') === yearLevel ? '' : 'none';
                });

                if (filterNote) {
                    filterNote.style.display = '';
                    filterNote.textContent = visibleOfferings > 0
                        ? 'Showing only subjects for the selected student year level. Available offerings: ' + visibleOfferings + '.'
                        : 'No open subject offerings match this student year level yet. Add a schedule first.';
                }
            }

            document.querySelectorAll('.choose-offering-btn').forEach(button => {
                button.addEventListener('click', () => {
                    if (!offeringSelect) {
                        return;
                    }
                    const offeringId = button.getAttribute('data-offering-id');
                    const option = offeringSelect.querySelector('option[value="' + offeringId + '"]');
                    if (option && !option.disabled) {
                        offeringSelect.value = offeringId;
                        offeringSelect.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }
                });
            });

            if (enrollmentSelect) {
                enrollmentSelect.addEventListener('change', filterSubjectsForStudent);
                filterSubjectsForStudent();
            }
        })();
    </script>
    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
