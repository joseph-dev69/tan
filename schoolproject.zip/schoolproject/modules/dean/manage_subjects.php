<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';

require_role('dean');
$current_user = get_logged_in_user();

$flash_messages = get_flash_messages();

$courses = get_multiple_results("SELECT course_id, course_code, course_name FROM courses ORDER BY course_code ASC");
$editing_id = (int)($_GET['edit_id'] ?? 0);
$editing_subject = null;

if ($editing_id > 0) {
    $editing_subject = get_single_result("SELECT * FROM subjects WHERE subject_id = ? LIMIT 1", [$editing_id]);
    if (!$editing_subject) {
        $editing_id = 0;
    }
}

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    $action = $_POST['action'] ?? '';

    if (!verify_csrf_token($csrf_token)) {
        flash_message('error', 'Invalid request token.');
        redirect('modules/dean/manage_subjects.php');
    }

    try {
        if ($action === 'create' || $action === 'update') {
            $subject_id = (int)($_POST['subject_id'] ?? 0);
            $subject_code = strtoupper(trim(sanitize_input($_POST['subject_code'] ?? '')));
            $subject_name = trim(sanitize_input($_POST['subject_name'] ?? ''));
            $description = trim(sanitize_input($_POST['description'] ?? ''));
            $units = (float)($_POST['units'] ?? 1);
            $lecture_hours = (float)($_POST['lecture_hours'] ?? 0);
            $lab_hours = (float)($_POST['lab_hours'] ?? 0);
            $course_id = (int)($_POST['course_id'] ?? 0);
            $year_level = (int)($_POST['year_level'] ?? 1);
            $semester_type = sanitize_input($_POST['semester_type'] ?? 'first');

            if ($subject_code === '' || $subject_name === '' || $course_id <= 0 || $year_level <= 0 || !in_array($semester_type, ['first', 'second', 'summer'], true)) {
                flash_message('error', 'Please complete required subject fields.');
            } else {
                if ($action === 'create') {
                    $exists = get_single_result("SELECT subject_id FROM subjects WHERE subject_code = ? LIMIT 1", [$subject_code]);
                    if ($exists) {
                        flash_message('error', 'Subject code already exists.');
                    } else {
                        insert_record('subjects', [
                            'subject_code' => $subject_code,
                            'subject_name' => $subject_name,
                            'description' => $description ?: null,
                            'units' => max(0.5, $units),
                            'lecture_hours' => max(0, $lecture_hours),
                            'lab_hours' => max(0, $lab_hours),
                            'course_id' => $course_id,
                            'year_level' => $year_level,
                            'semester_type' => $semester_type,
                        ]);
                        flash_message('success', 'Subject added successfully.');
                    }
                } else {
                    if ($subject_id <= 0) {
                        flash_message('error', 'Invalid subject selected.');
                    } else {
                        $exists = get_single_result("SELECT subject_id FROM subjects WHERE subject_code = ? AND subject_id <> ? LIMIT 1", [$subject_code, $subject_id]);
                        if ($exists) {
                            flash_message('error', 'Subject code already exists.');
                        } else {
                            update_record('subjects', [
                                'subject_code' => $subject_code,
                                'subject_name' => $subject_name,
                                'description' => $description ?: null,
                                'units' => max(0.5, $units),
                                'lecture_hours' => max(0, $lecture_hours),
                                'lab_hours' => max(0, $lab_hours),
                                'course_id' => $course_id,
                                'year_level' => $year_level,
                                'semester_type' => $semester_type,
                            ], ['subject_id' => $subject_id]);
                            flash_message('success', 'Subject updated successfully.');
                        }
                    }
                }
            }
        } elseif ($action === 'delete') {
            $subject_id = (int)($_POST['subject_id'] ?? 0);
            if ($subject_id <= 0) {
                flash_message('error', 'Invalid subject selected.');
            } else {
                try {
                    delete_record('subjects', ['subject_id' => $subject_id]);
                    flash_message('success', 'Subject deleted successfully.');
                } catch (Exception $e) {
                    flash_message('error', 'Cannot delete this subject. Remove related offerings/enrollments first.');
                }
            }
        } elseif ($action === 'delete_selected') {
            $raw_ids = $_POST['subject_ids'] ?? [];
            if (!is_array($raw_ids)) {
                $raw_ids = [];
            }
            $subject_ids = [];
            foreach ($raw_ids as $id) {
                $id = (int)$id;
                if ($id > 0) {
                    $subject_ids[$id] = true;
                }
            }
            $subject_ids = array_keys($subject_ids);
            if (empty($subject_ids)) {
                flash_message('error', 'Select at least one subject to delete.');
            } else {
                $deleted = 0;
                $failed = 0;
                foreach ($subject_ids as $sid) {
                    try {
                        delete_record('subjects', ['subject_id' => $sid]);
                        $deleted++;
                    } catch (Exception $e) {
                        $failed++;
                    }
                }
                if ($deleted > 0 && $failed === 0) {
                    flash_message('success', $deleted === 1 ? '1 subject deleted.' : "{$deleted} subjects deleted.");
                } elseif ($deleted > 0 && $failed > 0) {
                    flash_message('success', "Deleted {$deleted} subject(s). {$failed} could not be deleted (linked offerings/enrollments or other constraints).");
                } else {
                    flash_message('error', 'No subjects could be deleted. Remove related offerings/enrollments first.');
                }
            }
        }
    } catch (Exception $e) {
        error_log('Dean manage_subjects error: ' . $e->getMessage());
        flash_message('error', 'Action failed. Please try again.');
    }

    redirect('modules/dean/manage_subjects.php');
}

$subjects = get_multiple_results("
    SELECT s.*, c.course_code, c.course_name
    FROM subjects s
    JOIN courses c ON c.course_id = s.course_id
    ORDER BY c.course_code, s.year_level, FIELD(s.semester_type, 'first', 'second', 'summer'), s.subject_code
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <meta name="user-data" content="<?php echo htmlspecialchars(json_encode($current_user)); ?>">
    <title>Manage Subjects - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo"><a href="<?php echo APP_URL; ?>/modules/dean/dashboard.php">Enchong Dee University Information System</a></div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <?php render_dean_sidebar('manage_subjects'); ?>

        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Manage Subjects</h1>
                    <p>Create and maintain subjects by course, year level, and semester.</p>
                </div>

                <?php if ($flash_messages): ?>
                    <div class="flash-messages mb-3">
                        <?php foreach ($flash_messages as $message): ?>
                            <div class="alert alert-<?php echo $message['type']; ?>">
                                <?php echo htmlspecialchars($message['message']); ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <div class="card mb-4">
                    <div class="card-header">
                        <h4><?php echo $editing_id > 0 ? 'Edit Subject' : 'Add Subject'; ?></h4>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="" class="form-row">
                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                            <input type="hidden" name="action" value="<?php echo $editing_id > 0 ? 'update' : 'create'; ?>">
                            <?php if ($editing_id > 0): ?>
                                <input type="hidden" name="subject_id" value="<?php echo (int)$editing_subject['subject_id']; ?>">
                            <?php endif; ?>

                            <div class="form-group form-col-xs">
                                <label class="form-label" for="subject_code">Subject Code *</label>
                                <input id="subject_code" name="subject_code" class="form-control" required
                                       value="<?php echo htmlspecialchars($editing_subject['subject_code'] ?? ''); ?>"
                                       placeholder="e.g. IT101">
                            </div>

                            <div class="form-group form-col-md">
                                <label class="form-label" for="subject_name">Subject Name *</label>
                                <input id="subject_name" name="subject_name" class="form-control" required
                                       value="<?php echo htmlspecialchars($editing_subject['subject_name'] ?? ''); ?>"
                                       placeholder="e.g. Introduction to Computing">
                            </div>

                            <div class="form-group form-col-md">
                                <label class="form-label" for="course_id">Course *</label>
                                <select id="course_id" name="course_id" class="form-control" required>
                                    <option value="">Select Course</option>
                                    <?php foreach ($courses as $course): ?>
                                        <option value="<?php echo (int)$course['course_id']; ?>"
                                            <?php echo (int)($editing_subject['course_id'] ?? 0) === (int)$course['course_id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($course['course_code'] . ' - ' . $course['course_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group form-col-xs">
                                <label class="form-label" for="year_level">Year Level *</label>
                                <input type="number" id="year_level" name="year_level" class="form-control" min="1" max="10" required
                                       value="<?php echo htmlspecialchars((string)($editing_subject['year_level'] ?? 1)); ?>">
                            </div>

                            <div class="form-group form-col-sm">
                                <label class="form-label" for="semester_type">Semester *</label>
                                <select id="semester_type" name="semester_type" class="form-control" required>
                                    <?php
                                    $sem_val = $editing_subject['semester_type'] ?? 'first';
                                    $sem_opts = ['first' => 'First', 'second' => 'Second', 'summer' => 'Summer'];
                                    foreach ($sem_opts as $val => $label):
                                    ?>
                                        <option value="<?php echo $val; ?>" <?php echo $sem_val === $val ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($label); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group form-col-xs">
                                <label class="form-label" for="units">Units</label>
                                <input type="number" step="0.5" min="0.5" id="units" name="units" class="form-control"
                                       value="<?php echo htmlspecialchars((string)($editing_subject['units'] ?? 1)); ?>">
                            </div>

                            <div class="form-group form-col-xs">
                                <label class="form-label" for="lecture_hours">Lecture Hours</label>
                                <input type="number" step="0.5" min="0" id="lecture_hours" name="lecture_hours" class="form-control"
                                       value="<?php echo htmlspecialchars((string)($editing_subject['lecture_hours'] ?? 0)); ?>">
                            </div>

                            <div class="form-group form-col-xs">
                                <label class="form-label" for="lab_hours">Lab Hours</label>
                                <input type="number" step="0.5" min="0" id="lab_hours" name="lab_hours" class="form-control"
                                       value="<?php echo htmlspecialchars((string)($editing_subject['lab_hours'] ?? 0)); ?>">
                            </div>

                            <div class="form-group form-col-full">
                                <label class="form-label" for="description">Description</label>
                                <input id="description" name="description" class="form-control"
                                       value="<?php echo htmlspecialchars($editing_subject['description'] ?? ''); ?>"
                                       placeholder="Optional">
                            </div>

                            <div class="form-group">
                                <button type="submit" class="btn btn-success"><?php echo $editing_id > 0 ? 'Save Changes' : 'Add Subject'; ?></button>
                                <?php if ($editing_id > 0): ?>
                                    <a href="<?php echo APP_URL; ?>/modules/dean/manage_subjects.php" class="btn btn-secondary">Cancel</a>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="card">
                    <?php if ($subjects): ?>
                        <form method="POST" action="" id="bulkSubjectsForm" class="bulk-subjects-form" novalidate>
                            <div class="card-header" style="display:flex; flex-wrap:wrap; align-items:center; justify-content:space-between; gap:0.75rem;">
                                <h4 style="margin:0;">Existing Subjects</h4>
                                <button type="submit" class="btn btn-sm btn-danger" id="bulkDeleteBtn" disabled onclick="return confirmBulkDelete();">
                                    Delete selected
                                </button>
                            </div>
                            <div class="card-body">
                                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                <input type="hidden" name="action" value="delete_selected">
                                <div class="table-responsive">
                                    <table class="table table-sm">
                                        <thead>
                                            <tr>
                                                <th style="width:2.5rem;">
                                                    <input type="checkbox" id="selectAllSubjects" title="Select all" aria-label="Select all subjects">
                                                </th>
                                                <th>Course</th>
                                                <th>Code</th>
                                                <th>Title</th>
                                                <th>Year</th>
                                                <th>Sem</th>
                                                <th>Units</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($subjects as $s): ?>
                                                <tr>
                                                    <td>
                                                        <input type="checkbox" name="subject_ids[]" value="<?php echo (int)$s['subject_id']; ?>" class="subject-row-check" aria-label="Select <?php echo htmlspecialchars($s['subject_code']); ?>">
                                                    </td>
                                                    <td><?php echo htmlspecialchars($s['course_code']); ?></td>
                                                    <td><?php echo htmlspecialchars($s['subject_code']); ?></td>
                                                    <td><?php echo htmlspecialchars($s['subject_name']); ?></td>
                                                    <td><?php echo htmlspecialchars((string)$s['year_level']); ?></td>
                                                    <td><?php echo htmlspecialchars(ucfirst($s['semester_type'])); ?></td>
                                                    <td><?php echo htmlspecialchars((string)$s['units']); ?></td>
                                                    <td>
                                                        <div class="action-buttons">
                                                            <a class="btn btn-sm btn-info" href="<?php echo APP_URL; ?>/modules/dean/manage_subjects.php?edit_id=<?php echo (int)$s['subject_id']; ?>">Edit</a>
                                                            <button type="submit" class="btn btn-sm btn-danger" form="deleteSubjectForm_<?php echo (int)$s['subject_id']; ?>" onclick="return confirm('Delete this subject? This may fail if it has offerings/enrollments.');">
                                                                Delete
                                                            </button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </form>
                        <?php foreach ($subjects as $s): ?>
                            <form method="POST" action="" id="deleteSubjectForm_<?php echo (int)$s['subject_id']; ?>" style="display:none" aria-hidden="true">
                                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="subject_id" value="<?php echo (int)$s['subject_id']; ?>">
                            </form>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="card-header"><h4 style="margin:0;">Existing Subjects</h4></div>
                        <div class="card-body">
                            <p class="text-muted">No subjects yet.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>

    <script>
        function confirmBulkDelete() {
            var form = document.getElementById('bulkSubjectsForm');
            if (!form) {
                return false;
            }
            var n = form.querySelectorAll('input.subject-row-check:checked').length;
            if (n === 0) {
                return false;
            }
            return confirm('Delete ' + n + ' selected subject(s)? Subjects linked to offerings or enrollments will not be removed.');
        }

        document.addEventListener('DOMContentLoaded', function() {
            var form = document.getElementById('bulkSubjectsForm');
            var selectAll = document.getElementById('selectAllSubjects');
            var bulkBtn = document.getElementById('bulkDeleteBtn');
            if (!form || !selectAll || !bulkBtn) {
                return;
            }

            function rowChecks() {
                return form.querySelectorAll('input.subject-row-check');
            }

            function syncBulkButton() {
                bulkBtn.disabled = form.querySelectorAll('input.subject-row-check:checked').length === 0;
            }

            selectAll.addEventListener('change', function() {
                var on = selectAll.checked;
                rowChecks().forEach(function(cb) {
                    cb.checked = on;
                });
                syncBulkButton();
            });

            rowChecks().forEach(function(cb) {
                cb.addEventListener('change', function() {
                    var boxes = rowChecks();
                    var all = true;
                    boxes.forEach(function(b) {
                        if (!b.checked) {
                            all = false;
                        }
                    });
                    selectAll.checked = boxes.length > 0 && all;
                    syncBulkButton();
                });
            });

            syncBulkButton();
        });
    </script>
    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>

