<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';

require_role('dean');
$current_user = get_logged_in_user();

function dean_course_offer_semester_type_from_name($semester_name)
{
    $normalized = strtolower(trim((string)$semester_name));
    if (strpos($normalized, 'first') !== false) {
        return 'first';
    }
    if (strpos($normalized, 'second') !== false) {
        return 'second';
    }
    if (strpos($normalized, 'summer') !== false) {
        return 'summer';
    }
    return '';
}

function dean_course_offer_year_label($year_level)
{
    $year_level = (int)$year_level;
    $labels = [
        1 => 'First Year',
        2 => 'Second Year',
        3 => 'Third Year',
        4 => 'Fourth Year',
    ];
    return $labels[$year_level] ?? ($year_level > 0 ? $year_level . ' Year' : 'Year Level Not Set');
}

function dean_course_offer_fixed_semester_options($school_year_id)
{
    $fixed_semesters = ['First Semester', 'Second Semester', 'Summer'];
    $options = [];

    foreach ($fixed_semesters as $semester_name) {
        $semester = get_single_result("
            SELECT semester_id, semester_name
            FROM semesters
            WHERE school_year_id = ? AND semester_name = ?
            ORDER BY semester_id DESC
            LIMIT 1
        ", [$school_year_id, $semester_name]);

        if (!$semester) {
            $semester = get_single_result("
                SELECT semester_id, semester_name
                FROM semesters
                WHERE semester_name = ?
                ORDER BY is_current DESC, semester_id DESC
                LIMIT 1
            ", [$semester_name]);
        }

        if ($semester) {
            $options[] = [
                'semester_id' => (int)$semester['semester_id'],
                'semester_name' => $semester_name,
            ];
        }
    }

    return $options;
}

$school_year_id = (int)($_GET['school_year_id'] ?? 0);
$semester_id = (int)($_GET['semester_id'] ?? 0);
$course_id = (int)($_GET['course_id'] ?? 0);
$year_level = (int)($_GET['year_level'] ?? 0);

$school_years = get_multiple_results("SELECT school_year_id, year_name FROM school_years ORDER BY school_year_id DESC");
$courses = get_multiple_results("SELECT course_id, course_code, course_name FROM courses ORDER BY course_code ASC");
$current_school_year = get_single_result("SELECT school_year_id FROM school_years WHERE is_current = TRUE LIMIT 1");
$current_semester = get_single_result("SELECT semester_id, semester_name FROM semesters WHERE is_current = TRUE LIMIT 1");

if ($school_year_id <= 0) {
    $school_year_id = (int)($current_school_year['school_year_id'] ?? ($school_years[0]['school_year_id'] ?? 0));
}

$semesters = dean_course_offer_fixed_semester_options($school_year_id);
$selected_semester_name_from_id = '';
if ($semester_id > 0) {
    $semester_lookup = get_single_result("SELECT semester_name FROM semesters WHERE semester_id = ? LIMIT 1", [$semester_id]);
    $selected_semester_name_from_id = trim((string)($semester_lookup['semester_name'] ?? ''));
}

if ($semester_id <= 0 && $current_semester) {
    $selected_semester_name_from_id = trim((string)$current_semester['semester_name']);
}

if ($selected_semester_name_from_id !== '') {
    foreach ($semesters as $semester_option) {
        if ($semester_option['semester_name'] === $selected_semester_name_from_id) {
            $semester_id = (int)$semester_option['semester_id'];
            break;
        }
    }
}

if ($semester_id <= 0 && !empty($semesters)) {
    $semester_id = (int)$semesters[0]['semester_id'];
}

$selected_semester = null;
foreach ($semesters as $semester_option) {
    if ((int)$semester_option['semester_id'] === $semester_id) {
        $selected_semester = $semester_option;
        break;
    }
}
$selected_semester_name = trim((string)($selected_semester['semester_name'] ?? ''));
$selected_semester_type = dean_course_offer_semester_type_from_name($selected_semester_name);

$offered_courses_subjects = get_multiple_results("
    SELECT
        c.course_code,
        c.course_name,
        c.course_id,
        sub.subject_id,
        sub.subject_code,
        sub.subject_name,
        sub.units,
        sub.year_level,
        sub.semester_type,
        so.offering_id,
        so.section,
        so.status AS offering_status,
        CONCAT(u.last_name, ', ', u.first_name) AS teacher_name
    FROM subjects sub
    JOIN courses c ON c.course_id = sub.course_id
    LEFT JOIN subject_offerings so
        ON so.subject_id = sub.subject_id
       AND so.school_year_id = ?
       AND so.semester_id IN (
            SELECT semester_id
            FROM semesters
            WHERE semester_name = ?
       )
    LEFT JOIN teachers t ON t.teacher_id = so.teacher_id
    LEFT JOIN users u ON u.user_id = t.user_id
    WHERE (? <= 0 OR sub.course_id = ?)
      AND (? <= 0 OR sub.year_level = ?)
      AND (? = '' OR sub.semester_type = ?)
    ORDER BY c.course_code, sub.year_level ASC, FIELD(sub.semester_type, 'first', 'second', 'summer'), sub.subject_code, so.section
", [$school_year_id, $selected_semester_name, $course_id, $course_id, $year_level, $year_level, $selected_semester_type, $selected_semester_type]);

$subjects_by_group = [];
foreach ($offered_courses_subjects as $row) {
    $course_key = $row['course_code'] . ' - ' . $row['course_name'];
    $year_key = (int)$row['year_level'];
    $semester_key = $row['semester_type'] ?: 'other';
    $subjects_by_group[$course_key][$year_key][$semester_key][] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <title>Dean Course Offers - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo"><a href="<?php echo APP_URL; ?>/modules/dean/dashboard.php">Enchong Dee University Information System</a></div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <?php render_dean_sidebar('course_offers'); ?>
        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Course Offers</h1>
                    <p>View all courses and subjects by school year and semester.</p>
                </div>

                <div class="card mb-4">
                    <div class="card-body">
                        <form method="GET" action="" class="form-row">
                            <div class="form-group">
                                <label class="form-label" for="course_id">Course</label>
                                <select id="course_id" name="course_id" class="form-control">
                                    <option value="0">All Courses</option>
                                    <?php foreach ($courses as $course): ?>
                                        <option value="<?php echo (int)$course['course_id']; ?>" <?php echo (int)$course['course_id'] === $course_id ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($course['course_code'] . ' - ' . $course['course_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="year_level">Year Level</label>
                                <select id="year_level" name="year_level" class="form-control">
                                    <option value="0">All Year Levels</option>
                                    <?php for ($year = 1; $year <= 4; $year++): ?>
                                        <option value="<?php echo $year; ?>" <?php echo $year === $year_level ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars(dean_course_offer_year_label($year)); ?>
                                        </option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="school_year_id">School Year</label>
                                <select id="school_year_id" name="school_year_id" class="form-control" required>
                                    <?php foreach ($school_years as $sy): ?>
                                        <option value="<?php echo (int) $sy['school_year_id']; ?>" <?php echo (int) $sy['school_year_id'] === $school_year_id ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($sy['year_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="semester_id">Semester</label>
                                <select id="semester_id" name="semester_id" class="form-control" required>
                                    <?php foreach ($semesters as $sem): ?>
                                        <option value="<?php echo (int) $sem['semester_id']; ?>" <?php echo (int) $sem['semester_id'] === $semester_id ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($sem['semester_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group" style="align-self:end;">
                                <button type="submit" class="btn btn-primary">Apply Filter</button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header"><h4>Courses and Subjects</h4></div>
                    <div class="card-body">
                        <?php if ($subjects_by_group): ?>
                            <?php foreach ($subjects_by_group as $course_label => $year_groups): ?>
                                <h4><?php echo htmlspecialchars($course_label); ?></h4>
                                <?php foreach ($year_groups as $year_key => $semester_groups): ?>
                                    <h5><?php echo htmlspecialchars(dean_course_offer_year_label($year_key)); ?></h5>
                                    <?php foreach (['first' => 'First Semester', 'second' => 'Second Semester', 'summer' => 'Summer'] as $semester_type => $semester_label): ?>
                                        <?php if (empty($semester_groups[$semester_type])) { continue; } ?>
                                        <p><strong><?php echo htmlspecialchars($semester_label); ?></strong></p>
                                        <div class="table-responsive mb-4">
                                            <table class="table table-sm">
                                                <thead>
                                                    <tr>
                                                        <th>Subject Code</th>
                                                        <th>Subject Description</th>
                                                        <th>Units</th>
                                                        <th>Section</th>
                                                        <th>Teacher</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php foreach ($semester_groups[$semester_type] as $row): ?>
                                                        <tr>
                                                            <td><?php echo htmlspecialchars($row['subject_code']); ?></td>
                                                            <td><?php echo htmlspecialchars($row['subject_name']); ?></td>
                                                            <td><?php echo htmlspecialchars((string) $row['units']); ?></td>
                                                            <td><?php echo htmlspecialchars($row['section'] ?: 'Not yet assigned'); ?></td>
                                                            <td><?php echo htmlspecialchars($row['teacher_name'] ?: 'Not yet assigned'); ?></td>
                                                            <td><?php echo htmlspecialchars($row['offering_status'] ? ucfirst($row['offering_status']) : 'Not yet offered'); ?></td>
                                                            <td>
                                                                <?php if (!empty($row['offering_id'])): ?>
                                                                    <a class="btn btn-sm btn-primary" href="<?php echo APP_URL; ?>/modules/dean/add_schedule.php?school_year_id=<?php echo (int)$school_year_id; ?>&semester_id=<?php echo (int)$semester_id; ?>&course_id=<?php echo (int)$row['course_id']; ?>">Enroll</a>
                                                                <?php else: ?>
                                                                    <a class="btn btn-sm btn-secondary" href="<?php echo APP_URL; ?>/modules/dean/add_schedule.php?school_year_id=<?php echo (int)$school_year_id; ?>&semester_id=<?php echo (int)$semester_id; ?>&course_id=<?php echo (int)$row['course_id']; ?>">Add Schedule</a>
                                                                <?php endif; ?>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    <?php endforeach; ?>
                                <?php endforeach; ?>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p class="text-muted">No courses or subjects found.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>
    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
