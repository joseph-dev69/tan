<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';

require_role('dean');
$current_user = get_logged_in_user();

$flash_messages = get_flash_messages();
$error = '';

function course_delete_placeholders(array $ids): string {
    return implode(',', array_fill(0, count($ids), '?'));
}

function course_delete_table_exists(PDO $conn, string $table_name): bool {
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table_name)) {
        return false;
    }

    $stmt = $conn->prepare("
        SELECT COUNT(*) AS c
        FROM information_schema.tables
        WHERE table_schema = DATABASE() AND table_name = ?
    ");
    $stmt->execute([$table_name]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return ((int)($row['c'] ?? 0)) > 0;
}

function course_delete_fetch_ids(PDO $conn, string $sql, array $params, string $column): array {
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);

    return array_values(array_unique(array_filter(array_map(
        'intval',
        array_column($stmt->fetchAll(PDO::FETCH_ASSOC), $column)
    ))));
}

function course_delete_in(PDO $conn, string $table, string $column, array $ids): int {
    if (!$ids) {
        return 0;
    }

    if (!preg_match('/^[A-Za-z0-9_]+$/', $table) || !preg_match('/^[A-Za-z0-9_]+$/', $column)) {
        throw new InvalidArgumentException('Invalid delete target.');
    }

    $placeholders = course_delete_placeholders($ids);
    $stmt = $conn->prepare("DELETE FROM `$table` WHERE `$column` IN ($placeholders)");
    $stmt->execute($ids);
    return (int)$stmt->rowCount();
}

function delete_course_cascade(int $course_id): array {
    $conn = get_db_connection();
    $conn->beginTransaction();

    $counts = [
        'subjects' => 0,
        'offerings' => 0,
        'loads' => 0,
        'grades' => 0,
        'students' => 0,
        'applications' => 0,
        'fee_schedules' => 0,
        'schedules' => 0,
        'prerequisites' => 0,
        'enrollments' => 0,
        'billings' => 0,
        'billing_details' => 0,
        'payments' => 0,
        'receipts' => 0,
        'academic_records' => 0,
        'transcript_requests' => 0,
        'courses' => 0,
    ];

    try {
        $course = $conn->prepare("SELECT course_id FROM courses WHERE course_id = ? LIMIT 1");
        $course->execute([$course_id]);
        if (!$course->fetch(PDO::FETCH_ASSOC)) {
            if ($conn->inTransaction()) {
                $conn->commit();
            }
            return $counts;
        }

        $subject_ids = course_delete_fetch_ids(
            $conn,
            "SELECT subject_id FROM subjects WHERE course_id = ?",
            [$course_id],
            'subject_id'
        );
        $student_ids = course_delete_fetch_ids(
            $conn,
            "SELECT student_id FROM students WHERE course_id = ?",
            [$course_id],
            'student_id'
        );
        $fee_schedule_ids = course_delete_fetch_ids(
            $conn,
            "SELECT fee_schedule_id FROM fee_schedules WHERE course_id = ?",
            [$course_id],
            'fee_schedule_id'
        );

        $offering_ids = [];
        if ($subject_ids) {
            $subject_ph = course_delete_placeholders($subject_ids);
            $offering_ids = course_delete_fetch_ids(
                $conn,
                "SELECT offering_id FROM subject_offerings WHERE subject_id IN ($subject_ph)",
                $subject_ids,
                'offering_id'
            );
            $counts['subjects'] = count($subject_ids);
            $counts['offerings'] = count($offering_ids);
        }

        $enrollment_ids = [];
        $billing_ids = [];
        if ($student_ids) {
            $student_ph = course_delete_placeholders($student_ids);
            $enrollment_ids = course_delete_fetch_ids(
                $conn,
                "SELECT enrollment_id FROM enrollments WHERE student_id IN ($student_ph)",
                $student_ids,
                'enrollment_id'
            );
            $billing_ids = course_delete_fetch_ids(
                $conn,
                "SELECT billing_id FROM billings WHERE student_id IN ($student_ph)",
                $student_ids,
                'billing_id'
            );
            $counts['students'] = count($student_ids);
        }

        $load_ids = [];
        if ($offering_ids) {
            $off_ph = course_delete_placeholders($offering_ids);
            $load_ids = array_merge($load_ids, course_delete_fetch_ids(
                $conn,
                "SELECT load_id FROM student_subject_loads WHERE offering_id IN ($off_ph)",
                $offering_ids,
                'load_id'
            ));
        }

        if ($enrollment_ids) {
            $enrollment_ph = course_delete_placeholders($enrollment_ids);
            $load_ids = array_merge($load_ids, course_delete_fetch_ids(
                $conn,
                "SELECT load_id FROM student_subject_loads WHERE enrollment_id IN ($enrollment_ph)",
                $enrollment_ids,
                'load_id'
            ));
        }

        $load_ids = array_values(array_unique(array_filter(array_map('intval', $load_ids))));
        $counts['loads'] = count($load_ids);

        if ($billing_ids) {
            $billing_ph = course_delete_placeholders($billing_ids);
            $payment_ids = course_delete_fetch_ids(
                $conn,
                "SELECT payment_id FROM payments WHERE billing_id IN ($billing_ph)",
                $billing_ids,
                'payment_id'
            );

            $counts['receipts'] += course_delete_in($conn, 'receipts', 'payment_id', $payment_ids);
            $counts['payments'] += course_delete_in($conn, 'payments', 'billing_id', $billing_ids);
            $counts['billing_details'] += course_delete_in($conn, 'billing_details', 'billing_id', $billing_ids);
            $counts['billings'] += course_delete_in($conn, 'billings', 'billing_id', $billing_ids);
        }

        if ($fee_schedule_ids) {
            $counts['billing_details'] += course_delete_in($conn, 'billing_details', 'fee_schedule_id', $fee_schedule_ids);
        }

        if ($load_ids) {
            $counts['grades'] += course_delete_in($conn, 'grades', 'student_subject_load_id', $load_ids);
            $counts['loads'] = course_delete_in($conn, 'student_subject_loads', 'load_id', $load_ids);
        }

        if ($offering_ids) {
            $counts['schedules'] += course_delete_in($conn, 'schedules', 'offering_id', $offering_ids);
            $counts['offerings'] = course_delete_in($conn, 'subject_offerings', 'offering_id', $offering_ids);
        }

        if ($subject_ids) {
            $counts['prerequisites'] += course_delete_in($conn, 'subject_prerequisites', 'subject_id', $subject_ids);
            $counts['prerequisites'] += course_delete_in($conn, 'subject_prerequisites', 'prerequisite_subject_id', $subject_ids);
        }

        if ($student_ids) {
            $counts['academic_records'] += course_delete_in($conn, 'academic_records', 'student_id', $student_ids);
            $counts['transcript_requests'] += course_delete_in($conn, 'transcript_requests', 'student_id', $student_ids);
        }

        if ($enrollment_ids) {
            $counts['enrollments'] += course_delete_in($conn, 'enrollments', 'enrollment_id', $enrollment_ids);
        }

        if (course_delete_table_exists($conn, 'enrollment_applications')) {
            $delApps = $conn->prepare("DELETE FROM enrollment_applications WHERE course_id = ?");
            $delApps->execute([$course_id]);
            $counts['applications'] = (int)$delApps->rowCount();
        }

        $counts['students'] = course_delete_in($conn, 'students', 'student_id', $student_ids);
        $counts['subjects'] = course_delete_in($conn, 'subjects', 'subject_id', $subject_ids);
        $counts['fee_schedules'] = course_delete_in($conn, 'fee_schedules', 'fee_schedule_id', $fee_schedule_ids);

        $delCourse = $conn->prepare("DELETE FROM courses WHERE course_id = ?");
        $delCourse->execute([$course_id]);
        $counts['courses'] = (int)$delCourse->rowCount();

        if ($conn->inTransaction()) {
            $conn->commit();
        }
        return $counts;
    } catch (Throwable $e) {
        if ($conn->inTransaction()) {
            $conn->rollBack();
        }
        throw $e;
    }
}

$departments = get_multiple_results("SELECT department_id, department_code, department_name FROM departments ORDER BY department_name ASC");
$editing_id = (int)($_GET['edit_id'] ?? 0);
$editing_course = null;

if ($editing_id > 0) {
    $editing_course = get_single_result("SELECT * FROM courses WHERE course_id = ? LIMIT 1", [$editing_id]);
    if (!$editing_course) {
        $editing_id = 0;
    }
}

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    $action = $_POST['action'] ?? '';

    if (!verify_csrf_token($csrf_token)) {
        flash_message('error', 'Invalid request token.');
        redirect('modules/dean/manage_courses.php');
    }

    try {
        if ($action === 'create') {
            flash_message('info', 'Add Course is now handled in Course Curriculum Builder.');
        } elseif ($action === 'update') {
            $course_id = (int)($_POST['course_id'] ?? 0);
            $course_code = strtoupper(trim(sanitize_input($_POST['course_code'] ?? '')));
            $course_name = trim(sanitize_input($_POST['course_name'] ?? ''));
            $department_id = (int)($_POST['department_id'] ?? 0);
            $description = trim(sanitize_input($_POST['description'] ?? ''));
            $duration_years = (int)($_POST['duration_years'] ?? 4);

            if ($course_id <= 0 || $course_code === '' || $course_name === '' || $department_id <= 0) {
                flash_message('error', 'Please complete required course fields.');
            } else {
                $exists = get_single_result("SELECT course_id FROM courses WHERE course_code = ? AND course_id <> ? LIMIT 1", [$course_code, $course_id]);
                if ($exists) {
                    flash_message('error', 'Course code already exists.');
                } else {
                    update_record('courses', [
                        'course_name' => $course_name,
                        'course_code' => $course_code,
                        'department_id' => $department_id,
                        'description' => $description ?: null,
                        'duration_years' => max(1, $duration_years),
                    ], ['course_id' => $course_id]);
                    flash_message('success', 'Course updated successfully.');
                }
            }
        } elseif ($action === 'delete') {
            $course_id = (int)($_POST['course_id'] ?? 0);
            if ($course_id <= 0) {
                flash_message('error', 'Invalid course selected.');
            } else {
                try {
                    $counts = delete_course_cascade($course_id);
                    if (($counts['courses'] ?? 0) > 0) {
                        flash_message('success', 'Course deleted successfully.');
                    } else {
                        flash_message('error', 'Course was not deleted (not found or already removed).');
                    }
                } catch (Exception $e) {
                    error_log('Course cascade delete failed: ' . $e->getMessage());
                    flash_message('error', 'Cannot delete this course right now. Please try again.');
                }
            }
        }
    } catch (Exception $e) {
        error_log('Dean manage_courses error: ' . $e->getMessage());
        flash_message('error', 'Action failed. Please try again.');
    }

    redirect('modules/dean/manage_courses.php');
}

$courses = get_multiple_results("
    SELECT c.*, d.department_code, d.department_name
    FROM courses c
    JOIN departments d ON d.department_id = c.department_id
    ORDER BY c.course_code ASC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <meta name="user-data" content="<?php echo htmlspecialchars(json_encode($current_user)); ?>">
    <title>Manage Courses - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo"><a href="<?php echo APP_URL; ?>/modules/dean/dashboard.php">Enchong Dee University Information System</a></div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <?php render_dean_sidebar('manage_courses'); ?>

        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Manage Courses</h1>
                    <p>Create and maintain the course list used across the system.</p>
                </div>

                <?php if ($flash_messages): ?>
                    <div class="flash-messages mb-3">
                        <?php foreach ($flash_messages as $message): ?>
                            <div class="alert alert-<?php echo $message['type']; ?>">
                                <?php echo htmlspecialchars($message['message']); ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <?php if ($editing_id > 0): ?>
                    <div class="card mb-4">
                        <div class="card-header">
                            <h4>Edit Course</h4>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="" class="form-row">
                                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                <input type="hidden" name="action" value="update">
                                <input type="hidden" name="course_id" value="<?php echo (int)$editing_course['course_id']; ?>">

                                <div class="form-group form-col-xs">
                                    <label class="form-label" for="course_code">Course Code *</label>
                                    <input id="course_code" name="course_code" class="form-control" required
                                           value="<?php echo htmlspecialchars($editing_course['course_code'] ?? ''); ?>"
                                           placeholder="e.g. BSIT">
                                </div>

                                <div class="form-group form-col-md">
                                    <label class="form-label" for="course_name">Course Name *</label>
                                    <input id="course_name" name="course_name" class="form-control" required
                                           value="<?php echo htmlspecialchars($editing_course['course_name'] ?? ''); ?>"
                                           placeholder="e.g. Bachelor of Science in Information Technology">
                                </div>

                                <div class="form-group form-col-md">
                                    <label class="form-label" for="department_id">Department *</label>
                                    <select id="department_id" name="department_id" class="form-control" required>
                                        <option value="">Select Department</option>
                                        <?php foreach ($departments as $dept): ?>
                                            <option value="<?php echo (int)$dept['department_id']; ?>"
                                                <?php echo (int)($editing_course['department_id'] ?? 0) === (int)$dept['department_id'] ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($dept['department_code'] . ' - ' . $dept['department_name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="form-group form-col-xs">
                                    <label class="form-label" for="duration_years">Duration (years)</label>
                                    <input type="number" id="duration_years" name="duration_years" class="form-control" min="1" value="<?php echo htmlspecialchars((string)($editing_course['duration_years'] ?? 4)); ?>">
                                </div>

                                <div class="form-group form-col-full">
                                    <label class="form-label" for="description">Description</label>
                                    <input id="description" name="description" class="form-control"
                                           value="<?php echo htmlspecialchars($editing_course['description'] ?? ''); ?>"
                                           placeholder="Optional">
                                </div>

                                <div class="form-group">
                                    <button type="submit" class="btn btn-success">Save Changes</button>
                                    <a href="<?php echo APP_URL; ?>/modules/dean/manage_courses.php" class="btn btn-secondary">Cancel</a>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-header"><h4>Existing Courses</h4></div>
                    <div class="card-body">
                        <?php if ($courses): ?>
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Code</th>
                                            <th>Name</th>
                                            <th>Department</th>
                                            <th>Years</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($courses as $course): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($course['course_code']); ?></td>
                                                <td><?php echo htmlspecialchars($course['course_name']); ?></td>
                                                <td><?php echo htmlspecialchars($course['department_code'] . ' - ' . $course['department_name']); ?></td>
                                                <td><?php echo htmlspecialchars((string)$course['duration_years']); ?></td>
                                                <td>
                                                    <div class="action-buttons">
                                                        <a class="btn btn-sm btn-info" href="<?php echo APP_URL; ?>/modules/dean/manage_courses.php?edit_id=<?php echo (int)$course['course_id']; ?>">Edit</a>
                                                        <form method="POST" action="" onsubmit="return confirm('Delete this course? This may fail if it has related subjects/students.');">
                                                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                                            <input type="hidden" name="action" value="delete">
                                                            <input type="hidden" name="course_id" value="<?php echo (int)$course['course_id']; ?>">
                                                            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                                        </form>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">No courses yet.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
