<?php
/**
 * Dean Sidebar Navigation
 */

function render_dean_sidebar($active_page = 'dashboard') {
    $items = [
        'dashboard' => ['label' => 'Dashboard', 'href' => APP_URL . '/modules/dean/dashboard.php'],
        'manage_courses' => ['label' => 'Manage Courses', 'href' => APP_URL . '/modules/dean/manage_courses.php'],
        'course_curriculum_builder' => ['label' => 'Add New Courses', 'href' => APP_URL . '/modules/dean/course_curriculum_builder.php'],
        'manage_subjects' => ['label' => 'Manage Subjects', 'href' => APP_URL . '/modules/dean/manage_subjects.php'],
        'course_offers' => ['label' => 'Course Offers', 'href' => APP_URL . '/modules/dean/course_offers.php'],
        'enrollist_list' => ['label' => 'Enrollist List', 'href' => APP_URL . '/modules/dean/enrollist_list.php'],
        'add_schedule' => ['label' => 'Add Schedule', 'href' => APP_URL . '/modules/dean/add_schedule.php'],
        'teacher_assignments' => ['label' => 'Teacher Assignment', 'href' => APP_URL . '/modules/dean/teacher_assignments.php'],
        'academic_calendar' => ['label' => 'Academic Calendar', 'href' => APP_URL . '/modules/dean/academic_calendar.php'],
        'change_password' => ['label' => 'Change Password', 'href' => APP_URL . '/modules/account/change_password.php'],
    ];
    ?>
    <aside class="sidebar" id="sidebar">
        <ul class="sidebar-menu">
            <?php foreach ($items as $key => $item): ?>
                <li>
                    <a href="<?php echo $item['href']; ?>" class="<?php echo $active_page === $key ? 'active' : ''; ?>">
                        <span class="icon"><?php echo htmlspecialchars($item['label']); ?></span>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </aside>
    <?php
}
