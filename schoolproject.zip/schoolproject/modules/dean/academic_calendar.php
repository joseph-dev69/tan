<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';

require_role('dean');

function ensure_academic_calendar_suggestions_table_for_dean()
{
    static $initialized = false;
    if ($initialized) {
        return;
    }

    $conn = get_db_connection();
    $conn->exec("
        CREATE TABLE IF NOT EXISTS academic_calendar_suggestions (
            suggestion_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            dean_user_id INT NOT NULL,
            school_year_id INT NULL,
            semester_name VARCHAR(50) NULL,
            suggested_start_date DATE NULL,
            suggested_end_date DATE NULL,
            notes TEXT NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            reviewed_by INT NULL,
            reviewed_at DATETIME NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_dean_user_id (dean_user_id),
            INDEX idx_school_year_id (school_year_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");

    $initialized = true;
}

ensure_academic_calendar_suggestions_table_for_dean();

$current_user = get_logged_in_user();

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    $action = $_POST['action'] ?? '';

    if (!verify_csrf_token($csrf_token)) {
        flash_message('error', 'Invalid request token.');
        redirect('modules/dean/academic_calendar.php');
    }

    if ($action === 'submit_suggestion') {
        $school_year_id = (int)($_POST['school_year_id'] ?? 0);
        $semester_name = sanitize_input($_POST['semester_name'] ?? '');
        $suggested_start_date = sanitize_input($_POST['suggested_start_date'] ?? '');
        $suggested_end_date = sanitize_input($_POST['suggested_end_date'] ?? '');
        $notes = sanitize_input($_POST['notes'] ?? '');

        if ($notes === '') {
            flash_message('error', 'Please enter your suggested change or note.');
        } else {
            $conn = get_db_connection();
            $stmt = $conn->prepare("
                INSERT INTO academic_calendar_suggestions (
                    dean_user_id, school_year_id, semester_name, suggested_start_date, suggested_end_date, notes
                ) VALUES (?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $current_user['user_id'],
                $school_year_id > 0 ? $school_year_id : null,
                $semester_name !== '' ? $semester_name : null,
                $suggested_start_date !== '' ? $suggested_start_date : null,
                $suggested_end_date !== '' ? $suggested_end_date : null,
                $notes,
            ]);

            flash_message('success', 'Your suggestion was sent to Admin for review.');
            log_audit('SUBMIT_CALENDAR_SUGGESTION', 'academic_calendar_suggestions', (int)$conn->lastInsertId());
        }
    }

    redirect('modules/dean/academic_calendar.php');
}

$school_years = get_multiple_results("
    SELECT school_year_id, year_name, start_date, end_date, is_current
    FROM school_years
    ORDER BY start_date DESC
");

$semester_rows = get_multiple_results("
    SELECT sem.semester_id, sem.semester_name, sem.school_year_id, sem.start_date, sem.end_date, sem.is_current,
           sy.year_name
    FROM semesters sem
    JOIN school_years sy ON sem.school_year_id = sy.school_year_id
    ORDER BY sy.start_date DESC, sem.start_date ASC, sem.semester_name ASC
");

$semester_groups = [];
foreach ($semester_rows as $semester_row) {
    $semester_row['exam_periods'] = compute_exam_period_schedule($semester_row['start_date'], $semester_row['end_date']);
    $semester_groups[$semester_row['school_year_id']][] = $semester_row;
}

$my_suggestions = get_multiple_results("
    SELECT suggestion_id, semester_name, suggested_start_date, suggested_end_date, notes, status, created_at
    FROM academic_calendar_suggestions
    WHERE dean_user_id = ?
    ORDER BY created_at DESC
", [$current_user['user_id']]);

$flash_messages = get_flash_messages();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <title>Academic Calendar - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo"><a href="<?php echo APP_URL; ?>/modules/dean/dashboard.php">Enchong Dee University Information System</a></div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <?php render_dean_sidebar('academic_calendar'); ?>
        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Academic Calendar</h1>
                    <p>Deans can review the official calendar and submit suggestions, but only Admin can change the semester dates used by billing and permits.</p>
                </div>

                <?php if ($flash_messages): ?>
                    <div class="flash-messages mb-3">
                        <?php foreach ($flash_messages as $message): ?>
                            <div class="alert alert-<?php echo $message['type']; ?>">
                                <?php echo htmlspecialchars($message['message']); ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <div class="alert alert-info mb-4">
                    This page is read-only for the official academic calendar. Any billing due date or permit validation still follows the Admin-defined calendar.
                </div>

                <div class="card mb-4">
                    <div class="card-header"><h4>Official Academic Calendar</h4></div>
                    <div class="card-body">
                        <?php foreach ($school_years as $year): ?>
                            <div class="card mb-3">
                                <div class="card-header">
                                    <strong><?php echo htmlspecialchars($year['year_name']); ?></strong>
                                    <?php if ((int)$year['is_current'] === 1): ?>
                                        <span class="badge badge-success">Current Year</span>
                                    <?php endif; ?>
                                </div>
                                <div class="card-body">
                                    <?php if (!empty($semester_groups[$year['school_year_id']])): ?>
                                        <div class="table-responsive">
                                            <table class="table table-sm">
                                                <thead>
                                                    <tr>
                                                        <th>Semester</th>
                                                        <th>Start</th>
                                                        <th>End</th>
                                                        <th>Prelim</th>
                                                        <th>Midterm</th>
                                                        <th>Final</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php foreach ($semester_groups[$year['school_year_id']] as $semester): ?>
                                                        <tr>
                                                            <td>
                                                                <?php echo htmlspecialchars($semester['semester_name']); ?>
                                                                <?php if ((int)$semester['is_current'] === 1): ?>
                                                                    <span class="badge badge-primary">Current Term</span>
                                                                <?php endif; ?>
                                                            </td>
                                                            <td><?php echo htmlspecialchars($semester['start_date']); ?></td>
                                                            <td><?php echo htmlspecialchars($semester['end_date']); ?></td>
                                                            <td><?php echo htmlspecialchars($semester['exam_periods']['prelim']['due_date'] ?? 'Schedule Not Set'); ?></td>
                                                            <td><?php echo htmlspecialchars($semester['exam_periods']['midterm']['due_date'] ?? 'Schedule Not Set'); ?></td>
                                                            <td><?php echo htmlspecialchars($semester['exam_periods']['final']['due_date'] ?? 'Schedule Not Set'); ?></td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    <?php else: ?>
                                        <p class="text-muted">Admin has not set the semester calendar for this school year yet.</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-header"><h4>Suggest a Calendar Change</h4></div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                            <input type="hidden" name="action" value="submit_suggestion">

                            <div class="form-row">
                                <div class="form-group col-4">
                                    <label class="form-label">Academic Year</label>
                                    <select name="school_year_id" class="form-control">
                                        <option value="">Select Academic Year</option>
                                        <?php foreach ($school_years as $year): ?>
                                            <option value="<?php echo (int)$year['school_year_id']; ?>">
                                                <?php echo htmlspecialchars($year['year_name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="form-group col-4">
                                    <label class="form-label">Semester</label>
                                    <select name="semester_name" class="form-control">
                                        <option value="">Select Semester</option>
                                        <option value="First Semester">First Semester</option>
                                        <option value="Second Semester">Second Semester</option>
                                        <option value="Summer">Summer</option>
                                    </select>
                                </div>
                                <div class="form-group col-2">
                                    <label class="form-label">Suggested Start</label>
                                    <input type="date" name="suggested_start_date" class="form-control">
                                </div>
                                <div class="form-group col-2">
                                    <label class="form-label">Suggested End</label>
                                    <input type="date" name="suggested_end_date" class="form-control">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Reason / Note</label>
                                <textarea name="notes" class="form-control" rows="4" placeholder="Explain why the official calendar should be reviewed." required></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">Send Suggestion to Admin</button>
                        </form>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header"><h4>My Suggestions</h4></div>
                    <div class="card-body">
                        <?php if ($my_suggestions): ?>
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Semester</th>
                                            <th>Suggested Start</th>
                                            <th>Suggested End</th>
                                            <th>Notes</th>
                                            <th>Status</th>
                                            <th>Submitted</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($my_suggestions as $suggestion): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($suggestion['semester_name'] ?? 'Not specified'); ?></td>
                                                <td><?php echo htmlspecialchars($suggestion['suggested_start_date'] ?? 'N/A'); ?></td>
                                                <td><?php echo htmlspecialchars($suggestion['suggested_end_date'] ?? 'N/A'); ?></td>
                                                <td><?php echo nl2br(htmlspecialchars($suggestion['notes'])); ?></td>
                                                <td><span class="badge badge-info"><?php echo htmlspecialchars(ucfirst($suggestion['status'])); ?></span></td>
                                                <td><?php echo htmlspecialchars($suggestion['created_at']); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">You have not submitted any calendar suggestions yet.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>
    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
