<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';

require_role('dean');
$current_user = get_logged_in_user();

$courses = get_multiple_results("
    SELECT c.course_id, c.course_code, c.course_name, d.department_name
    FROM courses c
    JOIN departments d ON d.department_id = c.department_id
    ORDER BY c.course_code ASC
");

$current_school_year = get_single_result("SELECT school_year_id, year_name FROM school_years WHERE is_current = 1 ORDER BY school_year_id DESC LIMIT 1");
$fallback_school_year_id = (int)($current_school_year['school_year_id'] ?? 0);
$selected_course_id = (int)($_GET['course_id'] ?? 0);
$selected_school_year_id = (int)($_GET['school_year_id'] ?? $fallback_school_year_id);
$selected_semester_id = (int)($_GET['semester_id'] ?? 0);
$student_query = trim((string)($_GET['student_query'] ?? ''));
$export_format = trim((string)($_GET['export'] ?? ''));

$semester_selection = resolve_fixed_semester_selection($selected_school_year_id, $selected_semester_id);
$semester_options = $semester_selection['options'];
$selected_semester_id = (int)$semester_selection['semester_id'];
$selected_semester_name = $semester_selection['semester_name'];

if ($selected_course_id <= 0 && !empty($courses)) {
    $selected_course_id = (int)$courses[0]['course_id'];
}

$selected_course = null;
foreach ($courses as $course_row) {
    if ((int)$course_row['course_id'] === $selected_course_id) {
        $selected_course = $course_row;
        break;
    }
}

$enrollist_rows = [];
$course_totals = [
    'students' => 0,
    'subjects' => 0,
    'units' => 0.0,
];

if ($selected_course_id > 0 && $selected_school_year_id > 0 && $selected_semester_name !== '') {
    $where = [
        'st.course_id = ?',
        'e.school_year_id = ?',
        'sem.semester_name = ?',
        "e.status = 'enrolled'",
    ];
    $params = [$selected_course_id, $selected_school_year_id, $selected_semester_name];

    if ($student_query !== '') {
        $search_like = '%' . $student_query . '%';
        $where[] = "(
            st.student_number LIKE ?
            OR u.first_name LIKE ?
            OR u.last_name LIKE ?
            OR CONCAT(u.first_name, ' ', u.last_name) LIKE ?
            OR CONCAT(u.last_name, ', ', u.first_name) LIKE ?
        )";
        array_push($params, $search_like, $search_like, $search_like, $search_like, $search_like);
    }

    $where_sql = implode(' AND ', $where);

    $enrollist_rows = get_multiple_results("
        SELECT
            st.student_number,
            CONCAT(u.last_name, ', ', u.first_name) AS student_name,
            st.year_level,
            c.course_code,
            c.course_name,
            sy.year_name,
            sem.semester_name,
            e.status,
            COUNT(loadrec.load_id) AS subject_count,
            COALESCE(SUM(sub.units), 0) AS total_units
        FROM enrollments e
        JOIN students st ON st.student_id = e.student_id
        JOIN users u ON u.user_id = st.user_id
        JOIN courses c ON c.course_id = st.course_id
        JOIN school_years sy ON sy.school_year_id = e.school_year_id
        JOIN semesters sem ON sem.semester_id = e.semester_id
        LEFT JOIN student_subject_loads loadrec
            ON loadrec.enrollment_id = e.enrollment_id
            AND loadrec.status IN ('enrolled', 'completed', 'failed')
        LEFT JOIN subject_offerings so ON so.offering_id = loadrec.offering_id
        LEFT JOIN subjects sub ON sub.subject_id = so.subject_id
        WHERE $where_sql
        GROUP BY e.enrollment_id, st.student_number, u.last_name, u.first_name, st.year_level, c.course_code, c.course_name, sy.year_name, sem.semester_name, e.status
        ORDER BY u.last_name ASC, u.first_name ASC
    ", $params);

    foreach ($enrollist_rows as $row) {
        $course_totals['students']++;
        $course_totals['subjects'] += (int)$row['subject_count'];
        $course_totals['units'] += (float)$row['total_units'];
    }

    if ($export_format === 'csv' && $enrollist_rows) {
        $course_label = $selected_course ? $selected_course['course_code'] : 'course';
        $filename = 'enrollist-' . preg_replace('/[^A-Z0-9_-]+/i', '-', $course_label . '-' . ($current_school_year['year_name'] ?? 'term')) . '.csv';
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        $output = fopen('php://output', 'w');
        fputcsv($output, ['Student Number', 'Student Name', 'Year Level', 'Course', 'School Year', 'Semester', 'Subjects', 'Total Units', 'Status']);
        foreach ($enrollist_rows as $student_row) {
            fputcsv($output, [
                $student_row['student_number'],
                $student_row['student_name'],
                $student_row['year_level'],
                $student_row['course_code'],
                $student_row['year_name'],
                $student_row['semester_name'],
                $student_row['subject_count'],
                number_format((float)$student_row['total_units'], 1, '.', ''),
                ucfirst((string)$student_row['status']),
            ]);
        }
        fclose($output);
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <meta name="user-data" content="<?php echo htmlspecialchars(json_encode($current_user)); ?>">
    <title>List of Enrollist - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo"><a href="<?php echo APP_URL; ?>/modules/dean/dashboard.php">Enchong Dee University Information System</a></div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <?php render_dean_sidebar('enrollist'); ?>

        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>List of Enrollist</h1>
                    <p>View enrolled students by course using a dedicated enrollist workspace.</p>
                </div>

                <div class="stats-grid mb-4">
                    <div class="stat-card">
                        <div class="stat-number"><?php echo htmlspecialchars((string)$course_totals['students']); ?></div>
                        <div class="stat-label">Enrolled Students</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?php echo htmlspecialchars((string)$course_totals['subjects']); ?></div>
                        <div class="stat-label">Total Subject Loads</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?php echo htmlspecialchars(number_format($course_totals['units'], 1)); ?></div>
                        <div class="stat-label">Total Units</div>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-header">
                        <h4>Filter Enrollist</h4>
                    </div>
                    <div class="card-body">
                        <form method="GET" action="" class="form-row">
                            <div class="form-group form-col-md">
                                <label class="form-label" for="course_id">Course</label>
                                <select id="course_id" name="course_id" class="form-control" required>
                                    <option value="">Select Course</option>
                                    <?php foreach ($courses as $course): ?>
                                        <option value="<?php echo (int)$course['course_id']; ?>" <?php echo $selected_course_id === (int)$course['course_id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($course['course_code'] . ' - ' . $course['course_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group form-col-sm">
                                <label class="form-label" for="school_year_id">School Year</label>
                                <select id="school_year_id" name="school_year_id" class="form-control">
                                    <?php foreach (get_multiple_results("SELECT school_year_id, year_name FROM school_years ORDER BY school_year_id DESC") as $school_year): ?>
                                        <option value="<?php echo (int)$school_year['school_year_id']; ?>" <?php echo $selected_school_year_id === (int)$school_year['school_year_id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($school_year['year_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group form-col-sm">
                                <label class="form-label" for="semester_id">Semester</label>
                                <select id="semester_id" name="semester_id" class="form-control">
                                    <?php foreach ($semester_options as $semester_option): ?>
                                        <option value="<?php echo (int)$semester_option['semester_id']; ?>" <?php echo $selected_semester_id === (int)$semester_option['semester_id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($semester_option['semester_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group form-col-md">
                                <label class="form-label" for="student_query">Student Search</label>
                                <input type="text" id="student_query" name="student_query" class="form-control" value="<?php echo htmlspecialchars($student_query); ?>" placeholder="Student number or name">
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary">View Enrollist</button>
                            </div>
                            <?php if ($selected_course_id > 0): ?>
                                <div class="form-group">
                                    <a class="btn btn-secondary" href="<?php echo APP_URL; ?>/modules/dean/enrollist.php?course_id=<?php echo (int)$selected_course_id; ?>&school_year_id=<?php echo (int)$selected_school_year_id; ?>&semester_id=<?php echo (int)$selected_semester_id; ?>&student_query=<?php echo urlencode($student_query); ?>&export=csv">Export CSV</a>
                                </div>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h4>
                            <?php if ($selected_course): ?>
                                <?php echo htmlspecialchars($selected_course['course_code']); ?> Enrollist
                            <?php else: ?>
                                Enrollist
                            <?php endif; ?>
                        </h4>
                    </div>
                    <div class="card-body">
                        <?php if ($selected_course): ?>
                            <p class="mb-3 text-muted">
                                Showing enrolled students under <?php echo htmlspecialchars($selected_course['course_name']); ?><?php echo $selected_semester_name !== '' ? ' for ' . htmlspecialchars($selected_semester_name) : ''; ?>.
                            </p>
                        <?php endif; ?>

                        <?php if ($enrollist_rows): ?>
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Student Number</th>
                                            <th>Student Name</th>
                                            <th>Year Level</th>
                                            <th>Course</th>
                                            <th>School Year</th>
                                            <th>Semester</th>
                                            <th>Subjects</th>
                                            <th>Total Units</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($enrollist_rows as $student_row): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($student_row['student_number']); ?></td>
                                                <td><?php echo htmlspecialchars($student_row['student_name']); ?></td>
                                                <td><?php echo htmlspecialchars((string)$student_row['year_level']); ?></td>
                                                <td><?php echo htmlspecialchars($student_row['course_code']); ?></td>
                                                <td><?php echo htmlspecialchars($student_row['year_name']); ?></td>
                                                <td><?php echo htmlspecialchars($student_row['semester_name']); ?></td>
                                                <td><?php echo htmlspecialchars((string)$student_row['subject_count']); ?></td>
                                                <td><?php echo htmlspecialchars(number_format((float)$student_row['total_units'], 1)); ?></td>
                                                <td><?php echo htmlspecialchars(ucfirst($student_row['status'])); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">No enrolled students found for the selected course and filters.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
