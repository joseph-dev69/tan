<?php
/**
 * Student E-Form Page
 * School Information System
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';

require_role('student');

function ensure_enrollment_applications_table_for_eform() {
    $conn = get_db_connection();
    $conn->exec("
        CREATE TABLE IF NOT EXISTS enrollment_applications (
            application_id INT PRIMARY KEY AUTO_INCREMENT,
            user_id INT NOT NULL,
            school_year_id INT NOT NULL,
            semester_id INT NOT NULL,
            course_id INT NOT NULL,
            year_level INT NOT NULL DEFAULT 1,
            major_department_id INT NULL,
            region_code VARCHAR(20) NULL,
            province_code VARCHAR(20) NULL,
            citymun_code VARCHAR(20) NULL,
            barangay_code VARCHAR(20) NULL,
            first_name VARCHAR(100) NOT NULL,
            last_name VARCHAR(100) NOT NULL,
            middle_name VARCHAR(100) NULL,
            birth_date DATE NOT NULL,
            gender VARCHAR(20) NOT NULL,
            civil_status VARCHAR(20) NOT NULL,
            address_region VARCHAR(100) NULL,
            address_province VARCHAR(100) NOT NULL,
            address_city VARCHAR(100) NOT NULL,
            address_barangay VARCHAR(100) NOT NULL,
            address_street VARCHAR(150) NOT NULL,
            address_house_number VARCHAR(50) NOT NULL,
            phone_number VARCHAR(30) NOT NULL,
            email VARCHAR(150) NOT NULL,
            guardian_name VARCHAR(150) NOT NULL,
            guardian_contact VARCHAR(30) NOT NULL,
            guardian_address TEXT NOT NULL,
            status ENUM('submitted', 'reviewed', 'approved', 'rejected') DEFAULT 'submitted',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY unique_term_application (user_id, school_year_id, semester_id)
        )
    ");

    $existing_columns = [];
    foreach ($conn->query("SHOW COLUMNS FROM enrollment_applications") as $column) {
        $existing_columns[] = $column['Field'];
    }

    if (!in_array('year_level', $existing_columns, true)) {
        $conn->exec("ALTER TABLE enrollment_applications ADD COLUMN year_level INT NOT NULL DEFAULT 1 AFTER course_id");
    }
}

function create_or_update_official_enrollment_from_eform(PDO $conn, array $application, int $application_id) {
    $application_year_level = max(1, min(4, (int)($application['year_level'] ?? 1)));

    $stmt = $conn->prepare("
        SELECT *
        FROM students
        WHERE user_id = ?
        LIMIT 1
    ");
    $stmt->execute([$application['user_id']]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$student) {
        $student_number = generate_student_number();
        $expected_graduation_date = date('Y-m-d', strtotime('+4 years'));

        $stmt = $conn->prepare("
            INSERT INTO students (
                user_id, student_number, course_id, year_level, admission_date,
                expected_graduation_date, gpa, academic_status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $application['user_id'],
            $student_number,
            $application['course_id'],
            $application_year_level,
            date('Y-m-d'),
            $expected_graduation_date,
            0.00,
            'regular'
        ]);

        $student_id = (int)$conn->lastInsertId();
    } else {
        $student_id = (int)$student['student_id'];
        $stmt = $conn->prepare("
            UPDATE students
            SET course_id = ?, year_level = ?, updated_at = NOW()
            WHERE student_id = ?
        ");
        $stmt->execute([$application['course_id'], $application_year_level, $student_id]);
    }

    $stmt = $conn->prepare("
        SELECT *
        FROM enrollments
        WHERE student_id = ? AND school_year_id = ? AND semester_id = ?
        LIMIT 1
    ");
    $stmt->execute([$student_id, $application['school_year_id'], $application['semester_id']]);
    $existing_enrollment = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($existing_enrollment) {
        $stmt = $conn->prepare("
            UPDATE enrollments
            SET status = 'enrolled', updated_at = NOW()
            WHERE enrollment_id = ?
        ");
        $stmt->execute([$existing_enrollment['enrollment_id']]);
    } else {
        $stmt = $conn->prepare("
            INSERT INTO enrollments (
                student_id, semester_id, school_year_id, enrollment_date,
                status, total_units, total_fee, paid_amount, balance
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $student_id,
            $application['semester_id'],
            $application['school_year_id'],
            date('Y-m-d'),
            'enrolled',
            0.0,
            0.00,
            0.00,
            0.00
        ]);
    }

    $stmt = $conn->prepare("
        UPDATE enrollment_applications
        SET status = 'approved', updated_at = NOW()
        WHERE application_id = ?
    ");
    $stmt->execute([$application_id]);

    return $student_id;
}

function reference_table_exists_eform($table_name) {
    static $cache = [];
    if (!array_key_exists($table_name, $cache)) {
        $result = get_single_result("
            SELECT COUNT(*) AS table_count
            FROM information_schema.tables
            WHERE table_schema = DATABASE() AND table_name = ?
        ", [$table_name]);
        $cache[$table_name] = ((int)($result['table_count'] ?? 0)) > 0;
    }
    return $cache[$table_name];
}

function get_location_name_eform($table, $code_field, $desc_field, $code_value) {
    if (!$code_value || !reference_table_exists_eform($table)) {
        return '';
    }
    $row = get_single_result("SELECT $desc_field AS label FROM $table WHERE $code_field = ? LIMIT 1", [$code_value]);
    return $row['label'] ?? '';
}

function get_location_options_eform($table, $code_field, $desc_field, $where_sql = '', $params = []) {
    if (!reference_table_exists_eform($table)) {
        return [];
    }
    return get_multiple_results("
        SELECT $code_field AS code, $desc_field AS name
        FROM $table
        $where_sql
        ORDER BY $desc_field ASC
    ", $params);
}

ensure_enrollment_applications_table_for_eform();

$current_user = get_logged_in_user();
$student_info = get_single_result("
    SELECT s.*, c.course_name, c.course_code, d.department_name
    FROM students s
    JOIN courses c ON s.course_id = c.course_id
    JOIN departments d ON c.department_id = d.department_id
    WHERE s.user_id = ?
", [$current_user['user_id']]);
$student_setup_missing = !$student_info;

$has_location_reference_tables = reference_table_exists_eform('refregion')
    && reference_table_exists_eform('refprovince')
    && reference_table_exists_eform('refcitymun')
    && reference_table_exists_eform('refbrgy');

if (isset($_GET['location_lookup']) && $has_location_reference_tables) {
    header('Content-Type: application/json');
    $type = $_GET['location_lookup'];
    $items = [];
    if ($type === 'provinces') {
        $items = get_location_options_eform('refprovince', 'provCode', 'provDesc', 'WHERE regCode = ?', [$_GET['region_code'] ?? '']);
    } elseif ($type === 'cities') {
        $items = get_location_options_eform('refcitymun', 'citymunCode', 'citymunDesc', 'WHERE provCode = ?', [$_GET['province_code'] ?? '']);
    } elseif ($type === 'barangays') {
        $items = get_location_options_eform('refbrgy', 'brgyCode', 'brgyDesc', 'WHERE citymunCode = ?', [$_GET['citymun_code'] ?? '']);
    }
    echo json_encode($items);
    exit;
}

$current_school_year = get_single_result("SELECT * FROM school_years WHERE is_current = TRUE");
$current_semester = get_single_result("SELECT * FROM semesters WHERE is_current = TRUE");
$school_years = get_multiple_results("SELECT school_year_id, year_name FROM school_years ORDER BY school_year_id DESC");
$semesters = get_multiple_results("
    SELECT MIN(semester_id) AS semester_id, semester_name
    FROM semesters
    GROUP BY semester_name
    ORDER BY CASE
        WHEN LOWER(semester_name) LIKE '%first%' THEN 1
        WHEN LOWER(semester_name) LIKE '%second%' THEN 2
        ELSE 3
    END, semester_name ASC
");
$courses = get_multiple_results("SELECT course_id, course_name, course_code FROM courses ORDER BY course_name");
$departments = get_multiple_results("SELECT department_id, department_name, department_code FROM departments ORDER BY department_name");

if (!$current_school_year || !$current_semester) {
    flash_message('error', 'No current academic year or semester is set. Please contact the administrator.');
    redirect('modules/student/dashboard.php');
}

$application_form = [
    'school_year_id' => (int)$current_school_year['school_year_id'],
    'semester_id' => (int)$current_semester['semester_id'],
    'course_id' => (int)($student_info['course_id'] ?? 0),
    'year_level' => (int)($student_info['year_level'] ?? 1),
    'major_department_id' => 0,
    'region_code' => '',
    'province_code' => '',
    'citymun_code' => '',
    'barangay_code' => '',
    'first_name' => $current_user['first_name'] ?? '',
    'last_name' => $current_user['last_name'] ?? '',
    'middle_name' => '',
    'birth_date' => '',
    'gender' => 'Male',
    'civil_status' => 'Single',
    'address_region' => '',
    'address_province' => '',
    'address_city' => '',
    'address_barangay' => '',
    'address_street' => '',
    'address_house_number' => '',
    'phone_number' => '',
    'email' => $current_user['email'] ?? '',
    'guardian_name' => '',
    'guardian_contact' => '',
    'guardian_address' => ''
];

$application_errors = [];
$existing_application = get_single_result("
    SELECT *
    FROM enrollment_applications
    WHERE user_id = ? AND school_year_id = ? AND semester_id = ?
", [$current_user['user_id'], $current_school_year['school_year_id'], $current_semester['semester_id']]);

if ($existing_application) {
    foreach ($application_form as $key => $value) {
        if (array_key_exists($key, $existing_application)) {
            $application_form[$key] = $existing_application[$key];
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    if (!verify_csrf_token($csrf_token)) {
        flash_message('error', 'Invalid request. Please try again.');
    } else {
        $application_form = [
            'school_year_id' => (int)($_POST['school_year_id'] ?? 0),
            'semester_id' => (int)($_POST['semester_id'] ?? 0),
            'course_id' => (int)($_POST['course_id'] ?? 0),
            'year_level' => max(1, min(4, (int)($_POST['year_level'] ?? 0))),
            'major_department_id' => (int)($_POST['major_department_id'] ?? 0),
            'region_code' => sanitize_input($_POST['region_code'] ?? ''),
            'province_code' => sanitize_input($_POST['province_code'] ?? ''),
            'citymun_code' => sanitize_input($_POST['citymun_code'] ?? ''),
            'barangay_code' => sanitize_input($_POST['barangay_code'] ?? ''),
            'first_name' => sanitize_input($_POST['first_name'] ?? ''),
            'last_name' => sanitize_input($_POST['last_name'] ?? ''),
            'middle_name' => sanitize_input($_POST['middle_name'] ?? ''),
            'birth_date' => sanitize_input($_POST['birth_date'] ?? ''),
            'gender' => sanitize_input($_POST['gender'] ?? ''),
            'civil_status' => sanitize_input($_POST['civil_status'] ?? ''),
            'address_region' => '',
            'address_province' => '',
            'address_city' => '',
            'address_barangay' => '',
            'address_street' => sanitize_input($_POST['address_street'] ?? ''),
            'address_house_number' => sanitize_input($_POST['address_house_number'] ?? ''),
            'phone_number' => sanitize_input($_POST['phone_number'] ?? ''),
            'email' => sanitize_input($_POST['email'] ?? ''),
            'guardian_name' => sanitize_input($_POST['guardian_name'] ?? ''),
            'guardian_contact' => sanitize_input($_POST['guardian_contact'] ?? ''),
            'guardian_address' => sanitize_input($_POST['guardian_address'] ?? '')
        ];

        if ($has_location_reference_tables) {
            $application_form['address_region'] = get_location_name_eform('refregion', 'regCode', 'regDesc', $application_form['region_code']);
            $application_form['address_province'] = get_location_name_eform('refprovince', 'provCode', 'provDesc', $application_form['province_code']);
            $application_form['address_city'] = get_location_name_eform('refcitymun', 'citymunCode', 'citymunDesc', $application_form['citymun_code']);
            $application_form['address_barangay'] = get_location_name_eform('refbrgy', 'brgyCode', 'brgyDesc', $application_form['barangay_code']);
        }

        $required_application_fields = [
            'school_year_id', 'semester_id', 'course_id', 'year_level',
            'first_name', 'last_name', 'birth_date', 'gender', 'civil_status',
            'address_province', 'address_city', 'address_barangay', 'address_street',
            'address_house_number', 'phone_number', 'email', 'guardian_name',
            'guardian_contact', 'guardian_address'
        ];

        foreach ($required_application_fields as $field) {
            if (empty($application_form[$field])) {
                $application_errors[$field] = 'This field is required.';
            }
        }

        if (empty($application_errors['email']) && !validate_email($application_form['email'])) {
            $application_errors['email'] = 'Please enter a valid email address.';
        }

        if (empty($application_errors['phone_number']) && !validate_phone($application_form['phone_number'])) {
            $application_errors['phone_number'] = 'Please enter a valid Philippine phone number.';
        }

        if (empty($application_errors['guardian_contact']) && !validate_phone($application_form['guardian_contact'])) {
            $application_errors['guardian_contact'] = 'Please enter a valid guardian contact number.';
        }

        if (empty($application_errors['birth_date']) && !validate_date($application_form['birth_date'])) {
            $application_errors['birth_date'] = 'Please enter a valid birth date.';
        }

        if (empty($application_errors)) {
            $conn = null;
            try {
                $conn = get_db_connection();
                $conn->beginTransaction();

                $stmt = $conn->prepare("
                    SELECT *
                    FROM enrollment_applications
                    WHERE user_id = ? AND school_year_id = ? AND semester_id = ?
                    LIMIT 1
                ");
                $stmt->execute([
                    $current_user['user_id'],
                    $application_form['school_year_id'],
                    $application_form['semester_id']
                ]);
                $application_record = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($application_record) {
                    $stmt = $conn->prepare("
                        UPDATE enrollment_applications
                        SET school_year_id = ?, semester_id = ?, course_id = ?, year_level = ?, major_department_id = ?,
                            region_code = ?, province_code = ?, citymun_code = ?, barangay_code = ?,
                            first_name = ?, last_name = ?, middle_name = ?, birth_date = ?, gender = ?, civil_status = ?,
                            address_region = ?, address_province = ?, address_city = ?, address_barangay = ?, address_street = ?, address_house_number = ?,
                            phone_number = ?, email = ?, guardian_name = ?, guardian_contact = ?, guardian_address = ?, status = 'submitted'
                        WHERE application_id = ?
                    ");
                    $stmt->execute([
                        $application_form['school_year_id'], $application_form['semester_id'], $application_form['course_id'], $application_form['year_level'], $application_form['major_department_id'] ?: null,
                        $application_form['region_code'] ?: null, $application_form['province_code'] ?: null, $application_form['citymun_code'] ?: null, $application_form['barangay_code'] ?: null,
                        $application_form['first_name'], $application_form['last_name'], $application_form['middle_name'] ?: null, $application_form['birth_date'], $application_form['gender'], $application_form['civil_status'],
                        $application_form['address_region'], $application_form['address_province'], $application_form['address_city'], $application_form['address_barangay'], $application_form['address_street'], $application_form['address_house_number'],
                        $application_form['phone_number'], $application_form['email'], $application_form['guardian_name'], $application_form['guardian_contact'], $application_form['guardian_address'],
                        $application_record['application_id']
                    ]);
                    $application_id = (int)$application_record['application_id'];
                } else {
                    $stmt = $conn->prepare("
                        INSERT INTO enrollment_applications (
                            user_id, school_year_id, semester_id, course_id, year_level, major_department_id,
                            region_code, province_code, citymun_code, barangay_code,
                            first_name, last_name, middle_name, birth_date, gender, civil_status,
                            address_region, address_province, address_city, address_barangay, address_street, address_house_number,
                            phone_number, email, guardian_name, guardian_contact, guardian_address, status
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'submitted')
                    ");
                    $stmt->execute([
                        $current_user['user_id'], $application_form['school_year_id'], $application_form['semester_id'], $application_form['course_id'], $application_form['year_level'], $application_form['major_department_id'] ?: null,
                        $application_form['region_code'] ?: null, $application_form['province_code'] ?: null, $application_form['citymun_code'] ?: null, $application_form['barangay_code'] ?: null,
                        $application_form['first_name'], $application_form['last_name'], $application_form['middle_name'] ?: null, $application_form['birth_date'], $application_form['gender'], $application_form['civil_status'],
                        $application_form['address_region'], $application_form['address_province'], $application_form['address_city'], $application_form['address_barangay'], $application_form['address_street'], $application_form['address_house_number'],
                        $application_form['phone_number'], $application_form['email'], $application_form['guardian_name'], $application_form['guardian_contact'], $application_form['guardian_address']
                    ]);
                    $application_id = (int)$conn->lastInsertId();
                }

                $official_application = $application_form;
                $official_application['user_id'] = (int)$current_user['user_id'];
                create_or_update_official_enrollment_from_eform($conn, $official_application, $application_id);

                $conn->commit();

                flash_message('success', 'Enrollment e-form submitted and official enrollment created successfully.');
                redirect('modules/student/eform.php');
            } catch (Exception $e) {
                if ($conn instanceof PDO && $conn->inTransaction()) {
                    $conn->rollBack();
                }
                error_log("Enrollment e-form error: " . $e->getMessage());
                flash_message('error', 'Unable to submit the e-form right now.');
            }
        }
    }
}

$region_options = $has_location_reference_tables ? get_location_options_eform('refregion', 'regCode', 'regDesc') : [];
$province_options = ($has_location_reference_tables && !empty($application_form['region_code']))
    ? get_location_options_eform('refprovince', 'provCode', 'provDesc', 'WHERE regCode = ?', [$application_form['region_code']])
    : [];
$city_options = ($has_location_reference_tables && !empty($application_form['province_code']))
    ? get_location_options_eform('refcitymun', 'citymunCode', 'citymunDesc', 'WHERE provCode = ?', [$application_form['province_code']])
    : [];
$barangay_options = ($has_location_reference_tables && !empty($application_form['citymun_code']))
    ? get_location_options_eform('refbrgy', 'brgyCode', 'brgyDesc', 'WHERE citymunCode = ?', [$application_form['citymun_code']])
    : [];

$flash_messages = get_flash_messages();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <title>Student E-Form - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo"><a href="<?php echo APP_URL; ?>/modules/student/dashboard.php">Enchong Dee University Information System</a></div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <?php render_student_sidebar('eform'); ?>

        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Student E-Form</h1>
                    <p>Submit your enrollment e-form to create your official enrollment record for the selected term.</p>
                </div>

                <?php if ($flash_messages): ?>
                    <div class="flash-messages mb-3">
                        <?php foreach ($flash_messages as $message): ?>
                            <div class="alert alert-<?php echo $message['type']; ?>"><?php echo htmlspecialchars($message['message']); ?></div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <?php if ($application_errors): ?>
                    <div class="alert alert-danger mb-4">Please complete the required e-form fields correctly.</div>
                <?php endif; ?>

                <div class="card mb-4 eform-card">
                    <div class="card-body">
                        <div class="eform-heading-row">
                            <h2 class="eform-main-title">STUDENT-FORM</h2>
                            <?php if ($existing_application): ?>
                                <span class="badge badge-info"><?php echo htmlspecialchars(strtoupper((string)$existing_application['status'])); ?></span>
                            <?php endif; ?>
                        </div>
                        <form method="POST" action="">
                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="school_year_id" class="form-label">SY:</label>
                                    <select id="school_year_id" name="school_year_id" class="form-control">
                                        <?php foreach ($school_years as $school_year): ?>
                                            <option value="<?php echo (int)$school_year['school_year_id']; ?>" <?php echo (int)$application_form['school_year_id'] === (int)$school_year['school_year_id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($school_year['year_name']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="semester_id" class="form-label">SEM:</label>
                                    <select id="semester_id" name="semester_id" class="form-control">
                                        <?php foreach ($semesters as $semester): ?>
                                            <option value="<?php echo (int)$semester['semester_id']; ?>" <?php echo (int)$application_form['semester_id'] === (int)$semester['semester_id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($semester['semester_name']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="course_id" class="form-label">COURSE:</label>
                                    <select id="course_id" name="course_id" class="form-control">
                                        <option value="">Select Course</option>
                                        <?php foreach ($courses as $course): ?>
                                            <option value="<?php echo (int)$course['course_id']; ?>" <?php echo (int)$application_form['course_id'] === (int)$course['course_id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($course['course_name']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="year_level" class="form-label">YEAR LEVEL:</label>
                                    <select id="year_level" name="year_level" class="form-control">
                                        <?php
                                        $year_level_labels = [1 => 'First Year', 2 => 'Second Year', 3 => 'Third Year', 4 => 'Fourth Year'];
                                        foreach ($year_level_labels as $year_level_value => $year_level_label):
                                        ?>
                                            <option value="<?php echo $year_level_value; ?>" <?php echo (int)$application_form['year_level'] === $year_level_value ? 'selected' : ''; ?>><?php echo htmlspecialchars($year_level_label); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="major_department_id" class="form-label">MAJOR:</label>
                                    <select id="major_department_id" name="major_department_id" class="form-control">
                                        <option value="">Select Major</option>
                                        <?php foreach ($departments as $department): ?>
                                            <option value="<?php echo (int)$department['department_id']; ?>" <?php echo (int)$application_form['major_department_id'] === (int)$department['department_id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($department['department_name']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="eform-divider"></div>
                            <div class="form-row">
                                <div class="form-group"><label class="form-label">FIRST NAME</label><input type="text" name="first_name" class="form-control" value="<?php echo htmlspecialchars((string)$application_form['first_name']); ?>"></div>
                                <div class="form-group"><label class="form-label">LAST NAME</label><input type="text" name="last_name" class="form-control" value="<?php echo htmlspecialchars((string)$application_form['last_name']); ?>"></div>
                                <div class="form-group"><label class="form-label">MIDDLE NAME</label><input type="text" name="middle_name" class="form-control" value="<?php echo htmlspecialchars((string)$application_form['middle_name']); ?>"></div>
                            </div>
                            <div class="form-row">
                                <div class="form-group"><label class="form-label">BIRTH DATE</label><input type="date" name="birth_date" id="birth_date" class="form-control" value="<?php echo htmlspecialchars((string)$application_form['birth_date']); ?>"></div>
                                <div class="form-group"><label class="form-label">GENDER</label><select name="gender" class="form-control"><?php foreach (['Male','Female','Other'] as $gender): ?><option value="<?php echo $gender; ?>" <?php echo $application_form['gender'] === $gender ? 'selected' : ''; ?>><?php echo strtoupper($gender); ?></option><?php endforeach; ?></select></div>
                                <div class="form-group"><label class="form-label">STATUS</label><select name="civil_status" class="form-control"><?php foreach (['Single','Married','Widowed','Separated'] as $status): ?><option value="<?php echo $status; ?>" <?php echo $application_form['civil_status'] === $status ? 'selected' : ''; ?>><?php echo strtoupper($status); ?></option><?php endforeach; ?></select></div>
                            </div>
                            <h4 class="eform-section-title">ADDRESS:</h4>
                            <div class="form-row">
                                <div class="form-group">
                                    <label class="form-label">REGION</label>
                                    <select id="region_code" name="region_code" class="form-control">
                                        <option value="">Select Region</option>
                                        <?php foreach ($region_options as $region): ?><option value="<?php echo htmlspecialchars($region['code']); ?>" <?php echo $application_form['region_code'] === $region['code'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($region['name']); ?></option><?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">PROVINCE</label>
                                    <select id="province_code" name="province_code" class="form-control">
                                        <option value="">Select Province</option>
                                        <?php foreach ($province_options as $province): ?><option value="<?php echo htmlspecialchars($province['code']); ?>" <?php echo $application_form['province_code'] === $province['code'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($province['name']); ?></option><?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">MUNICIPALITY/CITY</label>
                                    <select id="citymun_code" name="citymun_code" class="form-control">
                                        <option value="">Select City</option>
                                        <?php foreach ($city_options as $city): ?><option value="<?php echo htmlspecialchars($city['code']); ?>" <?php echo $application_form['citymun_code'] === $city['code'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($city['name']); ?></option><?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label class="form-label">BARANGAY</label>
                                    <select id="barangay_code" name="barangay_code" class="form-control">
                                        <option value="">Select Barangay</option>
                                        <?php foreach ($barangay_options as $barangay): ?><option value="<?php echo htmlspecialchars($barangay['code']); ?>" <?php echo $application_form['barangay_code'] === $barangay['code'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($barangay['name']); ?></option><?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group eform-wide"><label class="form-label">STREET</label><input type="text" id="address_street" name="address_street" class="form-control" value="<?php echo htmlspecialchars((string)$application_form['address_street']); ?>" placeholder="e.g. Rizal St."></div>
                                <div class="form-group"><label class="form-label">HOUSE NUMBER</label><input type="text" name="address_house_number" class="form-control" value="<?php echo htmlspecialchars((string)$application_form['address_house_number']); ?>" placeholder="e.g. #123"></div>
                            </div>
                            <h4 class="eform-section-title">CONTACTS:</h4>
                            <div class="form-row">
                                <div class="form-group"><label class="form-label">PHONE</label><input type="text" name="phone_number" class="form-control" value="<?php echo htmlspecialchars((string)$application_form['phone_number']); ?>"></div>
                                <div class="form-group"><label class="form-label">EMAIL</label><input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars((string)$application_form['email']); ?>"></div>
                            </div>
                            <h4 class="eform-section-title">GUARDIAN:</h4>
                            <div class="form-row">
                                <div class="form-group"><label class="form-label">FULL NAME</label><input type="text" name="guardian_name" class="form-control" value="<?php echo htmlspecialchars((string)$application_form['guardian_name']); ?>"></div>
                                <div class="form-group"><label class="form-label">CONTACT</label><input type="text" name="guardian_contact" class="form-control" value="<?php echo htmlspecialchars((string)$application_form['guardian_contact']); ?>"></div>
                            </div>
                            <div class="form-group"><label class="form-label">ADDRESS</label><input type="text" name="guardian_address" class="form-control" value="<?php echo htmlspecialchars((string)$application_form['guardian_address']); ?>"></div>
                            <div class="eform-actions"><button type="submit" class="btn btn-dark eform-submit-btn">SUBMIT FORM</button></div>
                        </form>
                    </div>
                </div>

                <?php if ($student_setup_missing): ?>
                    <div class="alert alert-info">Submit the e-form to automatically create your student record and official enrollment.</div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <style>
        .eform-card { border-radius: 0; }
        .eform-heading-row { display:flex; justify-content:space-between; align-items:center; padding-bottom:1rem; margin-bottom:1rem; border-bottom:2px solid rgba(15,23,42,.55); }
        .eform-main-title { margin:0; font-size:2rem; letter-spacing:.02em; }
        .eform-divider { height:1px; background:rgba(15,23,42,.14); margin:.5rem 0 1rem; }
        .eform-section-title { margin:1rem 0 .75rem; font-size:1.1rem; text-decoration:underline; }
        .eform-wide { flex:1.4; }
        .eform-submit-btn { background:#111; color:#fff; border-radius:0; min-width:160px; }
        .eform-submit-btn:hover { background:#000; }
    </style>

    <script>
        async function populateLocationSelect(url, selectId, placeholder) {
            const select = document.getElementById(selectId);
            if (!select) return;
            select.innerHTML = `<option value="">${placeholder}</option>`;
            if (!url) return;
            const response = await fetch(url);
            const items = await response.json();
            items.forEach(item => {
                const option = document.createElement('option');
                option.value = item.code;
                option.textContent = item.name;
                select.appendChild(option);
            });
        }

        document.addEventListener('DOMContentLoaded', function() {
            const regionSelect = document.getElementById('region_code');
            const provinceSelect = document.getElementById('province_code');
            const citySelect = document.getElementById('citymun_code');
            const barangaySelect = document.getElementById('barangay_code');

            function setDisabledState() {
                provinceSelect.disabled = !regionSelect.value;
                citySelect.disabled = !provinceSelect.value;
                barangaySelect.disabled = !citySelect.value;
            }

            setDisabledState();

            regionSelect.addEventListener('change', async function() {
                await populateLocationSelect(`<?php echo APP_URL; ?>/modules/student/eform.php?location_lookup=provinces&region_code=${encodeURIComponent(this.value)}`, 'province_code', 'Select Province');
                await populateLocationSelect('', 'citymun_code', 'Select City');
                await populateLocationSelect('', 'barangay_code', 'Select Barangay');
                setDisabledState();
                if (this.value) provinceSelect.focus();
            });

            provinceSelect.addEventListener('change', async function() {
                await populateLocationSelect(`<?php echo APP_URL; ?>/modules/student/eform.php?location_lookup=cities&province_code=${encodeURIComponent(this.value)}`, 'citymun_code', 'Select City');
                await populateLocationSelect('', 'barangay_code', 'Select Barangay');
                setDisabledState();
                if (this.value) citySelect.focus();
            });

            citySelect.addEventListener('change', async function() {
                await populateLocationSelect(`<?php echo APP_URL; ?>/modules/student/eform.php?location_lookup=barangays&citymun_code=${encodeURIComponent(this.value)}`, 'barangay_code', 'Select Barangay');
                setDisabledState();
                if (this.value) barangaySelect.focus();
            });

            barangaySelect.addEventListener('change', function() {
                if (this.value) document.getElementById('address_street').focus();
            });
        });
    </script>

    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
