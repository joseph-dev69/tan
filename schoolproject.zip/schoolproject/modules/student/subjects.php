<?php
/**
 * Student Subjects / Grades Page
 * School Information System
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';

require_role('student');

$current_user = get_logged_in_user();
$student_info = get_single_result("
    SELECT s.*, c.course_name, c.course_code
    FROM students s
    LEFT JOIN courses c ON s.course_id = c.course_id
    WHERE s.user_id = ?
", [$current_user['user_id']]);

$student_setup_missing = !$student_info;
$student_id = $student_info['student_id'] ?? null;
$school_years = get_multiple_results("SELECT school_year_id, year_name FROM school_years ORDER BY school_year_id DESC");
$current_school_year = get_single_result("SELECT * FROM school_years WHERE is_current = TRUE");
$current_semester = get_single_result("SELECT * FROM semesters WHERE is_current = TRUE");
$selected_school_year_id = (int)($_GET['school_year_id'] ?? 0);
$selected_semester_id = (int)($_GET['semester_id'] ?? 0);
$semesters = get_fixed_semester_options($selected_school_year_id);
$selected_semester_name = $selected_semester_id > 0 ? get_semester_name_by_id($selected_semester_id) : '';
$subject_history = [];
$grouped_subjects = [];
$latest_term = null;

if ($student_id) {
    $conditions = ["e.student_id = ?"];
    $params = [$student_id];

    if ($selected_school_year_id > 0) {
        $conditions[] = "e.school_year_id = ?";
        $params[] = $selected_school_year_id;
    }

    if ($selected_semester_name !== '') {
        $conditions[] = "sem.semester_name = ?";
        $params[] = $selected_semester_name;
    }

    $subject_history = get_multiple_results("
        SELECT sy.school_year_id, sy.year_name,
               sem.semester_id, sem.semester_name,
               sub.subject_code, sub.subject_name, sub.units, sub.year_level,
               so.section,
               loadrec.status,
               loadrec.remarks,
               CONCAT(u.last_name, ', ', u.first_name) AS teacher_name,
               prelim.grade AS prelim_grade,
               midterm.grade AS midterm_grade,
               finals.grade AS final_grade
        FROM student_subject_loads loadrec
        JOIN enrollments e ON loadrec.enrollment_id = e.enrollment_id
        JOIN school_years sy ON e.school_year_id = sy.school_year_id
        JOIN semesters sem ON e.semester_id = sem.semester_id
        JOIN subject_offerings so ON loadrec.offering_id = so.offering_id
        JOIN subjects sub ON so.subject_id = sub.subject_id
        LEFT JOIN teachers t ON so.teacher_id = t.teacher_id
        LEFT JOIN users u ON t.user_id = u.user_id
        LEFT JOIN grades prelim ON prelim.student_subject_load_id = loadrec.load_id AND prelim.grading_period = 'prelim'
        LEFT JOIN grades midterm ON midterm.student_subject_load_id = loadrec.load_id AND midterm.grading_period = 'midterm'
        LEFT JOIN grades finals ON finals.student_subject_load_id = loadrec.load_id AND finals.grading_period = 'final'
        WHERE " . implode(' AND ', $conditions) . "
        ORDER BY sy.school_year_id ASC, sem.semester_id ASC, sub.subject_code ASC
    ", $params);

    foreach ($subject_history as $subject) {
        $group_key = $subject['year_name'] . '||' . $subject['semester_name'];
        $subject_year_level = (int)($subject['year_level'] ?? 0);
        $display_year_level = $subject_year_level > 0 ? $subject_year_level : (int)($student_info['year_level'] ?? 0);

        if (!isset($grouped_subjects[$group_key])) {
            $grouped_subjects[$group_key] = [
                'year_name' => $subject['year_name'],
                'semester_name' => $subject['semester_name'],
                'year_level' => $display_year_level,
                'subjects' => [],
                'total_units' => 0,
            ];
        }

        $status_code = strtolower((string)($subject['status'] ?? ''));
        $prelim_grade = $subject['prelim_grade'];
        $midterm_grade = $subject['midterm_grade'];
        $final_grade = $subject['final_grade'];

        $has_complete_grades = $prelim_grade !== null && $prelim_grade !== ''
            && $midterm_grade !== null && $midterm_grade !== ''
            && $final_grade !== null && $final_grade !== '';

        $overall_grade = null;
        if ($has_complete_grades) {
            $overall_grade = round((((float)$prelim_grade + (float)$midterm_grade + (float)$final_grade) / 3), 2);
        }

        if ($status_code === 'dropped') {
            $status_label = 'Dropped';
            $status_class = 'status-drop';
        } elseif (!$has_complete_grades) {
            $status_label = 'Pending';
            $status_class = 'status-pending';
        } elseif ((float)$overall_grade >= 75) {
            $status_label = 'Passed';
            $status_class = 'status-passed';
        } else {
            $status_label = 'Failed';
            $status_class = 'status-failed';
        }

        $subject['prelim_display'] = $prelim_grade !== null && $prelim_grade !== '' ? rtrim(rtrim(number_format((float)$prelim_grade, 2, '.', ''), '0'), '.') : '--';
        $subject['midterm_display'] = $midterm_grade !== null && $midterm_grade !== '' ? rtrim(rtrim(number_format((float)$midterm_grade, 2, '.', ''), '0'), '.') : '--';
        $subject['final_display'] = $final_grade !== null && $final_grade !== '' ? rtrim(rtrim(number_format((float)$final_grade, 2, '.', ''), '0'), '.') : '--';
        $subject['grade_display'] = $overall_grade !== null ? rtrim(rtrim(number_format((float)$overall_grade, 2, '.', ''), '0'), '.') : '--';
        $subject['status_label'] = $status_label;
        $subject['status_class'] = $status_class;

        $grouped_subjects[$group_key]['subjects'][] = $subject;
        $grouped_subjects[$group_key]['total_units'] += (float)$subject['units'];
    }

    if (!empty($grouped_subjects)) {
        $latest_term = end($grouped_subjects);
        reset($grouped_subjects);
    }
}

function format_year_level_label($year_level)
{
    $year_level = (int)$year_level;
    if ($year_level <= 0) {
        return 'Not assigned';
    }

    $suffix = 'th';
    if ($year_level % 10 === 1 && $year_level % 100 !== 11) {
        $suffix = 'st';
    } elseif ($year_level % 10 === 2 && $year_level % 100 !== 12) {
        $suffix = 'nd';
    } elseif ($year_level % 10 === 3 && $year_level % 100 !== 13) {
        $suffix = 'rd';
    }

    return $year_level . $suffix . ' Year';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Subjects - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
    <style>
        .grades-overview {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 1rem;
            margin-top: 1rem;
        }
        .grades-overview .meta-label,
        .term-grade-card .meta-label {
            display: block;
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: #7d8fb3;
            margin-bottom: 0.3rem;
        }
        .grades-overview .meta-value {
            color: #2457e6;
            font-weight: 600;
        }
        .notice-strip {
            margin-bottom: 1rem;
            padding: 0.85rem 1rem;
            border: 1px solid #f6c67a;
            background: #fff4e7;
            color: #9a5d00;
            border-radius: 12px;
            font-size: 0.92rem;
        }
        .legend-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 0.8rem;
        }
        .legend-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.82rem;
            color: #5f6f92;
        }
        .pill {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 64px;
            padding: 0.25rem 0.6rem;
            border-radius: 999px;
            font-size: 0.64rem;
            font-weight: 700;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            border: 1px solid transparent;
            white-space: nowrap;
        }
        .status-passed {
            background: #def9e5;
            color: #15803d;
        }
        .status-pending {
            background: #fde2e2;
            color: #dc2626;
        }
        .status-failed {
            background: #ffe3e3;
            color: #b91c1c;
        }
        .status-drop {
            background: #ffe4e6;
            color: #be123c;
        }
        .term-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(340px, 1fr));
            gap: 1rem;
        }
        .term-grade-card .card-header {
            display: flex;
            justify-content: center;
            text-align: center;
        }
        .term-grade-card table {
            font-size: 0.9rem;
        }
        .term-grade-card thead th {
            font-size: 0.68rem;
            letter-spacing: 0.08em;
            text-transform: uppercase;
        }
        .term-grade-card tbody td {
            vertical-align: top;
        }
        .grade-value {
            color: #07a33f;
            font-weight: 700;
        }
        .grade-column {
            text-align: center;
            white-space: nowrap;
        }
        .units-total-row td {
            background: #f5f7fb;
            font-weight: 700;
        }
        @media (max-width: 992px) {
            .grades-overview {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }
        @media (max-width: 640px) {
            .grades-overview {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo"><a href="<?php echo APP_URL; ?>/modules/student/dashboard.php">Enchong Dee University Information System</a></div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <?php render_student_sidebar('subjects'); ?>

        <main class="main-content">
            <div class="content-wrapper">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="page-header" style="margin-bottom: 0;">
                            <h1>Grades</h1>
                            <p>Academic performance overview</p>
                        </div>

                        <div class="grades-overview">
                            <div>
                                <span class="meta-label">Student No.</span>
                                <span class="meta-value"><?php echo htmlspecialchars($student_info['student_number'] ?? 'Not assigned'); ?></span>
                            </div>
                            <div>
                                <span class="meta-label">Course</span>
                                <span class="meta-value"><?php echo htmlspecialchars($student_info['course_code'] ?? 'N/A'); ?><?php echo !empty($student_info['course_name']) ? ' - ' . htmlspecialchars($student_info['course_name']) : ''; ?></span>
                            </div>
                            <div>
                                <span class="meta-label">Year Level</span>
                                <span class="meta-value"><?php echo htmlspecialchars(format_year_level_label($student_info['year_level'] ?? 0)); ?></span>
                            </div>
                            <div>
                                <span class="meta-label">Semester</span>
                                <span class="meta-value"><?php echo htmlspecialchars($latest_term['semester_name'] ?? ($current_semester['semester_name'] ?? 'Not assigned')); ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <?php if ($student_setup_missing): ?>
                    <div class="alert alert-warning mb-4">
                        Your student record is not assigned yet, so subject and grade records are not available.
                    </div>
                <?php else: ?>
                    <div class="notice-strip">
                        <strong>Notice:</strong> Your prelim, midterm, final, and overall grades per term appear below.
                    </div>
                <?php endif; ?>

                <div class="card mb-4">
                    <div class="card-header">
                        <h4>Legend</h4>
                    </div>
                    <div class="card-body">
                        <div class="legend-grid">
                            <div class="legend-item"><span class="pill status-pending">Pending</span><span>Grade has not been posted yet.</span></div>
                            <div class="legend-item"><span class="pill status-passed">Passed</span><span>Student passed the subject.</span></div>
                            <div class="legend-item"><span class="pill status-failed">Failed</span><span>Student did not pass the subject.</span></div>
                            <div class="legend-item"><span class="pill status-drop">Drop</span><span>Subject was officially dropped.</span></div>
                        </div>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-header">
                        <h4>Filter Grades</h4>
                    </div>
                    <div class="card-body">
                        <form method="GET" class="form-row">
                            <div class="form-group">
                                <label for="school_year_id" class="form-label">School Year</label>
                                <select id="school_year_id" name="school_year_id" class="form-control">
                                    <option value="0">All School Years</option>
                                    <?php foreach ($school_years as $school_year): ?>
                                        <option value="<?php echo (int)$school_year['school_year_id']; ?>" <?php echo $selected_school_year_id === (int)$school_year['school_year_id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($school_year['year_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="semester_id" class="form-label">Semester</label>
                                <select id="semester_id" name="semester_id" class="form-control">
                                    <option value="0">All Semesters</option>
                                    <?php foreach ($semesters as $semester): ?>
                                        <option value="<?php echo (int)$semester['semester_id']; ?>" <?php echo $selected_semester_id === (int)$semester['semester_id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($semester['semester_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group" style="align-self:end;">
                                <button type="submit" class="btn btn-primary">Apply Filter</button>
                            </div>
                        </form>
                    </div>
                </div>

                <?php if ($grouped_subjects): ?>
                    <div class="term-grid">
                        <?php foreach ($grouped_subjects as $term): ?>
                            <div class="card term-grade-card">
                                <div class="card-header">
                                    <h4><?php echo htmlspecialchars(format_year_level_label($term['year_level']) . ' - ' . $term['semester_name'] . ' (' . $term['year_name'] . ')'); ?></h4>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th>Code</th>
                                                    <th>Description</th>
                                                    <th>Units</th>
                                                    <th>Prelim</th>
                                                    <th>Midterm</th>
                                                    <th>Final</th>
                                                    <th>Grade</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($term['subjects'] as $subject): ?>
                                                    <tr>
                                                        <td><strong><?php echo htmlspecialchars($subject['subject_code']); ?></strong></td>
                                                        <td>
                                                            <?php echo htmlspecialchars($subject['subject_name']); ?>
                                                                <div class="text-muted" style="font-size:0.75rem;">
                                                                    <?php echo htmlspecialchars($subject['teacher_name'] ?: 'Teacher not assigned'); ?>
                                                                </div>
                                                        </td>
                                                        <td><?php echo htmlspecialchars(rtrim(rtrim(number_format((float)$subject['units'], 2, '.', ''), '0'), '.')); ?></td>
                                                        <td class="grade-column"><?php echo htmlspecialchars($subject['prelim_display']); ?></td>
                                                        <td class="grade-column"><?php echo htmlspecialchars($subject['midterm_display']); ?></td>
                                                        <td class="grade-column"><?php echo htmlspecialchars($subject['final_display']); ?></td>
                                                        <td class="grade-value grade-column"><?php echo htmlspecialchars($subject['grade_display']); ?></td>
                                                        <td><span class="pill <?php echo htmlspecialchars($subject['status_class']); ?>"><?php echo htmlspecialchars($subject['status_label']); ?></span></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                                <tr class="units-total-row">
                                                    <td colspan="2">Total Earned Units:</td>
                                                    <td colspan="6"><?php echo htmlspecialchars(rtrim(rtrim(number_format((float)$term['total_units'], 2, '.', ''), '0'), '.')); ?></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="card">
                        <div class="card-body">
                            <p class="text-muted">No subject or grade records found for the selected filters.</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
