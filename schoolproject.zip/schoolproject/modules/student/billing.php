<?php
/**
 * Student Billing Page
 * School Information System
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';
require_once __DIR__ . '/../finance/billing_helpers.php';

require_role('student');

$current_user = get_logged_in_user();
$student_info = get_single_result("
    SELECT s.*, c.course_name, c.course_code
    FROM students s
    LEFT JOIN courses c ON s.course_id = c.course_id
    WHERE s.user_id = ?
", [$current_user['user_id']]);

$student_setup_missing = !$student_info;
$student_id = $student_info['student_id'] ?? null;
$current_enrollment = false;
$current_billing = false;
$billing_records = [];
$billing_breakdown = [];
$payment_history = [];
$selected_phase = strtolower(trim($_GET['phase'] ?? 'prelim'));
$selected_phase = in_array($selected_phase, ['prelim', 'midterm', 'final'], true) ? $selected_phase : 'prelim';
$phase_statuses = [];
$next_due_phase = 'prelim';
$current_exam_phase = 'prelim';

if ($student_id) {
    $current_enrollment = get_single_result("
        SELECT e.*, sy.year_name, sem.semester_name
        FROM enrollments e
        JOIN school_years sy ON e.school_year_id = sy.school_year_id
        JOIN semesters sem ON e.semester_id = sem.semester_id
        WHERE e.student_id = ? AND e.status = 'enrolled'
        ORDER BY e.enrollment_date DESC
        LIMIT 1
    ", [$student_id]);

    if ($current_enrollment) {
        $current_billing = get_single_result("
            SELECT b.*, sy.year_name, sem.semester_name
            FROM billings b
            JOIN school_years sy ON b.school_year_id = sy.school_year_id
            JOIN semesters sem ON b.semester_id = sem.semester_id
            WHERE b.student_id = ? AND b.school_year_id = ? AND b.semester_id = ?
            ORDER BY b.billing_date DESC
            LIMIT 1
        ", [$student_id, $current_enrollment['school_year_id'], $current_enrollment['semester_id']]);
    }

    $billing_records = get_multiple_results("
        SELECT b.*, sy.year_name, sem.semester_name
        FROM billings b
        JOIN school_years sy ON b.school_year_id = sy.school_year_id
        JOIN semesters sem ON b.semester_id = sem.semester_id
        WHERE b.student_id = ?
        ORDER BY sy.school_year_id DESC, sem.semester_id DESC, b.billing_date DESC
    ", [$student_id]);

    if ($current_billing) {
        $billing_breakdown = get_multiple_results("
            SELECT bd.*, fs.fee_name, fs.fee_type
            FROM billing_details bd
            LEFT JOIN fee_schedules fs ON bd.fee_schedule_id = fs.fee_schedule_id
            WHERE bd.billing_id = ?
            ORDER BY fs.fee_type, fs.fee_name
        ", [$current_billing['billing_id']]);

        $payment_history = get_multiple_results("
            SELECT p.*
            FROM payments p
            WHERE p.billing_id = ?
            ORDER BY p.payment_date DESC, p.payment_id DESC
        ", [$current_billing['billing_id']]);

        $phase_statuses = finance_get_billing_phase_status($current_billing);
        $next_due_phase = finance_get_next_due_phase($phase_statuses);
        $current_exam_phase = finance_get_current_exam_phase((int)$current_billing['school_year_id'], (int)$current_billing['semester_id']);
    }
}

if (isset($_GET['download']) && $_GET['download'] === 'permit' && $student_id && $current_enrollment) {
    if (empty($_GET['phase'])) {
        $selected_phase = $current_exam_phase;
    }
    if (!$current_billing) {
        flash_message('error', 'Billing record is required before the permit can be generated.');
        redirect('modules/student/billing.php');
    }

    [$can_download_permit, $phase_status] = finance_can_download_permit($current_billing, $selected_phase);
    if (!$can_download_permit) {
        $remaining_text = format_currency((float)($phase_status['remaining_to_unlock'] ?? 0));
        flash_message('error', ucfirst($selected_phase) . ' permit cannot be generated yet. Payment of ' . $remaining_text . ' is still required before downloading the permit.');
        redirect('modules/student/billing.php?phase=' . urlencode($selected_phase));
    }

    $permit_subjects = get_multiple_results("
        SELECT sub.subject_code, sub.subject_name, sub.units, so.section,
               CONCAT(u.first_name, ' ', u.last_name) AS teacher_name
        FROM student_subject_loads loadrec
        JOIN subject_offerings so ON loadrec.offering_id = so.offering_id
        JOIN subjects sub ON so.subject_id = sub.subject_id
        JOIN teachers t ON so.teacher_id = t.teacher_id
        JOIN users u ON t.user_id = u.user_id
        WHERE loadrec.enrollment_id = ? AND loadrec.status = 'enrolled'
        ORDER BY sub.subject_code
    ", [$current_enrollment['enrollment_id']]);

    header('Content-Type: text/html; charset=UTF-8');
    header('Content-Disposition: attachment; filename="student_permit.html"');
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Permit</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 32px; color: #1f2937; }
        table { width: 100%; border-collapse: collapse; margin-top: 16px; }
        th, td { border: 1px solid #cbd5e1; padding: 8px; text-align: left; }
        th { background: #e2e8f0; }
    </style>
</head>
<body>
    <h1>Student Permit</h1>
    <p><strong>Name:</strong> <?php echo htmlspecialchars($current_user['first_name'] . ' ' . $current_user['last_name']); ?></p>
    <p><strong>Student Number:</strong> <?php echo htmlspecialchars($student_info['student_number'] ?? 'Not assigned'); ?></p>
    <p><strong>Course:</strong> <?php echo htmlspecialchars($student_info['course_name'] ?? 'Not assigned'); ?></p>
    <p><strong>School Year:</strong> <?php echo htmlspecialchars($current_enrollment['year_name'] ?? ''); ?></p>
    <p><strong>Semester:</strong> <?php echo htmlspecialchars($current_enrollment['semester_name'] ?? ''); ?></p>
    <p><strong>Exam Phase:</strong> <?php echo htmlspecialchars(ucfirst($selected_phase)); ?></p>
    <table>
        <thead>
            <tr>
                <th>Subject Code</th>
                <th>Subject Name</th>
                <th>Units</th>
                <th>Section</th>
                <th>Teacher</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($permit_subjects as $subject): ?>
                <tr>
                    <td><?php echo htmlspecialchars($subject['subject_code']); ?></td>
                    <td><?php echo htmlspecialchars($subject['subject_name']); ?></td>
                    <td><?php echo htmlspecialchars((string)$subject['units']); ?></td>
                    <td><?php echo htmlspecialchars($subject['section']); ?></td>
                    <td><?php echo htmlspecialchars($subject['teacher_name']); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
    <?php
    exit;
}

$billing_summary = [
    'total_amount' => 0,
    'paid_amount' => 0,
    'balance' => 0,
    'record_count' => count($billing_records)
];

foreach ($billing_records as $billing) {
    $billing_summary['total_amount'] += (float)$billing['total_amount'];
    $billing_summary['paid_amount'] += (float)$billing['paid_amount'];
    $billing_summary['balance'] += (float)$billing['balance'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Billing and Permit - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo"><a href="<?php echo APP_URL; ?>/modules/student/dashboard.php">School Information System</a></div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <?php render_student_sidebar('billing'); ?>

        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Billing / Permit</h1>
                    <p>Check your billing records and download your permit after enrollment.</p>
                </div>

                <?php if ($student_setup_missing): ?>
                    <div class="alert alert-warning mb-4">
                        Your student record is not assigned yet, so billing records are not available.
                    </div>
                <?php endif; ?>

                <div class="row mb-4">
                    <div class="col-3"><div class="card billing-stat"><div class="card-body text-center"><p class="billing-stat-label">Total Billing</p><h4 class="text-primary"><?php echo format_currency($billing_summary['total_amount']); ?></h4></div></div></div>
                    <div class="col-3"><div class="card billing-stat"><div class="card-body text-center"><p class="billing-stat-label">Total Paid</p><h4 class="text-success"><?php echo format_currency($billing_summary['paid_amount']); ?></h4></div></div></div>
                    <div class="col-3"><div class="card billing-stat"><div class="card-body text-center"><p class="billing-stat-label">Remaining Balance</p><h4 class="text-warning"><?php echo format_currency($billing_summary['balance']); ?></h4></div></div></div>
                    <div class="col-3"><div class="card billing-stat"><div class="card-body text-center"><p class="billing-stat-label">Records</p><h4 class="text-info"><?php echo (int)$billing_summary['record_count']; ?></h4></div></div></div>
                </div>

                <div class="row mb-4">
                    <div class="col-8">
                       <div class="card equal-height-card">
                            <div class="card-header"><h4>Current Billing</h4></div>
                            <div class="card-body">
                                <?php if ($current_billing): ?>
                                    <p><strong><?php echo htmlspecialchars($current_billing['year_name']); ?> - <?php echo htmlspecialchars($current_billing['semester_name']); ?></strong></p>
                                    <p>Total: <?php echo format_currency($current_billing['total_amount']); ?></p>
                                    <p>Paid: <?php echo format_currency($current_billing['paid_amount']); ?></p>
                                    <p>Balance: <?php echo format_currency($current_billing['balance']); ?></p>
                                    <p>Status: <span class="badge badge-info"><?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $current_billing['status']))); ?></span></p>
                                    <p>Current Exam Phase: <span class="badge badge-primary"><?php echo htmlspecialchars($current_exam_phase ? ucfirst($current_exam_phase) : 'Schedule Not Set'); ?></span></p>
                                <?php else: ?>
                                    <p class="text-muted">No active unpaid billing found.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="card">
                            <div class="card-header"><h4>Student Permit</h4></div>
                            <div class="card-body">
                                <?php if ($current_enrollment && $current_billing): ?>
                                    <p class="text-muted">Permit download is checked automatically based on your payment for each exam phase and its due date.</p>
                                    <div class="table-responsive">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th>Phase</th>
                                                    <th>Exam Payment</th>
                                                    <th>Required Now</th>
                                                    <th>Due Date</th>
                                                    <th>Paid for Phase</th>
                                                    <th>Status</th>
                                                    <th>Permit</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($phase_statuses as $phase_key => $phase): ?>
                                                    <tr>
                                                        <td><?php echo htmlspecialchars($phase['label']); ?></td>
                                                        <td><?php echo format_currency($phase['amount']); ?></td>
                                                        <td><?php echo format_currency($phase['remaining_for_phase'] > 0 ? $phase['remaining_for_phase'] : $phase['amount']); ?></td>
                                                        <td><?php echo htmlspecialchars(!empty($phase['due_date']) ? format_date($phase['due_date']) : 'Schedule Not Set'); ?></td>
                                                        <td><?php echo format_currency($phase['paid_amount']); ?></td>
                                                        <td>
                                                            <span class="badge badge-<?php echo htmlspecialchars($phase['status_badge']); ?>">
                                                                <?php echo htmlspecialchars($phase['status_label']); ?>
                                                            </span>
                                                        </td>
                                                        <td>
                                                            <?php if ($phase['is_paid']): ?>
                                                                <a href="<?php echo APP_URL; ?>/modules/student/billing.php?download=permit&phase=<?php echo urlencode($phase_key); ?>" class="btn btn-primary btn-sm">Download <?php echo htmlspecialchars($phase['label']); ?></a>
                                                            <?php else: ?>
                                                                <button type="button" class="btn btn-secondary btn-sm" disabled>Blocked</button>
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <p class="text-muted">Current payment priority: <strong><?php echo htmlspecialchars(ucfirst($next_due_phase)); ?></strong></p>
                                <?php else: ?>
                                    <p class="text-muted">Permit becomes available after enrollment and billing generation.</p>
                                    <button type="button" class="btn btn-secondary" disabled>Permit Not Available</button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mb-4">
                    <div class="col-6">
                        <div class="card">
                            <div class="card-header"><h4>Breakdown of Charges</h4></div>
                            <div class="card-body">
                                <?php if ($billing_breakdown): ?>
                                    <div class="table-responsive">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th>Charge</th>
                                                    <th>Type</th>
                                                    <th>Qty</th>
                                                    <th>Unit Cost</th>
                                                    <th>Total</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($billing_breakdown as $detail): ?>
                                                    <tr>
                                                        <td><?php echo htmlspecialchars($detail['fee_name'] ?? 'Manual Charge'); ?></td>
                                                        <td><?php echo htmlspecialchars(ucfirst($detail['fee_type'] ?? 'other')); ?></td>
                                                        <td><?php echo htmlspecialchars((string)$detail['quantity']); ?></td>
                                                        <td><?php echo format_currency($detail['unit_cost']); ?></td>
                                                        <td><?php echo format_currency($detail['total_cost']); ?></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php else: ?>
                                    <p class="text-muted">No charge breakdown available yet.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="card">
                            <div class="card-header"><h4>Payment History</h4></div>
                            <div class="card-body">
                                <?php if ($payment_history): ?>
                                    <div class="table-responsive">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th>Date</th>
                                                    <th>Amount</th>
                                                    <th>Method</th>
                                                    <th>Reference</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($payment_history as $payment): ?>
                                                    <tr>
                                                        <td><?php echo htmlspecialchars(format_date($payment['payment_date'])); ?></td>
                                                        <td><?php echo format_currency($payment['amount']); ?></td>
                                                        <td><?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $payment['payment_method']))); ?></td>
                                                        <td><?php echo htmlspecialchars($payment['reference_number'] ?: '-'); ?></td>
                                                        <td><span class="badge badge-info"><?php echo htmlspecialchars(ucfirst($payment['status'])); ?></span></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php else: ?>
                                    <p class="text-muted">No payment history available yet.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <?php if ($phase_statuses): ?>
                    <div class="card mb-4">
                        <div class="card-header"><h4>Exam Payment Schedule</h4></div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Exam Phase</th>
                                            <th>Payment Amount</th>
                                            <th>Due Date</th>
                                            <th>Paid for Phase</th>
                                            <th>Remaining for Phase</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($phase_statuses as $phase): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($phase['label']); ?></td>
                                                <td><?php echo format_currency($phase['amount']); ?></td>
                                                <td><?php echo htmlspecialchars(!empty($phase['due_date']) ? format_date($phase['due_date']) : 'Schedule Not Set'); ?></td>
                                                <td><?php echo format_currency($phase['paid_amount']); ?></td>
                                                <td><?php echo format_currency($phase['remaining_for_phase']); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-header"><h4>Billing Records</h4></div>
                    <div class="card-body">
                        <?php if ($billing_records): ?>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>School Year</th>
                                            <th>Semester</th>
                                            <th>Total Tuition and Fees</th>
                                            <th>Paid</th>
                                            <th>Remaining Balance</th>
                                            <th>Status</th>
                                            <th>Billing Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($billing_records as $billing): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($billing['year_name']); ?></td>
                                                <td><?php echo htmlspecialchars($billing['semester_name']); ?></td>
                                                <td><?php echo format_currency($billing['total_amount']); ?></td>
                                                <td><?php echo format_currency($billing['paid_amount']); ?></td>
                                                <td><?php echo format_currency($billing['balance']); ?></td>
                                                <td><span class="badge badge-info"><?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $billing['status']))); ?></span></td>
                                                <td><?php echo htmlspecialchars(format_date($billing['billing_date'])); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">No billing records available yet.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <style>
        .billing-stat { min-height: 130px; }
        .billing-stat-label {
            color: var(--gray-color);
            font-size: .9rem;
            text-transform: uppercase;
            letter-spacing: .04em;
            margin-bottom: .5rem;
        }
    </style>

    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
