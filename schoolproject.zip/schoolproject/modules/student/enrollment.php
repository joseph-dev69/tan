<?php
/**
 * Student Enrollment Page
 * School Information System
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';

// Require student role
require_role('student');

function ensure_enrollment_applications_table() {
    $conn = get_db_connection();
    $conn->exec("
        CREATE TABLE IF NOT EXISTS enrollment_applications (
            application_id INT PRIMARY KEY AUTO_INCREMENT,
            user_id INT NOT NULL,
            school_year_id INT NOT NULL,
            semester_id INT NOT NULL,
            course_id INT NOT NULL,
            year_level INT NOT NULL DEFAULT 1,
            major_department_id INT NULL,
            region_code VARCHAR(20) NULL,
            province_code VARCHAR(20) NULL,
            citymun_code VARCHAR(20) NULL,
            barangay_code VARCHAR(20) NULL,
            first_name VARCHAR(100) NOT NULL,
            last_name VARCHAR(100) NOT NULL,
            middle_name VARCHAR(100) NULL,
            birth_date DATE NOT NULL,
            gender VARCHAR(20) NOT NULL,
            civil_status VARCHAR(20) NOT NULL,
            address_region VARCHAR(100) NULL,
            address_province VARCHAR(100) NOT NULL,
            address_city VARCHAR(100) NOT NULL,
            address_barangay VARCHAR(100) NOT NULL,
            address_street VARCHAR(150) NOT NULL,
            address_house_number VARCHAR(50) NOT NULL,
            phone_number VARCHAR(30) NOT NULL,
            email VARCHAR(150) NOT NULL,
            guardian_name VARCHAR(150) NOT NULL,
            guardian_contact VARCHAR(30) NOT NULL,
            guardian_address TEXT NOT NULL,
            status ENUM('submitted', 'reviewed', 'approved', 'rejected') DEFAULT 'submitted',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY unique_term_application (user_id, school_year_id, semester_id),
            CONSTRAINT fk_enrollment_applications_user FOREIGN KEY (user_id) REFERENCES users(user_id),
            CONSTRAINT fk_enrollment_applications_school_year FOREIGN KEY (school_year_id) REFERENCES school_years(school_year_id),
            CONSTRAINT fk_enrollment_applications_semester FOREIGN KEY (semester_id) REFERENCES semesters(semester_id),
            CONSTRAINT fk_enrollment_applications_course FOREIGN KEY (course_id) REFERENCES courses(course_id),
            CONSTRAINT fk_enrollment_applications_major_department FOREIGN KEY (major_department_id) REFERENCES departments(department_id)
        )
    ");

    $existing_columns = [];
    foreach ($conn->query("SHOW COLUMNS FROM enrollment_applications") as $column) {
        $existing_columns[] = $column['Field'];
    }

    $column_updates = [
        "year_level INT NOT NULL DEFAULT 1 AFTER course_id",
        "region_code VARCHAR(20) NULL",
        "province_code VARCHAR(20) NULL",
        "citymun_code VARCHAR(20) NULL",
        "barangay_code VARCHAR(20) NULL",
        "address_region VARCHAR(100) NULL"
    ];

    foreach ($column_updates as $definition) {
        $column_name = strtok($definition, ' ');
        if (!in_array($column_name, $existing_columns, true)) {
            $conn->exec("ALTER TABLE enrollment_applications ADD COLUMN $definition");
        }
    }
}

ensure_enrollment_applications_table();

function reference_table_exists($table_name) {
    static $cache = [];

    if (!array_key_exists($table_name, $cache)) {
        try {
            $result = get_single_result("
                SELECT COUNT(*) AS table_count
                FROM information_schema.tables
                WHERE table_schema = DATABASE() AND table_name = ?
            ", [$table_name]);
            $cache[$table_name] = ((int)($result['table_count'] ?? 0)) > 0;
        } catch (Exception $e) {
            $cache[$table_name] = false;
        }
    }

    return $cache[$table_name];
}

function get_location_name($table, $code_field, $desc_field, $code_value) {
    if (!$code_value || !reference_table_exists($table)) {
        return '';
    }

    $row = get_single_result("SELECT $desc_field AS label FROM $table WHERE $code_field = ? LIMIT 1", [$code_value]);
    return $row['label'] ?? '';
}

function get_location_options($table, $code_field, $desc_field, $where_sql = '', $params = []) {
    if (!reference_table_exists($table)) {
        return [];
    }

    return get_multiple_results("
        SELECT $code_field AS code, $desc_field AS name
        FROM $table
        $where_sql
        ORDER BY $desc_field ASC
    ", $params);
}

// Get current student information
$current_user = get_logged_in_user();
$student_info = get_single_result("
    SELECT s.*, c.course_name, c.course_code, d.department_name
    FROM students s
    JOIN courses c ON s.course_id = c.course_id
    JOIN departments d ON c.department_id = d.department_id
    WHERE s.user_id = ?
", [$current_user['user_id']]);
$student_setup_missing = !$student_info;
$student_id = $student_info['student_id'] ?? null;
$has_location_reference_tables = reference_table_exists('refregion')
    && reference_table_exists('refprovince')
    && reference_table_exists('refcitymun')
    && reference_table_exists('refbrgy');

if (isset($_GET['location_lookup']) && $has_location_reference_tables) {
    header('Content-Type: application/json');

    $type = $_GET['location_lookup'];
    $items = [];

    if ($type === 'provinces') {
        $items = get_location_options('refprovince', 'provCode', 'provDesc', 'WHERE regCode = ?', [$_GET['region_code'] ?? '']);
    } elseif ($type === 'cities') {
        $items = get_location_options('refcitymun', 'citymunCode', 'citymunDesc', 'WHERE provCode = ?', [$_GET['province_code'] ?? '']);
    } elseif ($type === 'barangays') {
        $items = get_location_options('refbrgy', 'brgyCode', 'brgyDesc', 'WHERE citymunCode = ?', [$_GET['citymun_code'] ?? '']);
    }

    echo json_encode($items);
    exit;
}

// Get current academic year and semester
$current_school_year = get_single_result("SELECT * FROM school_years WHERE is_current = TRUE");
$current_semester = get_single_result("SELECT * FROM semesters WHERE is_current = TRUE");
$school_years = get_multiple_results("SELECT school_year_id, year_name FROM school_years ORDER BY school_year_id DESC");
$semesters = get_multiple_results("SELECT semester_id, semester_name FROM semesters ORDER BY semester_id ASC");
$courses = get_multiple_results("SELECT course_id, course_name, course_code FROM courses ORDER BY course_name");
$departments = get_multiple_results("SELECT department_id, department_name, department_code FROM departments ORDER BY department_name");

if (!$current_school_year || !$current_semester) {
    flash_message('error', 'No current academic year or semester is set. Please contact the administrator.');
    redirect('modules/student/dashboard.php');
}

$compatible_semester_ids = array_map('intval', array_column(get_multiple_results("
    SELECT semester_id
    FROM semesters
    WHERE semester_name = ?
", [$current_semester['semester_name']]), 'semester_id'));

if (!in_array((int)$current_semester['semester_id'], $compatible_semester_ids, true)) {
    $compatible_semester_ids[] = (int)$current_semester['semester_id'];
}

$compatible_semester_ids = array_values(array_unique(array_filter($compatible_semester_ids)));
$compatible_semester_placeholders = implode(',', array_fill(0, count($compatible_semester_ids), '?'));

$application_form = [
    'school_year_id' => (int)$current_school_year['school_year_id'],
    'semester_id' => (int)$current_semester['semester_id'],
    'course_id' => (int)($student_info['course_id'] ?? 0),
    'year_level' => (int)($student_info['year_level'] ?? 1),
    'major_department_id' => (int)($student_info['department_id'] ?? 0),
    'region_code' => '',
    'province_code' => '',
    'citymun_code' => '',
    'barangay_code' => '',
    'first_name' => $current_user['first_name'] ?? '',
    'last_name' => $current_user['last_name'] ?? '',
    'middle_name' => $current_user['middle_name'] ?? '',
    'birth_date' => '',
    'gender' => 'Male',
    'civil_status' => 'Single',
    'address_region' => '',
    'address_province' => '',
    'address_city' => '',
    'address_barangay' => '',
    'address_street' => '',
    'address_house_number' => '',
    'phone_number' => '',
    'email' => $current_user['email'] ?? '',
    'guardian_name' => '',
    'guardian_contact' => '',
    'guardian_address' => ''
];
$application_errors = [];
$existing_application = get_single_result("
    SELECT *
    FROM enrollment_applications
    WHERE user_id = ?
      AND school_year_id = ?
      AND semester_id IN ($compatible_semester_placeholders)
      AND status IN ('submitted', 'reviewed', 'approved')
    ORDER BY updated_at DESC, application_id DESC
    LIMIT 1
", array_merge([$current_user['user_id'], $current_school_year['school_year_id']], $compatible_semester_ids));

if ($existing_application) {
    foreach ($application_form as $key => $value) {
        if (array_key_exists($key, $existing_application)) {
            $application_form[$key] = $existing_application[$key];
        }
    }
}

$current_enrollment = false;
if ($student_id) {
    $current_enrollment = get_single_result("
        SELECT e.*, sy.year_name, sem.semester_name
        FROM enrollments e
        JOIN school_years sy ON e.school_year_id = sy.school_year_id
        JOIN semesters sem ON e.semester_id = sem.semester_id
        WHERE e.student_id = ?
          AND e.school_year_id = ?
          AND e.semester_id IN ($compatible_semester_placeholders)
        ORDER BY e.enrollment_id DESC
        LIMIT 1
    ", array_merge([$student_id, $current_school_year['school_year_id']], $compatible_semester_ids));
}

error_log(sprintf(
    'Add/Drop E-Form check: user_id=%s student_id=%s school_year_id=%s current_semester_id=%s compatible_semester_ids=%s application_id=%s application_status=%s enrollment_id=%s',
    $current_user['user_id'] ?? 'none',
    $student_id ?? 'none',
    $current_school_year['school_year_id'] ?? 'none',
    $current_semester['semester_id'] ?? 'none',
    implode('|', $compatible_semester_ids),
    $existing_application['application_id'] ?? 'none',
    $existing_application['status'] ?? 'none',
    $current_enrollment['enrollment_id'] ?? 'none'
));

// Handle enrollment form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    $action = $_POST['action'] ?? 'submit_eform';
    $selected_subjects = $_POST['subjects'] ?? [];
    $conn = null;
    
    if (!verify_csrf_token($csrf_token)) {
        flash_message('error', 'Invalid request. Please try again.');
    } elseif ($action === 'submit_eform') {
        $application_form = [
            'school_year_id' => (int)($_POST['school_year_id'] ?? 0),
            'semester_id' => (int)($_POST['semester_id'] ?? 0),
            'course_id' => (int)($_POST['course_id'] ?? 0),
            'year_level' => max(1, min(4, (int)($_POST['year_level'] ?? 0))),
            'major_department_id' => (int)($_POST['major_department_id'] ?? 0),
            'region_code' => sanitize_input($_POST['region_code'] ?? ''),
            'province_code' => sanitize_input($_POST['province_code'] ?? ''),
            'citymun_code' => sanitize_input($_POST['citymun_code'] ?? ''),
            'barangay_code' => sanitize_input($_POST['barangay_code'] ?? ''),
            'first_name' => sanitize_input($_POST['first_name'] ?? ''),
            'last_name' => sanitize_input($_POST['last_name'] ?? ''),
            'middle_name' => sanitize_input($_POST['middle_name'] ?? ''),
            'birth_date' => sanitize_input($_POST['birth_date'] ?? ''),
            'gender' => sanitize_input($_POST['gender'] ?? ''),
            'civil_status' => sanitize_input($_POST['civil_status'] ?? ''),
            'address_region' => '',
            'address_province' => '',
            'address_city' => '',
            'address_barangay' => '',
            'address_street' => sanitize_input($_POST['address_street'] ?? ''),
            'address_house_number' => sanitize_input($_POST['address_house_number'] ?? ''),
            'phone_number' => sanitize_input($_POST['phone_number'] ?? ''),
            'email' => sanitize_input($_POST['email'] ?? ''),
            'guardian_name' => sanitize_input($_POST['guardian_name'] ?? ''),
            'guardian_contact' => sanitize_input($_POST['guardian_contact'] ?? ''),
            'guardian_address' => sanitize_input($_POST['guardian_address'] ?? '')
        ];

        if ($has_location_reference_tables) {
            $application_form['address_region'] = get_location_name('refregion', 'regCode', 'regDesc', $application_form['region_code']);
            $application_form['address_province'] = get_location_name('refprovince', 'provCode', 'provDesc', $application_form['province_code']);
            $application_form['address_city'] = get_location_name('refcitymun', 'citymunCode', 'citymunDesc', $application_form['citymun_code']);
            $application_form['address_barangay'] = get_location_name('refbrgy', 'brgyCode', 'brgyDesc', $application_form['barangay_code']);
        } else {
            $application_form['address_region'] = sanitize_input($_POST['address_region'] ?? '');
            $application_form['address_province'] = sanitize_input($_POST['address_province'] ?? '');
            $application_form['address_city'] = sanitize_input($_POST['address_city'] ?? '');
            $application_form['address_barangay'] = sanitize_input($_POST['address_barangay'] ?? '');
        }

        $required_application_fields = [
            'school_year_id', 'semester_id', 'course_id', 'year_level',
            'first_name', 'last_name', 'birth_date', 'gender', 'civil_status',
            'address_province', 'address_city', 'address_barangay', 'address_street',
            'address_house_number', 'phone_number', 'email', 'guardian_name',
            'guardian_contact', 'guardian_address'
        ];

        foreach ($required_application_fields as $field) {
            if (empty($application_form[$field])) {
                $application_errors[$field] = 'This field is required.';
            }
        }

        if (empty($application_errors['email']) && !validate_email($application_form['email'])) {
            $application_errors['email'] = 'Please enter a valid email address.';
        }

        if (empty($application_errors['phone_number']) && !validate_phone($application_form['phone_number'])) {
            $application_errors['phone_number'] = 'Please enter a valid Philippine phone number.';
        }

        if (empty($application_errors['guardian_contact']) && !validate_phone($application_form['guardian_contact'])) {
            $application_errors['guardian_contact'] = 'Please enter a valid guardian contact number.';
        }

        if (empty($application_errors['birth_date']) && !validate_date($application_form['birth_date'])) {
            $application_errors['birth_date'] = 'Please enter a valid birth date.';
        }

        if (empty($application_errors)) {
            try {
                $conn = get_db_connection();
                if ($existing_application) {
                    $stmt = $conn->prepare("
                        UPDATE enrollment_applications
                        SET school_year_id = ?, semester_id = ?, course_id = ?, year_level = ?, major_department_id = ?,
                            region_code = ?, province_code = ?, citymun_code = ?, barangay_code = ?,
                            first_name = ?, last_name = ?, middle_name = ?, birth_date = ?, gender = ?, civil_status = ?,
                            address_region = ?, address_province = ?, address_city = ?, address_barangay = ?, address_street = ?, address_house_number = ?,
                            phone_number = ?, email = ?, guardian_name = ?, guardian_contact = ?, guardian_address = ?, status = 'submitted'
                        WHERE application_id = ?
                    ");
                    $stmt->execute([
                        $application_form['school_year_id'],
                        $application_form['semester_id'],
                        $application_form['course_id'],
                        $application_form['year_level'],
                        $application_form['major_department_id'] ?: null,
                        $application_form['region_code'] ?: null,
                        $application_form['province_code'] ?: null,
                        $application_form['citymun_code'] ?: null,
                        $application_form['barangay_code'] ?: null,
                        $application_form['first_name'],
                        $application_form['last_name'],
                        $application_form['middle_name'] ?: null,
                        $application_form['birth_date'],
                        $application_form['gender'],
                        $application_form['civil_status'],
                        $application_form['address_region'],
                        $application_form['address_province'],
                        $application_form['address_city'],
                        $application_form['address_barangay'],
                        $application_form['address_street'],
                        $application_form['address_house_number'],
                        $application_form['phone_number'],
                        $application_form['email'],
                        $application_form['guardian_name'],
                        $application_form['guardian_contact'],
                        $application_form['guardian_address'],
                        $existing_application['application_id']
                    ]);
                } else {
                    $stmt = $conn->prepare("
                        INSERT INTO enrollment_applications (
                            user_id, school_year_id, semester_id, course_id, year_level, major_department_id,
                            region_code, province_code, citymun_code, barangay_code,
                            first_name, last_name, middle_name, birth_date, gender, civil_status,
                            address_region, address_province, address_city, address_barangay, address_street, address_house_number,
                            phone_number, email, guardian_name, guardian_contact, guardian_address, status
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'submitted')
                    ");
                    $stmt->execute([
                        $current_user['user_id'],
                        $application_form['school_year_id'],
                        $application_form['semester_id'],
                        $application_form['course_id'],
                        $application_form['year_level'],
                        $application_form['major_department_id'] ?: null,
                        $application_form['region_code'] ?: null,
                        $application_form['province_code'] ?: null,
                        $application_form['citymun_code'] ?: null,
                        $application_form['barangay_code'] ?: null,
                        $application_form['first_name'],
                        $application_form['last_name'],
                        $application_form['middle_name'] ?: null,
                        $application_form['birth_date'],
                        $application_form['gender'],
                        $application_form['civil_status'],
                        $application_form['address_region'],
                        $application_form['address_province'],
                        $application_form['address_city'],
                        $application_form['address_barangay'],
                        $application_form['address_street'],
                        $application_form['address_house_number'],
                        $application_form['phone_number'],
                        $application_form['email'],
                        $application_form['guardian_name'],
                        $application_form['guardian_contact'],
                        $application_form['guardian_address']
                    ]);
                }

                flash_message('success', 'Enrollment e-form submitted successfully.');
                redirect('modules/student/enrollment.php');
            } catch (Exception $e) {
                error_log("Enrollment e-form error: " . $e->getMessage());
                flash_message('error', 'Unable to submit the e-form right now.');
            }
        } else {
            $existing_application = array_merge($existing_application ?: [], $application_form);
        }
    } elseif ($action === 'drop_subject' && !$student_setup_missing) {
        try {
            $conn = (new Database())->getConnection();
            $conn->beginTransaction();

            if (!$current_enrollment) {
                throw new Exception('No active enrollment found for dropping subjects.');
            }

            $load_id = (int)($_POST['load_id'] ?? 0);
            $load = get_single_result("
                SELECT loadrec.load_id, loadrec.offering_id, loadrec.status, sub.units
                FROM student_subject_loads loadrec
                JOIN subject_offerings so ON loadrec.offering_id = so.offering_id
                JOIN subjects sub ON so.subject_id = sub.subject_id
                WHERE loadrec.load_id = ? AND loadrec.enrollment_id = ?
            ", [$load_id, $current_enrollment['enrollment_id']]);

            if (!$load || $load['status'] !== 'enrolled') {
                throw new Exception('Selected subject cannot be dropped.');
            }

            $conn->prepare("
                UPDATE student_subject_loads
                SET status = 'dropped', remarks = 'Dropped by student'
                WHERE load_id = ?
            ")->execute([$load_id]);

            $conn->prepare("
                UPDATE subject_offerings
                SET current_students = CASE WHEN current_students > 0 THEN current_students - 1 ELSE 0 END
                WHERE offering_id = ?
            ")->execute([$load['offering_id']]);

            $updated_units = get_single_result("
                SELECT COALESCE(SUM(sub.units), 0) AS total_units
                FROM student_subject_loads loadrec
                JOIN subject_offerings so ON loadrec.offering_id = so.offering_id
                JOIN subjects sub ON so.subject_id = sub.subject_id
                WHERE loadrec.enrollment_id = ? AND loadrec.status = 'enrolled'
            ", [$current_enrollment['enrollment_id']]);

            $conn->prepare("
                UPDATE enrollments
                SET total_units = ?
                WHERE enrollment_id = ?
            ")->execute([
                (int)($updated_units['total_units'] ?? 0),
                $current_enrollment['enrollment_id']
            ]);

            $conn->commit();
            flash_message('success', 'Subject dropped successfully.');
            redirect('modules/student/enrollment.php');
        } catch (Exception $e) {
            if ($conn instanceof PDO && $conn->inTransaction()) {
                $conn->rollBack();
            }
            error_log("Drop subject error: " . $e->getMessage());
            flash_message('error', $e->getMessage());
        }
    } elseif ($action !== 'submit_eform' && $student_setup_missing) {
        flash_message('error', 'Please submit the enrollment e-form first and wait for student record setup.');
    } elseif ($current_enrollment) {
        flash_message('error', 'You are already enrolled for the current term. Use drop subject below if you need to adjust your load.');
    } elseif (empty($selected_subjects)) {
        flash_message('error', 'Please select at least one subject to enroll.');
    } else {
        try {
            $conn = (new Database())->getConnection();
            $conn->beginTransaction();
            
            // Calculate total units
            $total_units = 0;
            $subject_details = [];
            
            foreach ($selected_subjects as $offering_id) {
                $subject = get_single_result("
                    SELECT so.*, sub.units, sub.subject_name, sub.subject_code
                    FROM subject_offerings so
                    JOIN subjects sub ON so.subject_id = sub.subject_id
                    WHERE so.offering_id = ? AND so.status = 'open' AND so.current_students < so.max_students
                ", [$offering_id]);
                
                if (!$subject) {
                    throw new Exception("Subject offering $offering_id is not available");
                }
                
                $total_units += $subject['units'];
                $subject_details[] = $subject;
            }
            
            // Check if student meets prerequisites
            foreach ($subject_details as $subject) {
                $prerequisites = get_multiple_results("
                    SELECT sp.prerequisite_subject_id, sub.subject_code, sub.subject_name
                    FROM subject_prerequisites sp
                    JOIN subjects sub ON sp.prerequisite_subject_id = sub.subject_id
                    WHERE sp.subject_id = ?
                ", [$subject['subject_id']]);
                
                foreach ($prerequisites as $prereq) {
                    $completed = get_single_result("
                        SELECT 1
                        FROM grades g
                        JOIN student_subject_loads loadrec ON g.student_subject_load_id = loadrec.load_id
                        JOIN enrollments e ON loadrec.enrollment_id = e.enrollment_id
                        JOIN subject_offerings so ON loadrec.offering_id = so.offering_id
                        WHERE e.student_id = ? AND so.subject_id = ? AND g.grade >= 75
                    ", [$student_id, $prereq['prerequisite_subject_id']]);
                    
                    if (!$completed) {
                        throw new Exception("Prerequisite '{$prereq['subject_name']}' not completed for '{$subject['subject_name']}'");
                    }
                }
            }
            
            // Create enrollment record
            $enrollment_data = [
                'student_id' => $student_id,
                'semester_id' => $current_semester['semester_id'],
                'school_year_id' => $current_school_year['school_year_id'],
                'enrollment_date' => date(DATE_FORMAT),
                'total_units' => $total_units
            ];
            
            $enrollment_id = insert_record('enrollments', $enrollment_data);
            
            // Add subjects to student load
            foreach ($selected_subjects as $offering_id) {
                $load_data = [
                    'enrollment_id' => $enrollment_id,
                    'offering_id' => $offering_id
                ];
                
                insert_record('student_subject_loads', $load_data);
                
                // Update current students count
                $conn->prepare("UPDATE subject_offerings SET current_students = current_students + 1 WHERE offering_id = ?")
                     ->execute([$offering_id]);
            }
            
            // Calculate fees (simplified - in real system, this would be more complex)
            $tuition_per_unit = 1500;
            $misc_fees = 2000;
            $total_fee = ($total_units * $tuition_per_unit) + $misc_fees;
            
            // Update enrollment with fee information
            update_record('enrollments', [
                'total_fee' => $total_fee,
                'balance' => $total_fee
            ], ['enrollment_id' => $enrollment_id]);
            
            // Create billing record
            $billing_data = [
                'student_id' => $student_id,
                'semester_id' => $current_semester['semester_id'],
                'school_year_id' => $current_school_year['school_year_id'],
                'billing_date' => date(DATE_FORMAT),
                'due_date' => date('Y-m-d', strtotime('+30 days')),
                'total_amount' => $total_fee
            ];
            
            $billing_id = insert_record('billings', $billing_data);
            
            insert_record('billing_details', [
                'billing_id' => $billing_id,
                'fee_schedule_id' => 1,
                'quantity' => $total_units,
                'unit_cost' => $tuition_per_unit
            ]);
            
            insert_record('billing_details', [
                'billing_id' => $billing_id,
                'fee_schedule_id' => 2,
                'quantity' => 1,
                'unit_cost' => $misc_fees
            ]);
            
            $conn->commit();
            
            send_notification($student_id, 'enrollment_completed', 'Enrollment completed successfully', [
                'enrollment_id' => $enrollment_id,
                'total_units' => $total_units,
                'total_fee' => $total_fee
            ]);
            
            flash_message('success', 'Enrollment completed successfully!');
            log_audit('STUDENT_ENROLLMENT', 'enrollments', $enrollment_id);
            
            redirect('modules/student/enrollment.php');
            
        } catch (Exception $e) {
            if ($conn instanceof PDO && $conn->inTransaction()) {
                $conn->rollBack();
            }
            error_log("Enrollment error: " . $e->getMessage());
            flash_message('error', $e->getMessage());
        }
    }
}

$region_options = $has_location_reference_tables ? get_location_options('refregion', 'regCode', 'regDesc') : [];
$province_options = ($has_location_reference_tables && !empty($application_form['region_code']))
    ? get_location_options('refprovince', 'provCode', 'provDesc', 'WHERE regCode = ?', [$application_form['region_code']])
    : [];
$city_options = ($has_location_reference_tables && !empty($application_form['province_code']))
    ? get_location_options('refcitymun', 'citymunCode', 'citymunDesc', 'WHERE provCode = ?', [$application_form['province_code']])
    : [];
$barangay_options = ($has_location_reference_tables && !empty($application_form['citymun_code']))
    ? get_location_options('refbrgy', 'brgyCode', 'brgyDesc', 'WHERE citymunCode = ?', [$application_form['citymun_code']])
    : [];

// Get available subjects for enrollment
$available_subjects = [];
if ($existing_application && !$current_enrollment && !$student_setup_missing) {
    $available_subjects = get_multiple_results("
        SELECT so.*, sub.subject_code, sub.subject_name, sub.units, sub.lecture_hours, sub.lab_hours,
               u.first_name as teacher_first_name, u.last_name as teacher_last_name,
               c.course_name
        FROM subject_offerings so
        JOIN subjects sub ON so.subject_id = sub.subject_id
        LEFT JOIN teachers t ON so.teacher_id = t.teacher_id
        LEFT JOIN users u ON t.user_id = u.user_id
        JOIN courses c ON sub.course_id = c.course_id
        WHERE so.semester_id = ? 
          AND so.school_year_id = ? 
          AND so.status = 'open'
          AND so.current_students < so.max_students
          AND so.teacher_id IS NOT NULL
          AND sub.course_id = ?
          AND sub.year_level <= ?
          AND sub.semester_type = ?
        ORDER BY sub.subject_code, so.section
    ", [
        $current_semester['semester_id'],
        $current_school_year['school_year_id'],
        $student_info['course_id'],
        $student_info['year_level'],
        stripos($current_semester['semester_name'], 'first') !== false ? 'first' : 'second'
    ]);
}

// Get enrolled subjects if already enrolled
$enrolled_subjects = [];
if ($current_enrollment) {
    $enrolled_subjects = get_multiple_results("
        SELECT loadrec.*, so.section, sub.subject_code, sub.subject_name, sub.units,
               u.first_name as teacher_first_name, u.last_name as teacher_last_name,
               GROUP_CONCAT(CONCAT(sched.day_of_week, ' ', sched.start_time, '-', sched.end_time) ORDER BY sched.day_of_week SEPARATOR ', ') as schedule
        FROM student_subject_loads loadrec
        JOIN subject_offerings so ON loadrec.offering_id = so.offering_id
        JOIN subjects sub ON so.subject_id = sub.subject_id
        LEFT JOIN teachers t ON so.teacher_id = t.teacher_id
        LEFT JOIN users u ON t.user_id = u.user_id
        LEFT JOIN schedules sched ON so.offering_id = sched.offering_id
        WHERE loadrec.enrollment_id = ? AND loadrec.status = 'enrolled'
        GROUP BY loadrec.load_id
        ORDER BY sub.subject_code
    ", [$current_enrollment['enrollment_id']]);
}

// Get flash messages
$flash_messages = get_flash_messages();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <meta name="user-data" content="<?php echo htmlspecialchars(json_encode(get_logged_in_user())); ?>">
    <title>Student Enrollment - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="logo">
                <a href="<?php echo APP_URL; ?>/modules/student/dashboard.php">
                    Enchong Dee University Information System
                </a>
            </div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <!-- Sidebar -->
        <?php render_student_sidebar('enrollment'); ?>

        <!-- Main Content -->
        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Add / Drop Subject</h1>
                    <p>Manage your subject registration for <?php echo htmlspecialchars($current_school_year['year_name']); ?> - <?php echo htmlspecialchars($current_semester['semester_name']); ?>.</p>
                </div>

                <?php if ($flash_messages): ?>
                    <div class="flash-messages mb-3">
                        <?php foreach ($flash_messages as $message): ?>
                            <div class="alert alert-<?php echo $message['type']; ?>">
                                <?php echo htmlspecialchars($message['message']); ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <?php if (!$existing_application): ?>
                    <div class="alert alert-info mb-4">
                        Submit your <a href="<?php echo APP_URL; ?>/modules/student/eform.php">Student E-Form</a> first before proceeding with subject registration.
                    </div>
                <?php endif; ?>

                <?php if ($student_setup_missing): ?>
                    <div class="alert alert-warning mb-4">
                        Your student record is not assigned yet. Subject registration will open after the administrator completes your student setup.
                    </div>
                <?php endif; ?>

                <!-- Student Information -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h4>Student Information</h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-3">
                                <strong>Student Number:</strong><br>
                                <?php echo htmlspecialchars($student_info['student_number'] ?? 'Not assigned'); ?>
                            </div>
                            <div class="col-3">
                                <strong>Name:</strong><br>
                                <?php echo htmlspecialchars($current_user['first_name'] . ' ' . $current_user['last_name']); ?>
                            </div>
                            <div class="col-3">
                                <strong>Course:</strong><br>
                                <?php echo htmlspecialchars($student_info['course_name'] ?? 'Not assigned'); ?>
                            </div>
                            <div class="col-3">
                                <strong>Year Level:</strong><br>
                                <?php echo htmlspecialchars((string)($student_info['year_level'] ?? 'Pending')); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <?php if ($current_enrollment): ?>
                    <!-- Already Enrolled -->
                    <div class="card">
                        <div class="card-header">
                            <h4>Current Subject Load</h4>
                            <div class="badge badge-success">Enrolled</div>
                        </div>
                        <div class="card-body">
                            <div class="row mb-3">
                                <div class="col-3">
                                    <strong>Enrollment Date:</strong><br>
                                    <?php echo format_date($current_enrollment['enrollment_date']); ?>
                                </div>
                                <div class="col-3">
                                    <strong>Total Units:</strong><br>
                                    <?php echo $current_enrollment['total_units']; ?>
                                </div>
                                <div class="col-3">
                                    <strong>Total Fee:</strong><br>
                                    <?php echo format_currency($current_enrollment['total_fee']); ?>
                                </div>
                                <div class="col-3">
                                    <strong>Balance:</strong><br>
                                    <span class="badge badge-<?php echo $current_enrollment['balance'] > 0 ? 'warning' : 'success'; ?>">
                                        <?php echo format_currency($current_enrollment['balance']); ?>
                                    </span>
                                </div>
                            </div>
                            
                            <h5>Enrolled Subjects</h5>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Subject Code</th>
                                            <th>Subject Name</th>
                                            <th>Units</th>
                                            <th>Teacher</th>
                                            <th>Section</th>
                                            <th>Schedule</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($enrolled_subjects as $subject): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($subject['subject_code']); ?></td>
                                                <td><?php echo htmlspecialchars($subject['subject_name']); ?></td>
                                                <td><?php echo $subject['units']; ?></td>
                                                <td><?php echo htmlspecialchars($subject['teacher_first_name'] . ' ' . $subject['teacher_last_name']); ?></td>
                                                <td>
                                                    <span class="badge badge-info"><?php echo htmlspecialchars($subject['section']); ?></span>
                                                </td>
                                                <td><?php echo htmlspecialchars($subject['schedule'] ?? 'TBD'); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <div class="mt-3">
                                <a href="<?php echo APP_URL; ?>/modules/student/dashboard.php#subject-history" class="btn btn-primary">
                                    View Subject History
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="card mt-4">
                        <div class="card-header">
                            <h4>Drop Subject</h4>
                        </div>
                        <div class="card-body">
                            <?php
                            $droppable_subjects = array_filter($enrolled_subjects, function ($subject) {
                                return ($subject['status'] ?? 'enrolled') === 'enrolled';
                            });
                            ?>
                            <?php if ($droppable_subjects): ?>
                                <div class="table-responsive">
                                    <table class="table table-sm">
                                        <thead>
                                            <tr>
                                                <th>Subject Code</th>
                                                <th>Subject Name</th>
                                                <th>Units</th>
                                                <th>Section</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($droppable_subjects as $subject): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($subject['subject_code']); ?></td>
                                                    <td><?php echo htmlspecialchars($subject['subject_name']); ?></td>
                                                    <td><?php echo htmlspecialchars((string)$subject['units']); ?></td>
                                                    <td><?php echo htmlspecialchars($subject['section']); ?></td>
                                                    <td>
                                                        <form method="POST" action="" style="display:inline;" onsubmit="return confirm('Drop this subject?');">
                                                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                                            <input type="hidden" name="action" value="drop_subject">
                                                            <input type="hidden" name="load_id" value="<?php echo (int)$subject['load_id']; ?>">
                                                            <button type="submit" class="btn btn-danger btn-sm">Drop</button>
                                                        </form>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php else: ?>
                                <p class="text-muted">No subjects available to drop.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php elseif (!$student_setup_missing && $existing_application): ?>
                    <!-- Available Subjects for Enrollment -->
                    <div class="card">
                        <div class="card-header">
                            <h4>Register Subjects</h4>
                            <div class="card-info">
                                <small class="text-muted">Select subjects to enroll (minimum 12 units, maximum 24 units)</small>
                            </div>
                        </div>
                        <div class="card-body">
                            <?php if ($available_subjects): ?>
                                <form method="POST" action="" id="enrollmentForm">
                                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                    <input type="hidden" name="action" value="enroll_subjects">
                                    
                                    <div class="mb-3">
                                        <div class="row">
                                            <div class="col-6">
                                                <strong>Selected Units:</strong> 
                                                <span id="selectedUnits">0</span> / 24
                                            </div>
                                            <div class="col-6 text-right">
                                                <button type="submit" class="btn btn-success" id="submitBtn" disabled>
                                                    Proceed to Enrollment
                                                </button>
                                            </div>
                                        </div>
                                        <div class="progress mt-2">
                                            <div id="unitsProgress" class="progress-bar" style="width: 0%"></div>
                                        </div>
                                    </div>
                                    
                                    <div class="table-responsive">
                                        <table class="table data-table">
                                            <thead>
                                                <tr>
                                                    <th><input type="checkbox" id="selectAllSubjects" onchange="toggleAllSubjects()"></th>
                                                    <th data-sortable>Subject Code</th>
                                                    <th data-sortable>Subject Name</th>
                                                    <th data-sortable>Units</th>
                                                    <th data-sortable>Teacher</th>
                                                    <th data-sortable>Section</th>
                                                    <th data-sortable>Slots</th>
                                                    <th data-sortable>Schedule</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($available_subjects as $subject): ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" 
                                                                   name="subjects[]" 
                                                                   value="<?php echo $subject['offering_id']; ?>"
                                                                   class="subject-checkbox"
                                                                   data-units="<?php echo $subject['units']; ?>"
                                                                   onchange="updateUnits()">
                                                        </td>
                                                        <td><?php echo htmlspecialchars($subject['subject_code']); ?></td>
                                                        <td><?php echo htmlspecialchars($subject['subject_name']); ?></td>
                                                        <td><?php echo $subject['units']; ?></td>
                                                        <td><?php echo htmlspecialchars($subject['teacher_first_name'] . ' ' . $subject['teacher_last_name']); ?></td>
                                                        <td>
                                                            <span class="badge badge-info"><?php echo htmlspecialchars($subject['section']); ?></span>
                                                        </td>
                                                        <td>
                                                            <?php echo $subject['current_students']; ?> / <?php echo $subject['max_students']; ?>
                                                            <?php if ($subject['current_students'] >= $subject['max_students'] * 0.8): ?>
                                                                <span class="badge badge-warning">Limited</span>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <?php
                                                            $schedules = get_multiple_results("
                                                                SELECT day_of_week, start_time, end_time, room
                                                                FROM schedules
                                                                WHERE offering_id = ?
                                                                ORDER BY day_of_week, start_time
                                                            ", [$subject['offering_id']]);
                                                            
                                                            foreach ($schedules as $schedule):
                                                                echo ucfirst($schedule['day_of_week']) . ' ' . 
                                                                     date('h:i A', strtotime($schedule['start_time'])) . ' - ' . 
                                                                     date('h:i A', strtotime($schedule['end_time'])) . 
                                                                     ($schedule['room'] ? ' (' . htmlspecialchars($schedule['room']) . ')' : '') . '<br>';
                                                            endforeach;
                                                            ?>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </form>
                            <?php else: ?>
                                <div class="text-center py-4">
                                    <p class="text-muted">No subjects available for enrollment at this time.</p>
                                    <p>Please contact the registrar's office for assistance.</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php elseif (!$student_setup_missing): ?>
                    <div class="alert alert-info">
                        Submit the enrollment e-form first before registering your subjects.
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <style>
        .eform-card {
            border-radius: 0;
        }

        .eform-heading-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-bottom: 1rem;
            margin-bottom: 1rem;
            border-bottom: 2px solid rgba(15, 23, 42, 0.55);
        }

        .eform-main-title {
            margin: 0;
            font-size: 2rem;
            letter-spacing: 0.02em;
        }

        .eform-divider {
            height: 1px;
            background: rgba(15, 23, 42, 0.14);
            margin: 0.5rem 0 1rem;
        }

        .eform-section-title {
            margin: 1rem 0 0.75rem;
            font-size: 1.1rem;
            text-decoration: underline;
        }

        .eform-wide {
            flex: 1.4;
        }

        .eform-actions {
            margin-top: 1rem;
        }

        .eform-submit-btn {
            background: #111;
            color: #fff;
            border-radius: 0;
            min-width: 160px;
        }

        .eform-submit-btn:hover {
            background: #000;
        }

        @media (max-width: 768px) {
            .eform-heading-row {
                flex-direction: column;
                align-items: flex-start;
                gap: 0.75rem;
            }
        }
    </style>

    <script>
        let selectedUnits = 0;
        const MIN_UNITS = 12;
        const MAX_UNITS = 24;

        async function populateLocationSelect(url, selectId, placeholder) {
            const select = document.getElementById(selectId);
            if (!select) {
                return;
            }

            select.innerHTML = `<option value="">${placeholder}</option>`;

            if (!url) {
                return;
            }

            try {
                const response = await fetch(url);
                const items = await response.json();
                items.forEach(item => {
                    const option = document.createElement('option');
                    option.value = item.code;
                    option.textContent = item.name;
                    select.appendChild(option);
                });
            } catch (error) {
                console.error('Location lookup failed', error);
            }
        }

        function updateUnits() {
            const selectedUnitsEl = document.getElementById('selectedUnits');
            const progressBar = document.getElementById('unitsProgress');
            const submitBtn = document.getElementById('submitBtn');

            if (!selectedUnitsEl || !progressBar || !submitBtn) {
                return;
            }

            selectedUnits = 0;
            const checkboxes = document.querySelectorAll('.subject-checkbox:checked');
            
            checkboxes.forEach(checkbox => {
                selectedUnits += parseInt(checkbox.dataset.units);
            });
            
            selectedUnitsEl.textContent = selectedUnits;
            
            // Update progress bar
            const progress = (selectedUnits / MAX_UNITS) * 100;
            progressBar.style.width = Math.min(progress, 100) + '%';
            
            // Update progress bar color
            progressBar.className = 'progress-bar';
            if (selectedUnits < MIN_UNITS) {
                progressBar.classList.add('progress-bar-warning');
            } else if (selectedUnits > MAX_UNITS) {
                progressBar.classList.add('progress-bar-danger');
            } else {
                progressBar.classList.add('progress-bar-success');
            }
            
            // Enable/disable submit button
            if (selectedUnits >= MIN_UNITS && selectedUnits <= MAX_UNITS) {
                submitBtn.disabled = false;
            } else {
                submitBtn.disabled = true;
            }
            
            // Show warning if over limit
            if (selectedUnits > MAX_UNITS) {
                SIS.showAlert('warning', `Maximum units exceeded. Please remove ${selectedUnits - MAX_UNITS} units.`);
            }
        }

        function toggleAllSubjects() {
            const selectAll = document.getElementById('selectAllSubjects');
            const checkboxes = document.querySelectorAll('.subject-checkbox');

             if (!selectAll || !checkboxes.length) {
                return;
            }
            
            checkboxes.forEach(checkbox => {
                checkbox.checked = selectAll.checked;
            });
            
            updateUnits();
        }

        document.addEventListener('DOMContentLoaded', function() {
            updateUnits();

            const regionSelect = document.getElementById('region_code');
            const provinceSelect = document.getElementById('province_code');
            const citySelect = document.getElementById('citymun_code');
            const barangaySelect = document.getElementById('barangay_code');

            function setDisabledState() {
                if (provinceSelect) {
                    provinceSelect.disabled = !regionSelect.value;
                }
                if (citySelect) {
                    citySelect.disabled = !provinceSelect.value;
                }
                if (barangaySelect) {
                    barangaySelect.disabled = !citySelect.value;
                }
            }

            if (regionSelect && provinceSelect && citySelect && barangaySelect) {
                setDisabledState();

                regionSelect.addEventListener('change', async function() {
                    await populateLocationSelect(`<?php echo APP_URL; ?>/modules/student/enrollment.php?location_lookup=provinces&region_code=${encodeURIComponent(this.value)}`, 'province_code', 'Select Province');
                    await populateLocationSelect('', 'citymun_code', 'Select City');
                    await populateLocationSelect('', 'barangay_code', 'Select Barangay');
                    setDisabledState();
                    if (this.value) {
                        provinceSelect.focus();
                    }
                });

                provinceSelect.addEventListener('change', async function() {
                    await populateLocationSelect(`<?php echo APP_URL; ?>/modules/student/enrollment.php?location_lookup=cities&province_code=${encodeURIComponent(this.value)}`, 'citymun_code', 'Select City');
                    await populateLocationSelect('', 'barangay_code', 'Select Barangay');
                    setDisabledState();
                    if (this.value) {
                        citySelect.focus();
                    }
                });

                citySelect.addEventListener('change', async function() {
                    await populateLocationSelect(`<?php echo APP_URL; ?>/modules/student/enrollment.php?location_lookup=barangays&citymun_code=${encodeURIComponent(this.value)}`, 'barangay_code', 'Select Barangay');
                    setDisabledState();
                    if (this.value) {
                        barangaySelect.focus();
                    }
                });

                barangaySelect.addEventListener('change', function() {
                    if (this.value) {
                        const streetInput = document.getElementById('address_street');
                        if (streetInput) {
                            streetInput.focus();
                        }
                    }
                });
            }
        });
    </script>

    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
