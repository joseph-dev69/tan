<?php
/**
 * Student Sidebar Navigation
 * School Information System
 */

function render_student_sidebar($active_page = 'dashboard') {
    $items = [
        'dashboard' => ['label' => 'Dashboard', 'href' => APP_URL . '/modules/student/dashboard.php'],
        'profile' => ['label' => 'My Profile', 'href' => APP_URL . '/modules/student/profile.php'],
        'eform' => ['label' => 'E-Form', 'href' => APP_URL . '/modules/student/eform.php'],
        'subjects' => ['label' => 'Subjects', 'href' => APP_URL . '/modules/student/subjects.php'],
        'enrollment' => ['label' => 'Add / Drop Subject', 'href' => APP_URL . '/modules/student/enrollment.php'],
        'billing' => ['label' => 'Billing / Permit', 'href' => APP_URL . '/modules/student/billing.php'],
        'teachers' => ['label' => 'Teachers', 'href' => APP_URL . '/modules/student/teachers.php'],
        'change_password' => ['label' => 'Change Password', 'href' => APP_URL . '/modules/account/change_password.php'],
    ];
    ?>
    <aside class="sidebar" id="sidebar">
        <ul class="sidebar-menu">
            <?php foreach ($items as $key => $item): ?>
                <li>
                    <a href="<?php echo $item['href']; ?>" class="<?php echo $active_page === $key ? 'active' : ''; ?>">
                        <span class="icon"><?php echo htmlspecialchars($item['label']); ?></span>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </aside>
    <?php
}
