<?php
/**
 * Student Teachers Page
 * School Information System
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';

require_role('student');

$current_user = get_logged_in_user();
$student_info = get_single_result("
    SELECT s.*, c.course_name, c.course_code
    FROM students s
    LEFT JOIN courses c ON s.course_id = c.course_id
    WHERE s.user_id = ?
", [$current_user['user_id']]);

$student_setup_missing = !$student_info;
$teacher_list = [];

if ($student_info) {
    $teacher_list = get_multiple_results("
        SELECT DISTINCT
               u.first_name,
               u.last_name,
               sub.subject_code,
               sub.subject_name,
               so.section,
               d.department_name
        FROM student_subject_loads loadrec
        JOIN enrollments e ON loadrec.enrollment_id = e.enrollment_id
        JOIN subject_offerings so ON loadrec.offering_id = so.offering_id
        JOIN subjects sub ON so.subject_id = sub.subject_id
        JOIN teachers t ON so.teacher_id = t.teacher_id
        JOIN users u ON t.user_id = u.user_id
        LEFT JOIN departments d ON t.department_id = d.department_id
        WHERE e.student_id = ? AND loadrec.status IN ('enrolled', 'completed', 'failed')
        ORDER BY u.last_name, u.first_name, sub.subject_code
    ", [$student_info['student_id']]);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teachers - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo"><a href="<?php echo APP_URL; ?>/modules/student/dashboard.php">Enchong Dee University Information System</a></div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <?php render_student_sidebar('teachers'); ?>

        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Teachers</h1>
                    <p>View your current teachers and the subjects they handle.</p>
                </div>

                <?php if ($student_setup_missing): ?>
                    <div class="alert alert-warning mb-4">
                        Your student record is not assigned yet, so teacher assignments are not available.
                    </div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-header">
                        <h4>Teacher Assignments</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($teacher_list): ?>
                            <div class="teacher-grid">
                                <?php foreach ($teacher_list as $teacher): ?>
                                    <div class="teacher-card">
                                        <h5><?php echo htmlspecialchars($teacher['last_name'] . ', ' . $teacher['first_name']); ?></h5>
                                        <p class="text-muted"><?php echo htmlspecialchars($teacher['department_name'] ?? 'No department assigned'); ?></p>
                                        <div class="teacher-meta"><span>Subject</span><strong><?php echo htmlspecialchars($teacher['subject_code']); ?></strong></div>
                                        <div class="teacher-meta"><span>Title</span><strong><?php echo htmlspecialchars($teacher['subject_name']); ?></strong></div>
                                        <div class="teacher-meta"><span>Section</span><strong><?php echo htmlspecialchars($teacher['section']); ?></strong></div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">No teacher assignments available yet.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <style>
        .teacher-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 1rem;
        }
        .teacher-card {
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 1rem;
            background: rgba(255,255,255,.96);
            box-shadow: var(--shadow);
        }
        .teacher-meta {
            margin-top: .75rem;
        }
        .teacher-meta span {
            display: block;
            color: var(--gray-color);
            font-size: .82rem;
            margin-bottom: .2rem;
            text-transform: uppercase;
        }
    </style>

    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
