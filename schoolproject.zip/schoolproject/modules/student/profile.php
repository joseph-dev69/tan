<?php
/**
 * Student Profile Page
 * School Information System
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';

require_role('student');

$current_user = get_logged_in_user();
$student_info = get_single_result("
    SELECT s.*, c.course_name, c.course_code, d.department_name
    FROM students s
    LEFT JOIN courses c ON s.course_id = c.course_id
    LEFT JOIN departments d ON c.department_id = d.department_id
    WHERE s.user_id = ?
", [$current_user['user_id']]);

$student_setup_missing = !$student_info;
$current_enrollment = false;
$current_application = false;
$study_load_subjects = [];

if ($student_info) {
    $current_enrollment = get_single_result("
        SELECT e.*, sy.year_name, sem.semester_name
        FROM enrollments e
        JOIN school_years sy ON e.school_year_id = sy.school_year_id
        JOIN semesters sem ON e.semester_id = sem.semester_id
        WHERE e.student_id = ?
        ORDER BY e.enrollment_date DESC
        LIMIT 1
    ", [$student_info['student_id']]);

    if ($current_enrollment) {
        $study_load_subjects = get_multiple_results("
            SELECT
                loadrec.load_id,
                sub.subject_code,
                sub.subject_name,
                sub.units,
                so.section,
                loadrec.status,
                CONCAT(COALESCE(u.first_name, ''), ' ', COALESCE(u.last_name, '')) AS instructor_name,
                GROUP_CONCAT(
                    CONCAT(
                        UPPER(LEFT(sch.day_of_week, 1)),
                        ' ',
                        TIME_FORMAT(sch.start_time, '%h:%i %p'),
                        ' - ',
                        TIME_FORMAT(sch.end_time, '%h:%i %p'),
                        IF(sch.room IS NOT NULL AND sch.room <> '', CONCAT(' - ', sch.room), '')
                    )
                    ORDER BY sch.day_of_week, sch.start_time
                    SEPARATOR '<br>'
                ) AS schedule_text
            FROM student_subject_loads loadrec
            JOIN subject_offerings so ON so.offering_id = loadrec.offering_id
            JOIN subjects sub ON sub.subject_id = so.subject_id
            LEFT JOIN teachers t ON t.teacher_id = so.teacher_id
            LEFT JOIN users u ON u.user_id = t.user_id
            LEFT JOIN schedules sch ON sch.offering_id = so.offering_id
            WHERE loadrec.enrollment_id = ?
              AND loadrec.status IN ('enrolled', 'completed', 'failed')
            GROUP BY loadrec.load_id, sub.subject_code, sub.subject_name, sub.units, so.section, loadrec.status, instructor_name
            ORDER BY sub.subject_code
        ", [$current_enrollment['enrollment_id']]);
    }
}

$current_application = get_single_result("
    SELECT ea.*, sy.year_name, sem.semester_name
    FROM enrollment_applications ea
    JOIN school_years sy ON ea.school_year_id = sy.school_year_id
    JOIN semesters sem ON ea.semester_id = sem.semester_id
    WHERE ea.user_id = ?
    ORDER BY ea.updated_at DESC
    LIMIT 1
", [$current_user['user_id']]);

$download_study_load = isset($_GET['download']) && $_GET['download'] === 'study_load';
if ($download_study_load && $student_info && $current_enrollment) {
    $filename = 'study_load_' . ($student_info['student_number'] ?? $current_user['username']) . '.html';
    header('Content-Type: text/html; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Study Load</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 32px; color: #1f2937; }
        h1, h2 { margin: 0 0 8px; }
        p { margin: 4px 0; }
        table { width: 100%; border-collapse: collapse; margin-top: 16px; }
        th, td { border: 1px solid #cbd5e1; padding: 10px; text-align: left; vertical-align: top; }
        th { background: #2e1065; color: #fff; }
        .meta { margin: 18px 0; }
        .legend { margin-top: 8px; color: #475569; font-style: italic; }
    </style>
</head>
<body>
    <h1>Study Load</h1>
    <div class="meta">
        <p><strong>Student:</strong> <?php echo htmlspecialchars($current_user['first_name'] . ' ' . $current_user['last_name']); ?></p>
        <p><strong>Student Number:</strong> <?php echo htmlspecialchars($student_info['student_number'] ?? 'Not assigned'); ?></p>
        <p><strong>Course:</strong> <?php echo htmlspecialchars($student_info['course_name'] ?? 'Not assigned'); ?></p>
        <p><strong>School Year:</strong> <?php echo htmlspecialchars($current_enrollment['year_name'] ?? ''); ?></p>
        <p><strong>Semester:</strong> <?php echo htmlspecialchars($current_enrollment['semester_name'] ?? ''); ?></p>
    </div>
    <div class="legend">Legend: M - Monday, T - Tuesday, W - Wednesday, Th - Thursday, F - Friday, S - Saturday, Sun - Sunday, TBA - To be announced</div>
    <table>
        <thead>
            <tr>
                <th>Subject Code</th>
                <th>Descriptive Title</th>
                <th>Schedule</th>
                <th>Section</th>
                <th>Units</th>
                <th>Instructor</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($study_load_subjects as $subject): ?>
                <tr>
                    <td><?php echo htmlspecialchars($subject['subject_code']); ?></td>
                    <td><?php echo htmlspecialchars($subject['subject_name']); ?></td>
                    <td><?php echo $subject['schedule_text'] ?: 'TBA'; ?></td>
                    <td><?php echo htmlspecialchars($subject['section']); ?></td>
                    <td><?php echo htmlspecialchars((string)$subject['units']); ?></td>
                    <td><?php echo htmlspecialchars(trim($subject['instructor_name']) ?: 'TBA'); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
    <?php
    exit;
}

$flash_messages = get_flash_messages();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <title>My Profile - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo"><a href="<?php echo APP_URL; ?>/modules/student/dashboard.php">School Information System</a></div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <?php render_student_sidebar('profile'); ?>

        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>My Profile</h1>
                    <p>View your student account, course details, latest registration status, and current study load.</p>
                </div>

                <?php if ($flash_messages): ?>
                    <div class="flash-messages mb-3">
                        <?php foreach ($flash_messages as $message): ?>
                            <div class="alert alert-<?php echo $message['type']; ?>">
                                <?php echo htmlspecialchars($message['message']); ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <?php if ($student_setup_missing): ?>
                    <div class="alert alert-warning mb-4">
                        Your student profile is not fully assigned yet. Please wait for admin setup to complete your record.
                    </div>
                <?php endif; ?>

                <div class="row mb-4">
                    <div class="col-6">
                        <div class="card profile-card">
                            <div class="card-header">
                                <h4>Account Information</h4>
                            </div>
                            <div class="card-body">
                                <div class="profile-grid">
                                    <div><span class="profile-label">Full Name</span><strong><?php echo htmlspecialchars($current_user['first_name'] . ' ' . $current_user['last_name']); ?></strong></div>
                                    <div><span class="profile-label">Username</span><strong><?php echo htmlspecialchars($current_user['username']); ?></strong></div>
                                    <div><span class="profile-label">Email</span><strong><?php echo htmlspecialchars($current_user['email']); ?></strong></div>
                                    <div><span class="profile-label">Role</span><strong>Student</strong></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="card profile-card">
                            <div class="card-header">
                                <h4>Student Record</h4>
                            </div>
                            <div class="card-body">
                                <div class="profile-grid">
                                    <div><span class="profile-label">Student Number</span><strong><?php echo htmlspecialchars($student_info['student_number'] ?? 'Not assigned'); ?></strong></div>
                                    <div><span class="profile-label">Course</span><strong><?php echo htmlspecialchars($student_info['course_name'] ?? 'Not assigned'); ?></strong></div>
                                    <div><span class="profile-label">Course Code</span><strong><?php echo htmlspecialchars($student_info['course_code'] ?? 'Not assigned'); ?></strong></div>
                                    <div><span class="profile-label">Year Level</span><strong><?php echo htmlspecialchars((string)($student_info['year_level'] ?? 'Pending')); ?></strong></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-6">
                        <div class="card profile-card">
                            <div class="card-header">
                                <h4>Latest Enrollment</h4>
                            </div>
                            <div class="card-body">
                                <?php if ($current_enrollment): ?>
                                    <div class="profile-grid">
                                        <div><span class="profile-label">School Year</span><strong><?php echo htmlspecialchars($current_enrollment['year_name']); ?></strong></div>
                                        <div><span class="profile-label">Semester</span><strong><?php echo htmlspecialchars($current_enrollment['semester_name']); ?></strong></div>
                                        <div><span class="profile-label">Total Units</span><strong><?php echo htmlspecialchars((string)$current_enrollment['total_units']); ?></strong></div>
                                        <div><span class="profile-label">Status</span><strong><?php echo htmlspecialchars(ucfirst($current_enrollment['status'])); ?></strong></div>
                                    </div>
                                <?php else: ?>
                                    <p class="text-muted">No enrollment record available yet.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="card profile-card">
                            <div class="card-header">
                                <h4>Latest E-Form Status</h4>
                            </div>
                            <div class="card-body">
                                <?php if ($current_application): ?>
                                    <div class="profile-grid">
                                        <div><span class="profile-label">School Year</span><strong><?php echo htmlspecialchars($current_application['year_name']); ?></strong></div>
                                        <div><span class="profile-label">Semester</span><strong><?php echo htmlspecialchars($current_application['semester_name']); ?></strong></div>
                                        <div><span class="profile-label">Application Status</span><strong><?php echo htmlspecialchars(ucfirst($current_application['status'])); ?></strong></div>
                                        <div><span class="profile-label">Updated</span><strong><?php echo htmlspecialchars(format_date($current_application['updated_at'])); ?></strong></div>
                                    </div>
                                <?php else: ?>
                                    <p class="text-muted">You have not submitted an e-form yet.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card mt-4">
                    <div class="card-header study-load-header">
                        <div>
                            <h4>Study Load</h4>
                            <small class="text-muted">
                                Legend: M - Monday, T - Tuesday, W - Wednesday, Th - Thursday, F - Friday, S - Saturday, Sun - Sunday, TBA - To be announced
                            </small>
                        </div>
                        <?php if ($current_enrollment && $study_load_subjects): ?>
                            <a href="<?php echo APP_URL; ?>/modules/student/profile.php?download=study_load" class="btn btn-primary btn-sm">
                                Download PDF
                            </a>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <?php if ($current_enrollment && $study_load_subjects): ?>
                            <div class="table-responsive">
                                <table class="table study-load-table">
                                    <thead>
                                        <tr>
                                            <th>Subject Code</th>
                                            <th>Descriptive Title</th>
                                            <th>Schedule</th>
                                            <th>Section</th>
                                            <th>Units</th>
                                            <th>Instructor</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($study_load_subjects as $subject): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($subject['subject_code']); ?></td>
                                                <td><?php echo htmlspecialchars($subject['subject_name']); ?></td>
                                                <td><?php echo $subject['schedule_text'] ?: 'TBA'; ?></td>
                                                <td><?php echo htmlspecialchars($subject['section']); ?></td>
                                                <td><?php echo htmlspecialchars((string)$subject['units']); ?></td>
                                                <td><?php echo htmlspecialchars(trim($subject['instructor_name']) ?: 'TBA'); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php elseif ($current_enrollment): ?>
                            <p class="text-muted">No enrolled subjects found in your current study load yet.</p>
                        <?php else: ?>
                            <p class="text-muted">No study load available yet.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <style>
        .profile-card { height: 100%; }
        .study-load-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 1rem;
        }
        .profile-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 1rem;
        }
        .profile-label {
            display: block;
            color: var(--gray-color);
            font-size: .85rem;
            margin-bottom: .25rem;
            text-transform: uppercase;
            letter-spacing: .04em;
        }
        .profile-grid strong {
            display: block;
            font-size: 1rem;
        }
        .study-load-table thead th {
            background: #2e1065;
            color: #fff;
        }
        .study-load-table td {
            vertical-align: top;
        }
    </style>

    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
