<?php
/**
 * Student Dashboard
 * School Information System
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';
require_once __DIR__ . '/../finance/billing_helpers.php';

require_role('student');

$current_user = get_logged_in_user();
$student_info = get_single_result("
    SELECT s.*, c.course_name, c.course_code, d.department_name
    FROM students s
    LEFT JOIN courses c ON s.course_id = c.course_id
    LEFT JOIN departments d ON c.department_id = d.department_id
    WHERE s.user_id = ?
", [$current_user['user_id']]);

$student_setup_missing = !$student_info;
$student_id = $student_info['student_id'] ?? null;
$current_enrollment = false;
$current_subjects = [];
$recent_grades = [];
$current_billing = false;
$gpa = 0.00;
$billing_phase_statuses = [];
$next_due_phase = null;
$current_exam_phase = null;
$billing_status_label = 'UNPAID';
$billing_status_message = 'You have not paid yet.';

if ($student_id) {
    $current_enrollment = get_single_result("
        SELECT e.*, sy.year_name, sem.semester_name
        FROM enrollments e
        JOIN school_years sy ON e.school_year_id = sy.school_year_id
        JOIN semesters sem ON e.semester_id = sem.semester_id
        WHERE e.student_id = ? AND e.status = 'enrolled'
        ORDER BY e.enrollment_date DESC
        LIMIT 1
    ", [$student_id]);

    if ($current_enrollment) {
        $current_subjects = get_multiple_results("
            SELECT loadrec.load_id, so.section, sub.subject_code, sub.subject_name, sub.units,
                   u.first_name AS teacher_first_name, u.last_name AS teacher_last_name
            FROM student_subject_loads loadrec
            JOIN subject_offerings so ON loadrec.offering_id = so.offering_id
            JOIN subjects sub ON so.subject_id = sub.subject_id
            LEFT JOIN teachers t ON so.teacher_id = t.teacher_id
            LEFT JOIN users u ON t.user_id = u.user_id
            WHERE loadrec.enrollment_id = ? AND loadrec.status = 'enrolled'
            ORDER BY sub.subject_code
        ", [$current_enrollment['enrollment_id']]);

        $gpa_result = get_single_result("
            SELECT AVG(g.grade) AS avg_grade
            FROM grades g
            JOIN student_subject_loads loadrec ON g.student_subject_load_id = loadrec.load_id
            JOIN enrollments e ON loadrec.enrollment_id = e.enrollment_id
            WHERE e.student_id = ? AND e.school_year_id = ? AND e.semester_id = ?
        ", [$student_id, $current_enrollment['school_year_id'], $current_enrollment['semester_id']]);

        if ($gpa_result && $gpa_result['avg_grade'] !== null) {
            $gpa = round((float)$gpa_result['avg_grade'], 2);
        }
    }

    $recent_grades = get_multiple_results("
        SELECT g.grade, g.grading_period, sub.subject_code, sub.subject_name
        FROM grades g
        JOIN student_subject_loads loadrec ON g.student_subject_load_id = loadrec.load_id
        JOIN subject_offerings so ON loadrec.offering_id = so.offering_id
        JOIN subjects sub ON so.subject_id = sub.subject_id
        JOIN enrollments e ON loadrec.enrollment_id = e.enrollment_id
        WHERE e.student_id = ?
        ORDER BY g.date_graded DESC
        LIMIT 5
    ", [$student_id]);

    if ($current_enrollment) {
        $current_billing = get_single_result("
            SELECT b.*
            FROM billings b
            WHERE b.student_id = ? AND b.school_year_id = ? AND b.semester_id = ?
            ORDER BY b.billing_date DESC
            LIMIT 1
        ", [$student_id, $current_enrollment['school_year_id'], $current_enrollment['semester_id']]);
    } else {
        $current_billing = get_single_result("
            SELECT b.*
            FROM billings b
            WHERE b.student_id = ?
            ORDER BY b.billing_date DESC
            LIMIT 1
        ", [$student_id]);
    }

    if ($current_billing) {
        $billing_phase_statuses = finance_get_billing_phase_status($current_billing);
        $next_due_phase = finance_get_next_due_phase($billing_phase_statuses);
        $current_exam_phase = finance_get_current_exam_phase((int)$current_billing['school_year_id'], (int)$current_billing['semester_id']);
        $billing_status_label = finance_get_status_label($current_billing['status']);
        $billing_status_message = finance_get_student_billing_message($current_billing['status']);
    }
}

$academic_standing = get_academic_standing($gpa);
$flash_messages = get_flash_messages();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <meta name="user-data" content="<?php echo htmlspecialchars(json_encode(get_logged_in_user())); ?>">
    <title>Student Dashboard - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo">
                <a href="<?php echo APP_URL; ?>/modules/student/dashboard.php">Enchong Dee University Information System</a>
            </div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <?php render_student_sidebar('dashboard'); ?>

        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Student Dashboard</h1>
                    <p>Welcome back, <?php echo htmlspecialchars($current_user['first_name']); ?>!</p>
                </div>

                <?php if ($flash_messages): ?>
                    <div class="flash-messages mb-3">
                        <?php foreach ($flash_messages as $message): ?>
                            <div class="alert alert-<?php echo $message['type']; ?>">
                                <?php echo htmlspecialchars($message['message']); ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <?php if ($student_setup_missing): ?>
                    <div class="alert alert-warning mb-4">
                        Your student account is not fully set up yet. Please contact the administrator to assign your student record and course before using student features.
                    </div>
                <?php endif; ?>

                <div class="card mb-4">
                    <div class="card-header">
                        <h4>My Information</h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-3">
                                <strong>Student Number:</strong><br>
                                <?php echo htmlspecialchars($student_info['student_number'] ?? 'Not assigned'); ?>
                            </div>
                            <div class="col-3">
                                <strong>Course:</strong><br>
                                <?php echo htmlspecialchars($student_info['course_name'] ?? 'Not assigned'); ?>
                            </div>
                            <div class="col-3">
                                <strong>Year Level:</strong><br>
                                <?php echo htmlspecialchars((string)($student_info['year_level'] ?? 'Pending')); ?>
                            </div>
                            <div class="col-3">
                                <strong>GPA:</strong><br>
                                <span class="badge badge-<?php echo $gpa >= 3.0 ? 'success' : ($gpa >= 2.0 ? 'warning' : 'danger'); ?>">
                                    <?php echo htmlspecialchars((string)$gpa); ?>
                                </span>
                                <br>
                                <small class="text-muted"><?php echo htmlspecialchars(ucfirst($academic_standing)); ?></small>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mb-4">
                    <div class="col-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-primary"><?php echo count($current_subjects); ?></h3>
                                <p>Current Subjects</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-info"><?php echo htmlspecialchars((string)($current_enrollment['total_units'] ?? 0)); ?></h3>
                                <p>Total Units</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-success"><?php echo htmlspecialchars((string)$gpa); ?></h3>
                                <p>Current GPA</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-warning"><?php echo $current_billing ? htmlspecialchars(format_currency($current_billing['balance'])) : '0.00'; ?></h3>
                                <p>Outstanding Balance</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-6">
                        <div class="card">
                            <div class="card-header">
                                <h4>Current Subjects</h4>
                            </div>
                            <div class="card-body dashboard-panel-body">
                                <?php if ($current_subjects): ?>
                                    <div class="table-responsive">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th>Subject</th>
                                                    <th>Units</th>
                                                    <th>Teacher</th>
                                                    <th>Section</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($current_subjects as $subject): ?>
                                                    <tr>
                                                        <td>
                                                            <?php echo htmlspecialchars($subject['subject_code']); ?><br>
                                                            <small class="text-muted"><?php echo htmlspecialchars($subject['subject_name']); ?></small>
                                                        </td>
                                                        <td><?php echo htmlspecialchars((string)$subject['units']); ?></td>
                                                        <td><?php echo htmlspecialchars(trim(($subject['teacher_first_name'] ?? '') . ' ' . ($subject['teacher_last_name'] ?? '')) ?: 'TBA'); ?></td>
                                                        <td><?php echo htmlspecialchars($subject['section']); ?></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php else: ?>
                                    <p class="text-muted">No current subjects enrolled</p>
                                <?php endif; ?>
                            </div>
                            <div class="card-footer">
                                <a href="<?php echo APP_URL; ?>/modules/student/enrollment.php" class="btn btn-primary btn-sm">View Full Schedule</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="card">
                            <div class="card-header">
                                <h4>Recent Grades</h4>
                            </div>
                            <div class="card-body dashboard-panel-body">
                                <?php if ($recent_grades): ?>
                                    <div class="table-responsive">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th>Subject</th>
                                                    <th>Grade</th>
                                                    <th>Period</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($recent_grades as $grade): ?>
                                                    <tr>
                                                        <td>
                                                            <?php echo htmlspecialchars($grade['subject_code']); ?><br>
                                                            <small class="text-muted"><?php echo htmlspecialchars($grade['subject_name']); ?></small>
                                                        </td>
                                                        <td>
                                                            <span class="badge badge-<?php echo (float)$grade['grade'] >= 75 ? 'success' : 'danger'; ?>">
                                                                <?php echo htmlspecialchars((string)$grade['grade']); ?>
                                                            </span>
                                                        </td>
                                                        <td><?php echo htmlspecialchars(ucfirst($grade['grading_period'])); ?></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php else: ?>
                                    <p class="text-muted">No grades available yet</p>
                                <?php endif; ?>
                            </div>
                            <div class="card-footer">
                                <a href="<?php echo APP_URL; ?>/modules/student/subjects.php" class="btn btn-primary btn-sm">View All Grades</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <style>
        .dashboard-panel-body {
            min-height: 140px;
        }
    </style>

    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
