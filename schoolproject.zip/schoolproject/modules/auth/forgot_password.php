<?php
/**
 * Forgot Password Page
 * School Information System
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';

if (is_logged_in()) {
    redirect('index.php');
}

$error = '';
$success = '';
$username = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    $username = sanitize_input($_POST['username'] ?? '');
    $email = sanitize_input($_POST['email'] ?? '');
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (!verify_csrf_token($csrf_token)) {
        $error = 'Invalid request. Please try again.';
    } elseif ($username === '' || $email === '' || $new_password === '' || $confirm_password === '') {
        $error = 'Please complete all fields.';
    } elseif (!validate_email($email)) {
        $error = 'Please enter a valid email address.';
    } elseif ($new_password !== $confirm_password) {
        $error = 'New password and confirm password do not match.';
    } elseif (!validate_password($new_password)) {
        $error = 'Password must be at least 4 characters.';
    } else {
        try {
            $user = get_single_result("
                SELECT user_id, username, email, status
                FROM users
                WHERE username = ? AND email = ?
                LIMIT 1
            ", [$username, $email]);

            if (!$user) {
                $error = 'No account matched the username and email provided.';
            } elseif ($user['status'] === 'rejected' || $user['status'] === 'inactive') {
                $error = 'This account cannot reset password right now. Please contact the administrator.';
            } else {
                $password_hash = hash_password($new_password);
                $old_values = ['password_hash' => 'hidden'];
                $new_values = ['password_hash' => 'updated_by_forgot_password'];

                execute_query("
                    UPDATE users
                    SET password_hash = ?, updated_at = NOW()
                    WHERE user_id = ?
                ", [$password_hash, $user['user_id']]);

                error_log('Password reset completed for user_id=' . (int)$user['user_id'] . ' via forgot password form.');
                $success = 'Password changed successfully. You may now log in using your new password.';
                $username = '';
                $email = '';
            }
        } catch (Exception $e) {
            error_log('Forgot password reset error: ' . $e->getMessage());
            $error = 'Unable to reset password right now. Please try again.';
        }
    }
}

$flash_messages = get_flash_messages();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <title>Forgot Password - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body class="login-page">
    <div class="login-container">
        <div class="login-form">
            <div class="login-header">
                <div class="brand-icon">
                    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><rect width="24" height="24" rx="4" fill="#4A86F7"/><path d="M6 10l6-4 6 4v6a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2v-6z" fill="#fff"/></svg>
                </div>
                <h1>Forgot Password</h1>
                <p class="muted">Verify your account and create a new password.</p>
            </div>

            <?php if ($flash_messages): ?>
                <div class="flash-messages">
                    <?php foreach ($flash_messages as $message): ?>
                        <div class="alert alert-<?php echo htmlspecialchars($message['type']); ?>">
                            <?php echo htmlspecialchars($message['message']); ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>

            <form method="POST" action="" data-password-validation="none">
                <div class="form-group">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" id="username" name="username" class="form-control" value="<?php echo htmlspecialchars($username); ?>" placeholder="Enter your username" required autofocus>
                </div>

                <div class="form-group">
                    <label for="email" class="form-label">Email Address</label>
                    <input type="email" id="email" name="email" class="form-control" value="<?php echo htmlspecialchars($email); ?>" placeholder="Enter your registered email" required>
                </div>

                <div class="form-group">
                    <label for="new_password" class="form-label">New Password</label>
                    <input type="password" id="new_password" name="new_password" class="form-control" placeholder="Minimum 4 characters" minlength="4" required>
                </div>

                <div class="form-group">
                    <label for="confirm_password" class="form-label">Confirm New Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" class="form-control" placeholder="Retype new password" minlength="4" required>
                </div>

                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">

                <button type="submit" class="btn btn-primary btn-block">Reset Password</button>
            </form>

            <div class="login-footer">
                <p><a href="<?php echo APP_URL; ?>/modules/auth/login.php">Back to Login</a></p>
            </div>
        </div>
    </div>

    <style>
        :root {
    --bg: linear-gradient(135deg, #0f172a 0%, #1e3a8a 100%);
    --card: rgba(255, 255, 255, 0.08);
    --blue: #4A86F7;
    --blue-hover: #2563eb;
    --muted: #cbd5e1;
    --input-bg: rgba(255, 255, 255, 0.08);
    --border: rgba(255, 255, 255, 0.12);
    --white: #ffffff;
}

html,
body {
    height: 100%;
    margin: 0;
    padding: 0;
}

body.login-page {
    background: var(--bg);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: 'Segoe UI', sans-serif;
    position: relative;
    overflow: hidden;
}

/* Glow Effects */
body.login-page::before,
body.login-page::after {
    content: '';
    position: absolute;
    width: 350px;
    height: 350px;
    border-radius: 50%;
    filter: blur(100px);
    opacity: 0.35;
}

body.login-page::before {
    background: #2563eb;
    top: -100px;
    left: -100px;
}

body.login-page::after {
    background: #06b6d4;
    bottom: -100px;
    right: -100px;
}

.login-container {
    width: 100%;
    max-width: 460px;
    padding: 24px;
    position: relative;
    z-index: 2;
}

/* Card */
.login-form {
    background: var(--card);
    backdrop-filter: blur(18px);
    border: 1px solid var(--border);
    padding: 40px;
    border-radius: 24px;
    box-shadow: 0 15px 40px rgba(0,0,0,0.35);
    text-align: center;
    animation: fadeIn 0.7s ease;
}

/* Animation */
@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(25px);
    }

    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Header */
.login-header .brand-icon {
    margin: 0 auto 16px;
}

.login-header .brand-icon svg {
    width: 65px;
    height: 65px;
    border-radius: 18px;
    box-shadow: 0 6px 18px rgba(74,134,247,0.4);
}

.login-header h1 {
    margin: 0;
    font-size: 28px;
    font-weight: 700;
    color: var(--white);
    letter-spacing: 0.5px;
}

.login-header .muted {
    margin: 8px 0 22px;
    color: var(--muted);
    font-size: 14px;
}

/* Form */
.form-group {
    text-align: left;
    margin-bottom: 18px;
}

.form-label {
    display: block;
    margin-bottom: 8px;
    font-size: 14px;
    color: var(--muted);
    font-weight: 500;
}

.form-control {
    width: 100%;
    box-sizing: border-box;
    padding: 14px 16px;
    border-radius: 14px;
    border: 1px solid transparent;
    background: var(--input-bg);
    color: white;
    font-size: 15px;
    transition: all 0.3s ease;
    outline: none;
}

.form-control::placeholder {
    color: #cbd5e1;
}

.form-control:focus {
    border-color: var(--blue);
    background: rgba(255,255,255,0.12);
    box-shadow: 0 0 0 4px rgba(74,134,247,0.2);
}

/* Button */
.btn-block {
    width: 100%;
    padding: 14px;
    font-size: 16px;
    font-weight: 600;
    border-radius: 14px;
    border: none;
    cursor: pointer;
    background: linear-gradient(135deg, #4A86F7, #2563eb);
    color: white;
    transition: all 0.3s ease;
}

.btn-block:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 20px rgba(37,99,235,0.35);
}

/* Footer */
.login-footer {
    margin-top: 22px;
    font-size: 13px;
    color: var(--muted);
}

.login-footer a {
    color: #93c5fd;
    text-decoration: none;
    transition: 0.3s ease;
}

.login-footer a:hover {
    color: white;
}

/* Alerts */
.flash-messages {
    margin-bottom: 18px;
}

.alert {
    padding: 12px;
    border-radius: 12px;
    font-size: 14px;
    margin-bottom: 12px;
}

.alert-danger {
    background: rgba(239,68,68,0.15);
    border: 1px solid rgba(239,68,68,0.3);
    color: #fecaca;
}

.alert-success {
    background: rgba(34,197,94,0.15);
    border: 1px solid rgba(34,197,94,0.3);
    color: #bbf7d0;
}

/* Mobile */
@media (max-width: 480px) {
    .login-container {
        padding: 14px;
    }

    .login-form {
        padding: 28px 22px;
        border-radius: 20px;
    }

    .login-header h1 {
        font-size: 24px;
    }
}
    </style>

    <script>
        document.querySelector('form').addEventListener('submit', function (event) {
            const password = document.getElementById('new_password').value;
            const confirmPassword = document.getElementById('confirm_password').value;

            if (password !== confirmPassword) {
                event.preventDefault();
                alert('New password and confirm password do not match.');
            }
        });
    </script>
</body>
</html>
