<?php
/**
 * Enhanced Login Page
 * School Information System - Modern & User-Friendly Design
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';

// Redirect if already logged in
if (is_logged_in()) {
    redirect('index.php');
}

$error = '';
$success = '';
$login_attempts = 0;

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize_input($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $csrf_token = $_POST['csrf_token'] ?? '';
    $remember = isset($_POST['remember']);
    
    // Verify CSRF token
    if (!verify_csrf_token($csrf_token)) {
        $error = 'Invalid request. Please try again.';
    } else {
        // Check login attempts
        $attempts = check_login_attempts($username);
        $login_attempts = $attempts['count'];
        
        if ($attempts['count'] >= MAX_LOGIN_ATTEMPTS) {
            $remaining_time = LOGIN_ATTEMPT_TIMEOUT - (time() - $attempts['last_attempt']);
            $error = "Too many login attempts. Please try again in " . ceil($remaining_time / 60) . " minutes.";
        } elseif (empty($username) || empty($password)) {
            $error = 'Please enter both username and password.';
        } else {
            // Attempt login
            if (login_user($username, $password)) {
                reset_login_attempts($username);
                
                // Set remember me cookie if requested
                if ($remember) {
                    $cookie_name = 'remember_token';
                    $cookie_value = bin2hex(random_bytes(32));
                    $cookie_expiry = time() + (30 * 24 * 60 * 60); // 30 days
                    
                    setcookie($cookie_name, $cookie_value, $cookie_expiry, '/', '', true, true);
                    
                    // Store remember token in database (would need to implement this)
                }
                
                $success = 'Login successful! Redirecting to dashboard...';
                
                // Redirect after delay
                echo '<script>setTimeout(() => { window.location.href = "index.php"; }, 1500);</script>';
            } else {
                increment_login_attempts($username);
                $remaining_attempts = MAX_LOGIN_ATTEMPTS - $attempts['count'] - 1;
                $error = 'Invalid username or password.';
                if ($remaining_attempts > 0) {
                    $error .= " You have $remaining_attempts attempt(s) remaining.";
                }
            }
        }
    }
}

// Get flash messages
$flash_messages = get_flash_messages();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <title>Login - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/enhanced.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body class="login-page">
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <div class="school-logo">
                    <div class="logo-icon">🎓</div>
                    <h1> Enchong Dee University School Information System</h1>
                </div>
                <p class="login-subtitle">Welcome back! Please sign in to your account</p>
            </div>
            
            <?php if ($flash_messages): ?>
                <div class="flash-messages">
                    <?php foreach ($flash_messages as $message): ?>
                        <div class="alert alert-<?php echo $message['type']; ?> fade-in">
                            <div class="alert-icon">
                                <?php
                                $icons = ['success' => '✓', 'error' => '✕', 'warning' => '⚠', 'info' => 'ℹ'];
                                echo $icons[$message['type']] ?? 'ℹ';
                                ?>
                            </div>
                            <div class="alert-content">
                                <?php echo htmlspecialchars($message['message']); ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger fade-in">
                    <div class="alert-icon">✕</div>
                    <div class="alert-content">
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success fade-in">
                    <div class="alert-icon">✓</div>
                    <div class="alert-content">
                        <?php echo htmlspecialchars($success); ?>
                    </div>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="" class="login-form enhanced-form" id="loginForm">
                <div class="form-group floating-label-group">
                    <label for="username" class="form-label">Username or Email</label>
                    <input type="text" id="username" name="username" class="form-control" 
                           value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>" 
                           required autofocus>
                    <div class="field-feedback"></div>
                </div>
                
                <div class="form-group floating-label-group">
                    <label for="password" class="form-label">Password</label>
                    <div class="password-input-group">
                        <input type="password" id="password" name="password" class="form-control" required>
                        <button type="button" class="password-toggle" data-target="password" data-tooltip="Show password">
                            <span class="eye-icon">👁</span>
                        </button>
                    </div>
                    <div class="field-feedback"></div>
                </div>
                
                <div class="form-options">
                    <div class="form-check">
                        <input type="checkbox" id="remember" name="remember" class="form-check-input">
                        <label for="remember" class="form-check-label">
                            <span class="checkmark"></span>
                            Remember me for 30 days
                        </label>
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary btn-lg btn-block" id="loginBtn">
                        <span class="btn-text">Sign In</span>
                        <span class="btn-loading" style="display: none;">
                            <span class="spinner"></span>
                            Signing in...
                        </span>
                    </button>
                </div>
                
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                
                <div class="form-footer">
                    <div class="form-links">
                        <a href="forgot_password.php" class="link-forgot">Forgot your password?</a>
                        <span class="separator">•</span>
                        <a href="register.php" class="link-register">Create an account</a>
                    </div>
                </div>
            </form>
            
            <div class="login-help">
                <h3>Need Help?</h3>
                <div class="help-links">
                    <a href="#" class="help-link">
                        <span class="help-icon">📖</span>
                        <span class="help-text">User Guide</span>
                    </a>
                    <a href="#" class="help-link">
                        <span class="help-icon">💬</span>
                        <span class="help-text">Contact Support</span>
                    </a>
                    <a href="#" class="help-link">
                        <span class="help-icon">🔧</span>
                        <span class="help-text">System Status</span>
                    </a>
                </div>
            </div>
        </div>
        
        <div class="login-features">
            <div class="feature-card">
                <div class="feature-icon">🔐</div>
                <h4>Secure Login</h4>
                <p>Your account is protected with industry-standard encryption and security measures.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">⚡</div>
                <h4>Quick Access</h4>
                <p>Save your login preferences for faster access to your account.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">📱</div>
                <h4>Mobile Friendly</h4>
                <p>Access your account from any device, anywhere, anytime.</p>
            </div>
        </div>
    </div>
    
    <style>.login-page {
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #2563eb 100%);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 2rem;
    position: relative;
    overflow: hidden;
}

/* Animated Background */
.login-page::before {
    content: '';
    position: fixed;
    inset: 0;
    background:
        radial-gradient(circle at top left, rgba(59,130,246,0.25), transparent 35%),
        radial-gradient(circle at bottom right, rgba(14,165,233,0.25), transparent 35%);
    z-index: -2;
}

.login-page::after {
    content: '';
    position: fixed;
    inset: 0;
    background-image:
        linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px),
        linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px);
    background-size: 35px 35px;
    z-index: -1;
}

.login-container {
    display: flex;
    gap: 2.5rem;
    max-width: 1200px;
    width: 100%;
    align-items: center;
    justify-content: center;
}

/* Main Card */
.login-card {
    background: rgba(255, 255, 255, 0.08);
    backdrop-filter: blur(18px);
    border: 1px solid rgba(255,255,255,0.15);
    border-radius: 24px;
    padding: 3rem;
    box-shadow: 0 20px 45px rgba(0,0,0,0.35);
    flex: 1;
    max-width: 500px;
    position: relative;
    overflow: hidden;
    animation: fadeUp 0.7s ease;
}

.login-card::before {
    content: '';
    position: absolute;
    inset: 0;
    border-radius: 24px;
    padding: 1px;
    background: linear-gradient(135deg, rgba(255,255,255,0.25), transparent);
    -webkit-mask:
        linear-gradient(#fff 0 0) content-box,
        linear-gradient(#fff 0 0);
    -webkit-mask-composite: xor;
    mask-composite: exclude;
}

/* Animation */
@keyframes fadeUp {
    from {
        opacity: 0;
        transform: translateY(25px);
    }

    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Header */
.login-header {
    text-align: center;
    margin-bottom: 2.5rem;
}

.school-logo {
    margin-bottom: 1rem;
}

.logo-icon {
    font-size: 3.5rem;
    display: inline-block;
    background: linear-gradient(135deg, #60a5fa, #38bdf8);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.login-header h1 {
    font-size: 2rem;
    font-weight: 700;
    margin-bottom: 0.5rem;
    color: white;
    letter-spacing: 0.5px;
}

.login-subtitle {
    color: #cbd5e1;
    font-size: 0.95rem;
    margin: 0;
}

/* Floating Input */
.floating-label-group {
    position: relative;
    margin-bottom: 1.5rem;
}

.floating-label-group input {
    width: 100%;
    padding: 15px 16px;
    border-radius: 14px;
    border: 1px solid rgba(255,255,255,0.15);
    background: rgba(255,255,255,0.06);
    color: white;
    font-size: 15px;
    outline: none;
    transition: 0.3s ease;
}

.floating-label-group input::placeholder {
    color: #cbd5e1;
}

.floating-label-group input:focus {
    border-color: #60a5fa;
    background: rgba(255,255,255,0.1);
    box-shadow: 0 0 0 4px rgba(96,165,250,0.2);
}

/* Password */
.password-input-group {
    position: relative;
}

.password-toggle {
    position: absolute;
    right: 1rem;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    cursor: pointer;
    color: #cbd5e1;
    transition: 0.3s;
}

.password-toggle:hover {
    color: #60a5fa;
}

.eye-icon {
    font-size: 1.2rem;
}

/* Checkbox */
.form-options {
    margin-bottom: 2rem;
}

.form-check {
    display: flex;
    align-items: center;
}

.form-check-input {
    position: absolute;
    opacity: 0;
}

.form-check-label {
    display: flex;
    align-items: center;
    cursor: pointer;
    font-size: 0.9rem;
    color: #e2e8f0;
}

.checkmark {
    width: 20px;
    height: 20px;
    border: 2px solid rgba(255,255,255,0.25);
    border-radius: 6px;
    margin-right: 0.75rem;
    position: relative;
    transition: 0.3s;
}

.form-check-input:checked + .form-check-label .checkmark {
    background: linear-gradient(135deg, #3b82f6, #0ea5e9);
    border-color: transparent;
}

.form-check-input:checked + .form-check-label .checkmark::after {
    content: '✓';
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: white;
    font-size: 0.8rem;
}

/* Buttons */
.btn-loading {
    display: flex;
    align-items: center;
    justify-content: center;
}

button,
.btn {
    width: 100%;
    padding: 14px;
    border-radius: 14px;
    border: none;
    background: linear-gradient(135deg, #2563eb, #0ea5e9);
    color: white;
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
    transition: 0.3s ease;
}

button:hover,
.btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 20px rgba(37,99,235,0.35);
}

/* Loading Spinner */
.spinner {
    width: 20px;
    height: 20px;
    border: 2px solid rgba(255,255,255,0.3);
    border-top: 2px solid white;
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin-right: 0.5rem;
}

@keyframes spin {
    100% {
        transform: rotate(360deg);
    }
}

/* Footer */
.form-footer {
    text-align: center;
    margin-top: 2rem;
}

.form-links {
    display: flex;
    justify-content: center;
    gap: 1rem;
    flex-wrap: wrap;
}

.link-forgot,
.link-register {
    color: #93c5fd;
    text-decoration: none;
    font-weight: 500;
    transition: 0.3s;
}

.link-forgot:hover,
.link-register:hover {
    color: white;
}

.separator {
    color: rgba(255,255,255,0.3);
}

/* Help Section */
.login-help {
    background: rgba(255,255,255,0.08);
    border-radius: 20px;
    padding: 2rem;
    backdrop-filter: blur(14px);
    border: 1px solid rgba(255,255,255,0.15);
}

.login-help h3 {
    font-size: 1.25rem;
    margin-bottom: 1.5rem;
    color: white;
    text-align: center;
}

.help-links {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.help-link {
    display: flex;
    align-items: center;
    padding: 1rem;
    background: rgba(255,255,255,0.05);
    border-radius: 12px;
    text-decoration: none;
    color: #e2e8f0;
    transition: 0.3s ease;
}

.help-link:hover {
    background: rgba(255,255,255,0.1);
    transform: translateY(-2px);
}

.help-icon {
    font-size: 1.5rem;
    margin-right: 1rem;
}

.help-text {
    font-weight: 500;
}

/* Features */
.login-features {
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
    max-width: 300px;
}

.feature-card {
    background: rgba(255,255,255,0.08);
    border-radius: 18px;
    padding: 1.5rem;
    text-align: center;
    backdrop-filter: blur(14px);
    border: 1px solid rgba(255,255,255,0.12);
    transition: 0.3s ease;
}

.feature-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.25);
}

.feature-icon {
    font-size: 2rem;
    margin-bottom: 1rem;
    display: block;
}

.feature-card h4 {
    font-size: 1.1rem;
    margin-bottom: 0.5rem;
    color: white;
}

.feature-card p {
    font-size: 0.9rem;
    color: #cbd5e1;
    margin: 0;
    line-height: 1.5;
}

/* Responsive */
@media (max-width: 992px) {
    .login-container {
        flex-direction: column;
    }

    .login-features {
        flex-direction: row;
        max-width: 100%;
    }

    .feature-card {
        flex: 1;
    }
}

@media (max-width: 768px) {
    .login-card {
        padding: 2rem;
    }

    .login-features {
        flex-direction: column;
    }

    .form-links {
        flex-direction: column;
        gap: 0.5rem;
    }
}
    </style>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const loginForm = document.getElementById('loginForm');
            const loginBtn = document.getElementById('loginBtn');
            const passwordToggle = document.querySelector('.password-toggle');
            const passwordInput = document.getElementById('password');
            
            // Password visibility toggle
            passwordToggle.addEventListener('click', function() {
                const type = passwordInput.type === 'password' ? 'text' : 'password';
                passwordInput.type = type;
                this.querySelector('.eye-icon').textContent = type === 'password' ? '👁' : '👁‍🗨';
            });
            
            // Form submission enhancement
            loginForm.addEventListener('submit', function(e) {
                if (!validateLoginForm()) {
                    e.preventDefault();
                    return false;
                }
                
                // Show loading state
                loginBtn.disabled = true;
                loginBtn.querySelector('.btn-text').style.display = 'none';
                loginBtn.querySelector('.btn-loading').style.display = 'flex';
            });
            
            // Real-time validation
            const inputs = loginForm.querySelectorAll('input[required]');
            inputs.forEach(input => {
                input.addEventListener('blur', () => validateField(input));
                input.addEventListener('input', () => {
                    if (input.parentElement.querySelector('.field-feedback')) {
                        validateField(input);
                    }
                });
            });
        });
        
        function validateLoginForm() {
            const username = document.getElementById('username');
            const password = document.getElementById('password');
            let isValid = true;
            
            // Clear previous errors
            document.querySelectorAll('.field-feedback').forEach(feedback => feedback.remove());
            document.querySelectorAll('.is-invalid').forEach(field => field.classList.remove('is-invalid'));
            
            // Validate username
            if (!username.value.trim()) {
                showFieldError(username, 'Username or email is required');
                isValid = false;
            }
            
            // Validate password
            if (!password.value) {
                showFieldError(password, 'Password is required');
                isValid = false;
            } else if (password.value.length < 8) {
                showFieldError(password, 'Password must be at least 8 characters');
                isValid = false;
            }
            
            return isValid;
        }
        
        function validateField(field) {
            const value = field.value.trim();
            let isValid = true;
            let message = '';
            
            if (!value) {
                isValid = false;
                message = 'This field is required';
            }
            
            showFieldValidation(field, isValid, message);
            return isValid;
        }
        
        function showFieldError(field, message) {
            field.classList.add('is-invalid');
            
            let feedback = field.parentElement.querySelector('.field-feedback');
            if (!feedback) {
                feedback = document.createElement('div');
                feedback.className = 'field-feedback';
                field.parentElement.appendChild(feedback);
            }
            
            feedback.textContent = message;
            feedback.style.color = 'var(--accent-color)';
            feedback.style.fontSize = '0.875rem';
            feedback.style.marginTop = '0.5rem';
        }
        
        function showFieldValidation(field, isValid, message) {
            field.classList.remove('is-valid', 'is-invalid');
            
            const feedback = field.parentElement.querySelector('.field-feedback');
            if (feedback) {
                if (!isValid && message) {
                    field.classList.add('is-invalid');
                    feedback.textContent = message;
                    feedback.style.color = 'var(--accent-color)';
                } else if (isValid && field.value) {
                    field.classList.add('is-valid');
                    feedback.textContent = '✓ Valid';
                    feedback.style.color = 'var(--success-color)';
                } else {
                    feedback.textContent = '';
                }
            }
        }
    </script>
    
    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
    <script src="<?php echo APP_URL; ?>/assets/js/enhanced.js"></script>
</body>
</html>
