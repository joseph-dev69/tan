<?php
/**
 * Login Page
 * School Information System
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';

// Redirect if already logged in
if (is_logged_in()) {
    redirect('index.php');
}

$error = '';
$success = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize_input($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    // Verify CSRF token
    if (!verify_csrf_token($csrf_token)) {
        $error = 'Invalid request. Please try again.';
    } else {
        // Check login attempts
        $attempts = check_login_attempts($username);
        
        if ($attempts['count'] >= MAX_LOGIN_ATTEMPTS) {
            $error = 'Too many login attempts. Please try again later.';
        } elseif (empty($username) || empty($password)) {
            $error = 'Please enter both username and password.';
        } else {
            try {
                $user_account = get_single_result("
                    SELECT u.status, r.role_name
                    FROM users u
                    JOIN roles r ON u.role_id = r.role_id
                    WHERE u.username = ?
                ", [$username]);

                // Attempt login
                if (login_user($username, $password)) {
                    reset_login_attempts($username);
                    
                    // Redirect based on role
                    $role = get_user_role();
                    switch ($role) {
                        case 'admin':
                            redirect('modules/admin/dashboard.php');
                        case 'student':
                            redirect('modules/student/dashboard.php');
                        case 'teacher':
                            redirect('modules/teacher/dashboard.php');
                        case 'dean':
                            redirect('modules/dean/dashboard.php');
                        case 'records_officer':
                            redirect('modules/records/dashboard.php');
                        case 'finance_officer':
                            redirect('modules/finance/dashboard.php');
                        case 'cashier':
                            redirect('modules/cashier/dashboard.php');
                        default:
                            redirect('index.php');
                    }
                } else {
                    increment_login_attempts($username);
                    $remaining_attempts = MAX_LOGIN_ATTEMPTS - $attempts['count'] - 1;

                    if ($user_account && $user_account['status'] === 'pending') {
                        $error = 'Your registration is still pending admin approval.';
                    } elseif ($user_account && $user_account['status'] === 'rejected') {
                        $error = 'Your registration was rejected. Please contact the administrator.';
                    } else {
                        $error = 'Invalid username or password.';
                        if ($remaining_attempts > 0) {
                            $error .= " You have $remaining_attempts attempts remaining.";
                        }
                    }
                }
            } catch (Exception $e) {
                error_log('Login database error: ' . $e->getMessage());
                $error = 'Cannot connect to database. Please start MySQL in XAMPP and verify DB settings.';
            }
        }
    }
}

// Get flash messages
$flash_messages = get_flash_messages();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <title>Sign In - school Information System </title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body class="login-page">
    <div class="login-container">
        <div class="login-form">
            <div class="login-header">
                <div class="brand-icon">
                    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><rect width="24" height="24" rx="4" fill="#4A86F7"/><path d="M6 10l6-4 6 4v6a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2v-6z" fill="#fff"/></svg>
                </div>
                <h1>Enchong Dee University </h1>
                <p class="muted">Management System</p>
            </div>
            
            <?php if ($flash_messages): ?>
                <div class="flash-messages">
                    <?php foreach ($flash_messages as $message): ?>
                        <div class="alert alert-<?php echo $message['type']; ?>">
                            <?php echo htmlspecialchars($message['message']); ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="" data-password-validation="none">
                <div class="form-group">
                    <label for="username" class="form-label">Email</label>
                    <div class="input-icon">
                       
                        <input type="text" id="username" name="username" class="form-control" 
                               value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>" 
                               >
                    </div>
                    <div class="invalid-feedback"></div>
                </div>
                
                <div class="form-group">
                    <label for="password" class="form-label">Password</label>
                    <div class="input-icon">
                
                        <input type="password" id="password" name="password" class="form-control" placeholder=>
                    </div>
                    <div class="invalid-feedback"></div>
                </div>
                
                <div class="form-group">
                    <div class="form-check">
                        <input type="checkbox" id="remember" name="remember" class="form-check-input">
                        <label for="remember" class="form-check-label">Remember me</label>
                    </div>
                </div>
                
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                
                <button type="submit" class="btn btn-primary btn-block btn-green">
                    Sign In
                </button>
            </form>
            
            <div class="login-footer">
                <p><a href="forgot_password.php">Forgot your password?</a></p>
                <p>Don't have an account? <a href="register.php">Register here</a></p>
                <p>All registrations must be approved by the admin before login.</p>
            </div>
        </div>
    </div>
    
    <style>
        /* ===== MODERN LOGIN DESIGN ===== */

:root {
    --bg-main: linear-gradient(135deg, #0f172a, #1e293b);
    --card-bg: rgba(255, 255, 255, 0.08);
    --border: rgba(255, 255, 255, 0.15);
    --primary: #4A86F7;
    --primary-hover: #2563eb;
    --text: #ffffff;
    --muted: #cbd5e1;
    --input-bg: rgba(255, 255, 255, 0.08);
}

html,
body {
    height: 100%;
    margin: 0;
    padding: 0;
}

body.login-page {
    background: var(--bg-main);
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: 'Segoe UI', sans-serif;
    overflow: hidden;
    position: relative;
}

/* Background Glow */
body.login-page::before,
body.login-page::after {
    content: '';
    position: absolute;
    width: 350px;
    height: 350px;
    border-radius: 50%;
    filter: blur(100px);
    opacity: 0.4;
}

body.login-page::before {
    background: #2563eb;
    top: -100px;
    left: -100px;
}

body.login-page::after {
    background: #06b6d4;
    bottom: -100px;
    right: -100px;
}

.login-container {
    width: 100%;
    max-width: 430px;
    padding: 20px;
    z-index: 2;
}

.login-form {
    background: var(--card-bg);
    backdrop-filter: blur(18px);
    border: 1px solid var(--border);
    padding: 40px;
    border-radius: 24px;
    box-shadow: 0 15px 40px rgba(0, 0, 0, 0.35);
    text-align: center;
    animation: fadeIn 0.7s ease;
}

/* Animation */
@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(25px);
    }

    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Logo */
.brand-icon {
    margin-bottom: 15px;
}

.brand-icon svg {
    width: 65px;
    height: 65px;
    border-radius: 18px;
    box-shadow: 0 6px 15px rgba(74, 134, 247, 0.4);
}

/* Header */
.login-header h1 {
    margin: 0;
    font-size: 28px;
    font-weight: 700;
    color: var(--text);
}

.login-header .muted {
    margin-top: 8px;
    color: var(--muted);
    font-size: 14px;
    letter-spacing: 0.5px;
}

/* Form */
.form-group {
    text-align: left;
    margin-bottom: 18px;
}

.form-label {
    display: block;
    margin-bottom: 8px;
    color: var(--muted);
    font-size: 14px;
}

.form-control {
    width: 100%;
    box-sizing: border-box;
    padding: 14px 16px;
    border-radius: 14px;
    border: 1px solid transparent;
    background: var(--input-bg);
    color: white;
    font-size: 15px;
    transition: all 0.3s ease;
    outline: none;
}

.form-control::placeholder {
    color: #cbd5e1;
}

.form-control:focus {
    border-color: var(--primary);
    background: rgba(255, 255, 255, 0.12);
    box-shadow: 0 0 0 4px rgba(74, 134, 247, 0.2);
}

/* Checkbox */
.form-check {
    display: flex;
    align-items: center;
    gap: 8px;
    margin: 10px 0 20px;
    color: var(--muted);
    font-size: 14px;
}

/* Button */
.btn-block {
    width: 100%;
    padding: 14px;
    border: none;
    border-radius: 14px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
}

.btn-green {
    background: linear-gradient(135deg, #4A86F7, #2563eb);
    color: white;
}

.btn-green:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 20px rgba(37, 99, 235, 0.35);
}

/* Alerts */
.alert {
    padding: 12px;
    border-radius: 12px;
    margin-bottom: 15px;
    font-size: 14px;
}

.alert-danger {
    background: rgba(239, 68, 68, 0.2);
    color: #fecaca;
    border: 1px solid rgba(239, 68, 68, 0.4);
}

.alert-success {
    background: rgba(34, 197, 94, 0.2);
    color: #bbf7d0;
    border: 1px solid rgba(34, 197, 94, 0.4);
}

/* Footer */
.login-footer {
    margin-top: 22px;
    font-size: 13px;
    color: var(--muted);
}

.login-footer a {
    color: #93c5fd;
    text-decoration: none;
    transition: 0.3s;
}

.login-footer a:hover {
    color: white;
}

/* Mobile */
@media (max-width: 480px) {
    .login-form {
        padding: 28px 22px;
        border-radius: 18px;
    }

    .login-header h1 {
        font-size: 22px;
    }
}   
    </style>
    
    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
