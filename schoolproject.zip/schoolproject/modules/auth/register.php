<?php
/**
 * Registration Page
 * School Information System
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';

// Redirect if already logged in
if (is_logged_in()) {
    redirect('index.php');
}

$error = '';
$success = '';
$form_data = [];
$errors = [];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    // Verify CSRF token
    if (!verify_csrf_token($csrf_token)) {
        $error = 'Invalid request. Please try again.';
    } else {
        // Sanitize and validate input
        $form_data = [
            'username' => sanitize_input($_POST['username'] ?? ''),
            'email' => sanitize_input($_POST['email'] ?? ''),
            'password' => $_POST['password'] ?? '',
            'confirm_password' => $_POST['confirm_password'] ?? '',
            'first_name' => sanitize_input($_POST['first_name'] ?? ''),
            'last_name' => sanitize_input($_POST['last_name'] ?? ''),
            'middle_name' => sanitize_input($_POST['middle_name'] ?? ''),
            'role_id' => (int)($_POST['role_id'] ?? 0),
            'phone' => preg_replace('/[\s\-()]/', '', sanitize_input($_POST['phone'] ?? '')),
            'address' => sanitize_input($_POST['address'] ?? '')
        ];
        
        // Validation
        $errors = [];
        
        // Required fields
        $required_fields = ['username', 'email', 'password', 'confirm_password', 'first_name', 'last_name', 'role_id'];
        foreach ($required_fields as $field) {
            if (empty($form_data[$field])) {
                $errors[$field] = 'This field is required';
            }
        }
        
        // Username validation
        if (empty($errors['username'])) {
            if (strlen($form_data['username']) < 3) {
                $errors['username'] = 'Username must be at least 3 characters long';
            } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $form_data['username'])) {
                $errors['username'] = 'Username can only contain letters, numbers, and underscores';
            } else {
                // Check if username already exists
                $existing = get_single_result("SELECT user_id FROM users WHERE username = ?", [$form_data['username']]);
                if ($existing) {
                    $errors['username'] = 'Username already exists';
                }
            }
        }
        
        // Email validation
        if (empty($errors['email'])) {
            if (!validate_email($form_data['email'])) {
                $errors['email'] = 'Please enter a valid email address';
            } else {
                // Check if email already exists
                $existing = get_single_result("SELECT user_id FROM users WHERE email = ?", [$form_data['email']]);
                if ($existing) {
                    $errors['email'] = 'Email already exists';
                }
            }
        }
        
        // Password validation
        if (empty($errors['password'])) {
            if (!validate_password($form_data['password'])) {
                $errors['password'] = 'Password must be at least 4 characters long';
            }
        }
        
        // Confirm password validation
        if (empty($errors['confirm_password'])) {
            if ($form_data['password'] !== $form_data['confirm_password']) {
                $errors['confirm_password'] = 'Passwords do not match';
            }
        }
        
        // Name validation
        if (empty($errors['first_name']) && strlen($form_data['first_name']) < 2) {
            $errors['first_name'] = 'First name must be at least 2 characters long';
        }
        
        if (empty($errors['last_name']) && strlen($form_data['last_name']) < 2) {
            $errors['last_name'] = 'Last name must be at least 2 characters long';
        }
        
        // Phone validation (optional)
        if (!empty($form_data['phone']) && !validate_phone($form_data['phone'])) {
            $errors['phone'] = 'Please enter a valid Philippine phone number';
        }
        
        // Role validation
        if (empty($errors['role_id'])) {
            $valid_roles = get_multiple_results("SELECT role_id FROM roles WHERE role_name IN ('student', 'teacher', 'dean', 'records_officer', 'finance_officer', 'cashier')");
            $role_ids = array_column($valid_roles, 'role_id');
            if (!in_array($form_data['role_id'], $role_ids)) {
                $errors['role_id'] = 'Invalid role selected';
            }
        }
        
        if (empty($errors)) {
            try {
                // Insert user
                $user_data = [
                    'username' => $form_data['username'],
                    'email' => $form_data['email'],
                    'password_hash' => hash_password($form_data['password']),
                    'role_id' => $form_data['role_id'],
                    'first_name' => $form_data['first_name'],
                    'last_name' => $form_data['last_name'],
                    'middle_name' => $form_data['middle_name'] ?: null,
                    'status' => 'pending'
                ];
                
                $user_id = insert_record('users', $user_data);
                
                // Insert role-specific record if needed
                $role_name = get_single_result("SELECT role_name FROM roles WHERE role_id = ?", [$form_data['role_id']])['role_name'];
                
                switch ($role_name) {
                    case 'student':
                        // Generate student number
                        $student_number = generate_student_number();
                        $course_id = (int)($_POST['course_id'] ?? 0);
                        
                        if ($course_id > 0) {
                            $student_data = [
                                'user_id' => $user_id,
                                'student_number' => $student_number,
                                'course_id' => $course_id,
                                'year_level' => 1,
                                'admission_date' => date(DATE_FORMAT)
                            ];
                            insert_record('students', $student_data);
                        }
                        break;
                        
                    case 'teacher':
                        $department_id = (int)($_POST['department_id'] ?? 0);
                        $employee_number = 'EMP-' . date('Y') . '-' . str_pad($user_id, 5, '0', STR_PAD_LEFT);
                        
                        if ($department_id > 0) {
                            $teacher_data = [
                                'user_id' => $user_id,
                                'employee_number' => $employee_number,
                                'department_id' => $department_id,
                                'hire_date' => date(DATE_FORMAT)
                            ];
                            insert_record('teachers', $teacher_data);
                        }
                        break;

                    case 'records_officer':
                        insert_record('records_officers', [
                            'user_id' => $user_id,
                            'employee_number' => 'REC-' . date('Y') . '-' . str_pad($user_id, 5, '0', STR_PAD_LEFT)
                        ]);
                        break;

                    case 'finance_officer':
                        insert_record('finance_officers', [
                            'user_id' => $user_id,
                            'employee_number' => 'FIN-' . date('Y') . '-' . str_pad($user_id, 5, '0', STR_PAD_LEFT)
                        ]);
                        break;

                    case 'cashier':
                        insert_record('cashiers', [
                            'user_id' => $user_id,
                            'employee_number' => 'CAS-' . date('Y') . '-' . str_pad($user_id, 5, '0', STR_PAD_LEFT)
                        ]);
                        break;
                }
                
                // Log registration
                log_audit('USER_REGISTER', 'users', $user_id);
                
                // Send notification to admin
                send_notification(1, 'new_registration', 'New user registration awaiting approval', [
                    'user_id' => $user_id,
                    'username' => $form_data['username'],
                    'role' => $role_name
                ]);
                
                $success = 'Registration submitted successfully. Please wait for admin approval before logging in.';
                $form_data = []; // Clear form
                
            } catch (Exception $e) {
                error_log("Registration error: " . $e->getMessage());
                $error = 'Registration failed. Please try again.';
            }
        } else {
            $error = 'Please correct the errors below.';
        }
    }
}

// Get available roles for registration
$available_roles = get_multiple_results("
    SELECT r.role_id, r.role_name, r.description 
    FROM roles r 
    WHERE r.role_name IN ('student', 'teacher', 'dean', 'records_officer', 'finance_officer', 'cashier')
    ORDER BY r.role_name
");

// Get departments
$departments = get_multiple_results("SELECT department_id, department_name, department_code FROM departments ORDER BY department_name");

// Get flash messages
$flash_messages = get_flash_messages();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <title>Register - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body class="register-page">
    <div class="register-container">
        <div class="register-form">
            <div class="register-header">
                <h1>Create Account</h1>
                <p>Join the School Information System</p>
                <small class="form-text">All user registrations are subject to admin approval before account access is granted.</small>
            </div>
            
            <?php if ($flash_messages): ?>
                <div class="flash-messages">
                    <?php foreach ($flash_messages as $message): ?>
                        <div class="alert alert-<?php echo $message['type']; ?>">
                            <?php echo htmlspecialchars($message['message']); ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <?php echo htmlspecialchars($error); ?>
                    <?php if (!empty($errors)): ?>
                        <ul class="mt-2 mb-0">
                            <?php foreach ($errors as $field_error): ?>
                                <li><?php echo htmlspecialchars($field_error); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <?php echo htmlspecialchars($success); ?>
                    <div class="mt-3">
                        <a href="login.php" class="btn btn-primary">Go to Login</a>
                    </div>
                </div>
            <?php else: ?>
                <form method="POST" action="" id="registrationForm">
                    <div class="form-section">
                        <h3>Account Information</h3>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="username" class="form-label">Username *</label>
                                <input type="text" id="username" name="username" class="form-control" 
                                       value="<?php echo htmlspecialchars($form_data['username'] ?? ''); ?>" 
                                       required>
                                <div class="invalid-feedback"></div>
                                <small class="form-text">Letters, numbers, and underscores only</small>
                            </div>
                            
                            <div class="form-group">
                                <label for="email" class="form-label">Email Address *</label>
                                <input type="email" id="email" name="email" class="form-control" 
                                       value="<?php echo htmlspecialchars($form_data['email'] ?? ''); ?>" 
                                       required>
                                <div class="invalid-feedback"></div>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="password" class="form-label">Password *</label>
                                <input type="password" id="password" name="password" class="form-control" required>
                                <div class="invalid-feedback"></div>
                                <small class="form-text">Minimum 4 characters</small>
                            </div>
                            
                            <div class="form-group">
                                <label for="confirm_password" class="form-label">Confirm Password *</label>
                                <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
                                <div class="invalid-feedback"></div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="role_id" class="form-label">Account Type *</label>
                            <select id="role_id" name="role_id" class="form-control" required>
                                <option value="">Select Account Type</option>
                                <?php foreach ($available_roles as $role): ?>
                                    <option value="<?php echo $role['role_id']; ?>" 
                                            data-role-name="<?php echo htmlspecialchars($role['role_name']); ?>"
                                            <?php echo ($form_data['role_id'] ?? '') == $role['role_id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($role['role_name'] === 'dean' ? 'dean / program head' : ($role['role_name'] === 'finance_officer' ? 'finance office' : str_replace('_', ' ', $role['role_name']))); ?>
                                        <?php if ($role['description']): ?>
                                            - <?php echo htmlspecialchars($role['description']); ?>
                                        <?php endif; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <div class="invalid-feedback"></div>
                        </div>
                    </div>
                    
                    <div class="form-section">
                        <h3>Personal Information</h3>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="first_name" class="form-label">First Name *</label>
                                <input type="text" id="first_name" name="first_name" class="form-control" 
                                       value="<?php echo htmlspecialchars($form_data['first_name'] ?? ''); ?>" 
                                       required>
                                <div class="invalid-feedback"></div>
                            </div>
                            
                            <div class="form-group">
                                <label for="last_name" class="form-label">Last Name *</label>
                                <input type="text" id="last_name" name="last_name" class="form-control" 
                                       value="<?php echo htmlspecialchars($form_data['last_name'] ?? ''); ?>" 
                                       required>
                                <div class="invalid-feedback"></div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="middle_name" class="form-label">Middle Name</label>
                            <input type="text" id="middle_name" name="middle_name" class="form-control" 
                                   value="<?php echo htmlspecialchars($form_data['middle_name'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="phone" class="form-label">Phone Number</label>
                                <input type="tel" id="phone" name="phone" class="form-control" 
                                       value="<?php echo htmlspecialchars($form_data['phone'] ?? ''); ?>"
                                       placeholder="09XXXXXXXXX">
                                <div class="invalid-feedback"></div>
                                <small class="form-text">Format: 09XXXXXXXXX or +639XXXXXXXXX</small>
                            </div>
                            
                            <div class="form-group">
                                <label for="address" class="form-label">Address</label>
                                <input type="text" id="address" name="address" class="form-control" 
                                       value="<?php echo htmlspecialchars($form_data['address'] ?? ''); ?>">
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-section" id="teacherFields" style="display: none;">
                        <h3>Employment Information</h3>
                        <div class="form-group">
                            <label for="department_id" class="form-label">Department *</label>
                            <select id="department_id" name="department_id" class="form-control">
                                <option value="">Select Department</option>
                                <?php foreach ($departments as $department): ?>
                                    <option value="<?php echo $department['department_id']; ?>">
                                        <?php echo htmlspecialchars($department['department_name']); ?> (<?php echo htmlspecialchars($department['department_code']); ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <div class="invalid-feedback"></div>
                        </div>
                    </div>
                    
                    <div class="form-section">
                        <div class="form-check">
                            <input type="checkbox" id="terms" name="terms" class="form-check-input" required>
                            <label for="terms" class="form-check-label">
                                I agree to the <a href="#" onclick="showTerms(); return false;">Terms and Conditions</a> and <a href="#" onclick="showPrivacy(); return false;">Privacy Policy</a> *
                            </label>
                        </div>
                    </div>
                    
                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                    
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary btn-lg">
                            Create Account
                        </button>
                        <a href="login.php" class="btn btn-secondary btn-lg">
                            Cancel
                        </a>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
    
    <style>
        .register-page {
    background: linear-gradient(135deg, #0f172a 0%, #1e3a8a 50%, #0ea5e9 100%);
    min-height: 100vh;
    padding: 40px 0;
    position: relative;
    overflow-x: hidden;
}

/* Background Glow */
.register-page::before,
.register-page::after {
    content: '';
    position: absolute;
    width: 350px;
    height: 350px;
    border-radius: 50%;
    filter: blur(100px);
    opacity: 0.3;
}

.register-page::before {
    background: #2563eb;
    top: -100px;
    left: -100px;
}

.register-page::after {
    background: #06b6d4;
    bottom: -100px;
    right: -100px;
}

.register-container {
    max-width: 850px;
    margin: 0 auto;
    padding: 0 20px;
    position: relative;
    z-index: 2;
}

/* Form Card */
.register-form {
    background: rgba(255, 255, 255, 0.08);
    backdrop-filter: blur(18px);
    padding: 42px;
    border-radius: 28px;
    box-shadow: 0 20px 45px rgba(0, 0, 0, 0.35);
    border: 1px solid rgba(255, 255, 255, 0.12);
    animation: fadeUp 0.7s ease;
}

/* Animation */
@keyframes fadeUp {
    from {
        opacity: 0;
        transform: translateY(25px);
    }

    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Header */
.register-header {
    text-align: center;
    margin-bottom: 35px;
}

.register-header h1 {
    color: #ffffff;
    margin-bottom: 10px;
    font-size: 2.2rem;
    font-weight: 700;
}

.register-header p {
    color: #cbd5e1;
    margin-bottom: 0;
    font-size: 15px;
}

/* Sections */
.form-section {
    margin-bottom: 32px;
    padding-bottom: 24px;
    border-bottom: 1px solid rgba(255,255,255,0.12);
}

.form-section:last-child {
    border-bottom: none;
    margin-bottom: 0;
}

.form-section h3 {
    color: #93c5fd;
    margin-bottom: 22px;
    font-size: 1.2rem;
    font-weight: 600;
}

/* Inputs */
.form-group {
    margin-bottom: 18px;
}

select.form-control {
    appearance: none;
    -webkit-appearance: none;
    -moz-appearance: none;

    background: rgba(255,255,255,0.08);
    color: white;
    border: 1px solid rgba(255,255,255,0.15);
    padding: 14px 16px;
    border-radius: 14px;
    width: 100%;
    font-size: 15px;
    outline: none;
    cursor: pointer;

    /* custom arrow */
    background-image: url("data:image/svg+xml;charset=UTF-8,%3Csvg width='20' height='20' fill='white' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M5 7l5 5 5-5' stroke='white' stroke-width='2' fill='none' stroke-linecap='round'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right 15px center;
    background-size: 18px;
}

/* dropdown options */
select.form-control option {
    background: #1e293b;
    color: white;
    padding: 10px;
}

/* focus effect */
select.form-control:focus {
    border-color: #60a5fa;
    box-shadow: 0 0 0 4px rgba(96,165,250,0.2);
}
/* Responsive */
@media (max-width: 768px) {
    .register-form {
        padding: 24px;
        border-radius: 22px;
    }

    .form-row {
        flex-direction: column;
    }

    .form-actions {
        flex-direction: column;
    }

    .btn-lg {
        width: 100%;
    }

    .register-header h1 {
        font-size: 1.8rem;
    }
}
    </script>
    
    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
