<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';

if (!is_logged_in()) {
    flash_message('error', 'Please login to continue.');
    redirect('modules/auth/login.php');
}

$current_user = get_logged_in_user();
$role = $current_user['role'] ?? '';

$dashboard_routes = [
    'admin' => 'modules/admin/dashboard.php',
    'dean' => 'modules/dean/dashboard.php',
    'teacher' => 'modules/teacher/dashboard.php',
    'student' => 'modules/student/dashboard.php',
    'cashier' => 'modules/cashier/dashboard.php',
    'finance_officer' => 'modules/finance/dashboard.php',
    'records_officer' => 'modules/records/dashboard.php',
];
$back_route = $dashboard_routes[$role] ?? 'index.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    $current_password = (string)($_POST['current_password'] ?? '');
    $new_password = (string)($_POST['new_password'] ?? '');
    $confirm_password = (string)($_POST['confirm_password'] ?? '');

    if (!verify_csrf_token($csrf_token)) {
        flash_message('error', 'Invalid request token.');
        redirect('modules/account/change_password.php');
    }

    try {
        if ($current_password === '' || $new_password === '' || $confirm_password === '') {
            throw new Exception('Please complete all password fields.');
        }

        if (!validate_password($new_password)) {
            throw new Exception('New password must be at least 4 characters long.');
        }

        if ($new_password !== $confirm_password) {
            throw new Exception('New password and confirm password do not match.');
        }

        $user = get_single_result("
            SELECT user_id, password_hash
            FROM users
            WHERE user_id = ?
            LIMIT 1
        ", [$current_user['user_id']]);

        if (!$user || !verify_password($current_password, $user['password_hash'])) {
            throw new Exception('Current password is incorrect.');
        }

        $conn = get_db_connection();
        $stmt = $conn->prepare("
            UPDATE users
            SET password_hash = ?
            WHERE user_id = ?
        ");
        $stmt->execute([hash_password($new_password), $current_user['user_id']]);

        log_audit('PASSWORD_CHANGED', 'users', $current_user['user_id']);
        flash_message('success', 'Password changed successfully.');
        redirect('modules/account/change_password.php');
    } catch (Exception $e) {
        flash_message('error', $e->getMessage());
        redirect('modules/account/change_password.php');
    }
}

$flash_messages = get_flash_messages();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <title>Change Password - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo"><a href="<?php echo APP_URL . '/' . $back_route; ?>">Enchong Dee University Information System</a></div>
            <nav>
                <ul class="nav">
                    <li><a href="<?php echo APP_URL . '/' . $back_route; ?>">Back to Dashboard</a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main class="main-content" style="margin-left:0;">
        <div class="content-wrapper" style="max-width:760px;margin:2rem auto;">
            <div class="page-header">
                <h1>Change Password</h1>
                <p>Update your account password securely.</p>
            </div>

            <?php if ($flash_messages): ?>
                <div class="flash-messages mb-3">
                    <?php foreach ($flash_messages as $message): ?>
                        <div class="alert alert-<?php echo htmlspecialchars($message['type']); ?>">
                            <?php echo htmlspecialchars($message['message']); ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header"><h4>Password Details</h4></div>
                <div class="card-body">
                    <form method="POST" action="" data-password-validation="basic">
                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">

                        <div class="form-group">
                            <label class="form-label" for="current_password">Current Password</label>
                            <input type="password" id="current_password" name="current_password" class="form-control" autocomplete="current-password" required>
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="new_password">New Password</label>
                            <input type="password" id="new_password" name="new_password" class="form-control" autocomplete="new-password" minlength="4" required>
                            <small class="text-muted">Minimum 4 characters.</small>
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="confirm_password">Confirm New Password</label>
                            <input type="password" id="confirm_password" name="confirm_password" class="form-control" autocomplete="new-password" minlength="4" required>
                        </div>

                        <div style="display:flex;gap:.75rem;flex-wrap:wrap;">
                            <button type="submit" class="btn btn-primary">Change Password</button>
                            <a href="<?php echo APP_URL . '/' . $back_route; ?>" class="btn btn-secondary">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
    <script>
        (function () {
            const form = document.querySelector('form');
            const next = document.getElementById('new_password');
            const confirm = document.getElementById('confirm_password');

            if (!form || !next || !confirm) {
                return;
            }

            form.addEventListener('submit', function (event) {
                if (next.value !== confirm.value) {
                    event.preventDefault();
                    alert('New password and confirm password do not match.');
                    confirm.focus();
                }
            });
        })();
    </script>
</body>
</html>
