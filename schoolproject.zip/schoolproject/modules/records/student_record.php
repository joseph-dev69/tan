<?php
/**
 * Records Officer Student Detail Page
 */
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../finance/billing_helpers.php';

require_role('records_officer');

$current_user = get_logged_in_user();
$student_id = (int)($_GET['student_id'] ?? $_POST['student_id'] ?? 0);

if ($student_id <= 0) {
    flash_message('error', 'Student record was not found.');
    redirect('modules/records/dashboard.php');
}

function records_detail_redirect($student_id)
{
    redirect('modules/records/student_record.php?student_id=' . (int)$student_id);
}

function records_fetch_student($student_id)
{
    return get_single_result("
        SELECT s.*, u.username, u.email, u.first_name, u.last_name, u.middle_name, u.status AS user_status,
               c.course_code, c.course_name
        FROM students s
        JOIN users u ON s.user_id = u.user_id
        LEFT JOIN courses c ON s.course_id = c.course_id
        WHERE s.student_id = ?
    ", [$student_id]);
}

function records_safe_decimal($value)
{
    if ($value === '' || $value === null) {
        return null;
    }
    return round((float)$value, 2);
}

function records_badge_class($status)
{
    $normalized = strtolower(trim((string)$status));
    if (in_array($normalized, ['approved', 'regular', 'enrolled', 'completed', 'paid', 'verified'], true)) {
        return 'success';
    }
    if (in_array($normalized, ['pending', 'partially_paid', 'probation', 'irregular'], true)) {
        return 'warning';
    }
    if (in_array($normalized, ['dropped', 'failed', 'overdue', 'suspended', 'cancelled', 'inactive', 'rejected'], true)) {
        return 'danger';
    }
    return 'info';
}

$student = records_fetch_student($student_id);
if (!$student) {
    flash_message('error', 'Student record was not found.');
    redirect('modules/records/dashboard.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    $action = $_POST['action'] ?? '';

    if (!verify_csrf_token($csrf_token)) {
        flash_message('error', 'Invalid request token.');
        records_detail_redirect($student_id);
    }

    try {
        $conn = get_db_connection();
        $conn->beginTransaction();

        if ($action === 'update_profile') {
            $old_user = get_single_result("SELECT * FROM users WHERE user_id = ?", [$student['user_id']]);
            $old_student = get_single_result("SELECT * FROM students WHERE student_id = ?", [$student_id]);

            $user_data = [
                'username' => trim($_POST['username'] ?? ''),
                'email' => trim($_POST['email'] ?? ''),
                'first_name' => trim($_POST['first_name'] ?? ''),
                'middle_name' => trim($_POST['middle_name'] ?? ''),
                'last_name' => trim($_POST['last_name'] ?? ''),
                'status' => $_POST['user_status'] ?? 'approved',
            ];

            $student_data = [
                'student_number' => trim($_POST['student_number'] ?? ''),
                'course_id' => (int)($_POST['course_id'] ?? 0),
                'year_level' => (int)($_POST['year_level'] ?? 1),
                'academic_status' => $_POST['academic_status'] ?? 'regular',
                'admission_date' => $_POST['admission_date'] ?: date('Y-m-d'),
                'expected_graduation_date' => $_POST['expected_graduation_date'] ?: null,
                'gpa' => records_safe_decimal($_POST['gpa'] ?? 0) ?? 0,
            ];

            if ($user_data['username'] === '' || $user_data['email'] === '' || $user_data['first_name'] === '' || $user_data['last_name'] === '') {
                throw new Exception('Required account fields are missing.');
            }
            if (!validate_email($user_data['email'])) {
                throw new Exception('Email address is invalid.');
            }
            if ($student_data['student_number'] === '' || $student_data['course_id'] <= 0) {
                throw new Exception('Required student fields are missing.');
            }

            $stmt = $conn->prepare("
                UPDATE users
                SET username = ?, email = ?, first_name = ?, middle_name = ?, last_name = ?, status = ?, updated_at = NOW()
                WHERE user_id = ?
            ");
            $stmt->execute([
                $user_data['username'],
                $user_data['email'],
                $user_data['first_name'],
                $user_data['middle_name'],
                $user_data['last_name'],
                $user_data['status'],
                $student['user_id'],
            ]);

            $stmt = $conn->prepare("
                UPDATE students
                SET student_number = ?, course_id = ?, year_level = ?, academic_status = ?, admission_date = ?,
                    expected_graduation_date = ?, gpa = ?, updated_at = NOW()
                WHERE student_id = ?
            ");
            $stmt->execute([
                $student_data['student_number'],
                $student_data['course_id'],
                $student_data['year_level'],
                $student_data['academic_status'],
                $student_data['admission_date'],
                $student_data['expected_graduation_date'],
                $student_data['gpa'],
                $student_id,
            ]);

            log_audit('RECORDS_UPDATE_USER_PROFILE', 'users', $student['user_id'], $old_user, $user_data);
            log_audit('RECORDS_UPDATE_STUDENT_PROFILE', 'students', $student_id, $old_student, $student_data);
            $conn->commit();
            flash_message('success', 'Student profile updated successfully.');
            records_detail_redirect($student_id);
        }

        if ($action === 'update_enrollment') {
            $enrollment_id = (int)($_POST['enrollment_id'] ?? 0);
            $old = get_single_result("SELECT * FROM enrollments WHERE enrollment_id = ? AND student_id = ?", [$enrollment_id, $student_id]);
            if (!$old) {
                throw new Exception('Enrollment record was not found.');
            }

            $new = [
                'school_year_id' => (int)($_POST['school_year_id'] ?? 0),
                'semester_id' => (int)($_POST['semester_id'] ?? 0),
                'enrollment_date' => $_POST['enrollment_date'] ?: date('Y-m-d'),
                'status' => $_POST['status'] ?? 'enrolled',
                'total_units' => records_safe_decimal($_POST['total_units'] ?? 0) ?? 0,
                'total_fee' => records_safe_decimal($_POST['total_fee'] ?? 0) ?? 0,
                'paid_amount' => records_safe_decimal($_POST['paid_amount'] ?? 0) ?? 0,
            ];
            $new['balance'] = max(0, round($new['total_fee'] - $new['paid_amount'], 2));

            $stmt = $conn->prepare("
                UPDATE enrollments
                SET school_year_id = ?, semester_id = ?, enrollment_date = ?, status = ?,
                    total_units = ?, total_fee = ?, paid_amount = ?, balance = ?, updated_at = NOW()
                WHERE enrollment_id = ? AND student_id = ?
            ");
            $stmt->execute([
                $new['school_year_id'],
                $new['semester_id'],
                $new['enrollment_date'],
                $new['status'],
                $new['total_units'],
                $new['total_fee'],
                $new['paid_amount'],
                $new['balance'],
                $enrollment_id,
                $student_id,
            ]);

            log_audit('RECORDS_UPDATE_ENROLLMENT', 'enrollments', $enrollment_id, $old, $new);
            $conn->commit();
            flash_message('success', 'Enrollment updated successfully.');
            records_detail_redirect($student_id);
        }

        if ($action === 'update_load') {
            $load_id = (int)($_POST['load_id'] ?? 0);
            $old = get_single_result("
                SELECT loadrec.*
                FROM student_subject_loads loadrec
                JOIN enrollments e ON loadrec.enrollment_id = e.enrollment_id
                WHERE loadrec.load_id = ? AND e.student_id = ?
            ", [$load_id, $student_id]);
            if (!$old) {
                throw new Exception('Subject load record was not found.');
            }

            $new = [
                'status' => $_POST['status'] ?? 'enrolled',
                'final_grade' => records_safe_decimal($_POST['final_grade'] ?? null),
                'remarks' => trim($_POST['remarks'] ?? ''),
            ];

            $stmt = $conn->prepare("
                UPDATE student_subject_loads
                SET status = ?, final_grade = ?, remarks = ?, updated_at = NOW()
                WHERE load_id = ?
            ");
            $stmt->execute([$new['status'], $new['final_grade'], $new['remarks'], $load_id]);

            log_audit('RECORDS_UPDATE_SUBJECT_LOAD', 'student_subject_loads', $load_id, $old, $new);
            $conn->commit();
            flash_message('success', 'Subject load updated successfully.');
            records_detail_redirect($student_id);
        }

        if ($action === 'update_grade') {
            $load_id = (int)($_POST['load_id'] ?? 0);
            $period = strtolower(trim($_POST['grading_period'] ?? ''));
            $grade_value = trim($_POST['grade'] ?? '');
            $allowed_periods = ['prelim', 'midterm', 'prefinal', 'final'];

            if (!in_array($period, $allowed_periods, true)) {
                throw new Exception('Invalid grading period.');
            }

            $load = get_single_result("
                SELECT loadrec.load_id, so.teacher_id
                FROM student_subject_loads loadrec
                JOIN enrollments e ON loadrec.enrollment_id = e.enrollment_id
                JOIN subject_offerings so ON loadrec.offering_id = so.offering_id
                WHERE loadrec.load_id = ? AND e.student_id = ?
            ", [$load_id, $student_id]);
            if (!$load) {
                throw new Exception('Subject load record was not found.');
            }

            $old = get_single_result("
                SELECT *
                FROM grades
                WHERE student_subject_load_id = ? AND grading_period = ?
            ", [$load_id, $period]);

            if ($grade_value === '') {
                if ($old) {
                    $stmt = $conn->prepare("DELETE FROM grades WHERE grade_id = ?");
                    $stmt->execute([$old['grade_id']]);
                    log_audit('RECORDS_DELETE_GRADE', 'grades', $old['grade_id'], $old, null);
                }
            } else {
                $new_grade = records_safe_decimal($grade_value);
                if ($new_grade === null || $new_grade < 0 || $new_grade > 100) {
                    throw new Exception('Grade must be between 0 and 100.');
                }

                if ($old) {
                    $new = [
                        'grade' => $new_grade,
                        'date_graded' => date('Y-m-d'),
                    ];
                    $stmt = $conn->prepare("
                        UPDATE grades
                        SET grade = ?, date_graded = ?
                        WHERE grade_id = ?
                    ");
                    $stmt->execute([$new['grade'], $new['date_graded'], $old['grade_id']]);
                    log_audit('RECORDS_UPDATE_GRADE', 'grades', $old['grade_id'], $old, $new);
                } else {
                    if (empty($load['teacher_id'])) {
                        throw new Exception('Assign a teacher to this subject before adding a new grade.');
                    }
                    $new = [
                        'student_subject_load_id' => $load_id,
                        'grading_period' => $period,
                        'grade' => $new_grade,
                        'graded_by' => (int)$load['teacher_id'],
                        'date_graded' => date('Y-m-d'),
                    ];
                    $stmt = $conn->prepare("
                        INSERT INTO grades (student_subject_load_id, grading_period, grade, graded_by, date_graded)
                        VALUES (?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([$new['student_subject_load_id'], $new['grading_period'], $new['grade'], $new['graded_by'], $new['date_graded']]);
                    $new_grade_id = (int)$conn->lastInsertId();
                    log_audit('RECORDS_INSERT_GRADE', 'grades', $new_grade_id, null, $new);
                }
            }

            $conn->commit();
            flash_message('success', 'Grade updated successfully.');
            records_detail_redirect($student_id);
        }

        if ($action === 'update_billing') {
            $billing_id = (int)($_POST['billing_id'] ?? 0);
            $old = get_single_result("SELECT * FROM billings WHERE billing_id = ? AND student_id = ?", [$billing_id, $student_id]);
            if (!$old) {
                throw new Exception('Billing record was not found.');
            }

            $new = [
                'billing_date' => $_POST['billing_date'] ?: date('Y-m-d'),
                'due_date' => $_POST['due_date'] ?: date('Y-m-d'),
                'total_amount' => records_safe_decimal($_POST['total_amount'] ?? 0) ?? 0,
                'paid_amount' => records_safe_decimal($_POST['paid_amount'] ?? 0) ?? 0,
                'status' => $_POST['status'] ?? 'pending',
            ];

            if ($new['paid_amount'] > $new['total_amount']) {
                throw new Exception('Paid amount cannot exceed total amount.');
            }

            $stmt = $conn->prepare("
                UPDATE billings
                SET billing_date = ?, due_date = ?, total_amount = ?, paid_amount = ?, status = ?, updated_at = NOW()
                WHERE billing_id = ? AND student_id = ?
            ");
            $stmt->execute([
                $new['billing_date'],
                $new['due_date'],
                $new['total_amount'],
                $new['paid_amount'],
                $new['status'],
                $billing_id,
                $student_id,
            ]);

            log_audit('RECORDS_UPDATE_BILLING', 'billings', $billing_id, $old, $new);
            $conn->commit();
            flash_message('success', 'Billing record updated successfully.');
            records_detail_redirect($student_id);
        }

        throw new Exception('Unsupported action.');
    } catch (Exception $e) {
        if (isset($conn) && $conn instanceof PDO && $conn->inTransaction()) {
            $conn->rollBack();
        }
        error_log('Records student update error: ' . $e->getMessage());
        flash_message('error', $e->getMessage());
        records_detail_redirect($student_id);
    }
}

$courses = get_multiple_results("SELECT course_id, course_code, course_name FROM courses ORDER BY course_code ASC");
$school_years = get_multiple_results("SELECT school_year_id, year_name FROM school_years ORDER BY school_year_id DESC");
$semesters = get_multiple_results("SELECT semester_id, semester_name FROM semesters ORDER BY school_year_id DESC, semester_id DESC");

$enrollments = get_multiple_results("
    SELECT e.*, sy.year_name, sem.semester_name
    FROM enrollments e
    JOIN school_years sy ON e.school_year_id = sy.school_year_id
    JOIN semesters sem ON e.semester_id = sem.semester_id
    WHERE e.student_id = ?
    ORDER BY sy.school_year_id DESC, sem.semester_id DESC, e.enrollment_id DESC
", [$student_id]);

$subject_loads = get_multiple_results("
    SELECT loadrec.*, e.school_year_id, e.semester_id, sy.year_name, sem.semester_name,
           so.section, so.teacher_id, sub.subject_code, sub.subject_name, sub.units,
           CONCAT(tu.last_name, ', ', tu.first_name) AS teacher_name,
           prelim.grade AS prelim_grade,
           midterm.grade AS midterm_grade,
           prefinal.grade AS prefinal_grade,
           finals.grade AS final_period_grade
    FROM student_subject_loads loadrec
    JOIN enrollments e ON loadrec.enrollment_id = e.enrollment_id
    JOIN school_years sy ON e.school_year_id = sy.school_year_id
    JOIN semesters sem ON e.semester_id = sem.semester_id
    JOIN subject_offerings so ON loadrec.offering_id = so.offering_id
    JOIN subjects sub ON so.subject_id = sub.subject_id
    LEFT JOIN teachers t ON so.teacher_id = t.teacher_id
    LEFT JOIN users tu ON t.user_id = tu.user_id
    LEFT JOIN grades prelim ON prelim.student_subject_load_id = loadrec.load_id AND prelim.grading_period = 'prelim'
    LEFT JOIN grades midterm ON midterm.student_subject_load_id = loadrec.load_id AND midterm.grading_period = 'midterm'
    LEFT JOIN grades prefinal ON prefinal.student_subject_load_id = loadrec.load_id AND prefinal.grading_period = 'prefinal'
    LEFT JOIN grades finals ON finals.student_subject_load_id = loadrec.load_id AND finals.grading_period = 'final'
    WHERE e.student_id = ?
    ORDER BY sy.school_year_id DESC, sem.semester_id DESC, sub.subject_code ASC
", [$student_id]);

$billings = get_multiple_results("
    SELECT b.*, sy.year_name, sem.semester_name
    FROM billings b
    JOIN school_years sy ON b.school_year_id = sy.school_year_id
    JOIN semesters sem ON b.semester_id = sem.semester_id
    WHERE b.student_id = ?
    ORDER BY sy.school_year_id DESC, sem.semester_id DESC, b.billing_id DESC
", [$student_id]);

$billing_ids = array_map(static fn($billing) => (int)$billing['billing_id'], $billings);
$billing_details_by_id = [];
$payments_by_id = [];

if ($billing_ids) {
    $placeholders = implode(',', array_fill(0, count($billing_ids), '?'));
    $billing_details = get_multiple_results("
        SELECT bd.*, fs.fee_name, fs.fee_type
        FROM billing_details bd
        LEFT JOIN fee_schedules fs ON bd.fee_schedule_id = fs.fee_schedule_id
        WHERE bd.billing_id IN ($placeholders)
        ORDER BY bd.billing_id DESC, fs.fee_type ASC, fs.fee_name ASC
    ", $billing_ids);
    foreach ($billing_details as $detail) {
        $billing_details_by_id[(int)$detail['billing_id']][] = $detail;
    }

    $payments = get_multiple_results("
        SELECT p.*, r.receipt_number
        FROM payments p
        LEFT JOIN receipts r ON p.payment_id = r.payment_id
        WHERE p.billing_id IN ($placeholders)
        ORDER BY p.payment_date DESC, p.payment_id DESC
    ", $billing_ids);
    foreach ($payments as $payment) {
        $payments_by_id[(int)$payment['billing_id']][] = $payment;
    }
}

$latest_enrollment = $enrollments[0] ?? null;
$latest_billing = $billings[0] ?? null;
$phase_statuses = $latest_billing ? finance_get_billing_phase_status($latest_billing) : [];
$flash_messages = get_flash_messages();
$csrf_token = generate_csrf_token();

$user_statuses = ['pending', 'approved', 'rejected', 'inactive'];
$academic_statuses = ['regular', 'irregular', 'probation', 'suspended'];
$enrollment_statuses = ['enrolled', 'dropped', 'completed', 'withdrawn'];
$load_statuses = ['enrolled', 'dropped', 'completed', 'failed'];
$billing_statuses = ['pending', 'partially_paid', 'paid', 'overdue'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Record - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
    <style>
        .records-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 1rem; }
        .records-meta { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 1rem; }
        .records-meta .label { color: #64748b; font-size: .75rem; text-transform: uppercase; letter-spacing: .05em; }
        .records-meta .value { font-weight: 700; color: #0f172a; }
        .records-inline-form { display: contents; }
        .records-inline-form input,
        .records-inline-form select { min-width: 110px; }
        .records-actions { display: flex; gap: .5rem; align-items: center; flex-wrap: wrap; }
        .records-grade-form { display: inline-flex; gap: .35rem; align-items: center; }
        .records-grade-input { width: 86px; }
        @media (max-width: 900px) {
            .records-grid, .records-meta { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo"><a href="<?php echo APP_URL; ?>/modules/records/dashboard.php">Enchong Dee University Information System</a></div>
            <nav>
                <ul class="nav">
                    <li><a href="<?php echo APP_URL; ?>/modules/account/change_password.php">Change Password</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main class="main-content">
        <div class="content-wrapper">
            <div class="page-header">
                <h1>Student Record</h1>
                <p>Complete records for <?php echo htmlspecialchars(format_full_name($student['first_name'], $student['last_name'], $student['middle_name'] ?? '')); ?>.</p>
                <div style="display:flex; gap:.75rem; flex-wrap:wrap;">
                    <a class="btn btn-secondary" href="<?php echo APP_URL; ?>/modules/records/dashboard.php">Back to Student Records</a>
                    <a class="btn btn-primary" href="<?php echo APP_URL; ?>/modules/records/tor.php?student_id=<?php echo (int)$student_id; ?>">Print TOR</a>
                </div>
            </div>

            <?php if ($flash_messages): ?>
                <div class="flash-messages mb-3">
                    <?php foreach ($flash_messages as $message): ?>
                        <div class="alert alert-<?php echo htmlspecialchars($message['type']); ?>">
                            <?php echo htmlspecialchars($message['message']); ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <div class="card mb-4">
                <div class="card-header"><h4>Transcript of Records</h4></div>
                <div class="card-body">
                    <div class="records-meta">
                        <div><span class="label">Student Number</span><div class="value"><?php echo htmlspecialchars($student['student_number']); ?></div></div>
                        <div><span class="label">Course</span><div class="value"><?php echo htmlspecialchars(($student['course_code'] ?? '') . ' - ' . ($student['course_name'] ?? '')); ?></div></div>
                        <div><span class="label">Year Level</span><div class="value"><?php echo htmlspecialchars((string)$student['year_level']); ?></div></div>
                        <div><span class="label">Latest Term</span><div class="value"><?php echo htmlspecialchars($latest_enrollment ? ($latest_enrollment['year_name'] . ' / ' . $latest_enrollment['semester_name']) : 'No enrollment'); ?></div></div>
                    </div>
                    <div style="margin-top:1.5rem;">
                        <p class="text-muted">Use the official TOR view for preview, printing, and PDF export.</p>
                        <div style="display:flex; gap:.75rem; flex-wrap:wrap;">
                            <a class="btn btn-primary" href="<?php echo APP_URL; ?>/modules/records/tor.php?student_id=<?php echo (int)$student_id; ?>">Open TOR</a>
                            <a class="btn btn-secondary" href="<?php echo APP_URL; ?>/modules/records/dashboard.php">Back to Student Records</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
