<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';

require_role('records_officer');
$current_user = get_logged_in_user();

$search = trim((string)($_GET['search'] ?? ''));
$student_id_filter = (int)($_GET['student_id'] ?? 0);

$students = get_multiple_results("
    SELECT s.student_id, s.student_number, u.first_name, u.last_name
    FROM students s
    JOIN users u ON u.user_id = s.user_id
    ORDER BY u.last_name, u.first_name
");

$params = [];
$where = [];
if ($student_id_filter > 0) {
    $where[] = "b.student_id = ?";
    $params[] = $student_id_filter;
}
if ($search !== '') {
    $where[] = "(u.first_name LIKE ? OR u.last_name LIKE ? OR s.student_number LIKE ?)";
    $like = '%' . $search . '%';
    array_push($params, $like, $like, $like);
}
$where_sql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$payments = get_multiple_results("
    SELECT p.payment_date, p.amount,
           b.balance, b.status AS payment_status,
           s.student_number, u.first_name, u.last_name
    FROM payments p
    JOIN billings b ON b.billing_id = p.billing_id
    JOIN students s ON s.student_id = b.student_id
    JOIN users u ON u.user_id = s.user_id
    $where_sql
    ORDER BY p.payment_date DESC
", $params);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Record of Payment - Records</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
<header class="header">
    <div class="container">
        <div class="logo"><a href="<?php echo APP_URL; ?>/modules/records/dashboard.php">Enchong Dee University Information System</a></div>
        <nav>
            <ul class="nav">
                <li><a href="<?php echo APP_URL; ?>/modules/account/change_password.php">Change Password</a></li>
                <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
            </ul>
        </nav>
    </div>
</header>
<main class="main-content">
    <div class="content-wrapper">
        <div class="page-header">
            <h1>Record of Payment</h1>
            <p>View student payment date, amount paid, remaining balance, and payment status.</p>
        </div>

        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" class="form-row">
                    <div class="form-group">
                        <label class="form-label">Search</label>
                        <input class="form-control" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Name or student number">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Student</label>
                        <select class="form-control" name="student_id">
                            <option value="0">All Students</option>
                            <?php foreach ($students as $s): ?>
                                <option value="<?php echo (int)$s['student_id']; ?>" <?php echo $student_id_filter === (int)$s['student_id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($s['student_number'] . ' - ' . $s['last_name'] . ', ' . $s['first_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group" style="align-self:end;">
                        <button class="btn btn-primary" type="submit">Filter</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header"><h4>Payment Records</h4></div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>Student</th>
                                <th>Student ID</th>
                                <th>Payment Date</th>
                                <th>Amount Paid</th>
                                <th>Remaining Balance</th>
                                <th>Payment Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($payments as $row): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['last_name'] . ', ' . $row['first_name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['student_number']); ?></td>
                                    <td><?php echo htmlspecialchars(format_date($row['payment_date'])); ?></td>
                                    <td><?php echo htmlspecialchars(format_currency($row['amount'])); ?></td>
                                    <td><?php echo htmlspecialchars(format_currency($row['balance'])); ?></td>
                                    <td><?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', (string)$row['payment_status']))); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>
</body>
</html>
