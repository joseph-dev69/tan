<?php
/**
 * Records Officer Transcript of Records Preview
 */
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';

require_role('records_officer');

$current_user = get_logged_in_user();
$student_id = (int)($_GET['student_id'] ?? 0);

if ($student_id <= 0) {
    flash_message('error', 'Student record was not found.');
    redirect('modules/records/dashboard.php');
}

$student = get_single_result("
    SELECT
        s.student_id,
        s.student_number,
        s.year_level,
        s.academic_status,
        s.admission_date,
        s.expected_graduation_date,
        s.gpa AS stored_gpa,
        u.first_name,
        u.middle_name,
        u.last_name,
        u.email,
        c.course_code,
        c.course_name
    FROM students s
    JOIN users u ON s.user_id = u.user_id
    LEFT JOIN courses c ON s.course_id = c.course_id
    WHERE s.student_id = ?
", [$student_id]);

if (!$student) {
    flash_message('error', 'Student record was not found.');
    redirect('modules/records/dashboard.php');
}

$latest_enrollment = get_single_result("
    SELECT e.enrollment_id, e.status, e.total_units, sy.year_name, sem.semester_name
    FROM enrollments e
    JOIN school_years sy ON e.school_year_id = sy.school_year_id
    JOIN semesters sem ON e.semester_id = sem.semester_id
    WHERE e.student_id = ?
    ORDER BY sy.school_year_id DESC,
             FIELD(sem.semester_name, 'First Semester', 'Second Semester', 'Summer') DESC,
             e.enrollment_id DESC
    LIMIT 1
", [$student_id]);

$subject_loads = get_multiple_results("
    SELECT
        loadrec.load_id,
        loadrec.status,
        loadrec.final_grade,
        loadrec.remarks,
        sy.year_name,
        sem.semester_name,
        e.school_year_id,
        sub.subject_code,
        sub.subject_name,
        sub.units,
        so.section,
        prelim.grade AS prelim_grade,
        midterm.grade AS midterm_grade,
        finals.grade AS final_period_grade
    FROM student_subject_loads loadrec
    JOIN enrollments e ON loadrec.enrollment_id = e.enrollment_id
    JOIN school_years sy ON e.school_year_id = sy.school_year_id
    JOIN semesters sem ON e.semester_id = sem.semester_id
    JOIN subject_offerings so ON loadrec.offering_id = so.offering_id
    JOIN subjects sub ON so.subject_id = sub.subject_id
    LEFT JOIN grades prelim ON prelim.student_subject_load_id = loadrec.load_id AND prelim.grading_period = 'prelim'
    LEFT JOIN grades midterm ON midterm.student_subject_load_id = loadrec.load_id AND midterm.grading_period = 'midterm'
    LEFT JOIN grades finals ON finals.student_subject_load_id = loadrec.load_id AND finals.grading_period = 'final'
    WHERE e.student_id = ?
    ORDER BY sy.school_year_id ASC,
             FIELD(sem.semester_name, 'First Semester', 'Second Semester', 'Summer'),
             sub.subject_code ASC
", [$student_id]);

function tor_year_level_label($year_level)
{
    $year_level = (int)$year_level;
    $labels = [1 => 'First Year', 2 => 'Second Year', 3 => 'Third Year', 4 => 'Fourth Year'];
    return $labels[$year_level] ?? ($year_level > 0 ? ($year_level . ' Year') : 'Not assigned');
}

function tor_grade_value($value)
{
    return $value === null || $value === '' ? null : round((float)$value, 2);
}

function tor_display_grade($value)
{
    $numeric = tor_grade_value($value);
    if ($numeric === null) {
        return '--';
    }

    if (abs($numeric - round($numeric)) < 0.01) {
        return (string)(int)round($numeric);
    }

    return number_format($numeric, 2);
}

function tor_effective_final_grade(array $load)
{
    foreach (['final_grade', 'final_period_grade'] as $field) {
        $grade = tor_grade_value($load[$field] ?? null);
        if ($grade !== null) {
            return $grade;
        }
    }

    $components = [];
    foreach (['prelim_grade', 'midterm_grade', ] as $field) {
        $grade = tor_grade_value($load[$field] ?? null);
        if ($grade !== null) {
            $components[] = $grade;
        }
    }

    if (!$components) {
        return null;
    }

    return round(array_sum($components) / count($components), 2);
}

function tor_grade_status(array $load, $effective_final_grade)
{
    $load_status = strtolower(trim((string)($load['status'] ?? '')));
    if ($load_status === 'dropped') {
        return 'Dropped';
    }
    if ($load_status === 'failed') {
        return 'Failed';
    }
    if ($effective_final_grade === null) {
        return 'In Progress';
    }
    return $effective_final_grade >= 75 ? 'Passed' : 'Failed';
}

function tor_status_class($status)
{
    $status = strtolower(trim((string)$status));
    if (in_array($status, ['passed', 'completed'], true)) {
        return 'success';
    }
    if (in_array($status, ['failed', 'dropped'], true)) {
        return 'danger';
    }
    return 'warning';
}

$terms = [];
$overall_units_attempted = 0.0;
$overall_units_earned = 0.0;
$overall_quality_points = 0.0;
$overall_subject_count = 0;

foreach ($subject_loads as $load) {
    $term_key = $load['year_name'] . '|' . $load['semester_name'];
    if (!isset($terms[$term_key])) {
        $terms[$term_key] = [
            'year_name' => $load['year_name'],
            'semester_name' => $load['semester_name'],
            'rows' => [],
            'units_attempted' => 0.0,
            'units_earned' => 0.0,
            'quality_points' => 0.0,
            'graded_subjects' => 0,
            'term_gpa' => null,
        ];
    }

    $effective_final_grade = tor_effective_final_grade($load);
    $status_label = tor_grade_status($load, $effective_final_grade);
    $units = (float)($load['units'] ?? 0);

    $load['effective_final_grade'] = $effective_final_grade;
    $load['tor_status'] = $status_label;
    $terms[$term_key]['rows'][] = $load;
    $terms[$term_key]['units_attempted'] += $units;
    $overall_units_attempted += $units;
    $overall_subject_count++;

    if ($effective_final_grade !== null) {
        $terms[$term_key]['quality_points'] += $effective_final_grade * $units;
        $terms[$term_key]['graded_subjects']++;
        $overall_quality_points += $effective_final_grade * $units;

        if ($status_label === 'Passed') {
            $terms[$term_key]['units_earned'] += $units;
            $overall_units_earned += $units;
        }
    }
}

foreach ($terms as &$term) {
    if ($term['graded_subjects'] > 0 && $term['units_attempted'] > 0) {
        $term['term_gpa'] = round($term['quality_points'] / $term['units_attempted'], 2);
    }
}
unset($term);

$cumulative_gpa = ($overall_quality_points > 0 && $overall_units_attempted > 0)
    ? round($overall_quality_points / $overall_units_attempted, 2)
    : tor_grade_value($student['stored_gpa'] ?? null);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transcript of Records - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
    <style>
        .tor-shell {
            max-width: 1280px;
            margin: 0 auto;
        }
        .tor-toolbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
        }
        .tor-toolbar-actions {
            display: flex;
            gap: .75rem;
            flex-wrap: wrap;
        }
        .tor-document {
            background: rgba(255,255,255,0.96);
            border: 1px solid rgba(216,226,240,0.9);
            border-radius: 18px;
            box-shadow: var(--shadow);
            overflow: hidden;
        }
        .tor-banner {
            background: var(--gradient-soft);
            border-bottom: 1px solid var(--border-color);
            padding: 2rem;
        }
        .tor-banner-top {
            display: flex;
            justify-content: space-between;
            gap: 1rem;
            align-items: flex-start;
            flex-wrap: wrap;
        }
        .tor-banner h1 {
            margin-bottom: .35rem;
        }
        .tor-subtitle {
            color: var(--gray-color);
            margin-bottom: 0;
        }
        .tor-generated {
            text-align: right;
            color: var(--gray-color);
            font-size: .92rem;
        }
        .tor-meta-grid,
        .tor-summary-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 1rem;
        }
        .tor-meta-grid {
            padding: 1.5rem 2rem 0;
        }
        .tor-summary-grid {
            padding: 0 2rem 2rem;
        }
        .tor-meta-card,
        .tor-summary-card {
            background: rgba(255,255,255,0.88);
            border: 1px solid rgba(216,226,240,0.9);
            border-radius: 16px;
            padding: 1rem 1.1rem;
            box-shadow: 0 10px 28px rgba(15, 23, 42, 0.05);
        }
        .tor-meta-label,
        .tor-summary-label {
            display: block;
            text-transform: uppercase;
            letter-spacing: .06em;
            font-size: .75rem;
            color: var(--gray-color);
            margin-bottom: .45rem;
        }
        .tor-meta-value,
        .tor-summary-value {
            font-size: 1rem;
            font-weight: 700;
            color: var(--primary-color);
            line-height: 1.4;
        }
        .tor-summary-value.large {
            font-size: 1.5rem;
        }
        .tor-body {
            padding: 0 2rem 2rem;
        }
        .tor-term {
            margin-bottom: 1.75rem;
        }
        .tor-term-header {
            display: flex;
            justify-content: space-between;
            align-items: end;
            gap: 1rem;
            padding: 1rem 1.25rem;
            background: var(--gradient-soft);
            border: 1px solid rgba(216,226,240,0.9);
            border-radius: 16px 16px 0 0;
        }
        .tor-term-header h3 {
            margin-bottom: .25rem;
            font-size: 1.35rem;
        }
        .tor-term-meta {
            color: var(--gray-color);
            font-size: .92rem;
        }
        .tor-term-table {
            border: 1px solid rgba(216,226,240,0.9);
            border-top: none;
            border-radius: 0 0 16px 16px;
            overflow: hidden;
            background: #fff;
        }
        .tor-term-table table {
            width: 100%;
            border-collapse: collapse;
        }
        .tor-term-table th {
            background: rgba(236, 246, 253, 0.95);
            color: var(--primary-color);
            font-size: .78rem;
            text-transform: uppercase;
            letter-spacing: .04em;
            padding: .95rem .85rem;
            border-bottom: 1px solid var(--border-color);
            text-align: left;
        }
        .tor-term-table td {
            padding: .95rem .85rem;
            border-bottom: 1px solid rgba(216,226,240,0.8);
            vertical-align: top;
        }
        .tor-term-table tbody tr:last-child td {
            border-bottom: none;
        }
        .tor-term-table tbody tr:hover {
            background: rgba(14,165,233,0.04);
        }
        .tor-grade {
            font-weight: 700;
            color: var(--primary-color);
        }
        .tor-grade.muted {
            color: var(--gray-color);
            font-weight: 600;
        }
        .tor-term-footer {
            display: flex;
            justify-content: space-between;
            gap: 1rem;
            flex-wrap: wrap;
            padding: 1rem 1.25rem;
            background: rgba(248, 251, 255, 0.9);
            border-top: 1px solid rgba(216,226,240,0.8);
        }
        .tor-term-footer strong {
            color: var(--primary-color);
        }
        .tor-empty {
            padding: 2rem;
            text-align: center;
            color: var(--gray-color);
        }
        .tor-signatures {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 2rem;
            padding-top: 1rem;
        }
        .tor-signature-line {
            border-top: 1px solid rgba(15,23,42,0.35);
            padding-top: .65rem;
            text-align: center;
            color: var(--gray-color);
        }
        .tor-print-note {
            margin-top: 1rem;
            color: var(--gray-color);
            font-size: .9rem;
        }
        @media (max-width: 960px) {
            .tor-meta-grid,
            .tor-summary-grid,
            .tor-signatures {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }
        @media (max-width: 640px) {
            .tor-meta-grid,
            .tor-summary-grid,
            .tor-signatures {
                grid-template-columns: 1fr;
            }
            .tor-banner,
            .tor-meta-grid,
            .tor-summary-grid,
            .tor-body {
                padding-left: 1.25rem;
                padding-right: 1.25rem;
            }
        }
        @media print {
            body {
                background: #fff;
            }
            .header,
            .tor-toolbar,
            .tor-print-note {
                display: none !important;
            }
            .main-content {
                margin-left: 0;
                padding: 0;
            }
            .content-wrapper,
            .tor-document {
                box-shadow: none;
                border: none;
                background: #fff;
            }
            .tor-term-table tbody tr:hover {
                background: transparent;
            }
            .badge {
                border: 1px solid rgba(15,23,42,0.18);
                color: #000 !important;
                background: #fff !important;
            }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo"><a href="<?php echo APP_URL; ?>/modules/records/dashboard.php">Enchong Dee University Information System</a></div>
            <nav>
                <ul class="nav">
                    <li><a href="<?php echo APP_URL; ?>/modules/account/change_password.php">Change Password</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main class="main-content">
        <div class="content-wrapper tor-shell">
            <div class="tor-toolbar">
                <div class="page-header" style="margin-bottom:0;">
                    <h1>Transcript of Records</h1>
                    <p>Official transcript preview for <?php echo htmlspecialchars(format_full_name($student['first_name'], $student['last_name'], $student['middle_name'] ?? '')); ?>.</p>
                </div>
                <div class="tor-toolbar-actions">
                    <a class="btn btn-secondary" href="<?php echo APP_URL; ?>/modules/records/dashboard.php">Back to Records</a>
                    <button type="button" class="btn btn-primary" onclick="window.print()">Print TOR</button>
                    <button type="button" class="btn btn-success" onclick="window.print()">Save as PDF</button>
                </div>
            </div>

            <div class="tor-document">
                <div class="tor-banner">
                    <div class="tor-banner-top">
                        <div>
                            <p class="tor-subtitle" style="text-transform:uppercase; letter-spacing:.08em;">School Information System</p>
                            <h1>Official Transcript of Records</h1>
                            <p class="tor-subtitle">Academic record preview prepared for records processing and printing.</p>
                        </div>
                        <div class="tor-generated">
                            <div><strong>Date Generated:</strong> <?php echo htmlspecialchars(date('F d, Y')); ?></div>
                            <div><strong>Prepared By:</strong> <?php echo htmlspecialchars(format_full_name($current_user['first_name'], $current_user['last_name'], $current_user['middle_name'] ?? '')); ?></div>
                        </div>
                    </div>
                </div>

                <div class="tor-meta-grid">
                    <div class="tor-meta-card">
                        <span class="tor-meta-label">Student Name</span>
                        <div class="tor-meta-value"><?php echo htmlspecialchars(format_full_name($student['first_name'], $student['last_name'], $student['middle_name'] ?? '')); ?></div>
                    </div>
                    <div class="tor-meta-card">
                        <span class="tor-meta-label">Student Number</span>
                        <div class="tor-meta-value"><?php echo htmlspecialchars($student['student_number']); ?></div>
                    </div>
                    <div class="tor-meta-card">
                        <span class="tor-meta-label">Course / Program</span>
                        <div class="tor-meta-value"><?php echo htmlspecialchars(trim(($student['course_code'] ?? '') . ' - ' . ($student['course_name'] ?? ''), ' -')); ?></div>
                    </div>
                    <div class="tor-meta-card">
                        <span class="tor-meta-label">Current Year Level</span>
                        <div class="tor-meta-value"><?php echo htmlspecialchars(tor_year_level_label($student['year_level'])); ?></div>
                    </div>
                    <div class="tor-meta-card">
                        <span class="tor-meta-label">Academic Status</span>
                        <div class="tor-meta-value"><?php echo htmlspecialchars(ucfirst((string)($student['academic_status'] ?? 'Regular'))); ?></div>
                    </div>
                    <div class="tor-meta-card">
                        <span class="tor-meta-label">Latest Term</span>
                        <div class="tor-meta-value"><?php echo htmlspecialchars($latest_enrollment ? ($latest_enrollment['year_name'] . ' / ' . $latest_enrollment['semester_name']) : 'No enrollment'); ?></div>
                    </div>
                    <div class="tor-meta-card">
                        <span class="tor-meta-label">Admission Date</span>
                        <div class="tor-meta-value"><?php echo htmlspecialchars(!empty($student['admission_date']) ? format_date($student['admission_date']) : 'Not set'); ?></div>
                    </div>
                    <div class="tor-meta-card">
                        <span class="tor-meta-label">Expected Graduation</span>
                        <div class="tor-meta-value"><?php echo htmlspecialchars(!empty($student['expected_graduation_date']) ? format_date($student['expected_graduation_date']) : 'Not set'); ?></div>
                    </div>
                </div>

                <div class="tor-summary-grid">
                    <div class="tor-summary-card">
                        <span class="tor-summary-label">Subjects Listed</span>
                        <div class="tor-summary-value large"><?php echo (int)$overall_subject_count; ?></div>
                    </div>
                    <div class="tor-summary-card">
                        <span class="tor-summary-label">Units Attempted</span>
                        <div class="tor-summary-value large"><?php echo number_format($overall_units_attempted, 1); ?></div>
                    </div>
                    <div class="tor-summary-card">
                        <span class="tor-summary-label">Units Earned</span>
                        <div class="tor-summary-value large"><?php echo number_format($overall_units_earned, 1); ?></div>
                    </div>
                    <div class="tor-summary-card">
                        <span class="tor-summary-label">Cumulative GPA</span>
                        <div class="tor-summary-value large"><?php echo $cumulative_gpa !== null ? number_format($cumulative_gpa, 2) : '--'; ?></div>
                    </div>
                </div>

                <div class="tor-body">
                    <?php if ($terms): ?>
                        <?php foreach ($terms as $term): ?>
                            <section class="tor-term">
                                <div class="tor-term-header">
                                    <div>
                                        <h3><?php echo htmlspecialchars($term['year_name']); ?></h3>
                                        <div class="tor-term-meta"><?php echo htmlspecialchars($term['semester_name']); ?></div>
                                    </div>
                                    <div class="tor-term-meta">
                                        <?php echo (int)count($term['rows']); ?> subject(s) listed
                                    </div>
                                </div>
                                <div class="tor-term-table">
                                    <table>
                                        <thead>
                                            <tr>
                                                <th style="width:10%;">Code</th>
                                                <th style="width:28%;">Description</th>
                                                <th style="width:8%;">Units</th>
                                                <th style="width:8%;">Prelim</th>
                                                <th style="width:8%;">Midterm</th>
                                                <th style="width:8%;">Final</th>
                                                <th style="width:8%;">Grade</th>
                                                <th style="width:14%;">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($term['rows'] as $row): ?>
                                                <tr>
                                                    <td><strong><?php echo htmlspecialchars($row['subject_code']); ?></strong></td>
                                                    <td>
                                                        <?php echo htmlspecialchars($row['subject_name']); ?><br>
                                                        <small class="text-muted">Section <?php echo htmlspecialchars($row['section'] ?: 'N/A'); ?></small>
                                                    </td>
                                                    <td><?php echo number_format((float)$row['units'], 1); ?></td>
                                                    <td class="tor-grade <?php echo tor_grade_value($row['prelim_grade']) === null ? 'muted' : ''; ?>"><?php echo htmlspecialchars(tor_display_grade($row['prelim_grade'])); ?></td>
                                                    <td class="tor-grade <?php echo tor_grade_value($row['midterm_grade']) === null ? 'muted' : ''; ?>"><?php echo htmlspecialchars(tor_display_grade($row['midterm_grade'])); ?></td>
                                                    <td class="tor-grade <?php echo tor_grade_value($row['final_period_grade']) === null ? 'muted' : ''; ?>"><?php echo htmlspecialchars(tor_display_grade($row['final_period_grade'])); ?></td>
                                                    <td class="tor-grade <?php echo $row['effective_final_grade'] === null ? 'muted' : ''; ?>"><?php echo htmlspecialchars(tor_display_grade($row['effective_final_grade'])); ?></td>
                                                    <td>
                                                        <span class="badge badge-<?php echo tor_status_class($row['tor_status']); ?>">
                                                            <?php echo htmlspecialchars($row['tor_status']); ?>
                                                        </span>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                    <div class="tor-term-footer">
                                        <div><strong>Units Attempted:</strong> <?php echo number_format($term['units_attempted'], 1); ?></div>
                                        <div><strong>Units Earned:</strong> <?php echo number_format($term['units_earned'], 1); ?></div>
                                        <div><strong>Term GPA:</strong> <?php echo $term['term_gpa'] !== null ? number_format($term['term_gpa'], 2) : '--'; ?></div>
                                    </div>
                                </div>
                            </section>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="tor-empty">
                            No academic subject records are available for this student yet.
                        </div>
                    <?php endif; ?>

                    <div class="tor-signatures">
                        <div class="tor-signature-line">
                            Records Officer Signature<br>
                            <strong><?php echo htmlspecialchars(format_full_name($current_user['first_name'], $current_user['last_name'], $current_user['middle_name'] ?? '')); ?></strong>
                        </div>
                        <div class="tor-signature-line">
                            Registrar / Authorized Signatory<br>
                            <strong>School Information System</strong>
                        </div>
                    </div>

                    <p class="tor-print-note">
                        Use the <strong>Print TOR</strong> or <strong>Save as PDF</strong> button above. In the browser print dialog, choose your printer or select <strong>Save as PDF</strong> for an export-ready transcript copy.
                    </p>
                </div>
            </div>
        </div>
    </main>

    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
