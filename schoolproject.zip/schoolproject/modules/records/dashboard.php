<?php
/**
 * Records Officer Student Records Dashboard
 */
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';

require_role('records_officer');

$current_user = get_logged_in_user();
$search = trim($_GET['search'] ?? '');
$course_filter = (int)($_GET['course_id'] ?? 0);
$year_level_filter = (int)($_GET['year_level'] ?? 0);
$school_year_filter = (int)($_GET['school_year_id'] ?? 0);
$semester_filter = (int)($_GET['semester_id'] ?? 0);
$semester_name_filter = '';

if ($semester_filter > 0) {
    $semester_row = get_single_result("SELECT semester_name FROM semesters WHERE semester_id = ?", [$semester_filter]);
    $semester_name_filter = trim((string)($semester_row['semester_name'] ?? ''));
}

$courses = get_multiple_results("SELECT course_id, course_code, course_name FROM courses ORDER BY course_code ASC");
$school_years = get_multiple_results("SELECT school_year_id, year_name FROM school_years ORDER BY school_year_id DESC");
$semesters = get_multiple_results("
    SELECT MIN(semester_id) AS semester_id, semester_name
    FROM semesters
    GROUP BY semester_name
    ORDER BY FIELD(semester_name, 'First Semester', 'Second Semester', 'Summer'), semester_name
");

$conditions = [];
$params = [];

if ($search !== '') {
    $conditions[] = "(s.student_number LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ? OR u.email LIKE ?)";
    $like = '%' . $search . '%';
    array_push($params, $like, $like, $like, $like);
}

if ($course_filter > 0) {
    $conditions[] = "s.course_id = ?";
    $params[] = $course_filter;
}

if ($year_level_filter > 0) {
    $conditions[] = "s.year_level = ?";
    $params[] = $year_level_filter;
}

if ($school_year_filter > 0) {
    $conditions[] = "EXISTS (
        SELECT 1 FROM enrollments e_filter
        WHERE e_filter.student_id = s.student_id
          AND e_filter.school_year_id = ?
    )";
    $params[] = $school_year_filter;
}

if ($semester_name_filter !== '') {
    $conditions[] = "EXISTS (
        SELECT 1
        FROM enrollments e_filter
        JOIN semesters sem_filter ON sem_filter.semester_id = e_filter.semester_id
        WHERE e_filter.student_id = s.student_id
          AND sem_filter.semester_name = ?
    )";
    $params[] = $semester_name_filter;
}

$where_sql = $conditions ? 'WHERE ' . implode(' AND ', $conditions) : '';

$students = get_multiple_results("
    SELECT
        s.student_id,
        s.student_number,
        s.year_level,
        s.academic_status,
        u.first_name,
        u.last_name,
        u.middle_name,
        u.email,
        u.status AS user_status,
        c.course_code,
        c.course_name,
        le.enrollment_id,
        le.status AS enrollment_status,
        le.total_units,
        sy.year_name,
        sem.semester_name,
        COALESCE(subject_summary.subject_count, 0) AS subject_count,
        lb.billing_id,
        lb.total_amount,
        lb.paid_amount,
        lb.balance,
        lb.status AS billing_status
    FROM students s
    JOIN users u ON s.user_id = u.user_id
    LEFT JOIN courses c ON s.course_id = c.course_id
    LEFT JOIN (
        SELECT e1.*
        FROM enrollments e1
        JOIN (
            SELECT student_id, MAX(enrollment_id) AS enrollment_id
            FROM enrollments
            GROUP BY student_id
        ) latest ON latest.enrollment_id = e1.enrollment_id
    ) le ON le.student_id = s.student_id
    LEFT JOIN school_years sy ON le.school_year_id = sy.school_year_id
    LEFT JOIN semesters sem ON le.semester_id = sem.semester_id
    LEFT JOIN (
        SELECT e.student_id, COUNT(loadrec.load_id) AS subject_count
        FROM enrollments e
        JOIN student_subject_loads loadrec ON loadrec.enrollment_id = e.enrollment_id
        WHERE loadrec.status = 'enrolled'
        GROUP BY e.student_id
    ) subject_summary ON subject_summary.student_id = s.student_id
    LEFT JOIN (
        SELECT b1.*
        FROM billings b1
        JOIN (
            SELECT student_id, MAX(billing_id) AS billing_id
            FROM billings
            GROUP BY student_id
        ) latest_billing ON latest_billing.billing_id = b1.billing_id
    ) lb ON lb.student_id = s.student_id
    $where_sql
    ORDER BY u.last_name ASC, u.first_name ASC, s.student_number ASC
", $params);

$flash_messages = get_flash_messages();
$has_active_filters = $search !== ''
    || $course_filter > 0
    || $year_level_filter > 0
    || $school_year_filter > 0
    || $semester_filter > 0;

function records_year_level_label($year_level)
{
    $year_level = (int)$year_level;
    if ($year_level <= 0) {
        return 'Not assigned';
    }

    $labels = [1 => 'First Year', 2 => 'Second Year', 3 => 'Third Year', 4 => 'Fourth Year'];
    return $labels[$year_level] ?? ($year_level . ' Year');
}

function records_payment_label($status)
{
    $normalized = strtolower(trim((string)$status));
    if ($normalized === 'paid') {
        return ['Paid', 'success'];
    }
    if ($normalized === 'partially_paid') {
        return ['Partial', 'warning'];
    }
    if ($normalized === 'overdue') {
        return ['Overdue', 'danger'];
    }
    if ($normalized === 'pending') {
        return ['Unpaid', 'danger'];
    }
    return ['No Billing', 'secondary'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Records - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo"><a href="<?php echo APP_URL; ?>/modules/records/dashboard.php">School Information System</a></div>
            <nav>
                <ul class="nav">
                    <li><a href="<?php echo APP_URL; ?>/modules/account/change_password.php">Change Password</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main class="main-content">
        <div class="content-wrapper">
            <div class="page-header">
                <h1>Student Records</h1>
                <p>Search, filter, and review complete student records.</p>
            </div>

            <div class="card mb-4">
                <div class="card-body">
                    <div class="action-buttons">
                        <a class="btn btn-primary" href="<?php echo APP_URL; ?>/modules/records/student_list.php">Student List</a>
                        <a class="btn btn-secondary" href="<?php echo APP_URL; ?>/modules/records/payment_records.php">Record of Payment</a>
                    </div>
                </div>
            </div>

            <?php if ($flash_messages): ?>
                <div class="flash-messages mb-3">
                    <?php foreach ($flash_messages as $message): ?>
                        <div class="alert alert-<?php echo htmlspecialchars($message['type']); ?>">
                            <?php echo htmlspecialchars($message['message']); ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <div class="card mb-4">
                <div class="card-header"><h4>Filter Student Records</h4></div>
                <div class="card-body">
                    <form method="GET" class="form-row">
                        <div class="form-group">
                            <label class="form-label" for="search">Search</label>
                            <input type="text" class="form-control" id="search" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Student no., name, or email">
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="course_id">Course</label>
                            <select class="form-control" id="course_id" name="course_id">
                                <option value="0">All Courses</option>
                                <?php foreach ($courses as $course): ?>
                                    <option value="<?php echo (int)$course['course_id']; ?>" <?php echo (int)$course['course_id'] === $course_filter ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($course['course_code'] . ' - ' . $course['course_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="year_level">Year Level</label>
                            <select class="form-control" id="year_level" name="year_level">
                                <option value="0">All Year Levels</option>
                                <?php for ($i = 1; $i <= 4; $i++): ?>
                                    <option value="<?php echo $i; ?>" <?php echo $year_level_filter === $i ? 'selected' : ''; ?>><?php echo htmlspecialchars(records_year_level_label($i)); ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="school_year_id">School Year</label>
                            <select class="form-control" id="school_year_id" name="school_year_id">
                                <option value="0">All School Years</option>
                                <?php foreach ($school_years as $school_year): ?>
                                    <option value="<?php echo (int)$school_year['school_year_id']; ?>" <?php echo (int)$school_year['school_year_id'] === $school_year_filter ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($school_year['year_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="semester_id">Semester</label>
                            <select class="form-control" id="semester_id" name="semester_id">
                                <option value="0">All Semesters</option>
                                <?php foreach ($semesters as $semester): ?>
                                    <option value="<?php echo (int)$semester['semester_id']; ?>" <?php echo (int)$semester['semester_id'] === $semester_filter ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($semester['semester_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group" style="align-self: end;">
                            <button class="btn btn-primary" type="submit">Apply Filter</button>
                            <a class="btn btn-secondary" href="<?php echo APP_URL; ?>/modules/records/dashboard.php">Reset</a>
                        </div>
                    </form>
                </div>
            </div>

            <?php if ($has_active_filters): ?>
                <div class="card">
                    <div class="card-header"><h4>Transcript Results</h4></div>
                    <div class="card-body">
                        <?php if ($students): ?>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Student No.</th>
                                            <th>Full Name</th>
                                            <th>Course</th>
                                            <th>Year Level</th>
                                            <th>Latest Term</th>
                                            <th>Print TOR</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($students as $student): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($student['student_number']); ?></td>
                                                <td>
                                                    <?php echo htmlspecialchars(format_full_name($student['first_name'], $student['last_name'], $student['middle_name'] ?? '')); ?><br>
                                                    <small class="text-muted"><?php echo htmlspecialchars($student['email']); ?></small>
                                                </td>
                                                <td>
                                                    <?php echo htmlspecialchars($student['course_code'] ?: 'Not assigned'); ?><br>
                                                    <small class="text-muted"><?php echo htmlspecialchars($student['course_name'] ?: ''); ?></small>
                                                </td>
                                                <td><?php echo htmlspecialchars(records_year_level_label($student['year_level'])); ?></td>
                                                <td><?php echo htmlspecialchars(trim(($student['year_name'] ?? '') . ' / ' . ($student['semester_name'] ?? ''), ' /') ?: 'No enrollment'); ?></td>
                                                <td>
                                                    <a class="btn btn-secondary btn-sm" href="<?php echo APP_URL; ?>/modules/records/tor.php?student_id=<?php echo (int)$student['student_id']; ?>">Print TOR</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">No transcript-ready student records matched your filters.</p>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </main>

    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
