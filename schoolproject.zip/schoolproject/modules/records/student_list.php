<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';

require_role('records_officer');
$current_user = get_logged_in_user();

$search = trim((string)($_GET['search'] ?? ''));
$course_filter = (int)($_GET['course_id'] ?? 0);
$year_level_filter = (int)($_GET['year_level'] ?? 0);
$selected_student_id = (int)($_GET['student_id'] ?? 0);

$courses = get_multiple_results("SELECT course_id, course_code, course_name FROM courses ORDER BY course_code ASC");

$conditions = [];
$params = [];
if ($search !== '') {
    $conditions[] = "(u.first_name LIKE ? OR u.last_name LIKE ? OR s.student_number LIKE ?)";
    $like = '%' . $search . '%';
    array_push($params, $like, $like, $like);
}
if ($course_filter > 0) {
    $conditions[] = "s.course_id = ?";
    $params[] = $course_filter;
}
if ($year_level_filter > 0) {
    $conditions[] = "s.year_level = ?";
    $params[] = $year_level_filter;
}
$where_sql = $conditions ? 'WHERE ' . implode(' AND ', $conditions) : '';

$students = get_multiple_results("
    SELECT s.student_id, s.student_number, s.year_level,
           u.first_name, u.last_name,
           c.course_code, c.course_name
    FROM students s
    JOIN users u ON u.user_id = s.user_id
    LEFT JOIN courses c ON c.course_id = s.course_id
    $where_sql
    " . ($where_sql ? " AND " : " WHERE ") . "EXISTS (
        SELECT 1
        FROM enrollments e
        WHERE e.student_id = s.student_id
          AND e.status = 'enrolled'
    )
    ORDER BY u.last_name, u.first_name
", $params);

$student_subjects = [];
if ($selected_student_id > 0) {
    $student_subjects = get_multiple_results("
        SELECT sub.subject_code, sub.subject_name, sub.units,
               grade_summary.average_grade,
               COALESCE(
                   NULLIF(loadrec.remarks, ''),
                   CASE
                       WHEN grade_summary.grade_count IS NULL OR grade_summary.grade_count = 0 THEN 'No grade yet'
                       WHEN grade_summary.average_grade >= 75 THEN 'Passed'
                       ELSE 'Failed'
                   END
               ) AS remarks
        FROM enrollments e
        JOIN student_subject_loads loadrec ON loadrec.enrollment_id = e.enrollment_id
        JOIN subject_offerings so ON so.offering_id = loadrec.offering_id
        JOIN subjects sub ON sub.subject_id = so.subject_id
        LEFT JOIN (
            SELECT student_subject_load_id,
                   ROUND(AVG(grade), 2) AS average_grade,
                   COUNT(*) AS grade_count
            FROM grades
            GROUP BY student_subject_load_id
        ) grade_summary ON grade_summary.student_subject_load_id = loadrec.load_id
        WHERE e.student_id = ?
        ORDER BY sub.subject_code ASC
    ", [$selected_student_id]);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student List - Records</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
<header class="header">
    <div class="container">
        <div class="logo"><a href="<?php echo APP_URL; ?>/modules/records/dashboard.php">School Information System</a></div>
        <nav>
            <ul class="nav">
                <li><a href="<?php echo APP_URL; ?>/modules/account/change_password.php">Change Password</a></li>
                <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
            </ul>
        </nav>
    </div>
</header>
<main class="main-content">
    <div class="content-wrapper">
        <div class="page-header">
            <h1>Student List</h1>
            <p>Display all enrolled students and review subjects, grades, and remarks.</p>
        </div>

        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" class="form-row">
                    <div class="form-group">
                        <label class="form-label">Search</label>
                        <input class="form-control" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Name or student number">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Course</label>
                        <select class="form-control" name="course_id">
                            <option value="0">All Courses</option>
                            <?php foreach ($courses as $course): ?>
                                <option value="<?php echo (int)$course['course_id']; ?>" <?php echo $course_filter === (int)$course['course_id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($course['course_code'] . ' - ' . $course['course_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Year Level</label>
                        <select class="form-control" name="year_level">
                            <option value="0">All</option>
                            <?php for ($i = 1; $i <= 4; $i++): ?>
                                <option value="<?php echo $i; ?>" <?php echo $year_level_filter === $i ? 'selected' : ''; ?>><?php echo $i; ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="form-group" style="align-self:end;">
                        <button class="btn btn-primary" type="submit">Filter</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-header"><h4>Enrolled Students</h4></div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>Student Name</th>
                                <th>Student ID</th>
                                <th>Year Level</th>
                                <th>Course</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($students as $student): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($student['last_name'] . ', ' . $student['first_name']); ?></td>
                                    <td><?php echo htmlspecialchars($student['student_number']); ?></td>
                                    <td><?php echo htmlspecialchars((string)$student['year_level']); ?></td>
                                    <td><?php echo htmlspecialchars($student['course_code'] . ' - ' . $student['course_name']); ?></td>
                                    <td><a class="btn btn-sm btn-info" href="<?php echo APP_URL; ?>/modules/records/student_list.php?<?php echo http_build_query(['search' => $search, 'course_id' => $course_filter, 'year_level' => $year_level_filter, 'student_id' => (int)$student['student_id']]); ?>">View Subjects</a></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <?php if ($selected_student_id > 0): ?>
            <div class="card">
                <div class="card-header"><h4>Subjects, Grades, and Remarks</h4></div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Subject</th>
                                    <th>Description</th>
                                    <th>Units</th>
                                    <th>Grade</th>
                                    <th>Remarks</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($student_subjects as $row): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['subject_code']); ?></td>
                                        <td><?php echo htmlspecialchars($row['subject_name']); ?></td>
                                        <td><?php echo htmlspecialchars((string)$row['units']); ?></td>
                                        <td><?php echo $row['average_grade'] !== null ? htmlspecialchars(number_format((float)$row['average_grade'], 2)) : '--'; ?></td>
                                        <td><?php echo htmlspecialchars($row['remarks']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</main>
</body>
</html>
