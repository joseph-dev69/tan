<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';

require_role('cashier');

$current_user = get_logged_in_user();
$cashier = get_single_result("SELECT * FROM cashiers WHERE user_id = ?", [$current_user['user_id']]);

if (!$cashier) {
    flash_message('error', 'Cashier profile not found. Please contact the administrator.');
    redirect('index.php');
}

$school_years = get_multiple_results("SELECT school_year_id, year_name FROM school_years ORDER BY school_year_id DESC");
$current_school_year = get_single_result("SELECT * FROM school_years WHERE is_current = TRUE");
$current_semester = get_single_result("SELECT * FROM semesters WHERE is_current = TRUE");

$selected_school_year_id = (int)($_GET['school_year_id'] ?? ($current_school_year['school_year_id'] ?? 0));
$selected_semester_id = (int)($_GET['semester_id'] ?? ($current_semester['semester_id'] ?? 0));
$semester_selection = resolve_fixed_semester_selection(
    $selected_school_year_id,
    $selected_semester_id,
    $current_semester['semester_name'] ?? ''
);
$semesters = $semester_selection['options'];
$selected_semester_id = $semester_selection['semester_id'];
$selected_semester_name = $semester_selection['semester_name'];
$student_query = trim($_GET['student_query'] ?? '');

$billing_filters = [];
$billing_params = [];

if ($selected_school_year_id > 0) {
    $billing_filters[] = 'b.school_year_id = ?';
    $billing_params[] = $selected_school_year_id;
}

if ($selected_semester_name !== '') {
    $billing_filters[] = "EXISTS (
        SELECT 1
        FROM semesters sem_filter
        WHERE sem_filter.semester_id = b.semester_id
          AND sem_filter.semester_name = ?
    )";
    $billing_params[] = $selected_semester_name;
}

if ($student_query !== '') {
    $billing_filters[] = "(s.student_number LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ?)";
    $like = '%' . $student_query . '%';
    $billing_params[] = $like;
    $billing_params[] = $like;
    $billing_params[] = $like;
}

$billing_where_sql = $billing_filters ? ('WHERE ' . implode(' AND ', $billing_filters)) : '';

$billings = get_multiple_results("
    SELECT b.billing_id, b.billing_date, b.due_date, b.total_amount, b.paid_amount, b.balance, b.status,
           sy.year_name, sem.semester_name, s.student_number, u.first_name, u.last_name, c.course_code
    FROM billings b
    JOIN school_years sy ON b.school_year_id = sy.school_year_id
    JOIN semesters sem ON b.semester_id = sem.semester_id
    JOIN students s ON b.student_id = s.student_id
    JOIN users u ON s.user_id = u.user_id
    JOIN courses c ON s.course_id = c.course_id
    $billing_where_sql
    ORDER BY b.due_date ASC, u.last_name ASC
", $billing_params);

error_log(sprintf(
    'Cashier student_payable filters => school_year_id=%d, semester_id=%d, semester_name=%s, student_query=%s, results=%d',
    $selected_school_year_id,
    $selected_semester_id,
    $selected_semester_name,
    $student_query,
    count($billings)
));

$pending_total = 0.00;
$collected_total = 0.00;
foreach ($billings as $billing) {
    $pending_total += (float)$billing['balance'];
    $collected_total += (float)$billing['paid_amount'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Payable - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo"><a href="<?php echo APP_URL; ?>/modules/cashier/dashboard.php">School Information System</a></div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <?php render_cashier_sidebar('student_payable'); ?>
        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Student Payable</h1>
                    <p>View student billing balances by school year and semester.</p>
                </div>

                <div class="row mb-4">
                    <div class="col-6">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-warning"><?php echo format_currency($pending_total); ?></h3>
                                <p>Outstanding Balance</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-success"><?php echo format_currency($collected_total); ?></h3>
                                <p>Total Paid</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header"><h4>Billing Records</h4></div>
                    <div class="card-body">
                        <form method="GET" action="" class="form-row mb-3">
                            <div class="form-group">
                                <label for="school_year_id" class="form-label">School Year</label>
                                <select id="school_year_id" name="school_year_id" class="form-control">
                                    <?php foreach ($school_years as $school_year): ?>
                                        <option value="<?php echo (int)$school_year['school_year_id']; ?>" <?php echo (int)$school_year['school_year_id'] === $selected_school_year_id ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($school_year['year_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="semester_id" class="form-label">Semester</label>
                                <select id="semester_id" name="semester_id" class="form-control">
                                    <?php foreach ($semesters as $semester): ?>
                                        <option value="<?php echo (int)$semester['semester_id']; ?>" <?php echo (int)$semester['semester_id'] === $selected_semester_id ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($semester['semester_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="student_query" class="form-label">Student Search</label>
                                <input type="text" id="student_query" name="student_query" class="form-control" value="<?php echo htmlspecialchars($student_query); ?>" placeholder="Student number or last name">
                            </div>
                            <div class="form-group" style="align-self:end;">
                                <button type="submit" class="btn btn-primary">Apply Filter</button>
                            </div>
                        </form>

                        <?php if ($billings): ?>
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Student</th>
                                            <th>Term</th>
                                            <th>Total</th>
                                            <th>Paid</th>
                                            <th>Balance</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($billings as $billing): ?>
                                            <tr>
                                                <td>
                                                    <?php echo htmlspecialchars($billing['last_name'] . ', ' . $billing['first_name']); ?><br>
                                                    <small class="text-muted"><?php echo htmlspecialchars($billing['student_number'] . ' / ' . $billing['course_code']); ?></small>
                                                </td>
                                                <td><?php echo htmlspecialchars($billing['year_name'] . ' / ' . $billing['semester_name']); ?></td>
                                                <td><?php echo format_currency($billing['total_amount']); ?></td>
                                                <td><?php echo format_currency($billing['paid_amount']); ?></td>
                                                <td><?php echo format_currency($billing['balance']); ?></td>
                                                <td><?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $billing['status']))); ?></td>
                                                <td><a href="<?php echo APP_URL; ?>/modules/cashier/receive_payment.php?billing_id=<?php echo (int)$billing['billing_id']; ?>" class="btn btn-sm btn-success">Open</a></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">No billing records found for the selected filters.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>
    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
