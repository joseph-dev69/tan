<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';
require_once __DIR__ . '/../finance/billing_helpers.php';

require_role('cashier');

$current_user = get_logged_in_user();
$cashier = get_single_result("SELECT * FROM cashiers WHERE user_id = ?", [$current_user['user_id']]);

if (!$cashier) {
    flash_message('error', 'Cashier profile not found. Please contact the administrator.');
    redirect('index.php');
}

$billing_id = (int)($_GET['billing_id'] ?? ($_POST['billing_id'] ?? 0));
$receipt_to_print = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    if (!verify_csrf_token($csrf_token)) {
        flash_message('error', 'Invalid request token.');
        redirect('modules/cashier/receive_payment.php');
    }

    $amount = (float)($_POST['amount'] ?? 0);
    $payment_method = sanitize_input($_POST['payment_method'] ?? 'cash');
    $payment_date = sanitize_input($_POST['payment_date'] ?? date('Y-m-d'));

    try {
        $conn = get_db_connection();
        $conn->beginTransaction();

        $stmt = $conn->prepare("
            SELECT billing_id, total_amount, paid_amount, balance, status
            FROM billings
            WHERE billing_id = ?
            FOR UPDATE
        ");
        $stmt->execute([$billing_id]);
        $billing = $stmt->fetch();

        if (!$billing) {
            throw new Exception('Billing record not found.');
        }
        if ($amount <= 0) {
            throw new Exception('Payment amount must be greater than zero.');
        }
        if ($amount > (float)$billing['balance']) {
            throw new Exception('Payment amount cannot exceed the remaining balance.');
        }
        if ((float)$billing['balance'] <= 0 || strtolower((string)$billing['status']) === 'paid') {
            throw new Exception('This billing record is already fully paid.');
        }

        $reference_number = generate_payment_reference_number();

        $stmt = $conn->prepare("
            INSERT INTO payments (billing_id, payment_date, amount, payment_method, reference_number, processed_by, status)
            VALUES (?, ?, ?, ?, ?, ?, 'verified')
        ");
        $stmt->execute([$billing_id, $payment_date, $amount, $payment_method, $reference_number, $cashier['cashier_id']]);

        $payment_id = (int)$conn->lastInsertId();
        $current_paid_amount = (float)($billing['paid_amount'] ?? 0);
        $total_amount = (float)($billing['total_amount'] ?? 0);
        $new_paid_amount = round($current_paid_amount + $amount, 2);
        $new_remaining_balance = max(0, round($total_amount - $new_paid_amount, 2));
        $new_status = finance_determine_billing_status($total_amount, $new_paid_amount);

        $stmt = $conn->prepare("
            UPDATE billings
            SET paid_amount = ?, status = ?, updated_at = NOW()
            WHERE billing_id = ?
        ");
        $stmt->execute([$new_paid_amount, $new_status, $billing_id]);

        $stmt = $conn->prepare("
            SELECT enrollment_id
            FROM enrollments
            WHERE student_id = (
                SELECT student_id
                FROM billings
                WHERE billing_id = ?
            )
              AND school_year_id = (
                SELECT school_year_id
                FROM billings
                WHERE billing_id = ?
            )
              AND semester_id = (
                SELECT semester_id
                FROM billings
                WHERE billing_id = ?
            )
            ORDER BY enrollment_id DESC
            LIMIT 1
        ");
        $stmt->execute([$billing_id, $billing_id, $billing_id]);
        $enrollment = $stmt->fetch();

        if ($enrollment) {
            $stmt = $conn->prepare("
                UPDATE enrollments
                SET paid_amount = ?, balance = ?, updated_at = NOW()
                WHERE enrollment_id = ?
            ");
            $stmt->execute([$new_paid_amount, $new_remaining_balance, $enrollment['enrollment_id']]);
        }

        $receipt_number = generate_receipt_number();
        $conn->prepare("
            INSERT INTO receipts (payment_id, receipt_number, receipt_date, printed_by)
            VALUES (?, ?, ?, ?)
        ")->execute([$payment_id, $receipt_number, $payment_date, $cashier['cashier_id']]);

        $conn->commit();
        error_log(sprintf(
            'Cashier payment posted => billing_id=%d, payment_id=%d, amount=%.2f, paid_amount=%.2f, remaining_balance=%.2f, status=%s',
            $billing_id,
            $payment_id,
            $amount,
            $new_paid_amount,
            $new_remaining_balance,
            $new_status
        ));
        flash_message('success', 'Payment successfully posted. Student balance updated.');
        redirect('modules/cashier/receive_payment.php?receipt_payment_id=' . $payment_id . '&billing_id=' . $billing_id);
    } catch (Exception $e) {
        if (isset($conn) && $conn instanceof PDO && $conn->inTransaction()) {
            $conn->rollBack();
        }
        error_log('Cashier payment error: ' . $e->getMessage());
        flash_message('error', $e->getMessage());
        redirect('modules/cashier/receive_payment.php?billing_id=' . $billing_id);
    }
}

$selected_billing = null;
if ($billing_id > 0) {
    $selected_billing = get_single_result("
        SELECT b.billing_id, b.billing_date, b.due_date, b.total_amount, b.paid_amount, b.balance, b.status,
               sy.year_name, sem.semester_name, s.student_number, u.first_name, u.last_name, c.course_code
        FROM billings b
        JOIN school_years sy ON b.school_year_id = sy.school_year_id
        JOIN semesters sem ON b.semester_id = sem.semester_id
        JOIN students s ON b.student_id = s.student_id
        JOIN users u ON s.user_id = u.user_id
        JOIN courses c ON s.course_id = c.course_id
        WHERE b.billing_id = ?
    ", [$billing_id]);
}

$open_billings = get_multiple_results("
    SELECT b.billing_id, b.balance, b.status, s.student_number, u.first_name, u.last_name, c.course_code
    FROM billings b
    JOIN students s ON b.student_id = s.student_id
    JOIN users u ON s.user_id = u.user_id
    JOIN courses c ON s.course_id = c.course_id
    WHERE b.balance > 0 AND b.status <> 'paid'
    ORDER BY u.last_name ASC, u.first_name ASC
");

$receipt_payment_id = (int)($_GET['receipt_payment_id'] ?? 0);
if ($receipt_payment_id > 0) {
    $receipt_to_print = get_single_result("
        SELECT r.receipt_number, r.receipt_date, p.amount, p.payment_method, p.reference_number,
               b.total_amount, b.paid_amount, b.balance, sy.year_name, sem.semester_name,
               s.student_number, u.first_name, u.last_name, c.course_code
        FROM receipts r
        JOIN payments p ON r.payment_id = p.payment_id
        JOIN billings b ON p.billing_id = b.billing_id
        JOIN school_years sy ON b.school_year_id = sy.school_year_id
        JOIN semesters sem ON b.semester_id = sem.semester_id
        JOIN students s ON b.student_id = s.student_id
        JOIN users u ON s.user_id = u.user_id
        JOIN courses c ON s.course_id = c.course_id
        WHERE p.payment_id = ?
    ", [$receipt_payment_id]);
}

$flash_messages = get_flash_messages();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <meta name="user-data" content="<?php echo htmlspecialchars(json_encode($current_user)); ?>">
    <title>Receive Payment - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo"><a href="<?php echo APP_URL; ?>/modules/cashier/dashboard.php">Enchong Dee University Information System</a></div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <?php render_cashier_sidebar('receive_payment'); ?>
        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Receive Payment</h1>
                    <p>Select a billing record and post a payment.</p>
                </div>

                <?php if ($flash_messages): ?>
                    <div class="flash-messages mb-3">
                        <?php foreach ($flash_messages as $message): ?>
                            <div class="alert alert-<?php echo $message['type']; ?>"><?php echo htmlspecialchars($message['message']); ?></div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <div class="row mb-4">
                    <div class="col-5">
                        <div class="card equal-height-card">
                            <div class="card-header"><h4>Open Billing Records</h4></div>
                            <div class="card-body">
                                <?php if ($open_billings): ?>
                                    <div class="table-responsive">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th>Student</th>
                                                    <th>Balance</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($open_billings as $billing): ?>
                                                    <tr>
                                                        <td><?php echo htmlspecialchars($billing['last_name'] . ', ' . $billing['first_name']); ?><br><small class="text-muted"><?php echo htmlspecialchars($billing['student_number'] . ' / ' . $billing['course_code']); ?></small></td>
                                                        <td><?php echo format_currency($billing['balance']); ?></td>
                                                        <td><a href="<?php echo APP_URL; ?>/modules/cashier/receive_payment.php?billing_id=<?php echo (int)$billing['billing_id']; ?>" class="btn btn-sm btn-primary">Select</a></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php else: ?>
                                    <p class="text-muted">No open billing records found.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="col-7">
                    <div class="card equal-height-card">
                            <div class="card-header"><h4>Payment Form</h4></div>
                            <div class="card-body">
                                <?php if ($selected_billing): ?>
                                    <div class="alert alert-info">
                                        <strong><?php echo htmlspecialchars($selected_billing['last_name'] . ', ' . $selected_billing['first_name']); ?></strong><br>
                                        <?php echo htmlspecialchars($selected_billing['student_number'] . ' / ' . $selected_billing['course_code']); ?><br>
                                        Term: <?php echo htmlspecialchars($selected_billing['year_name'] . ' / ' . $selected_billing['semester_name']); ?><br>
                                        Remaining Balance: <strong><?php echo format_currency($selected_billing['balance']); ?></strong>
                                    </div>

                                    <form method="POST" action="">
                                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                        <input type="hidden" name="billing_id" value="<?php echo (int)$selected_billing['billing_id']; ?>">

                                        <div class="form-group">
                                            <label for="payment_date" class="form-label">Payment Date</label>
                                            <input type="date" id="payment_date" name="payment_date" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="amount" class="form-label">Amount</label>
                                            <input type="number" id="amount" name="amount" class="form-control" min="0.01" max="<?php echo htmlspecialchars(number_format((float)$selected_billing['balance'], 2, '.', '')); ?>" step="0.01" value="<?php echo htmlspecialchars(number_format((float)$selected_billing['balance'], 2, '.', '')); ?>" required>
                                            <small class="text-muted">Maximum payment allowed: <?php echo htmlspecialchars(format_currency((float)$selected_billing['balance'])); ?></small>
                                        </div>
                                        <div class="form-group">
                                            <label for="payment_method" class="form-label">Payment Method</label>
                                            <select id="payment_method" name="payment_method" class="form-control" required>
                                                <option value="cash">Cash</option>
                                                <option value="check">Check</option>
                                                <option value="bank_transfer">Bank Transfer</option>
                                                <option value="credit_card">Credit Card</option>
                                                <option value="online_payment">Online Payment</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="reference_number" class="form-label">Reference Number</label>
                                            <input type="text" id="reference_number" class="form-control" value="Auto-generated when saved" readonly>
                                            <small class="text-muted">The system will create the payment reference number automatically.</small>
                                        </div>
                                        <button type="submit" class="btn btn-success">Save Payment</button>
                                    </form>
                                <?php else: ?>
                                    <p class="text-muted">Select a billing record from the left side to receive a payment.</p>
                                <?php endif; ?>
                            </div>
                        </div>

                        <?php if ($receipt_to_print): ?>
                           <div class="card equal-height-card">
                                <div class="card-header"><h4>Latest Receipt</h4></div>
                                <div class="card-body">
                                    <div id="receiptPrintable" class="receipt-box">
                                        <h3>Official Receipt</h3>
                                        <p><strong>Receipt No:</strong> <?php echo htmlspecialchars($receipt_to_print['receipt_number']); ?></p>
                                        <p><strong>Date:</strong> <?php echo format_date($receipt_to_print['receipt_date']); ?></p>
                                        <p><strong>Student:</strong> <?php echo htmlspecialchars($receipt_to_print['last_name'] . ', ' . $receipt_to_print['first_name']); ?></p>
                                        <p><strong>Student No:</strong> <?php echo htmlspecialchars($receipt_to_print['student_number']); ?></p>
                                        <p><strong>Course:</strong> <?php echo htmlspecialchars($receipt_to_print['course_code']); ?></p>
                                        <p><strong>Term:</strong> <?php echo htmlspecialchars($receipt_to_print['year_name'] . ' / ' . $receipt_to_print['semester_name']); ?></p>
                                        <p><strong>Amount Paid:</strong> <?php echo format_currency($receipt_to_print['amount']); ?></p>
                                    </div>
                                    <div class="mt-3">
                                        <button type="button" class="btn btn-primary" onclick="printReceipt()">Print Receipt</button>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <style>
        .receipt-box { border: 1px solid var(--border-color); padding: 1.5rem; border-radius: 10px; background: #fff; }
    </style>
    <script>
        const amountInput = document.getElementById('amount');
        if (amountInput) {
            const maxAmount = parseFloat(amountInput.getAttribute('max') || '0');
            amountInput.addEventListener('input', function () {
                const currentValue = parseFloat(this.value || '0');
                if (maxAmount > 0 && currentValue > maxAmount) {
                    this.setCustomValidity('Payment amount cannot exceed the remaining balance.');
                } else if (currentValue <= 0) {
                    this.setCustomValidity('Payment amount must be greater than zero.');
                } else {
                    this.setCustomValidity('');
                }
            });
        }

        function printReceipt() {
            const printable = document.getElementById('receiptPrintable');
            if (!printable) return;
            const printWindow = window.open('', '_blank');
            printWindow.document.write('<html><head><title>Print Receipt</title></head><body>' + printable.innerHTML + '</body></html>');
            printWindow.document.close();
            printWindow.focus();
            printWindow.print();
            printWindow.close();
        }
    </script>
    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
