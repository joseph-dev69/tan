<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';

require_role('cashier');

$current_user = get_logged_in_user();
$cashier = get_single_result("SELECT * FROM cashiers WHERE user_id = ?", [$current_user['user_id']]);

if (!$cashier) {
    flash_message('error', 'Cashier profile not found. Please contact the administrator.');
    redirect('index.php');
}

$date_from = $_GET['date_from'] ?? date('Y-m-01');
$date_to = $_GET['date_to'] ?? date('Y-m-d');

$report_rows = get_multiple_results("
    SELECT p.payment_id, p.payment_date, p.amount, p.payment_method, p.reference_number,
           r.receipt_number, s.student_number, u.first_name, u.last_name, sy.year_name, sem.semester_name
    FROM payments p
    JOIN billings b ON p.billing_id = b.billing_id
    JOIN students s ON b.student_id = s.student_id
    JOIN users u ON s.user_id = u.user_id
    JOIN school_years sy ON b.school_year_id = sy.school_year_id
    JOIN semesters sem ON b.semester_id = sem.semester_id
    LEFT JOIN receipts r ON p.payment_id = r.payment_id
    WHERE p.status = 'verified'
      AND p.processed_by = ?
      AND p.payment_date BETWEEN ? AND ?
    ORDER BY p.payment_date DESC, p.payment_id DESC
", [$cashier['cashier_id'], $date_from, $date_to]);

$report_total = 0.00;
foreach ($report_rows as $row) {
    $report_total += (float)$row['amount'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cash Report - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo"><a href="<?php echo APP_URL; ?>/modules/cashier/dashboard.php">School Information System</a></div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <?php render_cashier_sidebar('cash_report'); ?>
        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Cash Report</h1>
                    <p>Review verified payments and print the cashier collection report.</p>
                </div>

                <div class="card mb-4">
                    <div class="card-body">
                        <form method="GET" action="" class="form-row">
                            <div class="form-group">
                                <label for="date_from" class="form-label">From Date</label>
                                <input type="date" id="date_from" name="date_from" class="form-control" value="<?php echo htmlspecialchars($date_from); ?>">
                            </div>
                            <div class="form-group">
                                <label for="date_to" class="form-label">To Date</label>
                                <input type="date" id="date_to" name="date_to" class="form-control" value="<?php echo htmlspecialchars($date_to); ?>">
                            </div>
                            <div class="form-group" style="align-self:end;">
                                <button type="submit" class="btn btn-primary">Show Report</button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header"><h4>Cash Collection Report</h4></div>
                    <div class="card-body">
                        <div class="mb-3"><strong>Total Collection:</strong> <?php echo format_currency($report_total); ?></div>

                        <?php if ($report_rows): ?>
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Receipt No.</th>
                                            <th>Student</th>
                                            <th>Term</th>
                                            <th>Method</th>
                                            <th>Amount</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($report_rows as $row): ?>
                                            <tr>
                                                <td><?php echo format_date($row['payment_date']); ?></td>
                                                <td><?php echo htmlspecialchars((string)($row['receipt_number'] ?? 'Pending')); ?></td>
                                                <td><?php echo htmlspecialchars($row['last_name'] . ', ' . $row['first_name']); ?><br><small class="text-muted"><?php echo htmlspecialchars($row['student_number']); ?></small></td>
                                                <td><?php echo htmlspecialchars($row['year_name'] . ' / ' . $row['semester_name']); ?></td>
                                                <td><?php echo htmlspecialchars(ucwords(str_replace('_', ' ', $row['payment_method']))); ?></td>
                                                <td><?php echo format_currency($row['amount']); ?></td>
                                                <td>
                                                    <?php if (!empty($row['receipt_number'])): ?>
                                                        <a href="<?php echo APP_URL; ?>/modules/cashier/receipts.php?search=<?php echo urlencode($row['receipt_number']); ?>" class="btn btn-sm btn-primary">View Receipt</a>
                                                    <?php else: ?>
                                                        <span class="text-muted">Not available</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="mt-3">
                                <button type="button" class="btn btn-primary" onclick="window.print()">Print Cash Collection Report</button>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">No verified payments found for the selected date range.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>
    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
