<?php
/**
 * Cashier Sidebar Navigation
 */

function render_cashier_sidebar($active_page = 'dashboard') {
    $items = [
        'dashboard' => ['label' => 'Dashboard', 'href' => APP_URL . '/modules/cashier/dashboard.php'],
        'student_payable' => ['label' => 'Student Payable', 'href' => APP_URL . '/modules/cashier/student_payable.php'],
        'receive_payment' => ['label' => 'Receive Payment', 'href' => APP_URL . '/modules/cashier/receive_payment.php'],
        'receipts' => ['label' => 'Receipts', 'href' => APP_URL . '/modules/cashier/receipts.php'],
        'cash_report' => ['label' => 'Cash Report', 'href' => APP_URL . '/modules/cashier/cash_report.php'],
        'change_password' => ['label' => 'Change Password', 'href' => APP_URL . '/modules/account/change_password.php'],
    ];
    ?>
    <aside class="sidebar" id="sidebar">
        <ul class="sidebar-menu">
            <?php foreach ($items as $key => $item): ?>
                <li>
                    <a href="<?php echo $item['href']; ?>" class="<?php echo $active_page === $key ? 'active' : ''; ?>">
                        <span class="icon"><?php echo htmlspecialchars($item['label']); ?></span>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </aside>
    <?php
}
