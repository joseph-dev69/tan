<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';

require_role('cashier');

$current_user = get_logged_in_user();
$cashier = get_single_result("SELECT * FROM cashiers WHERE user_id = ?", [$current_user['user_id']]);

if (!$cashier) {
    flash_message('error', 'Cashier profile not found. Please contact the administrator.');
    redirect('index.php');
}

$open_billings_count = get_single_result("SELECT COUNT(*) AS count FROM billings WHERE balance > 0")['count'] ?? 0;
$today_payments = get_single_result("SELECT COUNT(*) AS count FROM payments WHERE processed_by = ? AND payment_date = ?", [$cashier['cashier_id'], date('Y-m-d')])['count'] ?? 0;
$today_collection = get_single_result("SELECT COALESCE(SUM(amount), 0) AS total FROM payments WHERE processed_by = ? AND payment_date = ? AND status = 'verified'", [$cashier['cashier_id'], date('Y-m-d')])['total'] ?? 0;
$receipts_count = get_single_result("SELECT COUNT(*) AS count FROM receipts")['count'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cashier Dashboard - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo"><a href="<?php echo APP_URL; ?>/modules/cashier/dashboard.php">School Information System</a></div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <?php render_cashier_sidebar('dashboard'); ?>
        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Cashier Dashboard</h1>
                    <p>Quick overview of payables, receipts, and collections.</p>
                </div>

                <div class="row mb-4">
                    <div class="col-3">
                        <div class="card"><div class="card-body text-center"><h3 class="text-warning"><?php echo (int)$open_billings_count; ?></h3><p>Open Billings</p></div></div>
                    </div>
                    <div class="col-3">
                        <div class="card"><div class="card-body text-center"><h3 class="text-success"><?php echo (int)$today_payments; ?></h3><p>Payments Today</p></div></div>
                    </div>
                    <div class="col-3">
                        <div class="card"><div class="card-body text-center"><h3 class="text-primary"><?php echo format_currency($today_collection); ?></h3><p>Today's Collection</p></div></div>
                    </div>
                    <div class="col-3">
                        <div class="card"><div class="card-body text-center"><h3 class="text-info"><?php echo (int)$receipts_count; ?></h3><p>Total Receipts</p></div></div>
                    </div>
                </div>

            </div>
        </main>
    </div>
    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
