<div class="card equal-height-card"<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';

require_role('cashier');

$current_user = get_logged_in_user();
$cashier = get_single_result("SELECT * FROM cashiers WHERE user_id = ?", [$current_user['user_id']]);

if (!$cashier) {
    flash_message('error', 'Cashier profile not found. Please contact the administrator.');
    redirect('index.php');
}

$search = trim($_GET['search'] ?? '');
$selected_receipt_id = (int)($_GET['receipt_id'] ?? 0);

$receipt_sql = "
    SELECT r.receipt_id, r.receipt_number, r.receipt_date, p.payment_id, p.amount, p.payment_method, p.reference_number,
           b.total_amount, b.paid_amount, b.balance, sy.year_name, sem.semester_name,
           s.student_number, u.first_name, u.last_name, c.course_code
    FROM receipts r
    JOIN payments p ON r.payment_id = p.payment_id
    JOIN billings b ON p.billing_id = b.billing_id
    JOIN school_years sy ON b.school_year_id = sy.school_year_id
    JOIN semesters sem ON b.semester_id = sem.semester_id
    JOIN students s ON b.student_id = s.student_id
    JOIN users u ON s.user_id = u.user_id
    JOIN courses c ON s.course_id = c.course_id
    WHERE r.printed_by = ?
";

$receipt_params = [$cashier['cashier_id']];

if ($search !== '') {
    $receipt_sql .= "
        AND (
            r.receipt_number LIKE ?
            OR p.reference_number LIKE ?
            OR s.student_number LIKE ?
            OR u.first_name LIKE ?
            OR u.last_name LIKE ?
        )
    ";
    $like_search = '%' . $search . '%';
    array_push($receipt_params, $like_search, $like_search, $like_search, $like_search, $like_search);
}

$receipt_sql .= " ORDER BY r.receipt_date DESC, r.receipt_id DESC";
$receipt_rows = get_multiple_results($receipt_sql, $receipt_params);

$selected_receipt = null;
if ($selected_receipt_id > 0) {
    $selected_receipt = get_single_result("
        SELECT r.receipt_id, r.receipt_number, r.receipt_date, p.payment_id, p.amount, p.payment_method, p.reference_number,
               b.total_amount, b.paid_amount, b.balance, sy.year_name, sem.semester_name,
               s.student_number, u.first_name, u.last_name, c.course_code
        FROM receipts r
        JOIN payments p ON r.payment_id = p.payment_id
        JOIN billings b ON p.billing_id = b.billing_id
        JOIN school_years sy ON b.school_year_id = sy.school_year_id
        JOIN semesters sem ON b.semester_id = sem.semester_id
        JOIN students s ON b.student_id = s.student_id
        JOIN users u ON s.user_id = u.user_id
        JOIN courses c ON s.course_id = c.course_id
        WHERE r.receipt_id = ? AND r.printed_by = ?
    ", [$selected_receipt_id, $cashier['cashier_id']]);
}

if (!$selected_receipt && $receipt_rows) {
    $selected_receipt = $receipt_rows[0];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipts - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo"><a href="<?php echo APP_URL; ?>/modules/cashier/dashboard.php">School Information System</a></div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <?php render_cashier_sidebar('receipts'); ?>
        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Receipts</h1>
                    <p>View generated receipts and print them again anytime.</p>
                </div>

                <div class="card mb-4">
                    <div class="card-body">
                        <form method="GET" action="" class="form-row">
                            <div class="form-group flex-grow-1">
                                <label for="search" class="form-label">Search Receipt</label>
                                <input type="text" id="search" name="search" class="form-control" value="<?php echo htmlspecialchars($search); ?>" placeholder="Receipt no., reference no., student number, or name">
                            </div>
                            <div class="form-group" style="align-self:end;">
                                <button type="submit" class="btn btn-primary">Apply Filter</button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="row">
                   <div class="card equal-height-card">
                            <div class="card-header"><h4>Generated Receipts</h4></div>
                            <div class="card-body">
                                <?php if ($receipt_rows): ?>
                                    <div class="table-responsive">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th>Receipt No.</th>
                                                    <th>Student</th>
                                                    <th>Amount</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($receipt_rows as $receipt): ?>
                                                    <tr>
                                                        <td>
                                                            <?php echo htmlspecialchars($receipt['receipt_number']); ?><br>
                                                            <small class="text-muted"><?php echo format_date($receipt['receipt_date']); ?></small>
                                                        </td>
                                                        <td>
                                                            <?php echo htmlspecialchars($receipt['last_name'] . ', ' . $receipt['first_name']); ?><br>
                                                            <small class="text-muted"><?php echo htmlspecialchars($receipt['student_number']); ?></small>
                                                        </td>
                                                        <td><?php echo format_currency($receipt['amount']); ?></td>
                                                        <td><a href="<?php echo APP_URL; ?>/modules/cashier/receipts.php?receipt_id=<?php echo (int)$receipt['receipt_id']; ?>&search=<?php echo urlencode($search); ?>" class="btn btn-sm btn-primary">View</a></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php else: ?>
                                    <p class="text-muted">No receipts found for the selected search.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="card equal-height-card">
                            <div class="card-header"><h4>Receipt Preview</h4></div>
                            <div class="card-body">
                                <?php if ($selected_receipt): ?>
                                    <div id="receiptPrintable" class="receipt-box">
                                        <h3>Official Receipt</h3>
                                        <p><strong>Receipt No:</strong> <?php echo htmlspecialchars($selected_receipt['receipt_number']); ?></p>
                                        <p><strong>Date:</strong> <?php echo format_date($selected_receipt['receipt_date']); ?></p>
                                        <p><strong>Student:</strong> <?php echo htmlspecialchars($selected_receipt['last_name'] . ', ' . $selected_receipt['first_name']); ?></p>
                                        <p><strong>Student No:</strong> <?php echo htmlspecialchars($selected_receipt['student_number']); ?></p>
                                        <p><strong>Course:</strong> <?php echo htmlspecialchars($selected_receipt['course_code']); ?></p>
                                        <p><strong>Term:</strong> <?php echo htmlspecialchars($selected_receipt['year_name'] . ' / ' . $selected_receipt['semester_name']); ?></p>
                                        <p><strong>Payment Method:</strong> <?php echo htmlspecialchars(ucwords(str_replace('_', ' ', $selected_receipt['payment_method']))); ?></p>
                                        <p><strong>Reference No:</strong> <?php echo htmlspecialchars($selected_receipt['reference_number']); ?></p>
                                        <p><strong>Amount Paid:</strong> <?php echo format_currency($selected_receipt['amount']); ?></p>
                                        <p><strong>Total Billing:</strong> <?php echo format_currency($selected_receipt['total_amount']); ?></p>
                                        <p><strong>Total Paid:</strong> <?php echo format_currency($selected_receipt['paid_amount']); ?></p>
                                        <p><strong>Remaining Balance:</strong> <?php echo format_currency($selected_receipt['balance']); ?></p>
                                    </div>
                                    <div class="mt-3">
                                        <button type="button" class="btn btn-primary" onclick="printReceipt()">Print Receipt</button>
                                    </div>
                                <?php else: ?>
                                    <p class="text-muted">Select a receipt from the left side to view and print it.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <style>
        .receipt-box { border: 1px solid var(--border-color); padding: 1.5rem; border-radius: 10px; background: #fff; }
    </style>
    <script>
        function printReceipt() {
            const printable = document.getElementById('receiptPrintable');
            if (!printable) return;
            const printWindow = window.open('', '_blank');
            printWindow.document.write('<html><head><title>Print Receipt</title></head><body>' + printable.innerHTML + '</body></html>');
            printWindow.document.close();
            printWindow.focus();
            printWindow.print();
            printWindow.close();
        }
    </script>
    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
