<?php
/**
 * Teacher Dashboard
 * School Information System
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';

require_role('teacher');

$current_user = get_logged_in_user();
$teacher = get_single_result("SELECT * FROM teachers WHERE user_id = ?", [$current_user['user_id']]);

if (!$teacher) {
    flash_message('error', 'Teacher profile not found. Please contact the administrator.');
    redirect('index.php');
}

$current_school_year = get_single_result("SELECT * FROM school_years WHERE is_current = TRUE");
$current_semester = get_single_result("SELECT * FROM semesters WHERE is_current = TRUE");
$selected_school_year_id = (int)($current_school_year['school_year_id'] ?? 0);
$selected_semester_id = (int)($current_semester['semester_id'] ?? 0);
$semester_selection = resolve_fixed_semester_selection(
    $selected_school_year_id,
    $selected_semester_id,
    $current_semester['semester_name'] ?? ''
);
$selected_semester_id = $semester_selection['semester_id'];
$selected_semester_name = $semester_selection['semester_name'];

$schedule_summary = get_multiple_results("
    SELECT so.offering_id, sub.subject_code, sub.subject_name, so.section, sub.units,
           so.max_students,
           (
               SELECT COUNT(*)
               FROM student_subject_loads loadrec
               WHERE loadrec.offering_id = so.offering_id
                 AND loadrec.status IN ('enrolled', 'completed', 'failed')
           ) AS actual_student_count,
           (
               SELECT GROUP_CONCAT(
                   CONCAT(
                       sch.day_of_week,
                       ' ',
                       TIME_FORMAT(sch.start_time, '%h:%i %p'),
                       '-',
                       TIME_FORMAT(sch.end_time, '%h:%i %p')
                   )
                   ORDER BY sch.day_of_week, sch.start_time
                   SEPARATOR '<br>'
               )
               FROM schedules sch
               WHERE sch.offering_id = so.offering_id
           ) AS schedule_text
    FROM subject_offerings so
    JOIN subjects sub ON so.subject_id = sub.subject_id
    JOIN semesters sem_filter ON sem_filter.semester_id = so.semester_id
    WHERE so.teacher_id = ? AND so.school_year_id = ? AND sem_filter.semester_name = ?
    ORDER BY sub.subject_code, so.section
", [$teacher['teacher_id'], $selected_school_year_id, $selected_semester_name]);

$unique_student_summary = get_single_result("
    SELECT COUNT(DISTINCT e.student_id) AS unique_students
    FROM student_subject_loads loadrec
    JOIN enrollments e ON e.enrollment_id = loadrec.enrollment_id
    JOIN subject_offerings so ON so.offering_id = loadrec.offering_id
    JOIN semesters sem_filter ON sem_filter.semester_id = so.semester_id
    WHERE so.teacher_id = ? AND so.school_year_id = ? AND sem_filter.semester_name = ?
      AND loadrec.status IN ('enrolled', 'completed', 'failed')
", [$teacher['teacher_id'], $selected_school_year_id, $selected_semester_name]);

$summary_counts = [
    'subjects' => count($schedule_summary),
    'students' => (int)($unique_student_summary['unique_students'] ?? 0),
    'units' => 0,
];

foreach ($schedule_summary as $subject) {
    $summary_counts['units'] += (float)$subject['units'];
}

error_log(sprintf(
    'Teacher dashboard => teacher_id=%d, school_year_id=%d, semester_id=%d, semester_name=%s, subjects=%d, total_students=%d, total_units=%s',
    (int)$teacher['teacher_id'],
    (int)$selected_school_year_id,
    (int)$selected_semester_id,
    $selected_semester_name,
    (int)$summary_counts['subjects'],
    (int)$summary_counts['students'],
    (string)$summary_counts['units']
));

$flash_messages = get_flash_messages();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <meta name="user-data" content="<?php echo htmlspecialchars(json_encode($current_user)); ?>">
    <title>Teacher Dashboard - Enchong Dee University Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo"><a href="<?php echo APP_URL; ?>/modules/teacher/dashboard.php">Enchong Dee University Information System</a></div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <?php render_teacher_sidebar('dashboard'); ?>

        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Teacher Dashboard</h1>
                    <p>Quick overview of your teaching load for the current school year and semester.</p>
                </div>

                <?php if ($flash_messages): ?>
                    <div class="flash-messages mb-3">
                        <?php foreach ($flash_messages as $message): ?>
                            <div class="alert alert-<?php echo $message['type']; ?>">
                                <?php echo htmlspecialchars($message['message']); ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <div class="row mb-4">
                    <div class="col-4">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-primary"><?php echo htmlspecialchars((string)$summary_counts['subjects']); ?></h3>
                                <p>Subjects Handled</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-success"><?php echo htmlspecialchars((string)$summary_counts['students']); ?></h3>
                                <p>Total Students</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-info"><?php echo htmlspecialchars(rtrim(rtrim(number_format($summary_counts['units'], 2, '.', ''), '0'), '.')); ?></h3>
                                <p>Total Units</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h4>Current Teaching Load</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($schedule_summary): ?>
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Subject</th>
                                            <th>Section</th>
                                            <th>Units</th>
                                            <th>Schedule</th>
                                            <th>Students</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($schedule_summary as $subject): ?>
                                            <tr>
                                                <td>
                                                    <?php echo htmlspecialchars($subject['subject_code']); ?><br>
                                                    <small class="text-muted"><?php echo htmlspecialchars($subject['subject_name']); ?></small>
                                                </td>
                                                <td><?php echo htmlspecialchars($subject['section']); ?></td>
                                                <td><?php echo htmlspecialchars((string)$subject['units']); ?></td>
                                                <td><?php echo $subject['schedule_text'] ?: 'TBD'; ?></td>
                                                <td><?php echo htmlspecialchars((string)$subject['actual_student_count']) . ' / ' . htmlspecialchars((string)$subject['max_students']); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">No teaching schedules found for the current term.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
