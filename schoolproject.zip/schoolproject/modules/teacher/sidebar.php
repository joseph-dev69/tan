<?php
/**
 * Teacher Sidebar Navigation
 * School Information System
 */

function render_teacher_sidebar($active_page = 'dashboard')
{
    $items = [
        'dashboard' => ['label' => 'Dashboard', 'href' => APP_URL . '/modules/teacher/dashboard.php'],
        'schedules' => ['label' => 'Schedules', 'href' => APP_URL . '/modules/teacher/schedules.php'],
        'students' => ['label' => 'Student Lists', 'href' => APP_URL . '/modules/teacher/student_lists.php'],
        'grades' => ['label' => 'Encode Grades', 'href' => APP_URL . '/modules/teacher/encode_grades.php'],
        'change_password' => ['label' => 'Change Password', 'href' => APP_URL . '/modules/account/change_password.php'],
    ];
    ?>
    <aside class="sidebar" id="sidebar">
        <ul class="sidebar-menu">
            <?php foreach ($items as $key => $item): ?>
                <li>
                    <a href="<?php echo $item['href']; ?>" class="<?php echo $active_page === $key ? 'active' : ''; ?>">
                        <span class="icon"><?php echo htmlspecialchars($item['label']); ?></span>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </aside>
    <?php
}
