<?php
/**
 * Teacher Student Lists
 * School Information System
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';

require_role('teacher');

$current_user = get_logged_in_user();
$teacher = get_single_result("SELECT * FROM teachers WHERE user_id = ?", [$current_user['user_id']]);

if (!$teacher) {
    flash_message('error', 'Teacher profile not found. Please contact the administrator.');
    redirect('index.php');
}

$school_years = get_multiple_results("SELECT school_year_id, year_name FROM school_years ORDER BY school_year_id DESC");
$current_school_year = get_single_result("SELECT * FROM school_years WHERE is_current = TRUE");
$current_semester = get_single_result("SELECT * FROM semesters WHERE is_current = TRUE");
$selected_school_year_id = (int)($_GET['school_year_id'] ?? ($current_school_year['school_year_id'] ?? 0));
$selected_semester_id = (int)($_GET['semester_id'] ?? ($current_semester['semester_id'] ?? 0));
$semester_selection = resolve_fixed_semester_selection(
    $selected_school_year_id,
    $selected_semester_id,
    $current_semester['semester_name'] ?? ''
);
$semesters = $semester_selection['options'];
$selected_semester_id = $semester_selection['semester_id'];
$selected_semester_name = $semester_selection['semester_name'];
$selected_offering_id = (int)($_GET['offering_id'] ?? 0);
$student_search = trim($_GET['student_search'] ?? '');

$offered_subjects = get_multiple_results("
    SELECT so.offering_id, so.section, sub.subject_code, sub.subject_name
    FROM subject_offerings so
    JOIN subjects sub ON so.subject_id = sub.subject_id
    JOIN semesters sem_filter ON sem_filter.semester_id = so.semester_id
    WHERE so.teacher_id = ? AND so.school_year_id = ? AND sem_filter.semester_name = ?
    ORDER BY sub.subject_code, so.section
", [$teacher['teacher_id'], $selected_school_year_id, $selected_semester_name]);

if ($selected_offering_id <= 0 && !empty($offered_subjects)) {
    $selected_offering_id = (int)$offered_subjects[0]['offering_id'];
}

$selected_subject = null;
$class_list = [];

if ($selected_offering_id > 0) {
    $selected_subject = get_single_result("
        SELECT so.offering_id, so.section, sub.subject_code, sub.subject_name, sy.year_name, sem.semester_name
        FROM subject_offerings so
        JOIN subjects sub ON so.subject_id = sub.subject_id
        JOIN school_years sy ON so.school_year_id = sy.school_year_id
        JOIN semesters sem ON so.semester_id = sem.semester_id
        WHERE so.offering_id = ? AND so.teacher_id = ?
    ", [$selected_offering_id, $teacher['teacher_id']]);

    if ($selected_subject) {
        $class_filters = [
            'loadrec.offering_id = ?',
            "loadrec.status IN ('enrolled', 'completed', 'failed')"
        ];
        $class_params = [$selected_offering_id];

        if ($student_search !== '') {
            $class_filters[] = '(s.student_number LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ?)';
            $student_like = '%' . $student_search . '%';
            $class_params[] = $student_like;
            $class_params[] = $student_like;
            $class_params[] = $student_like;
        }

        $class_list = get_multiple_results("
            SELECT s.student_number, u.first_name, u.last_name, loadrec.status
            FROM student_subject_loads loadrec
            JOIN enrollments e ON loadrec.enrollment_id = e.enrollment_id
            JOIN students s ON e.student_id = s.student_id
            JOIN users u ON s.user_id = u.user_id
            WHERE " . implode(' AND ', $class_filters) . "
            ORDER BY u.last_name ASC, u.first_name ASC
        ", $class_params);
    }
}

error_log(sprintf(
    'Teacher student lists => teacher_id=%d, school_year_id=%d, semester_id=%d, semester_name=%s, selected_offering_id=%d, offered_subjects=%d, class_list=%d',
    (int)$teacher['teacher_id'],
    (int)$selected_school_year_id,
    (int)$selected_semester_id,
    $selected_semester_name,
    (int)$selected_offering_id,
    count($offered_subjects),
    count($class_list)
));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <meta name="user-data" content="<?php echo htmlspecialchars(json_encode($current_user)); ?>">
    <title>Student Lists - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo"><a href="<?php echo APP_URL; ?>/modules/teacher/dashboard.php">Enchong Dee University Information System</a></div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <?php render_teacher_sidebar('students'); ?>

        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Student Lists</h1>
                    <p>View enrolled students per subject, section, school year, and semester.</p>
                </div>

                <div class="card mb-4">
                    <div class="card-header">
                        <h4>Select Subject</h4>
                    </div>
                    <div class="card-body">
                        <form method="GET" action="" class="form-row">
                            <div class="form-group">
                                <label for="school_year_id" class="form-label">School Year</label>
                                <select id="school_year_id" name="school_year_id" class="form-control">
                                    <?php foreach ($school_years as $school_year): ?>
                                        <option value="<?php echo (int)$school_year['school_year_id']; ?>" <?php echo (int)$school_year['school_year_id'] === $selected_school_year_id ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($school_year['year_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="semester_id" class="form-label">Semester</label>
                                <select id="semester_id" name="semester_id" class="form-control">
                                    <?php foreach ($semesters as $semester): ?>
                                        <option value="<?php echo (int)$semester['semester_id']; ?>" <?php echo (int)$semester['semester_id'] === $selected_semester_id ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($semester['semester_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="offering_id" class="form-label">Subject / Section</label>
                                <select id="offering_id" name="offering_id" class="form-control">
                                    <?php foreach ($offered_subjects as $subject): ?>
                                        <option value="<?php echo (int)$subject['offering_id']; ?>" <?php echo (int)$subject['offering_id'] === $selected_offering_id ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($subject['subject_code'] . ' - ' . $subject['subject_name'] . ' / Section ' . $subject['section']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group" style="align-self:end;">
                                <button type="submit" class="btn btn-primary">Open List</button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h4>Student Lists by School Year / Semester</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($selected_subject): ?>
                            <p class="mb-3">
                                <strong><?php echo htmlspecialchars($selected_subject['subject_code'] . ' - ' . $selected_subject['subject_name']); ?></strong>
                                <span class="text-muted">| Section <?php echo htmlspecialchars($selected_subject['section']); ?> | <?php echo htmlspecialchars($selected_subject['year_name'] . ' / ' . $selected_subject['semester_name']); ?></span>
                            </p>

                            <form method="GET" action="" class="form-row mb-3">
                                <input type="hidden" name="school_year_id" value="<?php echo (int)$selected_school_year_id; ?>">
                                <input type="hidden" name="semester_id" value="<?php echo (int)$selected_semester_id; ?>">
                                <input type="hidden" name="offering_id" value="<?php echo (int)$selected_offering_id; ?>">

                                <div class="form-group">
                                    <label for="student_search" class="form-label">Student Search</label>
                                    <input type="text" id="student_search" name="student_search" class="form-control" value="<?php echo htmlspecialchars($student_search); ?>" placeholder="Student number or student name">
                                </div>
                                <div class="form-group" style="align-self:end;">
                                    <button type="submit" class="btn btn-primary">Search Student</button>
                                </div>
                            </form>
                        <?php endif; ?>

                        <?php if ($class_list): ?>
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Student Number</th>
                                            <th>Last Name</th>
                                            <th>First Name</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($class_list as $student): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($student['student_number']); ?></td>
                                                <td><?php echo htmlspecialchars($student['last_name']); ?></td>
                                                <td><?php echo htmlspecialchars($student['first_name']); ?></td>
                                                <td><?php echo htmlspecialchars(ucfirst($student['status'])); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php elseif ($selected_subject && $student_search !== ''): ?>
                            <p class="text-muted">No students found for "<?php echo htmlspecialchars($student_search); ?>" in this subject.</p>
                        <?php else: ?>
                            <p class="text-muted">Select a subject to view its student list.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
