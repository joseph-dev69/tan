<?php
/**
 * Teacher Grade Encoding
 * School Information System
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';

require_role('teacher');

$current_user = get_logged_in_user();
$teacher = get_single_result("SELECT * FROM teachers WHERE user_id = ?", [$current_user['user_id']]);

if (!$teacher) {
    flash_message('error', 'Teacher profile not found. Please contact the administrator.');
    redirect('index.php');
}

$school_years = get_multiple_results("SELECT school_year_id, year_name FROM school_years ORDER BY school_year_id DESC");
$current_school_year = get_single_result("SELECT * FROM school_years WHERE is_current = TRUE");
$current_semester = get_single_result("SELECT * FROM semesters WHERE is_current = TRUE");
$selected_school_year_id = (int)($_GET['school_year_id'] ?? ($current_school_year['school_year_id'] ?? 0));
$selected_semester_id = (int)($_GET['semester_id'] ?? ($current_semester['semester_id'] ?? 0));
$semester_selection = resolve_fixed_semester_selection(
    $selected_school_year_id,
    $selected_semester_id,
    $current_semester['semester_name'] ?? ''
);
$semesters = $semester_selection['options'];
$selected_semester_id = $semester_selection['semester_id'];
$selected_semester_name = $semester_selection['semester_name'];
$selected_offering_id = (int)($_GET['offering_id'] ?? 0);
$student_search = trim((string)($_GET['student_search'] ?? ''));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    $action = $_POST['action'] ?? '';

    if (!verify_csrf_token($csrf_token)) {
        flash_message('error', 'Invalid request token.');
        redirect('modules/teacher/encode_grades.php');
    }

    if ($action === 'save_grades') {
        $offering_id = (int)($_POST['offering_id'] ?? 0);
        $grade_rows = $_POST['grades'] ?? [];
        $student_search = trim((string)($_POST['student_search'] ?? ''));

        try {
            $conn = get_db_connection();
            $conn->beginTransaction();

            $offering = $conn->prepare("SELECT offering_id FROM subject_offerings WHERE offering_id = ? AND teacher_id = ? LIMIT 1");
            $offering->execute([$offering_id, $teacher['teacher_id']]);
            if (!$offering->fetch()) {
                throw new Exception('Selected subject offering is invalid.');
            }

            foreach ($grade_rows as $load_id => $row) {
                $load_id = (int)$load_id;
                if ($load_id <= 0) {
                    continue;
                }

                $load_lookup = $conn->prepare("
                    SELECT load_id
                    FROM student_subject_loads
                    WHERE load_id = ? AND offering_id = ?
                    LIMIT 1
                ");
                $load_lookup->execute([$load_id, $offering_id]);
                if (!$load_lookup->fetch()) {
                    continue;
                }

                $periods = ['prelim', 'midterm', 'final'];
                $period_values = [];

                foreach ($periods as $period) {
                    $grade_value = trim((string)($row[$period] ?? ''));
                    if ($grade_value === '') {
                        continue;
                    }

                    $grade_number = (float)$grade_value;
                    if ($grade_number < 0 || $grade_number > 100) {
                        throw new Exception('Grade must be between 0 and 100.');
                    }
                    $period_values[] = $grade_number;

                    $existing_grade_stmt = $conn->prepare("
                        SELECT grade_id
                        FROM grades
                        WHERE student_subject_load_id = ? AND grading_period = ?
                        ORDER BY grade_id ASC
                        LIMIT 1
                    ");
                    $existing_grade_stmt->execute([$load_id, $period]);
                    $existing_grade = $existing_grade_stmt->fetch();

                    if ($existing_grade) {
                        $stmt = $conn->prepare("
                            UPDATE grades
                            SET grade = ?, graded_by = ?, date_graded = ?
                            WHERE grade_id = ?
                        ");
                        $stmt->execute([$grade_number, $teacher['teacher_id'], date('Y-m-d'), $existing_grade['grade_id']]);
                    } else {
                        $stmt = $conn->prepare("
                            INSERT INTO grades (student_subject_load_id, grading_period, grade, graded_by, date_graded)
                            VALUES (?, ?, ?, ?, ?)
                        ");
                        $stmt->execute([$load_id, $period, $grade_number, $teacher['teacher_id'], date('Y-m-d')]);
                    }
                }

                $computed_final_grade = count($period_values) > 0 ? round(array_sum($period_values) / count($period_values), 2) : null;
                $computed_remarks = 'Pending';
                $computed_status = 'enrolled';

                if ($computed_final_grade !== null) {
                    if ($computed_final_grade >= 75) {
                        $computed_remarks = 'Passed';
                        $computed_status = 'completed';
                    } else {
                        $computed_remarks = 'Failed';
                        $computed_status = 'failed';
                    }
                }

                $stmt = $conn->prepare("
                    UPDATE student_subject_loads
                    SET remarks = ?, final_grade = ?, status = ?
                    WHERE load_id = ?
                ");
                $stmt->execute([$computed_remarks, $computed_final_grade, $computed_status, $load_id]);
            }

            $conn->commit();
            flash_message('success', 'Grades saved successfully.');
        } catch (Exception $e) {
            if (isset($conn) && $conn instanceof PDO && $conn->inTransaction()) {
                $conn->rollBack();
            }
            error_log('Teacher grade save error: ' . $e->getMessage());
            flash_message('error', 'Unable to save grades: ' . $e->getMessage());
        }

        redirect(
            'modules/teacher/encode_grades.php?school_year_id=' . $selected_school_year_id
            . '&semester_id=' . $selected_semester_id
            . '&offering_id=' . $offering_id
            . '&student_search=' . urlencode($student_search)
        );
    }
}

$offered_subjects = get_multiple_results("
    SELECT so.offering_id, so.section, sub.subject_code, sub.subject_name
    FROM subject_offerings so
    JOIN subjects sub ON so.subject_id = sub.subject_id
    JOIN semesters sem_filter ON sem_filter.semester_id = so.semester_id
    WHERE so.teacher_id = ? AND so.school_year_id = ? AND sem_filter.semester_name = ?
    ORDER BY sub.subject_code, so.section
", [$teacher['teacher_id'], $selected_school_year_id, $selected_semester_name]);

if ($selected_offering_id <= 0 && !empty($offered_subjects)) {
    $selected_offering_id = (int)$offered_subjects[0]['offering_id'];
}

$selected_subject = null;
$grade_book = [];

if ($selected_offering_id > 0) {
    $selected_subject = get_single_result("
        SELECT so.offering_id, so.section, sub.subject_code, sub.subject_name, sy.year_name, sem.semester_name
        FROM subject_offerings so
        JOIN subjects sub ON so.subject_id = sub.subject_id
        JOIN school_years sy ON so.school_year_id = sy.school_year_id
        JOIN semesters sem ON so.semester_id = sem.semester_id
        WHERE so.offering_id = ? AND so.teacher_id = ?
    ", [$selected_offering_id, $teacher['teacher_id']]);

    if ($selected_subject) {
        $grade_book = get_multiple_results("
            SELECT loadrec.load_id, loadrec.status, loadrec.final_grade, loadrec.remarks,
                   s.student_number, u.first_name, u.last_name,
                   prelim.grade AS prelim_grade,
                   midterm.grade AS midterm_grade,
                   finals.grade AS final_grade_period
            FROM student_subject_loads loadrec
            JOIN enrollments e ON loadrec.enrollment_id = e.enrollment_id
            JOIN students s ON e.student_id = s.student_id
            JOIN users u ON s.user_id = u.user_id
            LEFT JOIN grades prelim ON prelim.student_subject_load_id = loadrec.load_id AND prelim.grading_period = 'prelim'
            LEFT JOIN grades midterm ON midterm.student_subject_load_id = loadrec.load_id AND midterm.grading_period = 'midterm'
            LEFT JOIN grades finals ON finals.student_subject_load_id = loadrec.load_id AND finals.grading_period = 'final'
            WHERE loadrec.offering_id = ? AND loadrec.status IN ('enrolled', 'completed', 'failed')
              AND (
                  ? = ''
                  OR u.first_name LIKE ?
                  OR u.last_name LIKE ?
                  OR CONCAT(u.last_name, ', ', u.first_name) LIKE ?
                  OR CONCAT(u.first_name, ' ', u.last_name) LIKE ?
                  OR s.student_number LIKE ?
              )
            ORDER BY u.last_name ASC, u.first_name ASC
        ", [
            $selected_offering_id,
            $student_search,
            '%' . $student_search . '%',
            '%' . $student_search . '%',
            '%' . $student_search . '%',
            '%' . $student_search . '%',
            '%' . $student_search . '%'
        ]);
    }
}

error_log(sprintf(
    'Teacher encode grades => teacher_id=%d, school_year_id=%d, semester_id=%d, semester_name=%s, selected_offering_id=%d, offered_subjects=%d, grade_book=%d',
    (int)$teacher['teacher_id'],
    (int)$selected_school_year_id,
    (int)$selected_semester_id,
    $selected_semester_name,
    (int)$selected_offering_id,
    count($offered_subjects),
    count($grade_book)
));

$flash_messages = get_flash_messages();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <meta name="user-data" content="<?php echo htmlspecialchars(json_encode($current_user)); ?>">
    <title>Encode Grades - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
    <style>
        .readonly-grade {
            background: #f5f7fb;
            font-weight: 700;
            color: #1e40af;
        }
        .readonly-remarks {
            background: #f8fafc;
            font-weight: 700;
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo"><a href="<?php echo APP_URL; ?>/modules/teacher/dashboard.php">Enchong Dee University Information System</a></div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <?php render_teacher_sidebar('grades'); ?>

        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Encode Grades</h1>
                    <p>Encode grades per subject. Total grade and remarks are computed automatically for every student.</p>
                </div>

                <?php if ($flash_messages): ?>
                    <div class="flash-messages mb-3">
                        <?php foreach ($flash_messages as $message): ?>
                            <div class="alert alert-<?php echo $message['type']; ?>">
                                <?php echo htmlspecialchars($message['message']); ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <div class="card mb-4">
                    <div class="card-header">
                        <h4>Select Subject for Grade Encoding</h4>
                    </div>
                    <div class="card-body">
                        <form method="GET" action="" class="form-row">
                            <div class="form-group">
                                <label for="school_year_id" class="form-label">School Year</label>
                                <select id="school_year_id" name="school_year_id" class="form-control">
                                    <?php foreach ($school_years as $school_year): ?>
                                        <option value="<?php echo (int)$school_year['school_year_id']; ?>" <?php echo (int)$school_year['school_year_id'] === $selected_school_year_id ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($school_year['year_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="semester_id" class="form-label">Semester</label>
                                <select id="semester_id" name="semester_id" class="form-control">
                                    <?php foreach ($semesters as $semester): ?>
                                        <option value="<?php echo (int)$semester['semester_id']; ?>" <?php echo (int)$semester['semester_id'] === $selected_semester_id ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($semester['semester_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="offering_id" class="form-label">Subject / Section</label>
                                <select id="offering_id" name="offering_id" class="form-control">
                                    <?php foreach ($offered_subjects as $subject): ?>
                                        <option value="<?php echo (int)$subject['offering_id']; ?>" <?php echo (int)$subject['offering_id'] === $selected_offering_id ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($subject['subject_code'] . ' - ' . $subject['subject_name'] . ' / Section ' . $subject['section']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group" style="align-self:end;">
                                <button type="submit" class="btn btn-primary">Open Grade Sheet</button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h4>Encode Grades and Remarks</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($selected_subject): ?>
                            <p class="mb-3">
                                <strong><?php echo htmlspecialchars($selected_subject['subject_code'] . ' - ' . $selected_subject['subject_name']); ?></strong>
                                <span class="text-muted">| Section <?php echo htmlspecialchars($selected_subject['section']); ?> | <?php echo htmlspecialchars($selected_subject['year_name'] . ' / ' . $selected_subject['semester_name']); ?></span>
                            </p>
                            <form method="GET" action="" class="form-row mb-3">
                                <input type="hidden" name="school_year_id" value="<?php echo (int)$selected_school_year_id; ?>">
                                <input type="hidden" name="semester_id" value="<?php echo (int)$selected_semester_id; ?>">
                                <input type="hidden" name="offering_id" value="<?php echo (int)$selected_offering_id; ?>">
                                <div class="form-group">
                                    <label class="form-label" for="student_search_filter">Search Student</label>
                                    <input type="text" id="student_search_filter" name="student_search" class="form-control" value="<?php echo htmlspecialchars($student_search); ?>" placeholder="Type name or student number">
                                </div>
                                <div class="form-group" style="align-self:end;">
                                    <button type="submit" class="btn btn-secondary">Search</button>
                                </div>
                            </form>
                        <?php endif; ?>

                        <?php if ($grade_book): ?>
                            <form method="POST" action="" id="grade-encoding-form">
                                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                <input type="hidden" name="action" value="save_grades">
                                <input type="hidden" name="offering_id" value="<?php echo (int)$selected_offering_id; ?>">
                                <input type="hidden" name="student_search" value="<?php echo htmlspecialchars($student_search); ?>">

                                <div class="table-responsive">
                                    <table class="table table-sm">
                                        <thead>
                                            <tr>
                                                <th>Student</th>
                                                <th>Prelim</th>
                                                <th>Midterm</th>
                                                <th>Final</th>
                                                <th>Total Grade</th>
                                                <th>Remarks</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($grade_book as $student): ?>
                                                <?php
                                                $grade_values = [];
                                                foreach (['prelim_grade', 'midterm_grade', 'final_grade_period'] as $grade_key) {
                                                    if ($student[$grade_key] !== null && $student[$grade_key] !== '') {
                                                        $grade_values[] = (float)$student[$grade_key];
                                                    }
                                                }
                                                $computed_total = count($grade_values) > 0 ? round(array_sum($grade_values) / count($grade_values), 2) : null;
                                                $computed_remarks = $computed_total === null ? 'Pending' : ($computed_total >= 75 ? 'Passed' : 'Failed');
                                                ?>
                                                <tr data-grade-row>
                                                    <td>
                                                        <?php echo htmlspecialchars($student['last_name'] . ', ' . $student['first_name']); ?><br>
                                                        <small class="text-muted"><?php echo htmlspecialchars($student['student_number']); ?></small>
                                                    </td>
                                                    <td><input type="number" step="0.01" min="0" max="100" name="grades[<?php echo (int)$student['load_id']; ?>][prelim]" class="form-control period-grade" value="<?php echo htmlspecialchars((string)($student['prelim_grade'] ?? '')); ?>"></td>
                                                    <td><input type="number" step="0.01" min="0" max="100" name="grades[<?php echo (int)$student['load_id']; ?>][midterm]" class="form-control period-grade" value="<?php echo htmlspecialchars((string)($student['midterm_grade'] ?? '')); ?>"></td>
                                                    <td><input type="number" step="0.01" min="0" max="100" name="grades[<?php echo (int)$student['load_id']; ?>][final]" class="form-control period-grade" value="<?php echo htmlspecialchars((string)($student['final_grade_period'] ?? '')); ?>"></td>
                                                    <td>
                                                        <input type="text" class="form-control readonly-grade auto-total-grade" value="<?php echo $computed_total !== null ? htmlspecialchars(rtrim(rtrim(number_format($computed_total, 2, '.', ''), '0'), '.')) : ''; ?>" readonly>
                                                    </td>
                                                    <td>
                                                        <input type="text" class="form-control readonly-remarks auto-remarks" value="<?php echo htmlspecialchars($computed_remarks); ?>" readonly>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>

                                <div class="mt-3">
                                    <button type="submit" class="btn btn-success">Save Grades</button>
                                    <button type="button" class="btn btn-primary" onclick="printGrades()">Print Grades</button>
                                </div>
                            </form>
                        <?php else: ?>
                            <p class="text-muted">Select a subject to encode grades. Total grade and remarks will be computed automatically per student.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        function computeRowGrades(row) {
            const inputs = row.querySelectorAll('.period-grade');
            const totalField = row.querySelector('.auto-total-grade');
            const remarksField = row.querySelector('.auto-remarks');
            const values = [];

            inputs.forEach((input) => {
                const value = input.value.trim();
                if (value !== '' && !Number.isNaN(parseFloat(value))) {
                    values.push(parseFloat(value));
                }
            });

            if (values.length === 0) {
                totalField.value = '';
                remarksField.value = 'Pending';
                return;
            }

            const total = values.reduce((sum, value) => sum + value, 0) / values.length;
            totalField.value = total.toFixed(2).replace(/\.00$/, '');
            remarksField.value = total >= 75 ? 'Passed' : 'Failed';
        }

        document.addEventListener('DOMContentLoaded', function () {
            document.querySelectorAll('[data-grade-row]').forEach((row) => {
                computeRowGrades(row);

                row.querySelectorAll('.period-grade').forEach((input) => {
                    input.addEventListener('input', function () {
                        computeRowGrades(row);
                    });
                });
            });
        });

        function printGrades() {
            window.print();
        }
    </script>

    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
