<?php
/**
 * Teacher Schedules
 * School Information System
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';

require_role('teacher');

$current_user = get_logged_in_user();
$teacher = get_single_result("SELECT * FROM teachers WHERE user_id = ?", [$current_user['user_id']]);

if (!$teacher) {
    flash_message('error', 'Teacher profile not found. Please contact the administrator.');
    redirect('index.php');
}

$school_years = get_multiple_results("SELECT school_year_id, year_name FROM school_years ORDER BY school_year_id DESC");
$current_school_year = get_single_result("SELECT * FROM school_years WHERE is_current = TRUE");
$current_semester = get_single_result("SELECT * FROM semesters WHERE is_current = TRUE");
$selected_school_year_id = (int)($_GET['school_year_id'] ?? ($current_school_year['school_year_id'] ?? 0));
$selected_semester_id = (int)($_GET['semester_id'] ?? ($current_semester['semester_id'] ?? 0));
$semester_selection = resolve_fixed_semester_selection(
    $selected_school_year_id,
    $selected_semester_id,
    $current_semester['semester_name'] ?? ''
);
$semesters = $semester_selection['options'];
$selected_semester_id = $semester_selection['semester_id'];
$selected_semester_name = $semester_selection['semester_name'];
$schedule_search = trim($_GET['schedule_search'] ?? '');

$schedule_filters = [
    'so.teacher_id = ?',
    'so.school_year_id = ?'
];
$schedule_params = [$teacher['teacher_id'], $selected_school_year_id];

if ($selected_semester_name !== '') {
    $schedule_filters[] = 'sem_filter.semester_name = ?';
    $schedule_params[] = $selected_semester_name;
}

if ($schedule_search !== '') {
    $schedule_filters[] = '(sub.subject_code LIKE ? OR sub.subject_name LIKE ?)';
    $like = '%' . $schedule_search . '%';
    $schedule_params[] = $like;
    $schedule_params[] = $like;
}

$offered_subjects = get_multiple_results("
    SELECT so.offering_id, so.section, so.max_students, so.current_students, so.status,
           sub.subject_code, sub.subject_name, sub.units,
           (
               SELECT GROUP_CONCAT(
                   CONCAT(
                       sch.day_of_week, ' ',
                       TIME_FORMAT(sch.start_time, '%h:%i %p'),
                       '-',
                       TIME_FORMAT(sch.end_time, '%h:%i %p'),
                       IF(sch.room IS NOT NULL AND sch.room <> '', CONCAT(' / ', sch.room), '')
                   )
                   ORDER BY sch.day_of_week, sch.start_time SEPARATOR '<br>'
               )
               FROM schedules sch
               WHERE sch.offering_id = so.offering_id
           ) AS schedule_text,
           (
               SELECT COUNT(*)
               FROM student_subject_loads loadrec
               WHERE loadrec.offering_id = so.offering_id
                 AND loadrec.status IN ('enrolled', 'completed', 'failed')
           ) AS actual_student_count
    FROM subject_offerings so
    JOIN subjects sub ON so.subject_id = sub.subject_id
    JOIN semesters sem_filter ON sem_filter.semester_id = so.semester_id
    WHERE " . implode(' AND ', $schedule_filters) . "
    ORDER BY sub.subject_code, so.section
", $schedule_params);

error_log(sprintf(
    'Teacher schedules => teacher_id=%d, school_year_id=%d, semester_id=%d, semester_name=%s, search=%s, offerings=%d',
    (int)$teacher['teacher_id'],
    $selected_school_year_id,
    $selected_semester_id,
    $selected_semester_name,
    $schedule_search,
    count($offered_subjects)
));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <meta name="user-data" content="<?php echo htmlspecialchars(json_encode($current_user)); ?>">
    <title>Teacher Schedules - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo"><a href="<?php echo APP_URL; ?>/modules/teacher/dashboard.php">Enchong Dee University Information System</a></div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <?php render_teacher_sidebar('schedules'); ?>

        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Teacher Schedules</h1>
                    <p>View your assigned schedules by school year, semester, and subject.</p>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h4>Teacher Schedules by School Year / Semester</h4>
                    </div>
                    <div class="card-body">
                        <form method="GET" action="" class="form-row mb-3">
                            <div class="form-group">
                                <label for="school_year_id" class="form-label">School Year</label>
                                <select id="school_year_id" name="school_year_id" class="form-control">
                                    <?php foreach ($school_years as $school_year): ?>
                                        <option value="<?php echo (int)$school_year['school_year_id']; ?>" <?php echo (int)$school_year['school_year_id'] === $selected_school_year_id ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($school_year['year_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="semester_id" class="form-label">Semester</label>
                                <select id="semester_id" name="semester_id" class="form-control">
                                    <?php foreach ($semesters as $semester): ?>
                                        <option value="<?php echo (int)$semester['semester_id']; ?>" <?php echo (int)$semester['semester_id'] === $selected_semester_id ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($semester['semester_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="schedule_search" class="form-label">Subject Search</label>
                                <input type="text" id="schedule_search" name="schedule_search" class="form-control" value="<?php echo htmlspecialchars($schedule_search); ?>" placeholder="Subject code or subject name">
                            </div>
                            <div class="form-group" style="align-self: end;">
                                <button type="submit" class="btn btn-primary">Apply Filter</button>
                            </div>
                        </form>

                        <?php if ($offered_subjects): ?>
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Subject</th>
                                            <th>Section</th>
                                            <th>Units</th>
                                            <th>Schedule</th>
                                            <th>Students</th>
                                            <th>Open</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($offered_subjects as $subject): ?>
                                            <tr>
                                                <td>
                                                    <?php echo htmlspecialchars($subject['subject_code']); ?><br>
                                                    <small class="text-muted"><?php echo htmlspecialchars($subject['subject_name']); ?></small>
                                                </td>
                                                <td><?php echo htmlspecialchars($subject['section']); ?></td>
                                                <td><?php echo htmlspecialchars((string)$subject['units']); ?></td>
                                                <td><?php echo $subject['schedule_text'] ?: 'TBD'; ?></td>
                                                <td><?php echo htmlspecialchars((string)$subject['actual_student_count']) . ' / ' . htmlspecialchars((string)$subject['max_students']); ?></td>
                                                <td>
                                                    <a class="btn btn-sm btn-primary" href="<?php echo APP_URL; ?>/modules/teacher/student_lists.php?school_year_id=<?php echo (int)$selected_school_year_id; ?>&semester_id=<?php echo (int)$selected_semester_id; ?>&offering_id=<?php echo (int)$subject['offering_id']; ?>">Open</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">No teaching schedules found for the selected school year and semester.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
