<?php
/**
 * Finance Office Dashboard
 */
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';
require_once __DIR__ . '/billing_helpers.php';

require_role('finance_officer');
$current_user = get_logged_in_user();

$current_school_year = get_single_result("SELECT * FROM school_years WHERE is_current = TRUE");
$current_semester = get_single_result("SELECT * FROM semesters WHERE is_current = TRUE");
$current_school_year_id = (int)($current_school_year['school_year_id'] ?? 0);
$current_semester_name = trim((string)($current_semester['semester_name'] ?? ''));
$status_filter = strtolower(trim($_GET['status'] ?? 'all'));
$allowed_status_filters = ['all', 'paid', 'partial', 'unpaid'];
if (!in_array($status_filter, $allowed_status_filters, true)) {
    $status_filter = 'all';
}

$enrollment_summary = get_single_result("
    SELECT COUNT(*) AS enrolled_students,
           COALESCE(SUM(total_units), 0) AS total_units,
           COALESCE(SUM(total_fee), 0) AS total_fee,
           COALESCE(SUM(balance), 0) AS total_balance
    FROM enrollments
    WHERE school_year_id = ?
      AND semester_id IN (
          SELECT semester_id
          FROM semesters
          WHERE semester_name = ?
      )
      AND status = 'enrolled'
", [$current_school_year_id, $current_semester_name]);

$fee_summary = get_single_result("
    SELECT COUNT(*) AS fee_count,
           COALESCE(SUM(amount), 0) AS total_fee_schedule
    FROM fee_schedules
    WHERE is_active = 1
");

$billing_summary = get_single_result("
    SELECT COUNT(*) AS billing_count,
           COALESCE(SUM(total_amount), 0) AS billed_amount,
           COALESCE(SUM(balance), 0) AS remaining_balance
    FROM billings
");

$finance_conditions = ["b.school_year_id = ?"];
$finance_params = [$current_school_year_id];

if ($current_semester_name !== '') {
    $finance_conditions[] = "EXISTS (
        SELECT 1
        FROM semesters sem_filter
        WHERE sem_filter.semester_id = b.semester_id
          AND sem_filter.semester_name = ?
    )";
    $finance_params[] = $current_semester_name;
}

if ($status_filter === 'paid') {
    $finance_conditions[] = "b.status = 'paid'";
} elseif ($status_filter === 'partial') {
    $finance_conditions[] = "b.status = 'partially_paid'";
} elseif ($status_filter === 'unpaid') {
    $finance_conditions[] = "b.status = 'pending'";
}

$payment_records = get_multiple_results("
    SELECT b.billing_id, b.total_amount, b.paid_amount, b.balance, b.status,
           s.student_number,
           u.first_name, u.last_name,
           c.course_code
    FROM billings b
    JOIN students s ON b.student_id = s.student_id
    JOIN users u ON s.user_id = u.user_id
    LEFT JOIN courses c ON s.course_id = c.course_id
    WHERE " . implode(' AND ', $finance_conditions) . "
    ORDER BY u.last_name ASC, u.first_name ASC, b.billing_id DESC
", $finance_params);

$count_conditions = ["b.school_year_id = ?"];
$count_params = [$current_school_year_id];
if ($current_semester_name !== '') {
    $count_conditions[] = "EXISTS (
        SELECT 1
        FROM semesters sem_filter
        WHERE sem_filter.semester_id = b.semester_id
          AND sem_filter.semester_name = ?
    )";
    $count_params[] = $current_semester_name;
}

$status_count_row = get_single_result("
    SELECT
        SUM(CASE WHEN b.status = 'paid' THEN 1 ELSE 0 END) AS paid_count,
        SUM(CASE WHEN b.status = 'partially_paid' THEN 1 ELSE 0 END) AS partial_count,
        SUM(CASE WHEN b.status = 'pending' THEN 1 ELSE 0 END) AS unpaid_count
    FROM billings b
    WHERE " . implode(' AND ', $count_conditions) . "
", $count_params);

$status_counts = [
    'paid' => (int)($status_count_row['paid_count'] ?? 0),
    'partial' => (int)($status_count_row['partial_count'] ?? 0),
    'unpaid' => (int)($status_count_row['unpaid_count'] ?? 0),
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <meta name="user-data" content="<?php echo htmlspecialchars(json_encode($current_user)); ?>">
    <title>Finance Office Dashboard - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo"><a href="<?php echo APP_URL; ?>/modules/finance/dashboard.php">School Information System</a></div>
            <nav>
                <ul class="nav">
                    <li><a href="#" class="sidebar-toggle">Menu</a></li>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                    <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="app-container">
        <?php render_finance_sidebar('dashboard'); ?>

        <main class="main-content">
            <div class="content-wrapper">
                <div class="page-header">
                    <h1>Finance Office Dashboard</h1>
                    <p>View student load summaries, fee schedules, and student payable balances for the active term.</p>
                </div>

                <div class="card mb-4">
                    <div class="card-body">
                        <strong>Current School Year:</strong> <?php echo htmlspecialchars($current_school_year['year_name'] ?? 'Not set'); ?>
                        <span style="margin-left:2rem;"><strong>Current Semester:</strong> <?php echo htmlspecialchars($current_semester['semester_name'] ?? 'Not set'); ?></span>
                    </div>
                </div>

                <div class="row mb-4">
                    <div class="col-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-primary"><?php echo htmlspecialchars((string)($enrollment_summary['enrolled_students'] ?? 0)); ?></h3>
                                <p>Enrolled Students</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-info"><?php echo htmlspecialchars(rtrim(rtrim(number_format((float)($enrollment_summary['total_units'] ?? 0), 2, '.', ''), '0'), '.')); ?></h3>
                                <p>Total Units</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-success"><?php echo htmlspecialchars(format_currency((float)($billing_summary['billed_amount'] ?? 0))); ?></h3>
                                <p>Student Billings</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-warning"><?php echo htmlspecialchars(format_currency((float)($billing_summary['remaining_balance'] ?? 0))); ?></h3>
                                <p>Outstanding Balance</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h4>Student Payment Status</h4>
                    </div>
                    <div class="card-body">
                        <form method="GET" class="form-row mb-3">
                            <div class="form-group">
                                <label class="form-label" for="status">Status Filter</label>
                                <select id="status" name="status" class="form-control">
                                    <option value="all" <?php echo $status_filter === 'all' ? 'selected' : ''; ?>>All</option>
                                    <option value="paid" <?php echo $status_filter === 'paid' ? 'selected' : ''; ?>>Paid</option>
                                    <option value="partial" <?php echo $status_filter === 'partial' ? 'selected' : ''; ?>>Partial</option>
                                    <option value="unpaid" <?php echo $status_filter === 'unpaid' ? 'selected' : ''; ?>>Unpaid</option>
                                </select>
                            </div>
                            <div class="form-group" style="display:flex;align-items:end;">
                                <button type="submit" class="btn btn-primary">Apply Filter</button>
                            </div>
                        </form>

                        <?php if ($payment_records): ?>
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Student Name</th>
                                            <th>Student Number</th>
                                            <th>Total Fee</th>
                                            <th>Paid Amount</th>
                                            <th>Remaining Balance</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($payment_records as $row): ?>
                                            <?php $status_label = finance_get_status_label($row['status']); ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($row['last_name'] . ', ' . $row['first_name']); ?></td>
                                                <td><?php echo htmlspecialchars($row['student_number']); ?></td>
                                                <td><?php echo htmlspecialchars(format_currency((float)$row['total_amount'])); ?></td>
                                                <td><?php echo htmlspecialchars(format_currency((float)$row['paid_amount'])); ?></td>
                                                <td><?php echo htmlspecialchars(format_currency((float)$row['balance'])); ?></td>
                                                <td><span class="badge badge-<?php echo finance_get_status_badge_class($row['status']); ?>"><?php echo htmlspecialchars($status_label); ?></span></td>
                                                <td><a href="<?php echo APP_URL; ?>/modules/finance/payment_record.php?billing_id=<?php echo (int)$row['billing_id']; ?>" class="btn btn-sm btn-primary">Open</a></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">No billing records matched the selected payment status.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
