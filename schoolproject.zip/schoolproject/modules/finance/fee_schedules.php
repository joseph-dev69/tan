<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';

require_role('finance_officer');
$current_user = get_logged_in_user();

$fee_type = trim($_GET['fee_type'] ?? '');
$course_id = (int)($_GET['course_id'] ?? 0);
$courses = get_multiple_results("SELECT course_id, course_code, course_name FROM courses ORDER BY course_code");

$conditions = ['1 = 1'];
$params = [];
if ($fee_type !== '') {
    $conditions[] = 'fs.fee_type = ?';
    $params[] = $fee_type;
}
if ($course_id > 0) {
    $conditions[] = '(fs.course_id = ? OR fs.applicable_to = "all")';
    $params[] = $course_id;
}

$fee_schedules = get_multiple_results("
    SELECT fs.*, c.course_code, c.course_name
    FROM fee_schedules fs
    LEFT JOIN courses c ON fs.course_id = c.course_id
    WHERE " . implode(' AND ', $conditions) . "
    ORDER BY fs.fee_type, fs.fee_name
", $params);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <meta name="user-data" content="<?php echo htmlspecialchars(json_encode($current_user)); ?>">
    <title>Fee Schedules - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
<header class="header">
    <div class="container">
        <div class="logo"><a href="<?php echo APP_URL; ?>/modules/finance/dashboard.php">School Information System</a></div>
        <nav><ul class="nav"><li><a href="#" class="sidebar-toggle">Menu</a></li><li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li><li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li></ul></nav>
    </div>
</header>
<div class="app-container">
    <?php render_finance_sidebar('fees'); ?>
    <main class="main-content">
        <div class="content-wrapper">
            <div class="page-header">
                <h1>Fee Schedules</h1>
                <p>View tuition fee, miscellaneous fee, laboratory fee, and other finance schedules.</p>
            </div>

            <div class="card mb-4">
                <div class="card-header"><h4>Filter Fee Schedules</h4></div>
                <div class="card-body">
                    <form method="GET" class="form-row">
                        <div class="form-group">
                            <label class="form-label" for="fee_type">Fee Type</label>
                            <select class="form-control" id="fee_type" name="fee_type">
                                <option value="">All Fee Types</option>
                                <?php foreach (['tuition','miscellaneous','laboratory','library','sports','other'] as $type): ?>
                                    <option value="<?php echo htmlspecialchars($type); ?>" <?php echo $fee_type === $type ? 'selected' : ''; ?>><?php echo htmlspecialchars(ucfirst($type)); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="course_id">Course</label>
                            <select class="form-control" id="course_id" name="course_id">
                                <option value="0">All Courses</option>
                                <?php foreach ($courses as $course): ?>
                                    <option value="<?php echo (int)$course['course_id']; ?>" <?php echo (int)$course_id === (int)$course['course_id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($course['course_code'] . ' - ' . $course['course_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group" style="align-self:end;">
                            <button type="submit" class="btn btn-primary">Apply Filter</button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-header"><h4>Fee Schedules</h4></div>
                <div class="card-body">
                    <?php if ($fee_schedules): ?>
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Fee Name</th>
                                        <th>Type</th>
                                        <th>Amount</th>
                                        <th>Applicable To</th>
                                        <th>Course</th>
                                        <th>Year Level</th>
                                        <th>Semester</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($fee_schedules as $fee): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($fee['fee_name']); ?></td>
                                            <td><?php echo htmlspecialchars(ucfirst($fee['fee_type'])); ?></td>
                                            <td><?php echo htmlspecialchars(format_currency((float)$fee['amount'])); ?></td>
                                            <td><?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $fee['applicable_to']))); ?></td>
                                            <td><?php echo htmlspecialchars($fee['course_code'] ?? 'All Courses'); ?></td>
                                            <td><?php echo htmlspecialchars($fee['year_level'] ? (string)$fee['year_level'] : 'All'); ?></td>
                                            <td><?php echo htmlspecialchars(ucfirst($fee['semester_type'])); ?></td>
                                            <td><span class="badge badge-<?php echo $fee['is_active'] ? 'success' : 'secondary'; ?>"><?php echo $fee['is_active'] ? 'Active' : 'Inactive'; ?></span></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-muted">No fee schedules found for the selected filters.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>
</div>
<script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
