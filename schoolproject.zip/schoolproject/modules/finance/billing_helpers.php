<?php
/**
 * Finance Billing Helpers
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';

function finance_map_semester_type($semester_name)
{
    $normalized = strtolower(trim((string)$semester_name));
    if (strpos($normalized, 'first') !== false) {
        return 'first';
    }
    if (strpos($normalized, 'second') !== false) {
        return 'second';
    }
    if (strpos($normalized, 'summer') !== false) {
        return 'summer';
    }
    return 'all';
}

function finance_get_enrollment_billing_context($enrollment_id)
{
    return get_single_result("
        SELECT e.*, s.student_id, s.course_id, s.student_number,
               c.course_code, c.course_name,
               sem.semester_name, sy.year_name,
               COALESCE(subject_summary.subject_count, 0) AS subject_count
        FROM enrollments e
        JOIN students s ON e.student_id = s.student_id
        LEFT JOIN courses c ON s.course_id = c.course_id
        JOIN semesters sem ON e.semester_id = sem.semester_id
        JOIN school_years sy ON e.school_year_id = sy.school_year_id
        LEFT JOIN (
            SELECT enrollment_id, COUNT(*) AS subject_count
            FROM student_subject_loads
            WHERE status = 'enrolled'
            GROUP BY enrollment_id
        ) AS subject_summary ON e.enrollment_id = subject_summary.enrollment_id
        WHERE e.enrollment_id = ?
    ", [$enrollment_id]);
}

function finance_get_applicable_fee_schedules($course_id, $semester_type)
{
    return get_multiple_results("
        SELECT fs.*
        FROM fee_schedules fs
        WHERE fs.is_active = 1
          AND (fs.semester_type = 'all' OR fs.semester_type = ?)
          AND (
                fs.applicable_to = 'all'
                OR (fs.applicable_to = 'specific_course' AND fs.course_id = ?)
                OR fs.applicable_to = 'undergraduate'
              )
        ORDER BY fs.fee_type, fs.fee_name
    ", [$semester_type, $course_id]);
}

function finance_build_billing_line_items($enrollment)
{
    $semester_type = finance_map_semester_type($enrollment['semester_name'] ?? '');
    $fee_schedules = finance_get_applicable_fee_schedules((int)$enrollment['course_id'], $semester_type);
    $line_items = [];

    foreach ($fee_schedules as $fee) {
        $quantity = 1;

        if ($fee['fee_type'] === 'tuition') {
            $quantity = max(1, (int)ceil((float)$enrollment['total_units']));
        } elseif ($fee['fee_type'] === 'laboratory') {
            $quantity = max(1, (int)$enrollment['subject_count']);
        }

        $unit_cost = (float)$fee['amount'];
        $total_cost = $unit_cost * $quantity;

        $line_items[] = [
            'fee_schedule_id' => (int)$fee['fee_schedule_id'],
            'fee_name' => $fee['fee_name'],
            'fee_type' => $fee['fee_type'],
            'quantity' => $quantity,
            'unit_cost' => $unit_cost,
            'total_cost' => $total_cost,
        ];
    }

    return $line_items;
}

function finance_determine_billing_status($total_amount, $paid_amount)
{
    $total_amount = round((float)$total_amount, 2);
    $paid_amount = round((float)$paid_amount, 2);
    $remaining_balance = max(0, round($total_amount - $paid_amount, 2));

    if ($total_amount <= 0) {
        return 'pending';
    }

    if ($remaining_balance <= 0) {
        return 'paid';
    }

    if ($remaining_balance < $total_amount) {
        return 'partially_paid';
    }

    return 'pending';
}

function finance_get_status_label($status)
{
    $normalized = strtolower(trim((string)$status));

    if ($normalized === 'paid') {
        return 'PAID';
    }

    if ($normalized === 'partially_paid') {
        return 'PARTIAL';
    }

    return 'UNPAID';
}

function finance_get_status_badge_class($status)
{
    $normalized = strtolower(trim((string)$status));

    if ($normalized === 'paid') {
        return 'success';
    }

    if ($normalized === 'partially_paid') {
        return 'warning';
    }

    return 'danger';
}

function finance_get_student_billing_message($status)
{
    $normalized = strtolower(trim((string)$status));

    if ($normalized === 'paid') {
        return 'You have successfully paid your balance.';
    }

    if ($normalized === 'partially_paid') {
        return 'You still have remaining balance.';
    }

    return 'You have not paid yet.';
}

function finance_refresh_billing_totals($billing_id, $conn = null)
{
    $owns_connection = false;
    if (!$conn) {
        $conn = get_db_connection();
        $owns_connection = true;
        $conn->beginTransaction();
    }

    try {
        $stmt = $conn->prepare("
            SELECT *
            FROM billings
            WHERE billing_id = ?
        ");
        $stmt->execute([$billing_id]);
        $billing = $stmt->fetch();

        if (!$billing) {
            throw new Exception('Billing record not found.');
        }

        $stmt = $conn->prepare("
            SELECT COALESCE(SUM(amount), 0) AS total_paid
            FROM payments
            WHERE billing_id = ? AND status = 'verified'
        ");
        $stmt->execute([$billing_id]);
        $payment_total = $stmt->fetch();

        $paid_amount = (float)($payment_total['total_paid'] ?? 0);
        $status = finance_determine_billing_status((float)$billing['total_amount'], $paid_amount);

        $stmt = $conn->prepare("
            UPDATE billings
            SET paid_amount = ?, status = ?, updated_at = NOW()
            WHERE billing_id = ?
        ");
        $stmt->execute([$paid_amount, $status, $billing_id]);

        $stmt = $conn->prepare("
            SELECT enrollment_id
            FROM enrollments
            WHERE student_id = ? AND school_year_id = ? AND semester_id = ?
            ORDER BY enrollment_id DESC
            LIMIT 1
        ");
        $stmt->execute([$billing['student_id'], $billing['school_year_id'], $billing['semester_id']]);
        $enrollment = $stmt->fetch();

        if ($enrollment) {
            $stmt = $conn->prepare("
                UPDATE enrollments
                SET paid_amount = ?, balance = GREATEST(total_fee - ?, 0), updated_at = NOW()
                WHERE enrollment_id = ?
            ");
            $stmt->execute([$paid_amount, $paid_amount, $enrollment['enrollment_id']]);
        }

        if ($owns_connection && $conn->inTransaction()) {
            $conn->commit();
        }

        $stmt = $conn->prepare("
            SELECT *
            FROM billings
            WHERE billing_id = ?
        ");
        $stmt->execute([$billing_id]);
        return $stmt->fetch();
    } catch (Exception $e) {
        if ($owns_connection && $conn->inTransaction()) {
            $conn->rollBack();
        }
        throw $e;
    }
}

function finance_sync_billing_for_enrollment($enrollment_id)
{
    $enrollment = finance_get_enrollment_billing_context($enrollment_id);
    if (!$enrollment) {
        throw new Exception('Enrollment record not found.');
    }

    $line_items = finance_build_billing_line_items($enrollment);
    $total_amount = 0.0;
    foreach ($line_items as $item) {
        $total_amount += $item['total_cost'];
    }

    $conn = get_db_connection();
    $conn->beginTransaction();

    try {
        $stmt = $conn->prepare("
            SELECT *
            FROM billings
            WHERE student_id = ? AND school_year_id = ? AND semester_id = ?
            ORDER BY billing_id DESC
            LIMIT 1
        ");
        $stmt->execute([$enrollment['student_id'], $enrollment['school_year_id'], $enrollment['semester_id']]);
        $billing = $stmt->fetch();

        if ($billing) {
            $billing_id = (int)$billing['billing_id'];
            $paid_amount = (float)$billing['paid_amount'];
            $status = finance_determine_billing_status($total_amount, $paid_amount);
            $stmt = $conn->prepare("
                UPDATE billings
                SET total_amount = ?, paid_amount = ?, status = ?, updated_at = NOW()
                WHERE billing_id = ?
            ");
            $stmt->execute([$total_amount, $paid_amount, $status, $billing_id]);

            $delete_stmt = $conn->prepare("DELETE FROM billing_details WHERE billing_id = ?");
            $delete_stmt->execute([$billing_id]);
        } else {
            $paid_amount = 0.0;
            $stmt = $conn->prepare("
                INSERT INTO billings (student_id, semester_id, school_year_id, billing_date, due_date, total_amount, status, paid_amount)
                VALUES (?, ?, ?, ?, ?, ?, 'pending', 0)
            ");
            $billing_date = date('Y-m-d');
            $due_date = date('Y-m-d', strtotime('+30 days'));
            $stmt->execute([
                $enrollment['student_id'],
                $enrollment['semester_id'],
                $enrollment['school_year_id'],
                $billing_date,
                $due_date,
                $total_amount
            ]);
            $billing_id = (int)$conn->lastInsertId();
        }

        if (!empty($line_items)) {
            $detail_stmt = $conn->prepare("
                INSERT INTO billing_details (billing_id, fee_schedule_id, quantity, unit_cost, total_cost)
                VALUES (?, ?, ?, ?, ?)
            ");

            foreach ($line_items as $item) {
                $detail_stmt->execute([
                    $billing_id,
                    $item['fee_schedule_id'],
                    $item['quantity'],
                    $item['unit_cost'],
                    $item['total_cost']
                ]);
            }
        }

        $stmt = $conn->prepare("
            SELECT COALESCE(SUM(amount), 0) AS total_paid
            FROM payments
            WHERE billing_id = ? AND status = 'verified'
        ");
        $stmt->execute([$billing_id]);
        $verified_payments = $stmt->fetch();
        $paid_amount = (float)($verified_payments['total_paid'] ?? 0);
        $balance = max(0, $total_amount - $paid_amount);
        $status = finance_determine_billing_status($total_amount, $paid_amount);

        $stmt = $conn->prepare("
            UPDATE billings
            SET total_amount = ?, paid_amount = ?, status = ?, updated_at = NOW()
            WHERE billing_id = ?
        ");
        $stmt->execute([$total_amount, $paid_amount, $status, $billing_id]);

        $stmt = $conn->prepare("
            UPDATE enrollments
            SET total_fee = ?, paid_amount = ?, balance = ?, updated_at = NOW()
            WHERE enrollment_id = ?
        ");
        $stmt->execute([$total_amount, $paid_amount, $balance, $enrollment_id]);

        if ($conn->inTransaction()) {
            $conn->commit();
        }

        return [
            'billing_id' => $billing_id,
            'total_amount' => $total_amount,
            'paid_amount' => $paid_amount,
            'balance' => $balance,
            'line_items' => $line_items,
        ];
    } catch (Exception $e) {
        if ($conn->inTransaction()) {
            $conn->rollBack();
        }
        throw $e;
    }
}

function finance_get_exam_phase_breakdown($total_amount)
{
    $total_amount = round((float)$total_amount, 2);
    $prelim = round($total_amount / 3, 2);
    $midterm = round($total_amount / 3, 2);
    $final = round($total_amount - $prelim - $midterm, 2);

    return [
        'prelim' => [
            'label' => 'Prelim',
            'amount' => $prelim,
            'required_paid' => $prelim,
        ],
        'midterm' => [
            'label' => 'Midterm',
            'amount' => $midterm,
            'required_paid' => round($prelim + $midterm, 2),
        ],
        'final' => [
            'label' => 'Final',
            'amount' => $final,
            'required_paid' => $total_amount,
        ],
    ];
}

function finance_get_semester_phase_schedule($school_year_id, $semester_id)
{
    $semester = get_single_result("
        SELECT semester_id, semester_name, school_year_id, start_date, end_date
        FROM semesters
        WHERE semester_id = ? AND school_year_id = ?
    ", [$semester_id, $school_year_id]);

    if (!$semester && $semester_id > 0 && $school_year_id > 0) {
        $semester_name_row = get_single_result("
            SELECT semester_name
            FROM semesters
            WHERE semester_id = ?
        ", [$semester_id]);

        if (!empty($semester_name_row['semester_name'])) {
            $semester = get_single_result("
                SELECT semester_id, semester_name, school_year_id, start_date, end_date
                FROM semesters
                WHERE school_year_id = ? AND semester_name = ?
                ORDER BY semester_id DESC
                LIMIT 1
            ", [$school_year_id, $semester_name_row['semester_name']]);
        }
    }

    if (!$semester) {
        return [];
    }

    return compute_exam_period_schedule($semester['start_date'], $semester['end_date']);
}

function finance_get_verified_payment_total($billing_id)
{
    $payment_total = get_single_result("
        SELECT COALESCE(SUM(amount), 0) AS total_paid
        FROM payments
        WHERE billing_id = ? AND status = 'verified'
    ", [$billing_id]);

    return (float)($payment_total['total_paid'] ?? 0);
}

function finance_get_billing_phase_status($billing)
{
    if (!$billing) {
        return [];
    }

    $paid_amount = finance_get_verified_payment_total($billing['billing_id']);
    $phases = finance_get_exam_phase_breakdown($billing['total_amount']);
    $phase_schedule = finance_get_semester_phase_schedule($billing['school_year_id'], $billing['semester_id']);
    $today = new DateTime(date('Y-m-d'));
    $remaining_paid_pool = $paid_amount;

    foreach ($phases as $key => $phase) {
        $phase_amount = round((float)$phase['amount'], 2);
        $phase_paid_amount = min($remaining_paid_pool, $phase_amount);
        $remaining_paid_pool = max(0, round($remaining_paid_pool - $phase_paid_amount, 2));

        $remaining_to_unlock = max(0, round($phase['required_paid'] - $paid_amount, 2));
        $remaining_for_phase = max(0, round($phase_amount - $phase_paid_amount, 2));

        $phases[$key]['total_paid_amount'] = $paid_amount;
        $phases[$key]['paid_amount'] = $phase_paid_amount;
        $phases[$key]['remaining_for_phase'] = $remaining_for_phase;
        $phases[$key]['remaining_to_unlock'] = $remaining_to_unlock;
        $phases[$key]['is_paid'] = $remaining_for_phase <= 0;
        $phases[$key]['due_date'] = $phase_schedule[$key]['due_date'] ?? null;
        $phases[$key]['schedule_is_set'] = !empty($phases[$key]['due_date']);
        $phases[$key]['schedule_status'] = $phases[$key]['schedule_is_set'] ? 'Set' : 'Schedule Not Set';
        $phases[$key]['is_overdue'] = false;
        $phases[$key]['status_label'] = 'Payment Required';
        $phases[$key]['status_badge'] = 'warning';

        if ($phases[$key]['schedule_is_set']) {
            $due_date = new DateTime($phases[$key]['due_date']);
            $phases[$key]['is_overdue'] = $today > $due_date && !$phases[$key]['is_paid'];
        }

        if ($phases[$key]['is_paid']) {
            $phases[$key]['status_label'] = 'Settled';
            $phases[$key]['status_badge'] = 'success';
        } elseif ($phases[$key]['is_overdue']) {
            $phases[$key]['status_label'] = 'Overdue';
            $phases[$key]['status_badge'] = 'danger';
        } elseif (!$phases[$key]['schedule_is_set']) {
            $phases[$key]['status_label'] = 'Schedule Not Set';
            $phases[$key]['status_badge'] = 'secondary';
        } elseif ($phase_paid_amount > 0) {
            $phases[$key]['status_label'] = 'Partial';
            $phases[$key]['status_badge'] = 'warning';
        }
    }

    return $phases;
}

function finance_get_next_due_phase($phase_statuses)
{
    foreach (['prelim', 'midterm', 'final'] as $phase_key) {
        if (!empty($phase_statuses[$phase_key]) && !$phase_statuses[$phase_key]['is_paid']) {
            return $phase_key;
        }
    }

    return 'final';
}

function finance_can_download_permit($billing, $phase_key)
{
    $phase_key = strtolower(trim((string)$phase_key));
    $phase_statuses = finance_get_billing_phase_status($billing);
    if (!isset($phase_statuses[$phase_key])) {
        return [false, null];
    }

    return [$phase_statuses[$phase_key]['is_paid'], $phase_statuses[$phase_key]];
}

function finance_get_current_exam_phase($school_year_id, $semester_id)
{
    $phase_schedule = finance_get_semester_phase_schedule($school_year_id, $semester_id);
    if (empty($phase_schedule)) {
        return null;
    }

    $today = new DateTime(date('Y-m-d'));
    $prelim_due = new DateTime($phase_schedule['prelim']['due_date']);
    $midterm_due = new DateTime($phase_schedule['midterm']['due_date']);

    if ($today <= $prelim_due) {
        return 'prelim';
    }
    if ($today <= $midterm_due) {
        return 'midterm';
    }

    return 'final';
}
