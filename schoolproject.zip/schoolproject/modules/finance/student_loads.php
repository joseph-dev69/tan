<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';
require_once __DIR__ . '/billing_helpers.php';

require_role('finance_officer');
$current_user = get_logged_in_user();

$school_years = get_multiple_results("SELECT school_year_id, year_name FROM school_years ORDER BY school_year_id DESC");
$current_school_year = get_single_result("SELECT * FROM school_years WHERE is_current = TRUE");
$current_semester = get_single_result("SELECT * FROM semesters WHERE is_current = TRUE");
$selected_school_year_id = (int)($_GET['school_year_id'] ?? ($current_school_year['school_year_id'] ?? 0));
$selected_semester_id = (int)($_GET['semester_id'] ?? ($current_semester['semester_id'] ?? 0));
$semester_selection = resolve_fixed_semester_selection(
    $selected_school_year_id,
    $selected_semester_id,
    $current_semester['semester_name'] ?? ''
);
$semesters = $semester_selection['options'];
$selected_semester_id = $semester_selection['semester_id'];
$selected_semester_name = $semester_selection['semester_name'] ?? ($current_semester['semester_name'] ?? '');
$student_query = trim($_GET['student_query'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    $action = $_POST['action'] ?? '';

    if (!verify_csrf_token($csrf_token)) {
        flash_message('error', 'Invalid request token.');
        redirect('modules/finance/student_loads.php');
    }

    if ($action === 'sync_billing') {
        $enrollment_id = (int)($_POST['enrollment_id'] ?? 0);

        try {
            $result = finance_sync_billing_for_enrollment($enrollment_id);
            flash_message('success', 'Billing synchronized successfully. Total billing: ' . format_currency($result['total_amount']));
        } catch (Exception $e) {
            error_log('Finance billing sync error: ' . $e->getMessage());
            flash_message('error', 'Unable to synchronize billing for this student.');
        }

        redirect('modules/finance/student_loads.php?school_year_id=' . $selected_school_year_id . '&semester_id=' . $selected_semester_id . '&student_query=' . urlencode($student_query));
    }
}

$conditions = ["e.school_year_id = ?", "sem_filter.semester_name = ?", "e.status = 'enrolled'"];
$params = [$selected_school_year_id, $selected_semester_name];
if ($student_query !== '') {
    $conditions[] = "(s.student_number LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ? OR CONCAT(u.first_name, ' ', u.last_name) LIKE ? OR CONCAT(u.last_name, ', ', u.first_name) LIKE ?)";
    $like = '%' . $student_query . '%';
    array_push($params, $like, $like, $like, $like, $like);
}

$student_loads = get_multiple_results("
    SELECT e.enrollment_id, e.total_units, e.total_fee, e.balance,
           s.student_number, u.first_name, u.last_name,
           c.course_code, c.course_name,
           COUNT(DISTINCT loadrec.load_id) AS total_subjects,
           (
               SELECT b.billing_id
               FROM billings b
               JOIN semesters bill_sem ON bill_sem.semester_id = b.semester_id
               WHERE b.student_id = e.student_id
                 AND b.school_year_id = e.school_year_id
                 AND bill_sem.semester_name = sem_filter.semester_name
               ORDER BY b.billing_id DESC
               LIMIT 1
           ) AS billing_id,
           (
               SELECT b.status
               FROM billings b
               JOIN semesters bill_sem ON bill_sem.semester_id = b.semester_id
               WHERE b.student_id = e.student_id
                 AND b.school_year_id = e.school_year_id
                 AND bill_sem.semester_name = sem_filter.semester_name
               ORDER BY b.billing_id DESC
               LIMIT 1
           ) AS billing_status,
           (
               SELECT b.total_amount
               FROM billings b
               JOIN semesters bill_sem ON bill_sem.semester_id = b.semester_id
               WHERE b.student_id = e.student_id
                 AND b.school_year_id = e.school_year_id
                 AND bill_sem.semester_name = sem_filter.semester_name
               ORDER BY b.billing_id DESC
               LIMIT 1
           ) AS billing_total_amount,
           (
               SELECT b.balance
               FROM billings b
               JOIN semesters bill_sem ON bill_sem.semester_id = b.semester_id
               WHERE b.student_id = e.student_id
                 AND b.school_year_id = e.school_year_id
                 AND bill_sem.semester_name = sem_filter.semester_name
               ORDER BY b.billing_id DESC
               LIMIT 1
           ) AS billing_balance
    FROM enrollments e
    JOIN semesters sem_filter ON sem_filter.semester_id = e.semester_id
    JOIN students s ON e.student_id = s.student_id
    JOIN users u ON s.user_id = u.user_id
    LEFT JOIN courses c ON s.course_id = c.course_id
    LEFT JOIN student_subject_loads loadrec ON e.enrollment_id = loadrec.enrollment_id AND loadrec.status = 'enrolled'
    WHERE " . implode(' AND ', $conditions) . "
    GROUP BY e.enrollment_id
    ORDER BY u.last_name, u.first_name
", $params);

error_log('Finance student loads filter: school_year_id=' . $selected_school_year_id
    . ' semester_id=' . $selected_semester_id
    . ' semester_name=' . $selected_semester_name
    . ' student_query=' . $student_query
    . ' results=' . count($student_loads));

$flash_messages = get_flash_messages();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <meta name="user-data" content="<?php echo htmlspecialchars(json_encode($current_user)); ?>">
    <title>Student Load - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
<header class="header">
    <div class="container">
        <div class="logo"><a href="<?php echo APP_URL; ?>/modules/finance/dashboard.php">Enchong Dee University Information System</a></div>
        <nav><ul class="nav"><li><a href="#" class="sidebar-toggle">Menu</a></li><li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li></ul></nav>
    </div>
</header>
<div class="app-container">
    <?php render_finance_sidebar('loads'); ?>
    <main class="main-content">
        <div class="content-wrapper">
            <div class="page-header">
                <h1>Student Load</h1>
                <p>View student load with summary of units by school year and semester.</p>
            </div>

            <?php if ($flash_messages): ?>
                <div class="flash-messages mb-3">
                    <?php foreach ($flash_messages as $message): ?>
                        <div class="alert alert-<?php echo $message['type']; ?>">
                            <?php echo htmlspecialchars($message['message']); ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <div class="card mb-4">
                <div class="card-header"><h4>Filter Student Load</h4></div>
                <div class="card-body">
                    <form method="GET" class="form-row">
                        <div class="form-group">
                            <label class="form-label" for="school_year_id">School Year</label>
                            <select class="form-control" id="school_year_id" name="school_year_id">
                                <?php foreach ($school_years as $school_year): ?>
                                    <option value="<?php echo (int)$school_year['school_year_id']; ?>" <?php echo (int)$school_year['school_year_id'] === $selected_school_year_id ? 'selected' : ''; ?>><?php echo htmlspecialchars($school_year['year_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="semester_id">Semester</label>
                            <select class="form-control" id="semester_id" name="semester_id">
                                <?php foreach ($semesters as $semester): ?>
                                    <option value="<?php echo (int)$semester['semester_id']; ?>" <?php echo (int)$semester['semester_id'] === $selected_semester_id ? 'selected' : ''; ?>><?php echo htmlspecialchars($semester['semester_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="student_query">Student Search</label>
                            <input class="form-control" type="text" id="student_query" name="student_query" value="<?php echo htmlspecialchars($student_query); ?>" placeholder="Student number or last name">
                        </div>
                        <div class="form-group" style="align-self:end;">
                            <button type="submit" class="btn btn-primary">Apply Filter</button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-header"><h4>Student Load with Summary of Units</h4></div>
                <div class="card-body">
                    <?php if ($student_loads): ?>
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Student Number</th>
                                        <th>Name</th>
                                        <th>Course</th>
                                        <th>Subjects</th>
                                        <th>Total Units</th>
                                        <th>Total Fee</th>
                                        <th>Balance</th>
                                        <th>Billing</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($student_loads as $row): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($row['student_number']); ?></td>
                                            <td><?php echo htmlspecialchars($row['last_name'] . ', ' . $row['first_name']); ?></td>
                                            <td><?php echo htmlspecialchars(($row['course_code'] ?? 'N/A') . (!empty($row['course_name']) ? ' - ' . $row['course_name'] : '')); ?></td>
                                            <td><?php echo htmlspecialchars((string)$row['total_subjects']); ?></td>
                                            <td><?php echo htmlspecialchars((string)$row['total_units']); ?></td>
                                            <td><?php echo htmlspecialchars(format_currency((float)($row['billing_total_amount'] ?? $row['total_fee']))); ?></td>
                                            <td><?php echo htmlspecialchars(format_currency((float)($row['billing_balance'] ?? $row['balance']))); ?></td>
                                            <td>
                                                <?php if (!empty($row['billing_id'])): ?>
                                                    <span class="badge badge-success"><?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $row['billing_status']))); ?></span>
                                                <?php else: ?>
                                                    <span class="badge badge-warning">Not Generated</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <form method="POST" action="">
                                                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                                    <input type="hidden" name="action" value="sync_billing">
                                                    <input type="hidden" name="enrollment_id" value="<?php echo (int)$row['enrollment_id']; ?>">
                                                    <button type="submit" class="btn btn-sm btn-primary"><?php echo !empty($row['billing_id']) ? 'Update Billing' : 'Generate Billing'; ?></button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-muted">No student load records found for the selected filters.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>
</div>
<script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
