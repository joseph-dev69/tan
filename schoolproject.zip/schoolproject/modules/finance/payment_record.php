<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';
require_once __DIR__ . '/billing_helpers.php';

require_role('finance_officer');

$current_user = get_logged_in_user();
$billing_id = (int)($_GET['billing_id'] ?? 0);
$student_number = trim((string)($_GET['student_number'] ?? ''));

$billing = null;
if ($billing_id > 0) {
    $billing = get_single_result("
        SELECT b.*, sy.year_name, sem.semester_name,
               s.student_id, s.student_number,
               u.first_name, u.last_name,
               c.course_code, c.course_name
        FROM billings b
        JOIN students s ON b.student_id = s.student_id
        JOIN users u ON s.user_id = u.user_id
        LEFT JOIN courses c ON s.course_id = c.course_id
        JOIN school_years sy ON b.school_year_id = sy.school_year_id
        JOIN semesters sem ON b.semester_id = sem.semester_id
        WHERE b.billing_id = ?
    ", [$billing_id]);
} elseif ($student_number !== '') {
    $billing = get_single_result("
        SELECT b.*, sy.year_name, sem.semester_name,
               s.student_id, s.student_number,
               u.first_name, u.last_name,
               c.course_code, c.course_name
        FROM billings b
        JOIN students s ON b.student_id = s.student_id
        JOIN users u ON s.user_id = u.user_id
        LEFT JOIN courses c ON s.course_id = c.course_id
        JOIN school_years sy ON b.school_year_id = sy.school_year_id
        JOIN semesters sem ON b.semester_id = sem.semester_id
        WHERE s.student_number = ?
        ORDER BY b.billing_id DESC
        LIMIT 1
    ", [$student_number]);
}

$payment_history = [];
$billing_details = [];
$phase_statuses = [];

if ($billing) {
    $billing_id = (int)$billing['billing_id'];

    $billing_details = get_multiple_results("
        SELECT bd.*, fs.fee_name, fs.fee_type
        FROM billing_details bd
        LEFT JOIN fee_schedules fs ON bd.fee_schedule_id = fs.fee_schedule_id
        WHERE bd.billing_id = ?
        ORDER BY fs.fee_type, fs.fee_name
    ", [$billing_id]);

    $payment_history = get_multiple_results("
        SELECT p.payment_id, p.payment_date, p.amount, p.payment_method, p.reference_number,
               p.status, p.created_at,
               r.receipt_number,
               COALESCE(cashier_user.first_name, finance_user.first_name, admin_user.first_name) AS recorded_first_name,
               COALESCE(cashier_user.last_name, finance_user.last_name, admin_user.last_name) AS recorded_last_name,
               CASE
                   WHEN cashier_user.user_id IS NOT NULL THEN 'Cashier'
                   WHEN finance_user.user_id IS NOT NULL THEN 'Finance'
                   WHEN admin_user.user_id IS NOT NULL THEN 'System User'
                   ELSE 'System'
               END AS recorded_role
        FROM payments p
        LEFT JOIN receipts r ON p.payment_id = r.payment_id
        LEFT JOIN cashiers ca ON p.processed_by = ca.cashier_id
        LEFT JOIN users cashier_user ON ca.user_id = cashier_user.user_id
        LEFT JOIN finance_officers fo ON p.processed_by = fo.finance_officer_id
        LEFT JOIN users finance_user ON fo.user_id = finance_user.user_id
        LEFT JOIN users admin_user ON p.processed_by = admin_user.user_id
        WHERE p.billing_id = ?
        ORDER BY p.payment_date DESC, p.payment_id DESC
    ", [$billing_id]);

    $phase_statuses = finance_get_billing_phase_status($billing);
}

$status_badge_class = $billing ? finance_get_status_badge_class($billing['status']) : 'secondary';
$status_label = $billing ? finance_get_status_label($billing['status']) : 'Not Found';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <meta name="user-data" content="<?php echo htmlspecialchars(json_encode($current_user)); ?>">
    <title>Payment Record - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
<header class="header">
    <div class="container">
        <div class="logo"><a href="<?php echo APP_URL; ?>/modules/finance/dashboard.php">School Information System</a></div>
        <nav>
            <ul class="nav">
                <li><a href="#" class="sidebar-toggle">Menu</a></li>
                <li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li>
                <li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li>
            </ul>
        </nav>
    </div>
</header>

<div class="app-container">
    <?php render_finance_sidebar('payables'); ?>
    <main class="main-content">
        <div class="content-wrapper">
            <div class="page-header d-flex justify-content-between align-items-center">
                <div>
                    <h1>Payment Record</h1>
                    <p>Student billing details and payment history.</p>
                </div>
                <a href="<?php echo APP_URL; ?>/modules/finance/student_payables.php" class="btn btn-secondary">Back</a>
            </div>

            <?php if (!$billing): ?>
                <div class="alert alert-warning">No billing record found for the selected student.</div>
            <?php else: ?>
                <div class="card mb-4">
                    <div class="card-header"><h4>Student Billing Information</h4></div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-4">
                                <p><strong>Student Number:</strong><br><?php echo htmlspecialchars($billing['student_number']); ?></p>
                                <p><strong>Name:</strong><br><?php echo htmlspecialchars($billing['last_name'] . ', ' . $billing['first_name']); ?></p>
                                <p><strong>Course:</strong><br><?php echo htmlspecialchars(($billing['course_code'] ?? 'N/A') . (!empty($billing['course_name']) ? ' - ' . $billing['course_name'] : '')); ?></p>
                            </div>
                            <div class="col-4">
                                <p><strong>Billing Date:</strong><br><?php echo htmlspecialchars(format_date($billing['billing_date'])); ?></p>
                                <p><strong>School Year / Semester:</strong><br><?php echo htmlspecialchars($billing['year_name'] . ' / ' . $billing['semester_name']); ?></p>
                                <p><strong>Payment Status:</strong><br><span class="badge badge-<?php echo $status_badge_class; ?>"><?php echo htmlspecialchars($status_label); ?></span></p>
                            </div>
                            <div class="col-4">
                                <p><strong>Total Amount:</strong><br><?php echo htmlspecialchars(format_currency((float)$billing['total_amount'])); ?></p>
                                <p><strong>Total Paid:</strong><br><?php echo htmlspecialchars(format_currency((float)$billing['paid_amount'])); ?></p>
                                <p><strong>Remaining Balance:</strong><br><?php echo htmlspecialchars(format_currency((float)$billing['balance'])); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-6">
                        <div class="card">
                            <div class="card-header"><h4>Charge Breakdown</h4></div>
                            <div class="card-body">
                                <?php if ($billing_details): ?>
                                    <div class="table-responsive">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th>Charge</th>
                                                    <th>Type</th>
                                                    <th>Qty</th>
                                                    <th>Total</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($billing_details as $detail): ?>
                                                    <tr>
                                                        <td><?php echo htmlspecialchars($detail['fee_name'] ?? 'Manual Charge'); ?></td>
                                                        <td><?php echo htmlspecialchars(ucfirst($detail['fee_type'] ?? 'other')); ?></td>
                                                        <td><?php echo htmlspecialchars((string)$detail['quantity']); ?></td>
                                                        <td><?php echo htmlspecialchars(format_currency((float)$detail['total_cost'])); ?></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php else: ?>
                                    <p class="text-muted">No charge breakdown details found.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="card">
                            <div class="card-header"><h4>Exam Payment Status</h4></div>
                            <div class="card-body">
                                <?php if ($phase_statuses): ?>
                                    <div class="table-responsive">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th>Phase</th>
                                                    <th>Required Paid</th>
                                                    <th>Due Date</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($phase_statuses as $phase): ?>
                                                    <tr>
                                                        <td><?php echo htmlspecialchars($phase['label']); ?></td>
                                                        <td><?php echo htmlspecialchars(format_currency((float)$phase['required_paid'])); ?></td>
                                                        <td><?php echo htmlspecialchars(!empty($phase['due_date']) ? format_date($phase['due_date']) : 'Schedule Not Set'); ?></td>
                                                        <td><span class="badge badge-<?php echo $phase['is_paid'] ? 'success' : (!$phase['schedule_is_set'] ? 'secondary' : ($phase['is_overdue'] ? 'danger' : 'warning')); ?>"><?php echo $phase['is_paid'] ? 'Cleared' : (!$phase['schedule_is_set'] ? 'Schedule Not Set' : ($phase['is_overdue'] ? 'Overdue' : 'Payment Required')); ?></span></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php else: ?>
                                    <p class="text-muted">No exam payment status available.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header"><h4>Payment History</h4></div>
                    <div class="card-body">
                        <?php if ($payment_history): ?>
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Payment Date</th>
                                            <th>Amount Paid</th>
                                            <th>Payment Method</th>
                                            <th>Reference / Receipt</th>
                                            <th>Remarks</th>
                                            <th>Recorded By</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($payment_history as $payment): ?>
                                            <?php
                                                $recorded_name = trim((string)($payment['recorded_first_name'] ?? '') . ' ' . (string)($payment['recorded_last_name'] ?? ''));
                                                $recorded_by = $recorded_name !== '' ? $recorded_name . ' (' . $payment['recorded_role'] . ')' : 'System';
                                                $reference_text = $payment['reference_number'] ?: '-';
                                                if (!empty($payment['receipt_number'])) {
                                                    $reference_text .= ' / ' . $payment['receipt_number'];
                                                }
                                            ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars(format_date($payment['payment_date'])); ?></td>
                                                <td><?php echo htmlspecialchars(format_currency((float)$payment['amount'])); ?></td>
                                                <td><?php echo htmlspecialchars(ucwords(str_replace('_', ' ', $payment['payment_method']))); ?></td>
                                                <td><?php echo htmlspecialchars($reference_text); ?></td>
                                                <td><?php echo htmlspecialchars(ucfirst((string)$payment['status'])); ?></td>
                                                <td><?php echo htmlspecialchars($recorded_by); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">No payment history recorded for this student billing yet.</p>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </main>
</div>
<script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
