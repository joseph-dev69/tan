<?php
/**
 * Finance Sidebar Navigation
 * School Information System
 */

function render_finance_sidebar($active_page = 'dashboard')
{
    $items = [
        'dashboard' => ['label' => 'Dashboard', 'href' => APP_URL . '/modules/finance/dashboard.php'],
        'loads' => ['label' => 'Student Load', 'href' => APP_URL . '/modules/finance/student_loads.php'],
        'fees' => ['label' => 'Fee Schedules', 'href' => APP_URL . '/modules/finance/fee_schedules.php'],
        'payables' => ['label' => 'Student Payables', 'href' => APP_URL . '/modules/finance/student_payables.php'],
        'change_password' => ['label' => 'Change Password', 'href' => APP_URL . '/modules/account/change_password.php'],
    ];
    ?>
    <aside class="sidebar" id="sidebar">
        <ul class="sidebar-menu">
            <?php foreach ($items as $key => $item): ?>
                <li>
                    <a href="<?php echo $item['href']; ?>" class="<?php echo $active_page === $key ? 'active' : ''; ?>">
                        <span class="icon"><?php echo htmlspecialchars($item['label']); ?></span>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </aside>
    <?php
}
