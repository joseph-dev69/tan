<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/sidebar.php';
require_once __DIR__ . '/billing_helpers.php';

require_role('finance_officer');
$current_user = get_logged_in_user();

$school_years = get_multiple_results("SELECT school_year_id, year_name FROM school_years ORDER BY school_year_id DESC");
$current_school_year = get_single_result("SELECT * FROM school_years WHERE is_current = TRUE");
$current_semester = get_single_result("SELECT * FROM semesters WHERE is_current = TRUE");
$selected_school_year_id = (int)($_GET['school_year_id'] ?? ($current_school_year['school_year_id'] ?? 0));
$selected_semester_id = (int)($_GET['semester_id'] ?? ($current_semester['semester_id'] ?? 0));
$semester_selection = resolve_fixed_semester_selection(
    $selected_school_year_id,
    $selected_semester_id,
    $current_semester['semester_name'] ?? ''
);
$semesters = $semester_selection['options'];
$selected_semester_id = $semester_selection['semester_id'];
$selected_semester_name = $semester_selection['semester_name'];
$student_query = trim($_GET['student_query'] ?? '');
$selected_billing_id = (int)($_GET['billing_id'] ?? 0);
$finance_profile = get_single_result("SELECT * FROM finance_officers WHERE user_id = ?", [$current_user['user_id']]);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    $action = $_POST['action'] ?? '';

    if (!verify_csrf_token($csrf_token)) {
        flash_message('error', 'Invalid request token.');
        redirect('modules/finance/student_payables.php');
    }

    if ($action === 'sync_billing') {
        $enrollment_id = (int)($_POST['enrollment_id'] ?? 0);

        try {
            $result = finance_sync_billing_for_enrollment($enrollment_id);
            flash_message('success', 'Billing updated successfully. Remaining balance: ' . format_currency($result['balance']));
            $selected_billing_id = (int)$result['billing_id'];
        } catch (Exception $e) {
            error_log('Finance billing sync error: ' . $e->getMessage());
            flash_message('error', 'Unable to update this billing record.');
        }

        redirect('modules/finance/student_payables.php?school_year_id=' . $selected_school_year_id . '&semester_id=' . $selected_semester_id . '&student_query=' . urlencode($student_query) . '&billing_id=' . $selected_billing_id);
    }

    if ($action === 'record_payment') {
        $billing_id = (int)($_POST['billing_id'] ?? 0);
        $payment_date = $_POST['payment_date'] ?? date('Y-m-d');
        $amount = (float)($_POST['amount'] ?? 0);
        $payment_method = $_POST['payment_method'] ?? 'cash';
        try {
            if ($billing_id <= 0 || $amount <= 0) {
                throw new Exception('Invalid payment input.');
            }

            $conn = get_db_connection();
            $conn->beginTransaction();
            $reference_number = generate_payment_reference_number();

            $stmt = $conn->prepare("
                INSERT INTO payments (billing_id, payment_date, amount, payment_method, reference_number, processed_by, status)
                VALUES (?, ?, ?, ?, ?, ?, 'verified')
            ");
            $stmt->execute([
                $billing_id,
                $payment_date,
                $amount,
                $payment_method,
                $reference_number,
                $finance_profile['finance_officer_id'] ?? $current_user['user_id']
            ]);

            $updated_billing = finance_refresh_billing_totals($billing_id, $conn);

            $conn->commit();
            flash_message('success', 'Payment recorded and billing totals updated successfully. Status: ' . finance_get_status_label($updated_billing['status']) . '.');
        } catch (Exception $e) {
            if (isset($conn) && $conn instanceof PDO && $conn->inTransaction()) {
                $conn->rollBack();
            }
            error_log('Finance payment record error: ' . $e->getMessage());
            flash_message('error', 'Unable to record payment.');
        }

        redirect('modules/finance/student_payables.php?school_year_id=' . $selected_school_year_id . '&semester_id=' . $selected_semester_id . '&student_query=' . urlencode($student_query) . '&billing_id=' . $billing_id);
    }
}

$conditions = ["b.school_year_id = ?"];
$params = [$selected_school_year_id];
if ($selected_semester_name !== '') {
    $conditions[] = "EXISTS (
        SELECT 1
        FROM semesters sem_filter
        WHERE sem_filter.semester_id = b.semester_id
          AND sem_filter.semester_name = ?
    )";
    $params[] = $selected_semester_name;
}
if ($student_query !== '') {
    $conditions[] = "(s.student_number LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ?)";
    $like = '%' . $student_query . '%';
    array_push($params, $like, $like, $like);
}

$payables = get_multiple_results("
    SELECT b.billing_id, b.billing_date, b.total_amount, b.paid_amount, b.balance, b.status,
           s.student_number, u.first_name, u.last_name,
           c.course_code,
           e.enrollment_id
    FROM billings b
    JOIN students s ON b.student_id = s.student_id
    JOIN users u ON s.user_id = u.user_id
    LEFT JOIN courses c ON s.course_id = c.course_id
    LEFT JOIN enrollments e ON e.student_id = b.student_id AND e.school_year_id = b.school_year_id AND e.semester_id = b.semester_id
    WHERE " . implode(' AND ', $conditions) . "
    ORDER BY u.last_name, u.first_name, b.billing_date DESC
", $params);

if ($selected_billing_id <= 0 && !empty($payables)) {
    $selected_billing_id = (int)$payables[0]['billing_id'];
}

$selected_billing = null;
$billing_details = [];
$payment_history = [];
$phase_statuses = [];
$next_due_phase = 'prelim';
$phase_schedule = [];

if ($selected_billing_id > 0) {
    $selected_billing = get_single_result("
        SELECT b.*, sy.year_name, sem.semester_name,
               s.student_number, u.first_name, u.last_name, c.course_code, c.course_name
        FROM billings b
        JOIN students s ON b.student_id = s.student_id
        JOIN users u ON s.user_id = u.user_id
        LEFT JOIN courses c ON s.course_id = c.course_id
        JOIN school_years sy ON b.school_year_id = sy.school_year_id
        JOIN semesters sem ON b.semester_id = sem.semester_id
        WHERE b.billing_id = ?
    ", [$selected_billing_id]);

    if ($selected_billing) {
        $billing_details = get_multiple_results("
            SELECT bd.*, fs.fee_name, fs.fee_type
            FROM billing_details bd
            LEFT JOIN fee_schedules fs ON bd.fee_schedule_id = fs.fee_schedule_id
            WHERE bd.billing_id = ?
            ORDER BY fs.fee_type, fs.fee_name
        ", [$selected_billing_id]);

        $payment_history = get_multiple_results("
            SELECT p.*
            FROM payments p
            WHERE p.billing_id = ?
            ORDER BY p.payment_date DESC, p.payment_id DESC
        ", [$selected_billing_id]);

        $phase_statuses = finance_get_billing_phase_status($selected_billing);
        $next_due_phase = finance_get_next_due_phase($phase_statuses);
        $phase_schedule = finance_get_semester_phase_schedule((int)$selected_billing['school_year_id'], (int)$selected_billing['semester_id']);
    }
}

$flash_messages = get_flash_messages();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo generate_csrf_token(); ?>">
    <meta name="user-data" content="<?php echo htmlspecialchars(json_encode($current_user)); ?>">
    <title>Student Payables - School Information System</title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
</head>
<body>
<header class="header">
    <div class="container">
        <div class="logo"><a href="<?php echo APP_URL; ?>/modules/finance/dashboard.php">School Information System</a></div>
        <nav><ul class="nav"><li><a href="#" class="sidebar-toggle">Menu</a></li><li><a href="#">Welcome, <?php echo htmlspecialchars($current_user['first_name']); ?></a></li><li><a href="<?php echo APP_URL; ?>/modules/auth/logout.php">Logout</a></li></ul></nav>
    </div>
</header>
<div class="app-container">
    <?php render_finance_sidebar('payables'); ?>
    <main class="main-content">
        <div class="content-wrapper">
            <div class="page-header">
                <h1>Student Payable Fees</h1>
                <p>View student payable fees and billing per exam balance by school year and semester.</p>
            </div>

            <?php if ($flash_messages): ?>
                <div class="flash-messages mb-3">
                    <?php foreach ($flash_messages as $message): ?>
                        <div class="alert alert-<?php echo $message['type']; ?>">
                            <?php echo htmlspecialchars($message['message']); ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <div class="card mb-4">
                <div class="card-header"><h4>Filter Student Payables</h4></div>
                <div class="card-body">
                    <form method="GET" class="form-row">
                        <div class="form-group">
                            <label class="form-label" for="school_year_id">School Year</label>
                            <select class="form-control" id="school_year_id" name="school_year_id">
                                <?php foreach ($school_years as $school_year): ?>
                                    <option value="<?php echo (int)$school_year['school_year_id']; ?>" <?php echo (int)$school_year['school_year_id'] === $selected_school_year_id ? 'selected' : ''; ?>><?php echo htmlspecialchars($school_year['year_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="semester_id">Semester</label>
                            <select class="form-control" id="semester_id" name="semester_id">
                                <?php foreach ($semesters as $semester): ?>
                                    <option value="<?php echo (int)$semester['semester_id']; ?>" <?php echo (int)$semester['semester_id'] === $selected_semester_id ? 'selected' : ''; ?>><?php echo htmlspecialchars($semester['semester_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="student_query">Student Search</label>
                            <input class="form-control" type="text" id="student_query" name="student_query" value="<?php echo htmlspecialchars($student_query); ?>" placeholder="Student number or last name">
                        </div>
                        <div class="form-group" style="align-self:end;">
                            <button type="submit" class="btn btn-primary">Apply Filter</button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-header"><h4>Student Payable Fees / Billing</h4></div>
                <div class="card-body">
                    <?php if ($payables): ?>
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Student Number</th>
                                        <th>Name</th>
                                        <th>Course</th>
                                        <th>Billing Date</th>
                                        <th>Total Amount</th>
                                        <th>Paid</th>
                                        <th>Balance</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($payables as $row): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($row['student_number']); ?></td>
                                            <td><?php echo htmlspecialchars($row['last_name'] . ', ' . $row['first_name']); ?></td>
                                            <td><?php echo htmlspecialchars($row['course_code'] ?? 'N/A'); ?></td>
                                            <td><?php echo htmlspecialchars($row['billing_date']); ?></td>
                                            <td><?php echo htmlspecialchars(format_currency((float)$row['total_amount'])); ?></td>
                                            <td><?php echo htmlspecialchars(format_currency((float)$row['paid_amount'])); ?></td>
                                            <td><?php echo htmlspecialchars(format_currency((float)$row['balance'])); ?></td>
                                            <td><span class="badge badge-info"><?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $row['status']))); ?></span></td>
                                            <td style="display:flex;gap:.5rem;flex-wrap:wrap;">
                                                <a href="<?php echo APP_URL; ?>/modules/finance/payment_record.php?billing_id=<?php echo (int)$row['billing_id']; ?>" class="btn btn-sm btn-primary">Open</a>
                                                <?php if (!empty($row['enrollment_id'])): ?>
                                                    <form method="POST" action="">
                                                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                                        <input type="hidden" name="action" value="sync_billing">
                                                        <input type="hidden" name="enrollment_id" value="<?php echo (int)$row['enrollment_id']; ?>">
                                                        <button type="submit" class="btn btn-sm btn-secondary">Update</button>
                                                    </form>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-muted">No student payable records found for the selected filters.</p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="row" style="margin-top:1.5rem;">
                <div class="col-6">
                    <div class="card">
                        <div class="card-header"><h4>Billing Breakdown</h4></div>
                        <div class="card-body">
                            <?php if ($selected_billing): ?>
                                <p><strong><?php echo htmlspecialchars($selected_billing['student_number']); ?></strong> - <?php echo htmlspecialchars($selected_billing['last_name'] . ', ' . $selected_billing['first_name']); ?></p>
                                <p class="text-muted"><?php echo htmlspecialchars(($selected_billing['course_code'] ?? 'N/A') . (!empty($selected_billing['course_name']) ? ' - ' . $selected_billing['course_name'] : '')); ?> | <?php echo htmlspecialchars($selected_billing['year_name'] . ' / ' . $selected_billing['semester_name']); ?></p>
                                <?php if ($billing_details): ?>
                                    <div class="table-responsive">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th>Charge</th>
                                                    <th>Type</th>
                                                    <th>Qty</th>
                                                    <th>Unit Cost</th>
                                                    <th>Total</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($billing_details as $detail): ?>
                                                    <tr>
                                                        <td><?php echo htmlspecialchars($detail['fee_name'] ?? 'Manual Charge'); ?></td>
                                                        <td><?php echo htmlspecialchars(ucfirst($detail['fee_type'] ?? 'other')); ?></td>
                                                        <td><?php echo htmlspecialchars((string)$detail['quantity']); ?></td>
                                                        <td><?php echo htmlspecialchars(format_currency((float)$detail['unit_cost'])); ?></td>
                                                        <td><?php echo htmlspecialchars(format_currency((float)$detail['total_cost'])); ?></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php else: ?>
                                    <p class="text-muted">No billing breakdown details found.</p>
                                <?php endif; ?>
                            <?php else: ?>
                                <p class="text-muted">Open a billing record to view its charge breakdown.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div class="card">
                        <div class="card-header"><h4>Payment History</h4></div>
                        <div class="card-body">
                            <?php if ($selected_billing): ?>
                                <div class="card mb-3" style="box-shadow:none;border:1px solid var(--border-color);">
                                    <div class="card-body">
                                        <p><strong>Computed Exam Due Dates</strong></p>
                                        <?php if (!empty($phase_schedule)): ?>
                                            <p class="text-muted">
                                                Semester Timeline:
                                                <?php echo htmlspecialchars($phase_schedule['semester_start_date']); ?>
                                                to
                                                <?php echo htmlspecialchars($phase_schedule['semester_end_date']); ?>
                                            </p>
                                            <div class="table-responsive">
                                                <table class="table table-sm">
                                                    <thead>
                                                        <tr>
                                                            <th>Phase</th>
                                                            <th>Due Date</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>Prelim</td>
                                                            <td><?php echo htmlspecialchars($phase_schedule['prelim']['due_date']); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Midterm</td>
                                                            <td><?php echo htmlspecialchars($phase_schedule['midterm']['due_date']); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Final</td>
                                                            <td><?php echo htmlspecialchars($phase_schedule['final']['due_date']); ?></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        <?php else: ?>
                                            <p class="text-muted">Schedule Not Set</p>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="card mb-3" style="box-shadow:none;border:1px solid var(--border-color);">
                                    <div class="card-body">
                                        <p><strong>Exam Payment Status</strong></p>
                                        <p class="text-muted">Next payment priority: <?php echo htmlspecialchars(ucfirst($next_due_phase)); ?></p>
                                        <div class="table-responsive">
                                            <table class="table table-sm">
                                                <thead>
                                                    <tr>
                                                        <th>Phase</th>
                                                        <th>Exam Amount</th>
                                                        <th>Required Paid</th>
                                                        <th>Due Date</th>
                                                        <th>Verified Paid</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php foreach ($phase_statuses as $phase): ?>
                                                        <tr>
                                                            <td><?php echo htmlspecialchars($phase['label']); ?></td>
                                                            <td><?php echo htmlspecialchars(format_currency((float)$phase['amount'])); ?></td>
                                                            <td><?php echo htmlspecialchars(format_currency((float)$phase['required_paid'])); ?></td>
                                                            <td><?php echo htmlspecialchars(!empty($phase['due_date']) ? format_date($phase['due_date']) : 'Schedule Not Set'); ?></td>
                                                            <td><?php echo htmlspecialchars(format_currency((float)$phase['paid_amount'])); ?></td>
                                                            <td><span class="badge badge-<?php echo $phase['is_paid'] ? 'success' : (!$phase['schedule_is_set'] ? 'secondary' : ($phase['is_overdue'] ? 'danger' : 'warning')); ?>"><?php echo $phase['is_paid'] ? 'Cleared' : (!$phase['schedule_is_set'] ? 'Schedule Not Set' : ($phase['is_overdue'] ? 'Overdue' : 'Payment Required')); ?></span></td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>

                                <div class="card mb-3" style="box-shadow:none;border:1px solid var(--border-color);">
                                    <div class="card-body">
                                        <form method="POST" action="" class="form-row">
                                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                            <input type="hidden" name="action" value="record_payment">
                                            <input type="hidden" name="billing_id" value="<?php echo (int)$selected_billing['billing_id']; ?>">

                                            <div class="form-group">
                                                <label class="form-label" for="payment_date">Payment Date</label>
                                                <input class="form-control" type="date" id="payment_date" name="payment_date" value="<?php echo htmlspecialchars(date('Y-m-d')); ?>">
                                            </div>
                                            <div class="form-group">
                                                <label class="form-label" for="amount">Amount</label>
                                                <input class="form-control" type="number" min="0.01" step="0.01" id="amount" name="amount" placeholder="0.00">
                                            </div>
                                            <div class="form-group">
                                                <label class="form-label" for="payment_method">Method</label>
                                                <select class="form-control" id="payment_method" name="payment_method">
                                                    <option value="cash">Cash</option>
                                                    <option value="check">Check</option>
                                                    <option value="bank_transfer">Bank Transfer</option>
                                                    <option value="credit_card">Credit Card</option>
                                                    <option value="online_payment">Online Payment</option>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label class="form-label" for="reference_number">Reference</label>
                                                <input class="form-control" type="text" id="reference_number" value="Auto-generated when recorded" readonly>
                                            </div>
                                            <div class="form-group" style="align-self:end;">
                                                <button type="submit" class="btn btn-success">Record Payment</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>

                                <?php if ($payment_history): ?>
                                    <div class="table-responsive">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th>Date</th>
                                                    <th>Amount</th>
                                                    <th>Method</th>
                                                    <th>Reference</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($payment_history as $payment): ?>
                                                    <tr>
                                                        <td><?php echo htmlspecialchars($payment['payment_date']); ?></td>
                                                        <td><?php echo htmlspecialchars(format_currency((float)$payment['amount'])); ?></td>
                                                        <td><?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $payment['payment_method']))); ?></td>
                                                        <td><?php echo htmlspecialchars($payment['reference_number'] ?: '-'); ?></td>
                                                        <td><?php echo htmlspecialchars(ucfirst($payment['status'])); ?></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php else: ?>
                                    <p class="text-muted">No payment history recorded for this billing yet.</p>
                                <?php endif; ?>
                            <?php else: ?>
                                <p class="text-muted">Open a billing record to view payment history.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>
<script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
</body>
</html>
