# School Information System - Complete Design Document

## 1. System Overview

The School Information System (SIS) is a comprehensive web-based application designed to automate and streamline the administrative and academic operations of a college or university. Built using pure PHP, MySQL, JavaScript, HTML, and CSS, this system provides a robust platform for managing student information, enrollment processes, academic records, grading, billing, and financial operations.

### 1.1 System Objectives
- Centralize all student and academic data management
- Automate enrollment and registration workflows
- Streamline grade encoding and academic record management
- Simplify billing and payment processing
- Provide role-based access control for different user types
- Ensure data security and integrity
- Support multiple academic periods (school years and semesters)
- Generate comprehensive reports for administrative decision-making

### 1.2 Target Users
The system serves seven distinct user roles, each with specific responsibilities and access levels:
1. **Administrator** - System management and user administration
2. **Student** - Enrollment, grades, and account management
3. **Teacher** - Grade encoding and class management
4. **Dean/Program Head** - Academic program management
5. **Records Officer** - Academic records and transcript management
6. **Finance Officer** - Fee management and billing
7. **Cashier** - Payment processing and receipt generation

## 2. Functional Requirements

### 2.1 Authentication and User Management
- **FR-001**: User registration system for all roles except Admin
- **FR-002**: Admin approval workflow for new registrations
- **FR-003**: Secure login/logout functionality
- **FR-004**: Role-based access control (RBAC)
- **FR-005**: Session management and timeout
- **FR-006**: Password hashing and reset functionality
- **FR-007**: User profile management

### 2.2 Academic Management
- **FR-008**: School year and semester management
- **FR-009**: Department and course management
- **FR-010**: Subject catalog management
- **FR-011**: Subject offering creation per semester
- **FR-012**: Class scheduling and room assignment
- **FR-013**: Teacher assignment to subjects

### 2.3 Enrollment Management
- **FR-014**: Online enrollment application form
- **FR-015**: Subject selection and validation
- **FR-016**: Add/drop subjects functionality
- **FR-017**: Enrollment approval workflow
- **FR-018**: Schedule viewing and printing

### 2.4 Grade Management
- **FR-019**: Grade encoding by authorized teachers
- **FR-020**: Grade calculation and finalization
- **FR-021**: Grade viewing for students
- **FR-022**: Remarks and feedback system
- **FR-023**: Grade sheet printing

### 2.5 Financial Management
- **FR-024**: Fee structure management
- **FR-025**: Student billing generation
- **FR-026**: Payment processing and recording
- **FR-027**: Receipt generation and printing
- **FR-028**: Balance tracking and monitoring

### 2.6 Records Management
- **FR-029**: Academic record maintenance
- **FR-030**: Transcript of Records generation
- **FR-031**: Grade history tracking
- **FR-032**: Enrollment verification

### 2.7 Reporting
- **FR-033**: Enrollment statistics reports
- **FR-034**: Academic performance reports
- **FR-035**: Financial collection reports
- **FR-036**: System activity logs
- **FR-037**: Custom report generation

## 3. Non-Functional Requirements

### 3.1 Performance Requirements
- **NFR-001**: System response time < 3 seconds for standard operations
- **NFR-002**: Support concurrent users: 100+ simultaneous users
- **NFR-003**: Database query optimization for large datasets
- **NFR-004**: Efficient file handling for reports and documents

### 3.2 Security Requirements
- **NFR-005**: SQL injection prevention using prepared statements
- **NFR-006**: XSS protection through input sanitization
- **NFR-007**: CSRF protection for state-changing operations
- **NFR-008**: Secure password hashing (bcrypt)
- **NFR-009**: Session security and timeout management
- **NFR-010**: Role-based access control enforcement
- **NFR-011**: Audit logging for all critical operations

### 3.3 Usability Requirements
- **NFR-012**: Responsive design for desktop and mobile devices
- **NFR-013**: Intuitive user interface with clear navigation
- **NFR-014**: Consistent design language across all modules
- **NFR-015**: Error handling with user-friendly messages
- **NFR-016**: Form validation with real-time feedback

### 3.4 Reliability Requirements
- **NFR-017**: System availability: 99% uptime
- **NFR-018**: Data integrity and consistency
- **NFR-019**: Regular backup procedures
- **NFR-020**: Error recovery mechanisms

### 3.5 Maintainability Requirements
- **NFR-021**: Modular code structure
- **NFR-022**: Comprehensive code documentation
- **NFR-023**: Standardized coding conventions
- **NFR-024**: Easy configuration management

## 4. Role-Based Access Matrix

| Feature | Admin | Student | Teacher | Dean | Records | Finance | Cashier |
|---------|-------|---------|---------|------|---------|---------|---------|
| **Authentication** |
| Register Account | No | Yes | Yes | Yes | Yes | Yes | Yes |
| Login/Logout | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| **User Management** |
| View All Users | Yes | No | No | No | No | No | No |
| Approve Registrations | Yes | No | No | No | No | No | No |
| Edit User Profiles | Yes | Self | Self | Self | Self | Self | Self |
| **Academic Management** |
| Manage School Years | Yes | No | No | Yes | No | No | No |
| Manage Departments | Yes | No | View | Yes | View | View | View |
| Manage Courses | Yes | No | View | Yes | View | View | View |
| Manage Subjects | Yes | No | View | Yes | View | View | View |
| Create Subject Offerings | No | No | No | Yes | No | No | No |
| Assign Teachers | No | No | No | Yes | No | No | No |
| Manage Schedules | No | No | No | Yes | No | No | No |
| **Enrollment** |
| Apply for Enrollment | No | Yes | No | No | Yes | No | No |
| Approve Enrollment | Yes | No | No | Yes | Yes | No | No |
| Add/Drop Subjects | No | Yes | No | No | No | No | No |
| View Enrolled Subjects | Yes | Own | Own Classes | Dept | All | All | All |
| **Grade Management** |
| Encode Grades | No | No | Yes | No | No | No | No |
| View Grades | Yes | Own | Own Classes | Dept | All | All | All |
| Update Grades | No | No | Yes | No | No | No | No |
| Print Grade Sheets | Yes | No | Yes | No | Yes | No | No |
| **Financial Management** |
| Manage Fee Structure | Yes | No | No | No | No | Yes | No |
| Generate Billing | No | No | No | No | No | Yes | No |
| Receive Payments | No | No | No | No | No | No | Yes |
| View Financial Reports | Yes | Own | No | Dept | All | All | All |
| **Records Management** |
| View Academic Records | Yes | Own | Own Classes | Dept | All | All | All |
| Print Transcripts | Yes | No | No | No | Yes | No | No |
| **System Administration** |
| System Settings | Yes | No | No | No | No | No | No |
| View Audit Logs | Yes | No | No | No | No | No | No |

## 5. Complete Module Breakdown

### 5.1 Authentication Module
**Components:**
- Registration form with role selection
- Login/logout functionality
- Session management
- Password reset system
- Profile management

**Key Features:**
- Email verification for registration
- Admin approval workflow
- Secure password hashing
- Session timeout handling
- Remember me functionality

### 5.2 Administrator Module
**Components:**
- User management dashboard
- Registration approval interface
- System configuration
- Academic period management
- Department and course management
- Report generation tools

**Key Features:**
- Bulk user operations
- System statistics dashboard
- Audit log viewing
- Backup and restore utilities
- Email template management

### 5.3 Student Module
**Components:**
- Enrollment application form
- Subject selection interface
- Schedule viewer
- Grade viewer
- Account balance viewer
- Payment history

**Key Features:**
- Real-time enrollment status
- Interactive subject selection
- Printable schedules and grades
- Online payment status
- Academic progress tracking

### 5.4 Dean/Program Head Module
**Components:**
- Subject offering management
- Teacher assignment interface
- Schedule management
- Enrollment statistics
- Curriculum management

**Key Features:**
- Drag-and-drop scheduling
- Conflict detection
- Teacher workload monitoring
- Program performance metrics
- Curriculum planning tools

### 5.5 Teacher Module
**Components:**
- Class schedule viewer
- Student roster management
- Grade encoding interface
- Grade sheet printing
- Class statistics

**Key Features:**
- Bulk grade encoding
- Grade calculation automation
- Student performance analytics
- Attendance tracking
- Communication tools

### 5.6 Records Officer Module
**Components:**
- Academic record viewer
- Transcript generator
- Grade verification tools
- Enrollment history
- Report generation

**Key Features:**
- Official transcript printing
- Grade validation tools
- Academic standing calculations
- Record correction workflow
- Statistical reporting

### 5.7 Finance Officer Module
**Components:**
- Fee structure management
- Billing generation
- Financial reporting
- Account monitoring
- Payment tracking

**Key Features:**
- Automated billing calculations
- Discount and scholarship management
- Financial analytics dashboard
- Export to accounting systems
- Payment reminder system

### 5.8 Cashier Module
**Components:**
- Payment processing interface
- Receipt generation
- Daily collection reports
- Payment history viewer
- Cash reconciliation

**Key Features:**
- Multiple payment methods
- Automatic receipt generation
- Daily cash counting
- Over/short reporting
- Payment verification

## 6. User Workflows

### 6.1 Student Registration and Enrollment Workflow
```
1. User Registration
   Student fills registration form
   System sends email notification
   Admin reviews registration
   Admin approves/rejects registration
   System sends approval/rejection email

2. Account Activation
   Student receives approval email
   Student logs in for first time
   Student changes temporary password
   Student completes profile information

3. Enrollment Application
   Student accesses enrollment portal
   Student selects current semester
   System displays available subjects
   Student selects desired subjects
   System validates prerequisites
   Student submits enrollment application

4. Enrollment Processing
   Records officer reviews application
   System validates enrollment requirements
   Records officer approves enrollment
   System generates student account
   Finance officer creates billing statement
   Student receives enrollment confirmation

5. Payment and Finalization
   Student views billing statement
   Student proceeds to cashier for payment
   Cashier records payment
   System updates student status to "Enrolled"
   Student can now view schedule and access services
```

### 6.2 Grade Encoding Workflow
```
1. Grade Period Setup
   Admin sets grade submission deadlines
   System notifies teachers of upcoming deadlines
   Teachers prepare grade sheets

2. Grade Encoding
   Teacher logs into system
   Teacher selects class and grading period
   System displays student roster
   Teacher inputs grades and remarks
   System validates grade entries
   Teacher saves draft grades

3. Grade Review and Submission
   Teacher reviews entered grades
   Teacher makes necessary corrections
   Teacher submits final grades
   System records submission timestamp

4. Grade Processing
   Department head reviews submitted grades
   Department head approves or returns grades
   System calculates final grades
   System updates student academic records
   Students receive grade notifications

5. Grade Posting
   System posts grades to student portals
   Students can view grades online
   Teachers can print grade sheets
   Records office updates academic records
```

### 6.3 Payment Processing Workflow
```
1. Billing Generation
   Finance officer sets fee structures
   System calculates student assessments
   System generates billing statements
   Students receive billing notifications

2. Payment Processing
   Student presents billing statement to cashier
   Cashier verifies student identity and balance
   Student makes payment (cash/check/etc.)
   Cashier records payment details
   System generates official receipt

3. Account Update
   System updates student account balance
   System sends payment confirmation
   Student account status updated
- Financial reports updated automatically

4. Reconciliation
   Cashier generates daily collection report
   Finance officer reviews daily transactions
   System performs automatic reconciliation
   Discrepancies identified and resolved
```

## 7. Use Case Descriptions

### 7.1 UC-001: User Registration
**Actor:** Student, Teacher, Dean, Records Officer, Finance Officer, Cashier
**Description:** New users create accounts in the system
**Preconditions:** None
**Postconditions:** User account created with "pending" status
**Main Flow:**
1. User navigates to registration page
2. User selects role from dropdown
3. User fills required personal information
4. User enters email and password
5. System validates input data
6. System creates user account with "pending" status
7. System sends notification email to admin
8. System displays confirmation message to user

**Alternative Flow:**
- If validation fails, display error messages and allow corrections
- If email already exists, prompt user to login or reset password

### 7.2 UC-002: Admin Registration Approval
**Actor:** Administrator
**Description:** Admin reviews and approves new user registrations
**Preconditions:** User registration exists with "pending" status
**Postconditions:** User account status updated to "approved" or "rejected"
**Main Flow:**
1. Admin logs into system
2. Admin navigates to user management
3. Admin views pending registrations list
4. Admin selects user to review
5. Admin reviews user information
6. Admin approves or rejects registration
7. System updates user status
8. System sends notification email to user
9. System updates audit log

### 7.3 UC-003: Student Enrollment
**Actor:** Student
**Description:** Student applies for enrollment and selects subjects
**Preconditions:** Student account is approved, enrollment period is open
**Postconditions:** Enrollment application submitted for approval
**Main Flow:**
1. Student logs into system
2. Student navigates to enrollment portal
3. Student selects current school year and semester
4. System displays available courses and subjects
5. Student selects desired subjects
6. System validates subject selection
7. System checks prerequisites
8. Student submits enrollment application
9. System displays enrollment confirmation

### 7.4 UC-004: Grade Encoding
**Actor:** Teacher
**Description:** Teacher encodes grades for assigned subjects
**Preconditions:** Teacher is assigned to subject, grade period is open
**Postconditions:** Grades recorded in system
**Main Flow:**
1. Teacher logs into system
2. Teacher navigates to grade encoding
3. Teacher selects subject and grading period
4. System displays student roster
5. Teacher inputs grades for each student
6. System validates grade entries
7. Teacher saves grades
8. System confirms grade submission

### 7.5 UC-005: Payment Processing
**Actor:** Cashier
**Description:** Cashier receives and records student payments
**Preconditions:** Student has outstanding balance
**Postconditions:** Payment recorded, receipt generated
**Main Flow:**
1. Cashier logs into system
2. Student presents billing statement
3. Cashier searches student account
4. System displays student balance
5. Cashier enters payment details
6. System calculates remaining balance
7. Cashier confirms payment
8. System generates official receipt
9. System updates student account

## 8. ERD Explanation

### 8.1 Core Entities Relationship Overview

The database design follows a normalized relational model with the following key entity relationships:

```
USERS (Central Entity)
    |
    |-- STUDENTS (1:1)
    |-- TEACHERS (1:1)
    |-- RECORDS_OFFICERS (1:1)
    |-- FINANCE_OFFICERS (1:1)
    |-- CASHIERS (1:1)

ACADEMIC STRUCTURE:
    |
    |-- SCHOOL_YEARS
    |       |-- SEMESTERS
    |               |-- COURSE_OFFERINGS
    |               |-- SUBJECT_OFFERINGS
    |                       |-- SCHEDULES

ACADEMIC ENTITIES:
    |
    |-- DEPARTMENTS
    |       |-- COURSES
    |               |-- SUBJECTS
    |                       |-- PREREQUISITES (Self-referencing)

ENROLLMENT FLOW:
    |
    |-- ENROLLMENTS
    |       |-- STUDENT_SUBJECT_LOADS
    |               |-- GRADES
    |               |-- REMARKS

FINANCIAL ENTITIES:
    |
    |-- FEE_SCHEDULES
    |       |-- BILLINGS
    |               |-- PAYMENTS
    |                       |-- RECEIPTS

RECORDS ENTITIES:
    |
    |-- ACADEMIC_RECORDS
    |-- TRANSCRIPT_REQUESTS
```

### 8.2 Key Relationships Explained

**User Management:**
- Each user can have only one role-specific profile (student, teacher, etc.)
- This ensures data integrity and role separation

**Academic Structure:**
- School years contain multiple semesters
- Each semester has multiple course and subject offerings
- Subjects can have prerequisites (self-referencing relationship)

**Enrollment Process:**
- Students enroll in course offerings for specific semesters
- Each enrollment contains multiple subject loads
- Grades and remarks are linked to specific subject loads

**Financial System:**
- Fee schedules define pricing for different courses/semesters
- Billings are generated per student per semester
- Payments are linked to specific billing entries

**Records Management:**
- Academic records aggregate all student grade information
- Transcript requests track official document generation

## 9. Normalized MySQL Database Schema

### 9.1 Schema Normalization Levels

**First Normal Form (1NF):** All tables have primary keys, no repeating groups
**Second Normal Form (2NF):** All non-key attributes depend on the entire primary key
**Third Normal Form (3NF):** No transitive dependencies, proper foreign key relationships

### 9.2 Database Design Principles

- **Atomic Values:** Each field contains single, indivisible values
- **Proper Relationships:** Foreign keys maintain referential integrity
- **No Redundancy:** Data is stored only once to avoid update anomalies
- **Scalability:** Design supports growth in users and data volume
- **Performance:** Proper indexing for frequently queried fields

## 10. SQL CREATE TABLE Statements

### 10.1 Core Tables

```sql
-- Users table (central authentication table)
CREATE TABLE users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role_id INT NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    middle_name VARCHAR(50),
    status ENUM('pending', 'approved', 'rejected', 'inactive') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    FOREIGN KEY (role_id) REFERENCES roles(role_id)
);

-- Roles table
CREATE TABLE roles (
    role_id INT PRIMARY KEY AUTO_INCREMENT,
    role_name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default roles
INSERT INTO roles (role_name, description) VALUES
('admin', 'System Administrator'),
('student', 'Student'),
('teacher', 'Teacher'),
('dean', 'Dean/Program Head'),
('records', 'Records Officer'),
('finance', 'Finance Officer'),
('cashier', 'Cashier');
```

### 10.2 Academic Structure Tables

```sql
-- School years table
CREATE TABLE school_years (
    school_year_id INT PRIMARY KEY AUTO_INCREMENT,
    year_start INT NOT NULL,
    year_end INT NOT NULL,
    status ENUM('upcoming', 'current', 'completed') DEFAULT 'upcoming',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_year (year_start, year_end)
);

-- Semesters table
CREATE TABLE semesters (
    semester_id INT PRIMARY KEY AUTO_INCREMENT,
    school_year_id INT NOT NULL,
    semester_name ENUM('First', 'Second', 'Summer') NOT NULL,
    status ENUM('upcoming', 'current', 'completed') DEFAULT 'upcoming',
    start_date DATE,
    end_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (school_year_id) REFERENCES school_years(school_year_id),
    UNIQUE KEY unique_semester (school_year_id, semester_name)
);

-- Departments table
CREATE TABLE departments (
    department_id INT PRIMARY KEY AUTO_INCREMENT,
    department_code VARCHAR(20) UNIQUE NOT NULL,
    department_name VARCHAR(100) NOT NULL,
    description TEXT,
    head_name VARCHAR(100),
    contact_number VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Courses table
CREATE TABLE courses (
    course_id INT PRIMARY KEY AUTO_INCREMENT,
    department_id INT NOT NULL,
    course_code VARCHAR(20) UNIQUE NOT NULL,
    course_name VARCHAR(100) NOT NULL,
    description TEXT,
    degree_type ENUM('Bachelor', 'Master', 'Doctorate') DEFAULT 'Bachelor',
    duration_years INT DEFAULT 4,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(department_id)
);

-- Subjects table
CREATE TABLE subjects (
    subject_id INT PRIMARY KEY AUTO_INCREMENT,
    course_id INT NOT NULL,
    subject_code VARCHAR(20) UNIQUE NOT NULL,
    subject_title VARCHAR(100) NOT NULL,
    description TEXT,
    units FLOAT NOT NULL DEFAULT 1,
    lecture_hours FLOAT DEFAULT 0,
    lab_hours FLOAT DEFAULT 0,
    year_level INT,
    semester_offered ENUM('First', 'Second', 'Summer', 'Any') DEFAULT 'Any',
    is_elective BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(course_id)
);

-- Subject prerequisites (self-referencing)
CREATE TABLE subject_prerequisites (
    prerequisite_id INT PRIMARY KEY AUTO_INCREMENT,
    subject_id INT NOT NULL,
    prerequisite_subject_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id),
    FOREIGN KEY (prerequisite_subject_id) REFERENCES subjects(subject_id),
    UNIQUE KEY unique_prerequisite (subject_id, prerequisite_subject_id)
);
```

### 10.3 User Profile Tables

```sql
-- Students table
CREATE TABLE students (
    student_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT UNIQUE NOT NULL,
    student_number VARCHAR(20) UNIQUE NOT NULL,
    course_id INT NOT NULL,
    year_level INT DEFAULT 1,
    section VARCHAR(20),
    admission_date DATE,
    birth_date DATE,
    gender ENUM('Male', 'Female', 'Other'),
    civil_status ENUM('Single', 'Married', 'Widowed', 'Separated'),
    address_province VARCHAR(100),
    address_city VARCHAR(100),
    address_barangay VARCHAR(100),
    address_street VARCHAR(100),
    address_house_number VARCHAR(20),
    phone_number VARCHAR(20),
    emergency_contact_name VARCHAR(100),
    emergency_contact_number VARCHAR(20),
    guardian_name VARCHAR(100),
    guardian_contact VARCHAR(20),
    guardian_address TEXT,
    enrollment_status ENUM('Not Enrolled', 'Enrolled', 'Graduated', 'Dropped') DEFAULT 'Not Enrolled',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (course_id) REFERENCES courses(course_id)
);

-- Teachers table
CREATE TABLE teachers (
    teacher_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT UNIQUE NOT NULL,
    employee_number VARCHAR(20) UNIQUE NOT NULL,
    department_id INT NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    middle_name VARCHAR(50),
    birth_date DATE,
    gender ENUM('Male', 'Female', 'Other'),
    civil_status ENUM('Single', 'Married', 'Widowed', 'Separated'),
    address TEXT,
    phone_number VARCHAR(20),
    email VARCHAR(100),
    employment_type ENUM('Full-time', 'Part-time', 'Contractual'),
    specialization VARCHAR(100),
    rank VARCHAR(50),
    hire_date DATE,
    status ENUM('Active', 'Inactive', 'On Leave') DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (department_id) REFERENCES departments(department_id)
);

-- Records officers table
CREATE TABLE records_officers (
    records_officer_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT UNIQUE NOT NULL,
    employee_number VARCHAR(20) UNIQUE NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    middle_name VARCHAR(50),
    phone_number VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Finance officers table
CREATE TABLE finance_officers (
    finance_officer_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT UNIQUE NOT NULL,
    employee_number VARCHAR(20) UNIQUE NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    middle_name VARCHAR(50),
    phone_number VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Cashiers table
CREATE TABLE cashiers (
    cashier_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT UNIQUE NOT NULL,
    employee_number VARCHAR(20) UNIQUE NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    middle_name VARCHAR(50),
    phone_number VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);
```

### 10.4 Subject Offering and Scheduling Tables

```sql
-- Subject offerings table
CREATE TABLE subject_offerings (
    offering_id INT PRIMARY KEY AUTO_INCREMENT,
    subject_id INT NOT NULL,
    teacher_id INT NOT NULL,
    semester_id INT NOT NULL,
    section VARCHAR(20),
    max_students INT DEFAULT 40,
    current_students INT DEFAULT 0,
    status ENUM('Open', 'Closed', 'Cancelled') DEFAULT 'Open',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id),
    FOREIGN KEY (teacher_id) REFERENCES teachers(teacher_id),
    FOREIGN KEY (semester_id) REFERENCES semesters(semester_id)
);

-- Schedules table
CREATE TABLE schedules (
    schedule_id INT PRIMARY KEY AUTO_INCREMENT,
    offering_id INT NOT NULL,
    day_of_week ENUM('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday') NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    room VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (offering_id) REFERENCES subject_offerings(offering_id)
);
```

### 10.5 Enrollment and Grade Tables

```sql
-- Enrollments table
CREATE TABLE enrollments (
    enrollment_id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    semester_id INT NOT NULL,
    course_id INT NOT NULL,
    year_level INT NOT NULL,
    enrollment_date DATE NOT NULL,
    status ENUM('Pending', 'Approved', 'Rejected', 'Completed') DEFAULT 'Pending',
    approved_by INT,
    approved_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (semester_id) REFERENCES semesters(semester_id),
    FOREIGN KEY (course_id) REFERENCES courses(course_id),
    FOREIGN KEY (approved_by) REFERENCES users(user_id),
    UNIQUE KEY unique_enrollment (student_id, semester_id)
);

-- Student subject loads table
CREATE TABLE student_subject_loads (
    load_id INT PRIMARY KEY AUTO_INCREMENT,
    enrollment_id INT NOT NULL,
    offering_id INT NOT NULL,
    status ENUM('Enrolled', 'Dropped', 'Completed') DEFAULT 'Enrolled',
    grade_final FLOAT NULL,
    remarks TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (enrollment_id) REFERENCES enrollments(enrollment_id),
    FOREIGN KEY (offering_id) REFERENCES subject_offerings(offering_id),
    UNIQUE KEY unique_load (enrollment_id, offering_id)
);

-- Grades table
CREATE TABLE grades (
    grade_id INT PRIMARY KEY AUTO_INCREMENT,
    load_id INT NOT NULL,
    grading_period ENUM('Prelim', 'Midterm', 'Pre-Final', 'Final') NOT NULL,
    grade FLOAT NOT NULL,
    encoded_by INT NOT NULL,
    encoded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_by INT,
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (load_id) REFERENCES student_subject_loads(load_id),
    FOREIGN KEY (encoded_by) REFERENCES users(user_id),
    FOREIGN KEY (updated_by) REFERENCES users(user_id),
    UNIQUE KEY unique_grade (load_id, grading_period)
);
```

### 10.6 Financial Tables

```sql
-- Fee schedules table
CREATE TABLE fee_schedules (
    fee_id INT PRIMARY KEY AUTO_INCREMENT,
    course_id INT NOT NULL,
    semester_id INT NOT NULL,
    fee_type ENUM('Tuition', 'Miscellaneous', 'Laboratory', 'Library', 'Athletic', 'Other') NOT NULL,
    fee_name VARCHAR(100) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    is_per_unit BOOLEAN DEFAULT FALSE,
    unit_rate DECIMAL(10,2) NULL,
    is_required BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(course_id),
    FOREIGN KEY (semester_id) REFERENCES semesters(semester_id)
);

-- Billings table
CREATE TABLE billings (
    billing_id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    semester_id INT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    paid_amount DECIMAL(10,2) DEFAULT 0,
    balance DECIMAL(10,2) GENERATED ALWAYS AS (total_amount - paid_amount) STORED,
    status ENUM('Unpaid', 'Partially Paid', 'Fully Paid') DEFAULT 'Unpaid',
    billing_date DATE NOT NULL,
    due_date DATE NOT NULL,
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (semester_id) REFERENCES semesters(semester_id),
    FOREIGN KEY (created_by) REFERENCES users(user_id),
    UNIQUE KEY unique_billing (student_id, semester_id)
);

-- Billing details table
CREATE TABLE billing_details (
    billing_detail_id INT PRIMARY KEY AUTO_INCREMENT,
    billing_id INT NOT NULL,
    fee_id INT NOT NULL,
    quantity INT DEFAULT 1,
    unit_amount DECIMAL(10,2) NOT NULL,
    total_amount DECIMAL(10,2) GENERATED ALWAYS AS (quantity * unit_amount) STORED,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (billing_id) REFERENCES billings(billing_id),
    FOREIGN KEY (fee_id) REFERENCES fee_schedules(fee_id)
);

-- Payments table
CREATE TABLE payments (
    payment_id INT PRIMARY KEY AUTO_INCREMENT,
    billing_id INT NOT NULL,
    student_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_method ENUM('Cash', 'Check', 'Bank Transfer', 'Credit Card', 'Other') NOT NULL,
    payment_date DATE NOT NULL,
    reference_number VARCHAR(50),
    notes TEXT,
    received_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (billing_id) REFERENCES billings(billing_id),
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (received_by) REFERENCES users(user_id)
);

-- Receipts table
CREATE TABLE receipts (
    receipt_id INT PRIMARY KEY AUTO_INCREMENT,
    payment_id INT NOT NULL,
    receipt_number VARCHAR(50) UNIQUE NOT NULL,
    receipt_date DATE NOT NULL,
    printed_by INT NOT NULL,
    printed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (payment_id) REFERENCES payments(payment_id),
    FOREIGN KEY (printed_by) REFERENCES users(user_id)
);
```

### 10.7 Records and Audit Tables

```sql
-- Academic records table
CREATE TABLE academic_records (
    record_id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    semester_id INT NOT NULL,
    gpa DECIMAL(3,2) NULL,
    total_units INT DEFAULT 0,
    academic_status ENUM('Good', 'Warning', 'Probation', 'Dismissed') DEFAULT 'Good',
    honors ENUM('None', 'Dean\'s List', 'President\'s List', 'With Honors', 'Cum Laude', 'Magna Cum Laude', 'Summa Cum Laude') DEFAULT 'None',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (semester_id) REFERENCES semesters(semester_id),
    UNIQUE KEY unique_record (student_id, semester_id)
);

-- Transcript requests table
CREATE TABLE transcript_requests (
    request_id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    request_date DATE NOT NULL,
    purpose VARCHAR(200) NOT NULL,
    copies INT DEFAULT 1,
    status ENUM('Pending', 'Processing', 'Ready for Pickup', 'Released', 'Cancelled') DEFAULT 'Pending',
    processed_by INT,
    processed_at TIMESTAMP NULL,
    release_date DATE NULL,
    fee_amount DECIMAL(10,2) DEFAULT 0,
    paid BOOLEAN DEFAULT FALSE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (processed_by) REFERENCES users(user_id)
);

-- Audit logs table
CREATE TABLE audit_logs (
    log_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    action VARCHAR(100) NOT NULL,
    table_name VARCHAR(50),
    record_id INT,
    old_values TEXT,
    new_values TEXT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);
```

### 10.8 Indexes for Performance

```sql
-- Performance indexes
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_role_status ON users(role_id, status);
CREATE INDEX idx_students_student_number ON students(student_number);
CREATE INDEX idx_students_course_year ON students(course_id, year_level);
CREATE INDEX idx_enrollments_student_semester ON enrollments(student_id, semester_id);
CREATE INDEX idx_student_loads_enrollment ON student_subject_loads(enrollment_id);
CREATE INDEX idx_grades_load_period ON grades(load_id, grading_period);
CREATE INDEX idx_billings_student_semester ON billings(student_id, semester_id);
CREATE INDEX idx_payments_student_date ON payments(student_id, payment_date);
CREATE INDEX idx_audit_logs_user_date ON audit_logs(user_id, created_at);
CREATE INDEX idx_subject_offerings_semester ON subject_offerings(semester_id);
CREATE INDEX idx_schedules_offering_day ON schedules(offering_id, day_of_week);
```

## 11. Recommended Folder Structure

```
school_management_system/
|-- config/
|   |-- database.php              # Database connection settings
|   |-- config.php                # System configuration
|   |-- constants.php             # System constants
|   `-- functions.php            # Common functions
|
|-- includes/
|   |-- header.php                # HTML header with navigation
|   |-- footer.php                # HTML footer
|   |-- sidebar.php               # Sidebar navigation
|   |-- auth_check.php            # Authentication middleware
|   |-- session.php               # Session management
|   `-- helpers.php               # Helper functions
|
|-- assets/
|   |-- css/
|   |   |-- main.css              # Main stylesheet
|   |   |-- dashboard.css         # Dashboard styles
|   |   |-- forms.css             # Form styles
|   |   |-- tables.css            # Table styles
|   |   `-- print.css             # Print media styles
|   |
|   |-- js/
|   |   |-- main.js               # Main JavaScript file
|   |   |-- validation.js         # Form validation
|   |   |-- dashboard.js          # Dashboard functionality
|   |   `-- print.js              # Print functionality
|   |
|   |-- images/
|   |   |-- logo.png              # School logo
|   |   |-- favicon.ico           # Favicon
|   |   `-- backgrounds/          # Background images
|   |
|   `-- fonts/                    # Custom fonts (if needed)
|
|-- modules/
|   |-- auth/
|   |   |-- login.php             # Login page
|   |   |-- register.php          # Registration page
|   |   |-- logout.php            # Logout handler
|   |   |-- forgot_password.php   # Password reset
|   |   `-- reset_password.php    # Password reset handler
|   |
|   |-- admin/
|   |   |-- dashboard.php         # Admin dashboard
|   |   |-- users/
|   |   |   |-- manage.php        # User management
|   |   |   |-- approve.php        # Registration approval
|   |   |   `-- edit.php          # Edit user
|   |   |-- academics/
|   |   |   |-- departments.php   # Department management
|   |   |   |-- courses.php       # Course management
|   |   |   |-- subjects.php      # Subject management
|   |   |   |-- school_years.php  # School year management
|   |   |   `-- semesters.php     # Semester management
|   |   |-- reports/
|   |   |   |-- enrollment.php    # Enrollment reports
|   |   |   |-- financial.php     # Financial reports
|   |   |   `-- audit.php         # Audit logs
|   |   `-- settings/
|   |       |-- system.php        # System settings
|   |       `-- backup.php        # Backup utilities
|   |
|   |-- student/
|   |   |-- dashboard.php         # Student dashboard
|   |   |-- enrollment/
|   |   |   |-- apply.php         # Enrollment application
|   |   |   |-- subjects.php      # Subject selection
|   |   |   |-- add.php           # Add subject
|   |   |   `-- drop.php          # Drop subject
|   |   |-- academics/
|   |   |   |-- schedule.php      # View schedule
|   |   |   |-- grades.php        # View grades
|   |   |   `-- records.php       # Academic records
|   |   |-- finance/
|   |   |   |-- billing.php       # View billing
|   |   |   |-- payments.php      # Payment history
|   |   |   `-- receipt.php       # Print receipt
|   |   `-- profile/
|   |       |-- view.php          # View profile
|   |       `-- edit.php          # Edit profile
|   |
|   |-- teacher/
|   |   |-- dashboard.php         # Teacher dashboard
|   |   |-- schedule/
|   |   |   |-- view.php          # View schedule
|   |   |   `-- classes.php       # Class lists
|   |   |-- grades/
|   |   |   |-- encode.php        # Grade encoding
|   |   |   |-- edit.php          # Edit grades
|   |   |   `-- print.php         # Print grade sheet
|   |   `-- profile/
|   |       |-- view.php          # View profile
|   |       `-- edit.php          # Edit profile
|   |
|   |-- dean/
|   |   |-- dashboard.php         # Dean dashboard
|   |   |-- offerings/
|   |   |   |-- subjects.php      # Subject offerings
|   |   |   |-- teachers.php      # Teacher assignments
|   |   |   `-- schedules.php     # Schedule management
|   |   |-- enrollment/
|   |   |   |-- statistics.php    # Enrollment stats
|   |   |   `-- approval.php      # Enrollment approval
|   |   `-- reports/
|   |       |-- academic.php      # Academic reports
|   |       `-- faculty.php       # Faculty reports
|   |
|   |-- records/
|   |   |-- dashboard.php         # Records dashboard
|   |   |-- students/
|   |   |   |-- search.php        # Student search
|   |   |   |-- records.php       # Academic records
|   |   |   `-- transcript.php   # Transcript generation
|   |   |-- enrollment/
|   |   |   |-- verify.php        # Enrollment verification
|   |   |   `-- approve.php       # Enrollment approval
|   |   `-- reports/
|   |       |-- grades.php        # Grade reports
|   |       `-- statistics.php    # Academic statistics
|   |
|   |-- finance/
|   |   |-- dashboard.php         # Finance dashboard
|   |   |-- fees/
|   |   |   |-- manage.php        # Fee management
|   |   |   |-- schedules.php     # Fee schedules
|   |   |   `-- billing.php       # Billing generation
|   |   |-- accounts/
|   |   |   |-- monitor.php       # Account monitoring
|   |   |   `-- balances.php      # Balance tracking
|   |   `-- reports/
|   |       |-- collections.php   # Collection reports
|   |       `-- financial.php     # Financial summaries
|   |
|   `-- cashier/
|       |-- dashboard.php         # Cashier dashboard
|       |-- payments/
|       |   |-- receive.php       # Receive payment
|       |   |-- history.php       # Payment history
|       |   `-- receipt.php       # Print receipt
|       `-- reports/
|           |-- daily.php        # Daily collections
|           `-- monthly.php       # Monthly reports
|
|-- api/
|   |-- endpoints/
|   |   |-- auth.php              # Authentication API
|   |   |-- enrollment.php        # Enrollment API
|   |   |-- grades.php            # Grades API
|   |   |-- payments.php          # Payments API
|   |   `-- reports.php           # Reports API
|   |
|   `-- middleware/
|       |-- cors.php              # CORS handling
|       |-- rate_limit.php        # Rate limiting
|       `-- validation.php        # Input validation
|
|-- uploads/
|   |-- documents/                # Document uploads
|   |-- profiles/                 # Profile pictures
|   `-- temp/                     # Temporary files
|
|-- logs/
|   |-- error.log                 # Error logs
|   |-- access.log                # Access logs
|   `-- audit.log                 # Audit logs
|
|-- backups/
|   |-- database/                 # Database backups
|   `-- files/                    # File backups
|
|-- templates/
|   |-- emails/                   # Email templates
|   |-- reports/                  # Report templates
|   `-- certificates/             # Certificate templates
|
|-- cache/                        # Cache files
|
|-- index.php                     # Main entry point
|-- .htaccess                     # Apache configuration
|-- README.md                     # Project documentation
|-- LICENSE                       # License file
`-- composer.json                 # Dependencies (if any)
```

## 12. Backend Architecture Using Core PHP

### 12.1 MVC-like Structure

```php
// config/database.php - Database Connection Class
class Database {
    private $host = 'localhost';
    private $db_name = 'school_management';
    private $username = 'root';
    private $password = '';
    private $conn;

    public function getConnection() {
        $this->conn = null;
        
        try {
            $this->conn = new PDO(
                "mysql:host=" . $this->host . ";dbname=" . $this->db_name,
                $this->username,
                $this->password,
                array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION)
            );
        } catch(PDOException $exception) {
            echo "Connection error: " . $exception->getMessage();
        }
        
        return $this->conn;
    }
}

// includes/auth_check.php - Authentication Middleware
function requireLogin() {
    session_start();
    if (!isset($_SESSION['user_id'])) {
        header('Location: /modules/auth/login.php');
        exit();
    }
}

function requireRole($requiredRole) {
    requireLogin();
    if ($_SESSION['user_role'] !== $requiredRole) {
        header('HTTP/1.0 403 Forbidden');
        echo 'Access denied';
        exit();
    }
}

// config/functions.php - Common Functions
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function generateStudentNumber() {
    $year = date('Y');
    $random = str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
    return $year . '-' . $random;
}

function formatDate($date, $format = 'Y-m-d') {
    return date($format, strtotime($date));
}

function calculateGPA($grades) {
    if (empty($grades)) return 0;
    return array_sum($grades) / count($grades);
}
```

### 12.2 Model Classes

```php
// models/User.php
class User {
    private $conn;
    private $table_name = "users";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create($data) {
        $query = "INSERT INTO " . $this->table_name . "
                SET username=:username, email=:email, password_hash=:password_hash, 
                role_id=:role_id, first_name=:first_name, last_name=:last_name,
                middle_name=:middle_name";

        $stmt = $this->conn->prepare($query);

        // Sanitize
        $this->username = htmlspecialchars(strip_tags($data['username']));
        $this->email = htmlspecialchars(strip_tags($data['email']));
        $this->password_hash = password_hash($data['password'], PASSWORD_DEFAULT);
        $this->role_id = htmlspecialchars(strip_tags($data['role_id']));
        $this->first_name = htmlspecialchars(strip_tags($data['first_name']));
        $this->last_name = htmlspecialchars(strip_tags($data['last_name']));
        $this->middle_name = htmlspecialchars(strip_tags($data['middle_name']));

        // Bind values
        $stmt->bindParam(":username", $this->username);
        $stmt->bindParam(":email", $this->email);
        $stmt->bindParam(":password_hash", $this->password_hash);
        $stmt->bindParam(":role_id", $this->role_id);
        $stmt->bindParam(":first_name", $this->first_name);
        $stmt->bindParam(":last_name", $this->last_name);
        $stmt->bindParam(":middle_name", $this->middle_name);

        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    public function login($username, $password) {
        $query = "SELECT u.*, r.role_name 
                 FROM " . $this->table_name . " u
                 JOIN roles r ON u.role_id = r.role_id
                 WHERE u.username = ? AND u.status = 'approved' LIMIT 1";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $username);
        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if($row && password_verify($password, $row['password_hash'])) {
            return $row;
        }
        return false;
    }
}

// models/Student.php
class Student {
    private $conn;
    private $table_name = "students";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function enroll($data) {
        // Implementation for student enrollment
    }

    public function getSubjects($student_id, $semester_id) {
        // Implementation to get enrolled subjects
    }
}
```

## 13. Frontend Page Structure

### 13.1 HTML Template Structure

```html
<!-- includes/header.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title : 'School Management System'; ?></title>
    <link rel="stylesheet" href="/assets/css/main.css">
    <link rel="stylesheet" href="/assets/css/dashboard.css">
    <?php if(isset($extra_css)): ?>
        <?php foreach($extra_css as $css): ?>
            <link rel="stylesheet" href="<?php echo $css; ?>">
        <?php endforeach; ?>
    <?php endif; ?>
</head>
<body>
    <div class="container">
        <header class="main-header">
            <div class="header-content">
                <div class="logo">
                    <img src="/assets/images/logo.png" alt="School Logo">
                    <h1>School Management System</h1>
                </div>
                <nav class="main-nav">
                    <ul>
                        <li><a href="/dashboard.php">Dashboard</a></li>
                        <li><a href="/profile.php">Profile</a></li>
                        <li><a href="/modules/auth/logout.php">Logout</a></li>
                    </ul>
                </nav>
            </div>
        </header>

<!-- includes/sidebar.php -->
<aside class="sidebar">
    <nav class="sidebar-nav">
        <?php if($_SESSION['user_role'] === 'admin'): ?>
            <ul class="admin-menu">
                <li><a href="/modules/admin/dashboard.php">Dashboard</a></li>
                <li><a href="/modules/admin/users/manage.php">User Management</a></li>
                <li><a href="/modules/admin/academics/departments.php">Academics</a></li>
                <li><a href="/modules/admin/reports/">Reports</a></li>
                <li><a href="/modules/admin/settings/system.php">Settings</a></li>
            </ul>
        <?php elseif($_SESSION['user_role'] === 'student'): ?>
            <ul class="student-menu">
                <li><a href="/modules/student/dashboard.php">Dashboard</a></li>
                <li><a href="/modules/student/enrollment/apply.php">Enrollment</a></li>
                <li><a href="/modules/student/academics/schedule.php">Schedule</a></li>
                <li><a href="/modules/student/academics/grades.php">Grades</a></li>
                <li><a href="/modules/student/finance/billing.php">Billing</a></li>
            </ul>
        <?php endif; ?>
    </nav>
</aside>

<main class="main-content">
    <div class="content-wrapper">
        <?php if(isset($page_heading)): ?>
            <h1 class="page-heading"><?php echo $page_heading; ?></h1>
        <?php endif; ?>

<!-- includes/footer.php -->
    </div>
</main>

<footer class="main-footer">
    <div class="footer-content">
        <p>&copy; <?php echo date('Y'); ?> School Management System. All rights reserved.</p>
    </div>
</footer>
</div>

<script src="/assets/js/main.js"></script>
<?php if(isset($extra_js)): ?>
    <?php foreach($extra_js as $js): ?>
        <script src="<?php echo $js; ?>"></script>
    <?php endforeach; ?>
<?php endif; ?>
</body>
</html>
```

### 13.2 CSS Architecture

```css
/* assets/css/main.css */
:root {
    --primary-color: #2c3e50;
    --secondary-color: #3498db;
    --success-color: #27ae60;
    --warning-color: #f39c12;
    --danger-color: #e74c3c;
    --light-color: #ecf0f1;
    --dark-color: #2c3e50;
    --border-radius: 4px;
    --box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Arial', sans-serif;
    line-height: 1.6;
    color: var(--dark-color);
    background-color: var(--light-color);
}

.container {
    display: grid;
    grid-template-columns: 250px 1fr;
    grid-template-rows: auto 1fr auto;
    min-height: 100vh;
}

.main-header {
    grid-column: 1 / -1;
    background: var(--primary-color);
    color: white;
    padding: 1rem;
    box-shadow: var(--box-shadow);
}

.header-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.logo {
    display: flex;
    align-items: center;
    gap: 1rem;
}

.logo img {
    height: 40px;
}

.main-nav ul {
    display: flex;
    list-style: none;
    gap: 2rem;
}

.main-nav a {
    color: white;
    text-decoration: none;
    padding: 0.5rem 1rem;
    border-radius: var(--border-radius);
    transition: background-color 0.3s;
}

.main-nav a:hover {
    background-color: rgba(255,255,255,0.1);
}

.sidebar {
    background: white;
    border-right: 1px solid #ddd;
    padding: 1rem;
}

.sidebar-nav ul {
    list-style: none;
}

.sidebar-nav li {
    margin-bottom: 0.5rem;
}

.sidebar-nav a {
    display: block;
    padding: 0.75rem 1rem;
    color: var(--dark-color);
    text-decoration: none;
    border-radius: var(--border-radius);
    transition: all 0.3s;
}

.sidebar-nav a:hover,
.sidebar-nav a.active {
    background-color: var(--secondary-color);
    color: white;
}

.main-content {
    padding: 2rem;
    overflow-y: auto;
}

.content-wrapper {
    max-width: 1200px;
    margin: 0 auto;
}

.main-footer {
    grid-column: 1 / -1;
    background: var(--primary-color);
    color: white;
    text-align: center;
    padding: 1rem;
}

/* Responsive Design */
@media (max-width: 768px) {
    .container {
        grid-template-columns: 1fr;
    }
    
    .sidebar {
        display: none;
    }
    
    .header-content {
        flex-direction: column;
        gap: 1rem;
    }
    
    .main-nav ul {
        flex-direction: column;
        text-align: center;
        gap: 0.5rem;
    }
}
```

## 14. Form Handling and CRUD Flow

### 14.1 Form Processing Pattern

```php
// Generic form processing pattern
<?php
require_once '../../config/database.php';
require_once '../../includes/auth_check.php';
require_once '../../includes/session.php';

// Initialize variables
$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $errors[] = "Invalid request";
    } else {
        // Sanitize and validate inputs
        $name = sanitizeInput($_POST['name'] ?? '');
        $email = sanitizeInput($_POST['email'] ?? '');
        
        // Custom validation
        if (empty($name)) {
            $errors[] = "Name is required";
        }
        
        if (empty($email)) {
            $errors[] = "Email is required";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Invalid email format";
        }
        
        // If no errors, proceed with database operation
        if (empty($errors)) {
            try {
                $database = new Database();
                $db = $database->getConnection();
                
                // Perform CRUD operation
                $query = "INSERT INTO table_name (name, email) VALUES (:name, :email)";
                $stmt = $db->prepare($query);
                $stmt->bindParam(':name', $name);
                $stmt->bindParam(':email', $email);
                
                if ($stmt->execute()) {
                    $success = true;
                    // Log the action
                    logAction($_SESSION['user_id'], 'CREATE', 'table_name', $db->lastInsertId());
                } else {
                    $errors[] = "Database error occurred";
                }
            } catch (PDOException $e) {
                $errors[] = "Database error: " . $e->getMessage();
            }
        }
    }
}

// Generate CSRF token
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));
?>

<!-- Form HTML -->
<form method="POST" action="">
    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
    
    <?php if ($success): ?>
        <div class="alert alert-success">
            Operation completed successfully!
        </div>
    <?php endif; ?>
    
    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <?php foreach ($errors as $error): ?>
                <p><?php echo $error; ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    
    <div class="form-group">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($name ?? ''); ?>" required>
    </div>
    
    <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email ?? ''); ?>" required>
    </div>
    
    <button type="submit" class="btn btn-primary">Submit</button>
</form>
```

### 14.2 CRUD Operations Example

```php
// models/BaseModel.php - Base CRUD operations
abstract class BaseModel {
    protected $conn;
    protected $table_name;

    public function __construct($db) {
        $this->conn = $db;
    }

    // Create
    public function create($data) {
        $columns = implode(', ', array_keys($data));
        $placeholders = ':' . implode(', :', array_keys($data));
        
        $query = "INSERT INTO " . $this->table_name . " ($columns) VALUES ($placeholders)";
        
        $stmt = $this->conn->prepare($query);
        
        foreach ($data as $key => $value) {
            $stmt->bindValue(":$key", $value);
        }
        
        return $stmt->execute();
    }

    // Read (single record)
    public function read($id) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE id = :id LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Read (all records)
    public function readAll($limit = 50, $offset = 0) {
        $query = "SELECT * FROM " . $this->table_name . " LIMIT :limit OFFSET :offset";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Update
    public function update($id, $data) {
        $set_parts = [];
        foreach ($data as $key => $value) {
            $set_parts[] = "$key = :$key";
        }
        $set_clause = implode(', ', $set_parts);
        
        $query = "UPDATE " . $this->table_name . " SET $set_clause WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        
        foreach ($data as $key => $value) {
            $stmt->bindValue(":$key", $value);
        }
        $stmt->bindParam(':id', $id);
        
        return $stmt->execute();
    }

    // Delete
    public function delete($id) {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        
        return $stmt->execute();
    }
}
```

## 15. Validation Rules

### 15.1 Server-Side Validation

```php
// includes/validation.php
class Validator {
    private $errors = [];
    
    public function validate($data, $rules) {
        foreach ($rules as $field => $fieldRules) {
            $value = $data[$field] ?? '';
            
            foreach ($fieldRules as $rule => $parameter) {
                switch ($rule) {
                    case 'required':
                        if (empty($value)) {
                            $this->addError($field, ucfirst($field) . ' is required');
                        }
                        break;
                        
                    case 'email':
                        if (!empty($value) && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
                            $this->addError($field, 'Invalid email format');
                        }
                        break;
                        
                    case 'min':
                        if (strlen($value) < $parameter) {
                            $this->addError($field, ucfirst($field) . ' must be at least ' . $parameter . ' characters');
                        }
                        break;
                        
                    case 'max':
                        if (strlen($value) > $parameter) {
                            $this->addError($field, ucfirst($field) . ' must not exceed ' . $parameter . ' characters');
                        }
                        break;
                        
                    case 'numeric':
                        if (!empty($value) && !is_numeric($value)) {
                            $this->addError($field, ucfirst($field) . ' must be a number');
                        }
                        break;
                        
                    case 'unique':
                        if (!$this->isUnique($field, $value, $parameter)) {
                            $this->addError($field, ucfirst($field) . ' already exists');
                        }
                        break;
                        
                    case 'regex':
                        if (!empty($value) && !preg_match($parameter, $value)) {
                            $this->addError($field, ucfirst($field) . ' format is invalid');
                        }
                        break;
                }
            }
        }
        
        return empty($this->errors);
    }
    
    private function addError($field, $message) {
        $this->errors[$field] = $message;
    }
    
    public function getErrors() {
        return $this->errors;
    }
    
    private function isUnique($field, $value, $table) {
        global $db;
        $query = "SELECT COUNT(*) FROM $table WHERE $field = ?";
        $stmt = $db->prepare($query);
        $stmt->execute([$value]);
        return $stmt->fetchColumn() == 0;
    }
}

// Usage example
$validator = new Validator();
$rules = [
    'username' => [
        'required' => true,
        'min' => 3,
        'max' => 50,
        'unique' => 'users'
    ],
    'email' => [
        'required' => true,
        'email' => true,
        'unique' => 'users'
    ],
    'password' => [
        'required' => true,
        'min' => 8,
        'regex' => '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/'
    ]
];

if ($validator->validate($_POST, $rules)) {
    // Proceed with form processing
} else {
    $errors = $validator->getErrors();
}
```

### 15.2 Client-Side Validation

```javascript
// assets/js/validation.js
class FormValidator {
    constructor(formId) {
        this.form = document.getElementById(formId);
        this.errors = {};
        this.init();
    }
    
    init() {
        this.form.addEventListener('submit', (e) => {
            if (!this.validate()) {
                e.preventDefault();
                this.displayErrors();
            }
        });
        
        // Real-time validation
        this.form.querySelectorAll('input, select, textarea').forEach(field => {
            field.addEventListener('blur', () => this.validateField(field));
            field.addEventListener('input', () => this.clearFieldError(field));
        });
    }
    
    validate() {
        this.errors = {};
        const fields = this.form.querySelectorAll('input, select, textarea');
        
        fields.forEach(field => this.validateField(field));
        
        return Object.keys(this.errors).length === 0;
    }
    
    validateField(field) {
        const name = field.name;
        const value = field.value.trim();
        const rules = this.getFieldRules(field);
        
        // Clear previous errors
        this.clearFieldError(field);
        
        rules.forEach(rule => {
            switch (rule.type) {
                case 'required':
                    if (!value) {
                        this.addError(name, rule.message || `${name} is required`);
                    }
                    break;
                    
                case 'email':
                    if (value && !this.isValidEmail(value)) {
                        this.addError(name, rule.message || 'Invalid email format');
                    }
                    break;
                    
                case 'min':
                    if (value.length < rule.value) {
                        this.addError(name, rule.message || `${name} must be at least ${rule.value} characters`);
                    }
                    break;
                    
                case 'max':
                    if (value.length > rule.value) {
                        this.addError(name, rule.message || `${name} must not exceed ${rule.value} characters`);
                    }
                    break;
                    
                case 'pattern':
                    if (value && !new RegExp(rule.value).test(value)) {
                        this.addError(name, rule.message || `${name} format is invalid`);
                    }
                    break;
            }
        });
    }
    
    getFieldRules(field) {
        const rules = [];
        
        if (field.hasAttribute('required')) {
            rules.push({ type: 'required' });
        }
        
        if (field.type === 'email') {
            rules.push({ type: 'email' });
        }
        
        if (field.hasAttribute('minlength')) {
            rules.push({ type: 'min', value: parseInt(field.getAttribute('minlength')) });
        }
        
        if (field.hasAttribute('maxlength')) {
            rules.push({ type: 'max', value: parseInt(field.getAttribute('maxlength')) });
        }
        
        if (field.hasAttribute('pattern')) {
            rules.push({ type: 'pattern', value: field.getAttribute('pattern') });
        }
        
        return rules;
    }
    
    isValidEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }
    
    addError(field, message) {
        if (!this.errors[field]) {
            this.errors[field] = [];
        }
        this.errors[field].push(message);
    }
    
    clearFieldError(field) {
        const errorElement = field.parentNode.querySelector('.error-message');
        if (errorElement) {
            errorElement.remove();
        }
        field.classList.remove('error');
    }
    
    displayErrors() {
        Object.keys(this.errors).forEach(fieldName => {
            const field = this.form.querySelector(`[name="${fieldName}"]`);
            if (field) {
                field.classList.add('error');
                
                const errorDiv = document.createElement('div');
                errorDiv.className = 'error-message';
                errorDiv.textContent = this.errors[fieldName][0];
                field.parentNode.appendChild(errorDiv);
            }
        });
    }
}

// Usage
document.addEventListener('DOMContentLoaded', () => {
    new FormValidator('registrationForm');
    new FormValidator('enrollmentForm');
});
```

## 16. Security Best Practices

### 16.1 Security Configuration

```php
// config/security.php
class Security {
    // Generate CSRF token
    public static function generateCSRFToken() {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            $_SESSION['csrf_token_time'] = time();
        }
        return $_SESSION['csrf_token'];
    }
    
    // Validate CSRF token
    public static function validateCSRFToken($token) {
        if (!isset($_SESSION['csrf_token']) || !isset($_SESSION['csrf_token_time'])) {
            return false;
        }
        
        // Check if token is valid (24 hours expiry)
        if (time() - $_SESSION['csrf_token_time'] > 86400) {
            unset($_SESSION['csrf_token']);
            unset($_SESSION['csrf_token_time']);
            return false;
        }
        
        return hash_equals($_SESSION['csrf_token'], $token);
    }
    
    // XSS protection
    public static function escape($string) {
        return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
    }
    
    // SQL injection protection (use prepared statements)
    public static function sanitizeInput($input) {
        return filter_var($input, FILTER_SANITIZE_STRING, FILTER_FLAG_NO_ENCODE_QUOTES);
    }
    
    // Password strength validation
    public static function validatePassword($password) {
        $length = strlen($password);
        $hasUpper = preg_match('/[A-Z]/', $password);
        $hasLower = preg_match('/[a-z]/', $password);
        $hasNumber = preg_match('/[0-9]/', $password);
        $hasSpecial = preg_match('/[!@#$%^&*(),.?":{}|<>]/', $password);
        
        return $length >= 8 && $hasUpper && $hasLower && $hasNumber && $hasSpecial;
    }
    
    // Rate limiting
    public static function checkRateLimit($action, $limit = 5, $window = 300) {
        $key = $action . '_' . $_SERVER['REMOTE_ADDR'];
        
        if (!isset($_SESSION['rate_limit'][$key])) {
            $_SESSION['rate_limit'][$key] = ['count' => 0, 'start' => time()];
        }
        
        $current = $_SESSION['rate_limit'][$key];
        
        // Reset if window expired
        if (time() - $current['start'] > $window) {
            $_SESSION['rate_limit'][$key] = ['count' => 0, 'start' => time()];
        }
        
        // Check limit
        if ($current['count'] >= $limit) {
            return false;
        }
        
        $_SESSION['rate_limit'][$key]['count']++;
        return true;
    }
    
    // Secure session configuration
    public static function secureSession() {
        ini_set('session.cookie_httponly', 1);
        ini_set('session.cookie_secure', 1);
        ini_set('session.use_strict_mode', 1);
        ini_set('session.cookie_samesite', 'Strict');
        
        session_start();
        
        // Regenerate session ID on login
        if (!isset($_SESSION['initiated'])) {
            session_regenerate_id(true);
            $_SESSION['initiated'] = true;
        }
    }
    
    // Input validation
    public static function validateInput($input, $type) {
        switch ($type) {
            case 'email':
                return filter_var($input, FILTER_VALIDATE_EMAIL);
            case 'int':
                return filter_var($input, FILTER_VALIDATE_INT);
            case 'float':
                return filter_var($input, FILTER_VALIDATE_FLOAT);
            case 'url':
                return filter_var($input, FILTER_VALIDATE_URL);
            case 'boolean':
                return filter_var($input, FILTER_VALIDATE_BOOLEAN);
            default:
                return filter_var($input, FILTER_SANITIZE_STRING);
        }
    }
}

// Security headers
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');
header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
header('Content-Security-Policy: default-src \'self\'');
```

### 16.2 Audit Logging

```php
// includes/audit.php
class AuditLogger {
    private $db;
    
    public function __construct($database) {
        $this->db = $database;
    }
    
    public function log($userId, $action, $tableName = null, $recordId = null, $oldValues = null, $newValues = null) {
        $query = "INSERT INTO audit_logs 
                 SET user_id = :user_id, action = :action, table_name = :table_name,
                     record_id = :record_id, old_values = :old_values, new_values = :new_values,
                     ip_address = :ip_address, user_agent = :user_agent";
        
        $stmt = $this->db->prepare($query);
        
        $stmt->bindParam(':user_id', $userId);
        $stmt->bindParam(':action', $action);
        $stmt->bindParam(':table_name', $tableName);
        $stmt->bindParam(':record_id', $recordId);
        $stmt->bindParam(':old_values', json_encode($oldValues));
        $stmt->bindParam(':new_values', json_encode($newValues));
        $stmt->bindParam(':ip_address', $_SERVER['REMOTE_ADDR']);
        $stmt->bindParam(':user_agent', $_SERVER['HTTP_USER_AGENT']);
        
        return $stmt->execute();
    }
    
    public function getLogs($userId = null, $limit = 100) {
        $query = "SELECT al.*, u.first_name, u.last_name 
                 FROM audit_logs al
                 JOIN users u ON al.user_id = u.user_id";
        
        if ($userId) {
            $query .= " WHERE al.user_id = :user_id";
        }
        
        $query .= " ORDER BY al.created_at DESC LIMIT :limit";
        
        $stmt = $this->db->prepare($query);
        
        if ($userId) {
            $stmt->bindParam(':user_id', $userId);
        }
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

// Usage
$audit = new AuditLogger($db);
$audit->log($_SESSION['user_id'], 'LOGIN', null, null, null, null);
```

## 17. Dashboard Design per Role

### 17.1 Admin Dashboard Layout

```php
<!-- modules/admin/dashboard.php -->
<?php
$page_title = 'Admin Dashboard';
$page_heading = 'System Overview';
require_once '../../includes/header.php';
require_once '../../includes/sidebar.php';
?>

<div class="dashboard-grid">
    <!-- Statistics Cards -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon users">
                <i class="icon-users"></i>
            </div>
            <div class="stat-content">
                <h3><?php echo $total_users; ?></h3>
                <p>Total Users</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon students">
                <i class="icon-students"></i>
            </div>
            <div class="stat-content">
                <h3><?php echo $total_students; ?></h3>
                <p>Active Students</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon pending">
                <i class="icon-pending"></i>
            </div>
            <div class="stat-content">
                <h3><?php echo $pending_registrations; ?></h3>
                <p>Pending Registrations</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon courses">
                <i class="icon-courses"></i>
            </div>
            <div class="stat-content">
                <h3><?php echo $total_courses; ?></h3>
                <p>Total Courses</p>
            </div>
        </div>
    </div>
    
    <!-- Recent Activity -->
    <div class="dashboard-section">
        <h2>Recent Activity</h2>
        <div class="activity-list">
            <?php foreach ($recent_activities as $activity): ?>
                <div class="activity-item">
                    <div class="activity-info">
                        <span class="activity-user"><?php echo $activity['user_name']; ?></span>
                        <span class="activity-action"><?php echo $activity['action']; ?></span>
                        <span class="activity-time"><?php echo timeAgo($activity['created_at']); ?></span>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <!-- Quick Actions -->
    <div class="dashboard-section">
        <h2>Quick Actions</h2>
        <div class="quick-actions">
            <a href="/modules/admin/users/approve.php" class="action-btn">
                <i class="icon-approve"></i>
                Approve Registrations
            </a>
            <a href="/modules/admin/academics/subjects.php" class="action-btn">
                <i class="icon-subjects"></i>
                Manage Subjects
            </a>
            <a href="/modules/admin/reports/enrollment.php" class="action-btn">
                <i class="icon-reports"></i>
                View Reports
            </a>
        </div>
    </div>
    
    <!-- System Status -->
    <div class="dashboard-section">
        <h2>System Status</h2>
        <div class="system-status">
            <div class="status-item">
                <span class="status-label">Database:</span>
                <span class="status-value online">Online</span>
            </div>
            <div class="status-item">
                <span class="status-label">Storage:</span>
                <span class="status-value"><?php echo $disk_usage; ?>% Used</span>
            </div>
            <div class="status-item">
                <span class="status-label">Last Backup:</span>
                <span class="status-value"><?php echo $last_backup; ?></span>
            </div>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
```

### 17.2 Student Dashboard Layout

```php
<!-- modules/student/dashboard.php -->
<div class="dashboard-grid">
    <!-- Student Info Card -->
    <div class="student-info-card">
        <div class="student-avatar">
            <img src="/uploads/profiles/<?php echo $student['profile_image'] ?? 'default.png'; ?>" alt="Profile">
        </div>
        <div class="student-details">
            <h3><?php echo $student['first_name'] . ' ' . $student['last_name']; ?></h3>
            <p>Student ID: <?php echo $student['student_number']; ?></p>
            <p>Course: <?php echo $student['course_name']; ?></p>
            <p>Year: <?php echo $student['year_level']; ?></p>
        </div>
    </div>
    
    <!-- Academic Summary -->
    <div class="dashboard-section">
        <h2>Academic Summary</h2>
        <div class="academic-stats">
            <div class="stat-item">
                <span class="stat-label">Current Units:</span>
                <span class="stat-value"><?php echo $current_units; ?></span>
            </div>
            <div class="stat-item">
                <span class="stat-label">GPA:</span>
                <span class="stat-value"><?php echo $gpa; ?></span>
            </div>
            <div class="stat-item">
                <span class="stat-label">Status:</span>
                <span class="stat-value <?php echo $enrollment_status_class; ?>"><?php echo $enrollment_status; ?></span>
            </div>
        </div>
    </div>
    
    <!-- Current Schedule -->
    <div class="dashboard-section">
        <h2>Today's Schedule</h2>
        <div class="schedule-list">
            <?php if (!empty($today_schedule)): ?>
                <?php foreach ($today_schedule as $class): ?>
                    <div class="schedule-item">
                        <div class="schedule-time"><?php echo $class['start_time']; ?> - <?php echo $class['end_time']; ?></div>
                        <div class="schedule-subject"><?php echo $class['subject_code']; ?></div>
                        <div class="schedule-room">Room: <?php echo $class['room']; ?></div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No classes scheduled for today.</p>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Financial Summary -->
    <div class="dashboard-section">
        <h2>Financial Summary</h2>
        <div class="financial-stats">
            <div class="stat-item">
                <span class="stat-label">Total Assessment:</span>
                <span class="stat-value">PHP <?php echo number_format($total_assessment, 2); ?></span>
            </div>
            <div class="stat-item">
                <span class="stat-label">Paid Amount:</span>
                <span class="stat-value">PHP <?php echo number_format($paid_amount, 2); ?></span>
            </div>
            <div class="stat-item">
                <span class="stat-label">Remaining Balance:</span>
                <span class="stat-value <?php echo $balance_class; ?>">PHP <?php echo number_format($remaining_balance, 2); ?></span>
            </div>
        </div>
    </div>
    
    <!-- Quick Links -->
    <div class="dashboard-section">
        <h2>Quick Links</h2>
        <div class="quick-links">
            <a href="/modules/student/enrollment/apply.php" class="link-btn">
                <i class="icon-enrollment"></i>
                Enrollment
            </a>
            <a href="/modules/student/academics/grades.php" class="link-btn">
                <i class="icon-grades"></i>
                View Grades
            </a>
            <a href="/modules/student/finance/billing.php" class="link-btn">
                <i class="icon-billing"></i>
                Billing Statement
            </a>
        </div>
    </div>
</div>
```

## 18. Printable Reports List

### 18.1 Academic Reports

1. **Student Enrollment Report**
   - List of enrolled students by semester
   - Filter by course, year level, status
   - Summary statistics

2. **Grade Sheet Report**
   - Class list with grades
   - Grade distribution analysis
   - Teacher signature lines

3. **Transcript of Records**
   - Complete academic history
   - GPA calculations
   - Dean's list recognition

4. **Academic Performance Report**
   - Course completion rates
   - GPA distribution
   - Academic standing summary

5. **Subject Offering Report**
   - List of subjects offered
   - Enrollment counts per subject
   - Teacher assignments

### 18.2 Financial Reports

1. **Collection Report**
   - Daily cash collections
   - Payment method breakdown
   - Cashier reconciliation

2. **Billing Statement**
   - Student assessment details
   - Fee breakdown
   - Payment history

3. **Aged Receivables Report**
   - Outstanding balances
   - Age of receivables
   - Collection status

4. **Financial Summary Report**
   - Revenue by semester
   - Expense tracking
   - Budget analysis

### 18.3 Administrative Reports

1. **User Activity Report**
   - Login statistics
   - System usage patterns
   - Security audit logs

2. **Enrollment Statistics**
   - New vs. returning students
   - Course popularity
   - Retention rates

3. **Faculty Load Report**
   - Teaching assignments
   - Workload analysis
   - Schedule conflicts

4. **System Utilization Report**
   - Feature usage statistics
   - Performance metrics
   - Error logs

## 19. Step-by-Step Development Plan

### Phase 1: Foundation (Week 1-2)
1. **Database Setup**
   - Create MySQL database
   - Execute CREATE TABLE statements
   - Set up indexes and constraints
   - Insert initial data (roles, admin user)

2. **Project Structure**
   - Create folder structure
   - Set up configuration files
   - Create base templates
   - Implement error handling

3. **Core Authentication**
   - User registration system
   - Login/logout functionality
   - Session management
   - Password hashing

### Phase 2: User Management (Week 3)
1. **Admin Module**
   - User management interface
   - Registration approval system
   - Role assignment
   - Profile management

2. **Security Implementation**
   - CSRF protection
   - Input validation
   - XSS prevention
   - Audit logging

### Phase 3: Academic Structure (Week 4-5)
1. **Academic Setup**
   - Department management
   - Course management
   - Subject management
   - School year/semester setup

2. **Subject Offerings**
   - Subject scheduling
   - Teacher assignments
   - Room assignments
   - Conflict detection

### Phase 4: Enrollment System (Week 6-7)
1. **Student Enrollment**
   - Enrollment application form
   - Subject selection
   - Prerequisite validation
   - Enrollment approval

2. **Schedule Management**
   - Schedule viewing
   - Add/drop subjects
   - Enrollment confirmation
   - Assessment generation

### Phase 5: Grade Management (Week 8-9)
1. **Grade Encoding**
   - Teacher grade entry
   - Grade validation
   - Grade calculation
   - Grade submission

2. **Academic Records**
   - Grade viewing
   - Transcript generation
   - Academic standing
   - GPA calculation

### Phase 6: Financial System (Week 10-11)
1. **Fee Management**
   - Fee structure setup
   - Assessment generation
   - Billing statements
   - Payment processing

2. **Cashier Module**
   - Payment recording
   - Receipt generation
   - Collection reports
   - Cash reconciliation

### Phase 7: Reporting (Week 12)
1. **Report Generation**
   - Academic reports
   - Financial reports
   - Administrative reports
   - Export functionality

2. **Printable Formats**
   - PDF generation
   - Print layouts
   - Certificate templates
   - Official documents

### Phase 8: Testing & Deployment (Week 13-14)
1. **Testing**
   - Unit testing
   - Integration testing
   - Security testing
   - Performance testing

2. **Deployment**
   - Production setup
   - Data migration
   - User training
   - Documentation

## 20. Sample Code

### 20.1 Database Connection

```php
<?php
// config/database.php
class Database {
    private $host = 'localhost';
    private $db_name = 'school_management';
    private $username = 'root';
    private $password = '';
    private $charset = 'utf8mb4';
    
    public $conn;
    
    public function getConnection() {
        $this->conn = null;
        
        try {
            $dsn = "mysql:host=" . $this->host . ";dbname=" . $this->db_name . ";charset=" . $this->charset;
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ];
            
            $this->conn = new PDO($dsn, $this->username, $this->password, $options);
        } catch(PDOException $exception) {
            echo "Connection error: " . $exception->getMessage();
        }
        
        return $this->conn;
    }
}
?>
```

### 20.2 Login System

```php
<?php
// modules/auth/login.php
require_once '../../config/database.php';
require_once '../../includes/security.php';

// Initialize variables
$errors = [];
$success = false;

// Rate limiting
if (!Security::checkRateLimit('login', 5, 300)) {
    $errors[] = "Too many login attempts. Please try again later.";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($errors)) {
    $username = sanitizeInput($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    // Validate inputs
    if (empty($username)) {
        $errors[] = "Username is required";
    }
    
    if (empty($password)) {
        $errors[] = "Password is required";
    }
    
    if (empty($errors)) {
        try {
            $database = new Database();
            $db = $database->getConnection();
            
            $query = "SELECT u.*, r.role_name 
                     FROM users u
                     JOIN roles r ON u.role_id = r.role_id
                     WHERE u.username = ? AND u.status = 'approved' LIMIT 1";
            
            $stmt = $db->prepare($query);
            $stmt->execute([$username]);
            $user = $stmt->fetch();
            
            if ($user && password_verify($password, $user['password_hash'])) {
                // Successful login
                Security::secureSession();
                
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['user_role'] = $user['role_name'];
                $_SESSION['first_name'] = $user['first_name'];
                $_SESSION['last_name'] = $user['last_name'];
                
                // Update last login
                $updateQuery = "UPDATE users SET last_login = NOW() WHERE user_id = ?";
                $updateStmt = $db->prepare($updateQuery);
                $updateStmt->execute([$user['user_id']]);
                
                // Log the login
                $audit = new AuditLogger($db);
                $audit->log($user['user_id'], 'LOGIN');
                
                // Redirect to appropriate dashboard
                $dashboardPath = getDashboardPath($user['role_name']);
                header("Location: /modules/{$dashboardPath}/dashboard.php");
                exit();
                
            } else {
                $errors[] = "Invalid username or password";
            }
        } catch(PDOException $e) {
            $errors[] = "Database error occurred";
        }
    }
}

function getDashboardPath($role) {
    $dashboards = [
        'admin' => 'admin',
        'student' => 'student',
        'teacher' => 'teacher',
        'dean' => 'dean',
        'records' => 'records',
        'finance' => 'finance',
        'cashier' => 'cashier'
    ];
    
    return $dashboards[$role] ?? 'student';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - School Management System</title>
    <link rel="stylesheet" href="/assets/css/main.css">
    <style>
        .login-container {
            max-width: 400px;
            margin: 100px auto;
            padding: 2rem;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        
        .login-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .form-group {
            margin-bottom: 1rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: bold;
        }
        
        .form-group input {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
        }
        
        .btn {
            width: 100%;
            padding: 0.75rem;
            background: #3498db;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 1rem;
            cursor: pointer;
        }
        
        .btn:hover {
            background: #2980b9;
        }
        
        .alert {
            padding: 1rem;
            margin-bottom: 1rem;
            border-radius: 4px;
        }
        
        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .login-links {
            text-align: center;
            margin-top: 1rem;
        }
        
        .login-links a {
            color: #3498db;
            text-decoration: none;
        }
        
        .login-links a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <h1>School Management System</h1>
            <p>Please login to continue</p>
        </div>
        
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <?php foreach ($errors as $error): ?>
                    <p><?php echo $error; ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>
            
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            
            <button type="submit" class="btn">Login</button>
        </form>
        
        <div class="login-links">
            <p><a href="register.php">Don't have an account? Register here</a></p>
            <p><a href="forgot_password.php">Forgot password?</a></p>
        </div>
    </div>
</body>
</html>
```

### 20.3 Registration with Admin Approval

```php
<?php
// modules/auth/register.php
require_once '../../config/database.php';
require_once '../../includes/security.php';

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Rate limiting
    if (!Security::checkRateLimit('register', 3, 3600)) {
        $errors[] = "Too many registration attempts. Please try again later.";
    }
    
    // Sanitize and validate inputs
    $data = [
        'username' => sanitizeInput($_POST['username'] ?? ''),
        'email' => sanitizeInput($_POST['email'] ?? ''),
        'password' => $_POST['password'] ?? '',
        'confirm_password' => $_POST['confirm_password'] ?? '',
        'first_name' => sanitizeInput($_POST['first_name'] ?? ''),
        'last_name' => sanitizeInput($_POST['last_name'] ?? ''),
        'middle_name' => sanitizeInput($_POST['middle_name'] ?? ''),
        'role_id' => (int)($_POST['role_id'] ?? 0)
    ];
    
    // Validation rules
    if (empty($data['username'])) {
        $errors[] = "Username is required";
    } elseif (strlen($data['username']) < 3) {
        $errors[] = "Username must be at least 3 characters";
    }
    
    if (empty($data['email'])) {
        $errors[] = "Email is required";
    } elseif (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }
    
    if (empty($data['password'])) {
        $errors[] = "Password is required";
    } elseif (!Security::validatePassword($data['password'])) {
        $errors[] = "Password must be at least 8 characters with uppercase, lowercase, number, and special character";
    }
    
    if ($data['password'] !== $data['confirm_password']) {
        $errors[] = "Passwords do not match";
    }
    
    if (empty($data['first_name'])) {
        $errors[] = "First name is required";
    }
    
    if (empty($data['last_name'])) {
        $errors[] = "Last name is required";
    }
    
    if (empty($data['role_id']) || $data['role_id'] == 1) {
        $errors[] = "Please select a valid role (Admin cannot self-register)";
    }
    
    if (empty($errors)) {
        try {
            $database = new Database();
            $db = $database->getConnection();
            
            // Check if username or email already exists
            $checkQuery = "SELECT COUNT(*) FROM users WHERE username = ? OR email = ?";
            $checkStmt = $db->prepare($checkQuery);
            $checkStmt->execute([$data['username'], $data['email']]);
            
            if ($checkStmt->fetchColumn() > 0) {
                $errors[] = "Username or email already exists";
            } else {
                // Create user
                $query = "INSERT INTO users 
                         SET username = ?, email = ?, password_hash = ?, role_id = ?, 
                             first_name = ?, last_name = ?, middle_name = ?, status = 'pending'";
                
                $stmt = $db->prepare($query);
                $password_hash = password_hash($data['password'], PASSWORD_DEFAULT);
                
                $stmt->execute([
                    $data['username'],
                    $data['email'],
                    $password_hash,
                    $data['role_id'],
                    $data['first_name'],
                    $data['last_name'],
                    $data['middle_name']
                ]);
                
                $user_id = $db->lastInsertId();
                
                // Create role-specific profile
                $this->createRoleProfile($db, $user_id, $data['role_id'], $data);
                
                // Log the registration
                $audit = new AuditLogger($db);
                $audit->log($user_id, 'REGISTER', 'users', $user_id);
                
                // Send notification email to admin
                $this->sendAdminNotification($data);
                
                $success = true;
            }
        } catch(PDOException $e) {
            $errors[] = "Registration failed. Please try again.";
        }
    }
}

function createRoleProfile($db, $user_id, $role_id, $data) {
    switch ($role_id) {
        case 2: // Student
            $student_number = generateStudentNumber();
            $query = "INSERT INTO students 
                     SET user_id = ?, student_number = ?, course_id = 1, year_level = 1";
            $stmt = $db->prepare($query);
            $stmt->execute([$user_id, $student_number]);
            break;
            
        case 3: // Teacher
            $employee_number = generateEmployeeNumber();
            $query = "INSERT INTO teachers 
                     SET user_id = ?, employee_number = ?, department_id = 1, 
                         first_name = ?, last_name = ?, middle_name = ?";
            $stmt = $db->prepare($query);
            $stmt->execute([$user_id, $employee_number, $data['first_name'], 
                           $data['last_name'], $data['middle_name']]);
            break;
            
        // Add other roles as needed
    }
}

function generateStudentNumber() {
    $year = date('Y');
    $random = str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
    return $year . '-' . $random;
}

function generateEmployeeNumber() {
    $year = date('Y');
    $random = str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
    return 'EMP' . $year . '-' . $random;
}

function sendAdminNotification($data) {
    // In production, implement actual email sending
    // For now, just log the notification
    error_log("New registration: " . $data['username'] . " (" . $data['email'] . ")");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - School Management System</title>
    <link rel="stylesheet" href="/assets/css/main.css">
</head>
<body>
    <div class="register-container">
        <div class="register-header">
            <h1>Create Account</h1>
            <p>Please fill in your information to register</p>
        </div>
        
        <?php if ($success): ?>
            <div class="alert alert-success">
                <h3>Registration Successful!</h3>
                <p>Your account has been created and is pending approval from the administrator.</p>
                <p>You will receive an email once your account is approved.</p>
                <p><a href="login.php">Click here to login</a></p>
            </div>
        <?php else: ?>
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <?php foreach ($errors as $error): ?>
                        <p><?php echo $error; ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="form-row">
                    <div class="form-group">
                        <label for="first_name">First Name:</label>
                        <input type="text" id="first_name" name="first_name" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="last_name">Last Name:</label>
                        <input type="text" id="last_name" name="last_name" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="middle_name">Middle Name:</label>
                    <input type="text" id="middle_name" name="middle_name">
                </div>
                
                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" id="username" name="username" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required>
                </div>
                
                <div class="form-group">
                    <label for="role">Role:</label>
                    <select id="role" name="role_id" required>
                        <option value="">Select Role</option>
                        <option value="2">Student</option>
                        <option value="3">Teacher</option>
                        <option value="4">Dean/Program Head</option>
                        <option value="5">Records Officer</option>
                        <option value="6">Finance Officer</option>
                        <option value="7">Cashier</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" required>
                    <small>Password must be at least 8 characters with uppercase, lowercase, number, and special character</small>
                </div>
                
                <div class="form-group">
                    <label for="confirm_password">Confirm Password:</label>
                    <input type="password" id="confirm_password" name="confirm_password" required>
                </div>
                
                <button type="submit" class="btn">Register</button>
            </form>
            
            <div class="login-links">
                <p>Already have an account? <a href="login.php">Login here</a></p>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
```

### 20.4 Student Enrollment

```php
<?php
// modules/student/enrollment/apply.php
require_once '../../../config/database.php';
require_once '../../../includes/auth_check.php';

// Require student role
requireRole('student');

// Get student information
$database = new Database();
$db = $database->getConnection();

$student_query = "SELECT s.*, c.course_name 
                 FROM students s 
                 JOIN courses c ON s.course_id = c.course_id 
                 WHERE s.user_id = ?";
$stmt = $db->prepare($student_query);
$stmt->execute([$_SESSION['user_id']]);
$student = $stmt->fetch();

// Get current semester
$current_semester = getCurrentSemester($db);

// Get available subjects for student's course
$subjects_query = "SELECT so.*, sub.subject_code, sub.subject_title, sub.units, 
                         t.first_name, t.last_name, sec.section
                  FROM subject_offerings so
                  JOIN subjects sub ON so.subject_id = sub.subject_id
                  JOIN teachers t ON so.teacher_id = t.teacher_id
                  LEFT JOIN schedules sch ON so.offering_id = sch.offering_id
                  LEFT JOIN sections sec ON so.section = sec.section_id
                  WHERE so.semester_id = ? AND so.status = 'Open'
                  AND (sub.course_id = ? OR sub.is_elective = 1)
                  GROUP BY so.offering_id
                  ORDER BY sub.subject_code";
$stmt = $db->prepare($subjects_query);
$stmt->execute([$current_semester['semester_id'], $student['course_id']]);
$available_subjects = $stmt->fetchAll();

// Get current enrollment if exists
$enrollment_query = "SELECT e.*, esl.load_id, so.offering_id, sub.subject_code, sub.subject_title
                    FROM enrollments e
                    LEFT JOIN student_subject_loads esl ON e.enrollment_id = esl.enrollment_id
                    LEFT JOIN subject_offerings so ON esl.offering_id = so.offering_id
                    LEFT JOIN subjects sub ON so.subject_id = sub.subject_id
                    WHERE e.student_id = ? AND e.semester_id = ?";
$stmt = $db->prepare($enrollment_query);
$stmt->execute([$student['student_id'], $current_semester['semester_id']]);
$current_enrollment = $stmt->fetchAll();

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $selected_subjects = $_POST['subjects'] ?? [];
    
    if (empty($selected_subjects)) {
        $errors[] = "Please select at least one subject";
    } else {
        try {
            $db->beginTransaction();
            
            // Check prerequisites
            foreach ($selected_subjects as $offering_id) {
                if (!checkPrerequisites($db, $student['student_id'], $offering_id)) {
                    $errors[] = "Prerequisites not met for one or more subjects";
                    break;
                }
            }
            
            if (empty($errors)) {
                // Create or update enrollment
                if (empty($current_enrollment)) {
                    // Create new enrollment
                    $enroll_query = "INSERT INTO enrollments 
                                   SET student_id = ?, semester_id = ?, course_id = ?, 
                                       year_level = ?, enrollment_date = CURDATE(), status = 'Pending'";
                    $stmt = $db->prepare($enroll_query);
                    $stmt->execute([
                        $student['student_id'],
                        $current_semester['semester_id'],
                        $student['course_id'],
                        $student['year_level']
                    ]);
                    $enrollment_id = $db->lastInsertId();
                } else {
                    $enrollment_id = $current_enrollment[0]['enrollment_id'];
                    
                    // Remove existing subject loads
                    $delete_query = "DELETE FROM student_subject_loads WHERE enrollment_id = ?";
                    $stmt = $db->prepare($delete_query);
                    $stmt->execute([$enrollment_id]);
                }
                
                // Add selected subjects
                foreach ($selected_subjects as $offering_id) {
                    $load_query = "INSERT INTO student_subject_loads 
                                SET enrollment_id = ?, offering_id = ?";
                    $stmt = $db->prepare($load_query);
                    $stmt->execute([$enrollment_id, $offering_id]);
                    
                    // Update current students count
                    $update_query = "UPDATE subject_offerings 
                                   SET current_students = current_students + 1 
                                   WHERE offering_id = ?";
                    $stmt = $db->prepare($update_query);
                    $stmt->execute([$offering_id]);
                }
                
                // Log the action
                $audit = new AuditLogger($db);
                $audit->log($_SESSION['user_id'], 'ENROLL', 'enrollments', $enrollment_id);
                
                $db->commit();
                $success = true;
                
                // Refresh enrollment data
                $stmt = $db->prepare($enrollment_query);
                $stmt->execute([$student['student_id'], $current_semester['semester_id']]);
                $current_enrollment = $stmt->fetchAll();
            } else {
                $db->rollBack();
            }
        } catch (Exception $e) {
            $db->rollBack();
            $errors[] = "Enrollment failed. Please try again.";
        }
    }
}

function getCurrentSemester($db) {
    $query = "SELECT * FROM semesters WHERE status = 'current' LIMIT 1";
    $stmt = $db->prepare($query);
    $stmt->execute();
    return $stmt->fetch();
}

function checkPrerequisites($db, $student_id, $offering_id) {
    // Get subject and check prerequisites
    $query = "SELECT sub.subject_id 
             FROM subject_offerings so
             JOIN subjects sub ON so.subject_id = sub.subject_id
             WHERE so.offering_id = ?";
    $stmt = $db->prepare($query);
    $stmt->execute([$offering_id]);
    $subject = $stmt->fetch();
    
    if (!$subject) return false;
    
    // Check if prerequisites are completed
    $prereq_query = "SELECT COUNT(*) as count
                    FROM subject_prerequisites sp
                    LEFT JOIN student_subject_loads ssl ON sp.prerequisite_subject_id = 
                        (SELECT so2.subject_id FROM subject_offerings so2 WHERE so2.offering_id = ssl.offering_id)
                    WHERE sp.subject_id = ? AND (ssl.load_id IS NULL OR ssl.grade_final < 3.0)";
    $stmt = $db->prepare($prereq_query);
    $stmt->execute([$subject['subject_id']]);
    $result = $stmt->fetch();
    
    return $result['count'] == 0;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Enrollment</title>
    <link rel="stylesheet" href="/assets/css/main.css">
</head>
<body>
    <div class="enrollment-container">
        <h1>Student Enrollment</h1>
        
        <div class="student-info">
            <h2>Student Information</h2>
            <p><strong>Name:</strong> <?php echo $student['first_name'] . ' ' . $student['last_name']; ?></p>
            <p><strong>Student ID:</strong> <?php echo $student['student_number']; ?></p>
            <p><strong>Course:</strong> <?php echo $student['course_name']; ?></p>
            <p><strong>Year Level:</strong> <?php echo $student['year_level']; ?></p>
            <p><strong>Semester:</strong> <?php echo $current_semester['semester_name'] . ' ' . $current_semester['year_start'] . '-' . $current_semester['year_end']; ?></p>
        </div>
        
        <?php if ($success): ?>
            <div class="alert alert-success">
                <h3>Enrollment Submitted!</h3>
                <p>Your enrollment application has been submitted for approval.</p>
                <p>You will be notified once your enrollment is approved.</p>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <?php foreach ($errors as $error): ?>
                    <p><?php echo $error; ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        
        <div class="enrollment-form">
            <h2>Available Subjects</h2>
            
            <form method="POST" action="">
                <div class="subjects-grid">
                    <?php foreach ($available_subjects as $subject): ?>
                        <div class="subject-card">
                            <div class="subject-header">
                                <input type="checkbox" name="subjects[]" value="<?php echo $subject['offering_id']; ?>"
                                       id="subject_<?php echo $subject['offering_id']; ?>"
                                       <?php echo in_array($subject['offering_id'], array_column($current_enrollment, 'offering_id')) ? 'checked' : ''; ?>>
                                <label for="subject_<?php echo $subject['offering_id']; ?>">
                                    <strong><?php echo $subject['subject_code']; ?></strong>
                                    <?php echo $subject['subject_title']; ?>
                                </label>
                            </div>
                            <div class="subject-details">
                                <p><strong>Units:</strong> <?php echo $subject['units']; ?></p>
                                <p><strong>Instructor:</strong> <?php echo $subject['first_name'] . ' ' . $subject['last_name']; ?></p>
                                <p><strong>Section:</strong> <?php echo $subject['section'] ?? 'TBA'; ?></p>
                                <p><strong>Slots:</strong> <?php echo $subject['current_students']; ?>/<?php echo $subject['max_students']; ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <div class="enrollment-summary">
                    <h3>Enrollment Summary</h3>
                    <div id="selected-subjects">
                        <p>Total Units: <span id="total-units">0</span></p>
                        <p>Selected Subjects: <span id="subject-count">0</span></p>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary">Submit Enrollment</button>
            </form>
        </div>
    </div>
    
    <script>
        // Update enrollment summary
        document.addEventListener('DOMContentLoaded', function() {
            const checkboxes = document.querySelectorAll('input[name="subjects[]"]');
            const totalUnitsElement = document.getElementById('total-units');
            const subjectCountElement = document.getElementById('subject-count');
            
            function updateSummary() {
                let totalUnits = 0;
                let subjectCount = 0;
                
                checkboxes.forEach(function(checkbox) {
                    if (checkbox.checked) {
                        const card = checkbox.closest('.subject-card');
                        const units = parseFloat(card.querySelector('.subject-details p').textContent.replace(/[^\d.]/g, ''));
                        totalUnits += units;
                        subjectCount++;
                    }
                });
                
                totalUnitsElement.textContent = totalUnits.toFixed(1);
                subjectCountElement.textContent = subjectCount;
            }
            
            checkboxes.forEach(function(checkbox) {
                checkbox.addEventListener('change', updateSummary);
            });
            
            // Initial update
            updateSummary();
        });
    </script>
</body>
</html>
```

This completes the comprehensive School Information System design document. The system is now ready for implementation following the structured approach outlined in the development plan.
