<?php
/**
 * Database Connection Test
 */

echo "<h1>School Information System - Test</h1>";

// Test 1: PHP Version
echo "<h2>PHP Version: " . phpversion() . "</h2>";

// Test 2: Required Extensions
$required_extensions = ['pdo', 'pdo_mysql', 'json', 'mbstring'];
echo "<h2>PHP Extensions:</h2>";
foreach ($required_extensions as $ext) {
    $status = extension_loaded($ext) ? "OK" : "MISSING";
    echo "$ext: $status<br>";
}

// Test 3: Database Connection
echo "<h2>Database Connection:</h2>";
try {
    require_once __DIR__ . '/config/database.php';
    $db = new Database();
    $conn = $db->getConnection();
    
    if ($conn) {
        echo "Database Connection: SUCCESS<br>";
        
        // Test 4: Table Existence
        echo "<h2>Database Tables:</h2>";
        $tables = ['users', 'roles', 'students', 'courses', 'subjects'];
        foreach ($tables as $table) {
            $stmt = $conn->prepare("SHOW TABLES LIKE '$table'");
            $stmt->execute();
            $exists = $stmt->rowCount() > 0 ? "EXISTS" : "MISSING";
            echo "$table: $exists<br>";
        }
        
        // Test 5: Default Admin User
        echo "<h2>Default Admin User:</h2>";
        $stmt = $conn->prepare("SELECT username FROM users WHERE username = 'admin'");
        $stmt->execute();
        $admin = $stmt->fetch();
        if ($admin) {
            echo "Admin user: EXISTS<br>";
        } else {
            echo "Admin user: MISSING<br>";
        }
    }
} catch (Exception $e) {
    echo "Database Connection: FAILED<br>";
    echo "Error: " . $e->getMessage() . "<br>";
}

// Test 6: File Paths
echo "<h2>File Paths:</h2>";
$files = [
    'config/config.php',
    'config/database.php', 
    'includes/functions.php',
    'modules/auth/login.php'
];
foreach ($files as $file) {
    $exists = file_exists(__DIR__ . '/' . $file) ? "EXISTS" : "MISSING";
    echo "$file: $exists<br>";
}

echo "<h2><a href='modules/auth/login.php'>Go to Login Page</a></h2>";
?>
