/**
 * School Information System - Main JavaScript
 * Version: 1.0.0
 */

// Global variables
let csrfToken = '';
let currentUser = null;

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

// Initialize application
function initializeApp() {
    // Get CSRF token from meta tag or generate one
    csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || generateCSRFToken();
    
    // Initialize current user data
    currentUser = getCurrentUser();
    
    // Initialize components
    initializeModals();
    initializeForms();
    initializeTables();
    initializeSidebar();
    initializeTooltips();
    initializeDatePickers();
    initializeFileUploads();
    initializeAccountNavigation();
    
    // Setup global event listeners
    setupGlobalEventListeners();
    
    console.log('School Information System initialized');
}

function initializeAccountNavigation() {
    const navLists = document.querySelectorAll('.nav');

    navLists.forEach(nav => {
        if (nav.querySelector('a[href*="/modules/account/change_password.php"]')) {
            return;
        }

        const logoutLink = nav.querySelector('a[href*="/modules/auth/logout.php"]');
        if (!logoutLink) {
            return;
        }

        const changePasswordUrl = logoutLink.href.replace('/modules/auth/logout.php', '/modules/account/change_password.php');
        const item = document.createElement('li');
        const link = document.createElement('a');
        link.href = changePasswordUrl;
        link.textContent = 'Change Password';
        item.appendChild(link);
        logoutLink.closest('li')?.before(item);
    });
}

// CSRF Token Management
function generateCSRFToken() {
    const array = new Uint8Array(32);
    crypto.getRandomValues(array);
    return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
}

function getCSRFToken() {
    return csrfToken;
}

function addCSRFToForm(form) {
    if (!form) return;
    
    let csrfInput = form.querySelector('input[name="csrf_token"]');
    if (!csrfInput) {
        csrfInput = document.createElement('input');
        csrfInput.type = 'hidden';
        csrfInput.name = 'csrf_token';
        form.appendChild(csrfInput);
    }

    // Keep server-rendered CSRF tokens intact.
    // Only inject a token when the form does not already have one.
    if (!csrfInput.value) {
        csrfInput.value = getCSRFToken();
    }
}

// User Management
function getCurrentUser() {
    try {
        const userData = document.querySelector('meta[name="user-data"]')?.getAttribute('content');
        return userData ? JSON.parse(userData) : null;
    } catch (e) {
        console.error('Error parsing user data:', e);
        return null;
    }
}

function hasPermission(permission) {
    return currentUser?.permissions?.includes(permission) || currentUser?.role === 'admin';
}

// Modal Management
function initializeModals() {
    const modals = document.querySelectorAll('.modal');
    
    modals.forEach(modal => {
        const closeBtn = modal.querySelector('.modal-close');
        const cancelBtn = modal.querySelector('.modal-cancel');
        
        if (closeBtn) {
            closeBtn.addEventListener('click', () => closeModal(modal));
        }
        
        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => closeModal(modal));
        }
        
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                closeModal(modal);
            }
        });
    });
}

function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
        
        // Focus first input
        const firstInput = modal.querySelector('input, select, textarea');
        if (firstInput) {
            firstInput.focus();
        }
    }
}

function closeModal(modal) {
    if (modal) {
        modal.classList.remove('show');
        document.body.style.overflow = '';
        
        // Clear form if it exists
        const form = modal.querySelector('form');
        if (form) {
            form.reset();
            clearValidationErrors(form);
        }
    }
}

function closeAllModals() {
    const modals = document.querySelectorAll('.modal.show');
    modals.forEach(modal => closeModal(modal));
}

// Form Management
function initializeForms() {
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        // Add CSRF token to all forms
        addCSRFToForm(form);
        
        // Add submit event listener
        form.addEventListener('submit', handleFormSubmit);
        
        // Add real-time validation
        addRealtimeValidation(form);
    });
}

function handleFormSubmit(e) {
    const form = e.target;
    
    // Skip if form has novalidate attribute
    if (form.hasAttribute('novalidate')) {
        return;
    }
    
    // Validate form
    if (!validateForm(form)) {
        e.preventDefault();
        return false;
    }
    
    // Show loading state
    const submitBtn = form.querySelector('[type="submit"]');
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner"></span> Processing...';
    }
    
    // Handle AJAX forms
    if (form.classList.contains('ajax-form')) {
        e.preventDefault();
        submitFormAJAX(form);
    }
}

function validateForm(form) {
    let isValid = true;
    clearValidationErrors(form);
    
    const requiredFields = form.querySelectorAll('[required]');
    requiredFields.forEach(field => {
        if (!validateField(field)) {
            isValid = false;
        }
    });
    
    return isValid;
}

function validateField(field) {
    const value = field.value.trim();
    let isValid = true;
    let errorMessage = '';
    
    // Required validation
    if (field.hasAttribute('required') && !value) {
        errorMessage = 'This field is required';
        isValid = false;
    }
    
    // Email validation
    if (isValid && field.type === 'email' && value) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(value)) {
            errorMessage = 'Please enter a valid email address';
            isValid = false;
        }
    }
    
    // Phone validation
    if (isValid && field.type === 'tel' && value) {
        const phoneRegex = /^(09|\+639)\d{9}$/;
        if (!phoneRegex.test(value)) {
            errorMessage = 'Please enter a valid phone number';
            isValid = false;
        }
    }
    
    // Password validation
    if (isValid && field.type === 'password' && value) {
        const passwordValidationMode = field.form?.dataset?.passwordValidation || 'basic';

        // "none" is used by login form to avoid blocking existing short passwords.
        if (passwordValidationMode === 'none') {
            // No client-side password complexity checks.
        } else if (passwordValidationMode === 'strong') {
            if (value.length < 8) {
                errorMessage = 'Password must be at least 8 characters long';
                isValid = false;
            } else if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])/.test(value)) {
                errorMessage = 'Password must contain uppercase, lowercase, number, and special character';
                isValid = false;
            }
        } else {
            // Basic mode matches backend relaxed rule.
            if (value.length < 4) {
                errorMessage = 'Password must be at least 4 characters long';
                isValid = false;
            }
        }
    }
    
    // Custom validation
    if (isValid && field.dataset.validation) {
        const customValidation = validateCustomField(field, value);
        if (!customValidation.valid) {
            errorMessage = customValidation.message;
            isValid = false;
        }
    }
    
    // Show validation feedback
    showFieldValidation(field, isValid, errorMessage);
    
    return isValid;
}

function validateCustomField(field, value) {
    const validation = field.dataset.validation;
    
    switch (validation) {
        case 'student-number':
            const studentNumberRegex = /^\d{4}-\d{5}$/;
            return {
                valid: studentNumberRegex.test(value),
                message: 'Student number must be in format YYYY-XXXXX'
            };
            
        case 'numeric':
            return {
                valid: !isNaN(value) && value !== '',
                message: 'Please enter a valid number'
            };
            
        case 'positive-numeric':
            return {
                valid: !isNaN(value) && parseFloat(value) > 0,
                message: 'Please enter a positive number'
            };
            
        default:
            return { valid: true };
    }
}

function showFieldValidation(field, isValid, errorMessage) {
    const feedback = field.parentElement.querySelector('.invalid-feedback') || 
                    field.parentElement.querySelector('.valid-feedback');
    
    field.classList.remove('is-valid', 'is-invalid');
    
    if (isValid) {
        field.classList.add('is-valid');
        if (feedback && feedback.classList.contains('valid-feedback')) {
            feedback.textContent = '';
        }
    } else {
        field.classList.add('is-invalid');
        if (feedback && feedback.classList.contains('invalid-feedback')) {
            feedback.textContent = errorMessage;
        } else {
            const errorDiv = document.createElement('div');
            errorDiv.className = 'invalid-feedback';
            errorDiv.textContent = errorMessage;
            field.parentElement.appendChild(errorDiv);
        }
    }
}

function clearValidationErrors(form) {
    const fields = form.querySelectorAll('.is-invalid, .is-valid');
    fields.forEach(field => {
        field.classList.remove('is-invalid', 'is-valid');
    });
    
    const feedbacks = form.querySelectorAll('.invalid-feedback, .valid-feedback');
    feedbacks.forEach(feedback => {
        feedback.textContent = '';
    });
}

function addRealtimeValidation(form) {
    const fields = form.querySelectorAll('input, select, textarea');
    
    fields.forEach(field => {
        field.addEventListener('blur', () => validateField(field));
        field.addEventListener('input', () => {
            if (field.classList.contains('is-invalid')) {
                validateField(field);
            }
        });
    });
}

// AJAX Functions
function submitFormAJAX(form) {
    const formData = new FormData(form);
    const method = form.method || 'POST';
    const action = form.action;
    
    fetch(action, {
        method: method,
        body: formData,
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        handleAJAXResponse(data, form);
    })
    .catch(error => {
        console.error('AJAX Error:', error);
        showAlert('error', 'An error occurred. Please try again.');
        resetFormSubmitButton(form);
    });
}

function handleAJAXResponse(data, form) {
    resetFormSubmitButton(form);
    
    if (data.success) {
        showAlert('success', data.message || 'Operation completed successfully');
        
        // Close modal if form is in one
        const modal = form.closest('.modal');
        if (modal) {
            closeModal(modal);
        }
        
        // Reload page or update content
        if (data.reload) {
            setTimeout(() => window.location.reload(), 1000);
        } else if (data.redirect) {
            window.location.href = data.redirect;
        } else if (data.callback) {
            window[data.callback](data.data);
        }
    } else {
        showAlert('error', data.message || 'Operation failed');
        
        // Show validation errors if provided
        if (data.errors) {
            showFormErrors(form, data.errors);
        }
    }
}

function showFormErrors(form, errors) {
    Object.keys(errors).forEach(fieldName => {
        const field = form.querySelector(`[name="${fieldName}"]`);
        if (field) {
            showFieldValidation(field, false, errors[fieldName]);
        }
    });
}

function resetFormSubmitButton(form) {
    const submitBtn = form.querySelector('[type="submit"]');
    if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = submitBtn.dataset.originalText || 'Submit';
    }
}

// Table Management
function initializeTables() {
    const tables = document.querySelectorAll('.data-table');
    
    tables.forEach(table => {
        initializeDataTable(table);
    });
}

function initializeDataTable(table) {
    // Add sorting functionality
    const headers = table.querySelectorAll('th[data-sortable]');
    headers.forEach(header => {
        header.addEventListener('click', () => sortTable(table, header));
        header.style.cursor = 'pointer';
    });
    
    // Add search functionality
    const searchInput = table.parentElement.querySelector('.table-search');
    if (searchInput) {
        searchInput.addEventListener('input', () => filterTable(table, searchInput.value));
    }
}

function sortTable(table, header) {
    const tbody = table.querySelector('tbody');
    const rows = Array.from(tbody.querySelectorAll('tr'));
    const columnIndex = Array.from(header.parentElement.children).indexOf(header);
    const isAscending = !header.classList.contains('sort-asc');
    
    // Remove existing sort classes
    table.querySelectorAll('th').forEach(th => {
        th.classList.remove('sort-asc', 'sort-desc');
    });
    
    // Add sort class to current header
    header.classList.add(isAscending ? 'sort-asc' : 'sort-desc');
    
    // Sort rows
    rows.sort((a, b) => {
        const aValue = a.children[columnIndex].textContent.trim();
        const bValue = b.children[columnIndex].textContent.trim();
        
        if (isNumeric(aValue) && isNumeric(bValue)) {
            return isAscending ? 
                parseFloat(aValue) - parseFloat(bValue) : 
                parseFloat(bValue) - parseFloat(aValue);
        } else {
            return isAscending ? 
                aValue.localeCompare(bValue) : 
                bValue.localeCompare(aValue);
        }
    });
    
    // Reorder rows
    rows.forEach(row => tbody.appendChild(row));
}

function filterTable(table, searchTerm) {
    const tbody = table.querySelector('tbody');
    const rows = tbody.querySelectorAll('tr');
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        const matches = text.includes(searchTerm.toLowerCase());
        row.style.display = matches ? '' : 'none';
    });
}

function isNumeric(str) {
    return !isNaN(str) && !isNaN(parseFloat(str));
}

// Sidebar Management
function initializeSidebar() {
    const toggleBtn = document.querySelector('.sidebar-toggle');
    const sidebar = document.querySelector('.sidebar');
    
    if (toggleBtn && sidebar) {
        toggleBtn.addEventListener('click', () => {
            sidebar.classList.toggle('show');
        });
        
        // Close sidebar when clicking outside
        document.addEventListener('click', (e) => {
            if (!sidebar.contains(e.target) && !toggleBtn.contains(e.target)) {
                sidebar.classList.remove('show');
            }
        });
    }
    
    // Set active menu item
    setActiveMenuItem();
}

function setActiveMenuItem() {
    const currentPath = window.location.pathname;
    const menuItems = document.querySelectorAll('.sidebar-menu a');
    
    menuItems.forEach(item => {
        const itemPath = new URL(item.href).pathname;
        if (currentPath === itemPath || currentPath.startsWith(itemPath + '/')) {
            item.classList.add('active');
        }
    });
}

// Alert System
function showAlert(type, message, duration = 5000) {
    const alertContainer = getAlertContainer();
    const alertId = 'alert-' + Date.now();
    
    const alertHTML = `
        <div id="${alertId}" class="alert alert-${type} alert-dismissible" role="alert">
            <span>${message}</span>
            <button type="button" class="alert-close" data-dismiss="alert">&times;</button>
        </div>
    `;
    
    alertContainer.insertAdjacentHTML('beforeend', alertHTML);
    
    const alert = document.getElementById(alertId);
    const closeBtn = alert.querySelector('.alert-close');
    
    closeBtn.addEventListener('click', () => {
        alert.remove();
    });
    
    // Auto-remove after duration
    setTimeout(() => {
        if (alert.parentElement) {
            alert.remove();
        }
    }, duration);
}

function getAlertContainer() {
    let container = document.querySelector('.alert-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'alert-container';
        container.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            max-width: 400px;
        `;
        document.body.appendChild(container);
    }
    return container;
}

// Tooltip System
function initializeTooltips() {
    const tooltipElements = document.querySelectorAll('[data-tooltip]');
    
    tooltipElements.forEach(element => {
        element.addEventListener('mouseenter', showTooltip);
        element.addEventListener('mouseleave', hideTooltip);
    });
}

function showTooltip(e) {
    const element = e.target;
    const text = element.dataset.tooltip;
    
    if (!text) return;
    
    const tooltip = document.createElement('div');
    tooltip.className = 'tooltip';
    tooltip.textContent = text;
    tooltip.style.cssText = `
        position: absolute;
        background: #333;
        color: white;
        padding: 5px 10px;
        border-radius: 4px;
        font-size: 12px;
        z-index: 10000;
        pointer-events: none;
        white-space: nowrap;
    `;
    
    document.body.appendChild(tooltip);
    
    const rect = element.getBoundingClientRect();
    tooltip.style.left = rect.left + (rect.width / 2) - (tooltip.offsetWidth / 2) + 'px';
    tooltip.style.top = rect.top - tooltip.offsetHeight - 5 + 'px';
    
    element.dataset.tooltipId = tooltip.id = 'tooltip-' + Date.now();
}

function hideTooltip(e) {
    const element = e.target;
    const tooltipId = element.dataset.tooltipId;
    
    if (tooltipId) {
        const tooltip = document.getElementById(tooltipId);
        if (tooltip) {
            tooltip.remove();
        }
        delete element.dataset.tooltipId;
    }
}

// Date Picker
function initializeDatePickers() {
    const dateInputs = document.querySelectorAll('input[type="date"]');
    
    dateInputs.forEach(input => {
        // Set max date to today for past date fields
        if (input.dataset.maxDate === 'today') {
            input.max = new Date().toISOString().split('T')[0];
        }
        
        // Set min date to today for future date fields
        if (input.dataset.minDate === 'today') {
            input.min = new Date().toISOString().split('T')[0];
        }
    });
}

// File Upload
function initializeFileUploads() {
    const fileInputs = document.querySelectorAll('input[type="file"]');
    
    fileInputs.forEach(input => {
        input.addEventListener('change', handleFileSelect);
    });
}

function handleFileSelect(e) {
    const input = e.target;
    const files = input.files;
    const preview = input.parentElement.querySelector('.file-preview');
    
    if (preview) {
        preview.innerHTML = '';
        
        Array.from(files).forEach(file => {
            const fileInfo = document.createElement('div');
            fileInfo.className = 'file-info';
            fileInfo.innerHTML = `
                <span class="file-name">${file.name}</span>
                <span class="file-size">(${formatFileSize(file.size)})</span>
            `;
            preview.appendChild(fileInfo);
        });
    }
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Global Event Listeners
function setupGlobalEventListeners() {
    // Handle escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            closeAllModals();
        }
    });
    
    // Handle print
    window.addEventListener('beforeprint', () => {
        document.body.classList.add('printing');
    });
    
    window.addEventListener('afterprint', () => {
        document.body.classList.remove('printing');
    });
    
    // Handle online/offline
    window.addEventListener('online', () => {
        showAlert('success', 'Connection restored');
    });
    
    window.addEventListener('offline', () => {
        showAlert('warning', 'Connection lost. Some features may not work.');
    });
}

// Utility Functions
function confirmAction(message, callback) {
    if (confirm(message)) {
        callback();
    }
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('en-PH', {
        style: 'currency',
        currency: 'PHP'
    }).format(amount);
}

function formatDate(date, format = 'YYYY-MM-DD') {
    const d = new Date(date);
    
    if (isNaN(d.getTime())) {
        return '';
    }
    
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    
    return format
        .replace('YYYY', year)
        .replace('MM', month)
        .replace('DD', day);
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Export functions for global use
window.SIS = {
    openModal,
    closeModal,
    showAlert,
    confirmAction,
    formatCurrency,
    formatDate,
    hasPermission,
    getCSRFToken
};
