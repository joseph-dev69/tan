/**
 * Enhanced UI/UX JavaScript
 * School Information System - Modern & User-Friendly Interactions
 * Version: 2.0.0
 */

// Global variables
let isLoading = false;
let notifications = [];
let theme = localStorage.getItem('theme') || 'light';

// Initialize enhanced features
document.addEventListener('DOMContentLoaded', function() {
    initializeEnhancedFeatures();
    initializeTheme();
    initializeAnimations();
    initializeEnhancedForms();
    initializeEnhancedNavigation();
    initializeEnhancedTables();
    initializeEnhancedModals();
    initializeEnhancedNotifications();
    initializeEnhancedSearch();
    initializeEnhancedAccessibility();
});

// Enhanced Features Initialization
function initializeEnhancedFeatures() {
    // Add loading overlay
    createLoadingOverlay();
    
    // Add mobile menu toggle
    createMobileMenuToggle();
    
    // Add theme toggle
    createThemeToggle();
    
    // Add back to top button
    createBackToTopButton();
    
    // Initialize tooltips
    initializeEnhancedTooltips();
    
    // Setup global error handling
    setupGlobalErrorHandling();
    
    // Initialize keyboard shortcuts
    initializeKeyboardShortcuts();
}

// Theme Management
function initializeTheme() {
    applyTheme(theme);
    
    // Listen for system theme changes
    if (window.matchMedia) {
        const darkModeQuery = window.matchMedia('(prefers-color-scheme: dark)');
        darkModeQuery.addListener((e) => {
            if (theme === 'system') {
                applyTheme(e.matches ? 'dark' : 'light');
            }
        });
    }
}

function createThemeToggle() {
    const themeToggle = document.createElement('button');
    themeToggle.className = 'theme-toggle';
    themeToggle.innerHTML = '🌙';
    themeToggle.setAttribute('aria-label', 'Toggle theme');
    themeToggle.setAttribute('data-tooltip', 'Toggle theme');
    
    themeToggle.addEventListener('click', () => {
        const themes = ['light', 'dark', 'system'];
        const currentIndex = themes.indexOf(theme);
        theme = themes[(currentIndex + 1) % themes.length];
        localStorage.setItem('theme', theme);
        applyTheme(theme);
        updateThemeToggle(theme);
    });
    
    document.body.appendChild(themeToggle);
}

function applyTheme(theme) {
    document.body.classList.remove('theme-light', 'theme-dark', 'theme-system');
    document.body.classList.add(`theme-${theme}`);
    
    if (theme === 'system') {
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        document.body.classList.toggle('theme-dark', prefersDark);
    }
}

function updateThemeToggle(theme) {
    const toggle = document.querySelector('.theme-toggle');
    if (toggle) {
        const icons = { light: '🌙', dark: '☀️', system: '💻' };
        toggle.innerHTML = icons[theme];
    }
}

// Enhanced Loading States
function createLoadingOverlay() {
    const overlay = document.createElement('div');
    overlay.className = 'loading-overlay';
    overlay.style.display = 'none';
    overlay.innerHTML = `
        <div class="loading-content">
            <div class="spinner"></div>
            <p>Loading...</p>
        </div>
    `;
    document.body.appendChild(overlay);
}

function showLoading(message = 'Loading...') {
    isLoading = true;
    const overlay = document.querySelector('.loading-overlay');
    if (overlay) {
        overlay.style.display = 'flex';
        overlay.querySelector('.loading-content p').textContent = message;
    }
}

function hideLoading() {
    isLoading = false;
    const overlay = document.querySelector('.loading-overlay');
    if (overlay) {
        overlay.style.display = 'none';
    }
}

// Enhanced Navigation
function createMobileMenuToggle() {
    const toggle = document.createElement('button');
    toggle.className = 'mobile-menu-toggle';
    toggle.innerHTML = '☰';
    toggle.setAttribute('aria-label', 'Toggle menu');
    toggle.addEventListener('click', () => {
        const sidebar = document.querySelector('.sidebar');
        sidebar.classList.toggle('show');
    });
    
    // Insert into header nav
    const headerNav = document.querySelector('.header .nav');
    if (headerNav) {
        headerNav.insertBefore(toggle, headerNav.firstChild);
    }
}

function initializeEnhancedNavigation() {
    // Add smooth scrolling to navigation links
    document.querySelectorAll('.sidebar-menu a').forEach(link => {
        link.addEventListener('click', function(e) {
            if (this.getAttribute('href').startsWith('#')) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth' });
                }
            }
        });
    });
    
    // Add active state indicators
    updateActiveNavigation();
}

function updateActiveNavigation() {
    const currentPath = window.location.pathname;
    document.querySelectorAll('.sidebar-menu a').forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === currentPath || 
            currentPath.startsWith(link.getAttribute('href'))) {
            link.classList.add('active');
        }
    });
}

// Enhanced Forms
function initializeEnhancedForms() {
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        enhanceForm(form);
    });
}

function enhanceForm(form) {
    // Add floating labels
    addFloatingLabels(form);
    
    // Add real-time validation
    addRealtimeValidation(form);
    
    // Add form progress indicator
    addFormProgress(form);
    
    // Add auto-save for long forms
    addAutoSave(form);
}

function addFloatingLabels(form) {
    const inputs = form.querySelectorAll('input, textarea, select');
    
    inputs.forEach(input => {
        const label = form.querySelector(`label[for="${input.id}"]`);
        if (label && !label.classList.contains('floating-label')) {
            label.classList.add('floating-label');
            
            input.addEventListener('focus', () => {
                label.classList.add('active');
            });
            
            input.addEventListener('blur', () => {
                if (!input.value) {
                    label.classList.remove('active');
                }
            });
            
            // Check initial state
            if (input.value) {
                label.classList.add('active');
            }
        }
    });
}

function addRealtimeValidation(form) {
    const inputs = form.querySelectorAll('input, textarea, select');
    
    inputs.forEach(input => {
        input.addEventListener('input', () => {
            validateFieldEnhanced(input);
        });
        
        input.addEventListener('blur', () => {
            validateFieldEnhanced(input);
        });
    });
}

function validateFieldEnhanced(field) {
    const value = field.value.trim();
    let isValid = true;
    let message = '';
    
    // Enhanced validation rules
    switch (field.type) {
        case 'email':
            isValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
            message = isValid ? '' : 'Please enter a valid email address';
            break;
            
        case 'tel':
            isValid = /^(09|\+639)\d{9}$/.test(value);
            message = isValid ? '' : 'Please enter a valid Philippine phone number';
            break;
            
        case 'password':
            if (value.length < 8) {
                isValid = false;
                message = 'Password must be at least 8 characters';
            } else if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])/.test(value)) {
                isValid = false;
                message = 'Password must contain uppercase, lowercase, number, and special character';
            }
            break;
    }
    
    showFieldValidation(field, isValid, message);
    return isValid;
}

function showFieldValidation(field, isValid, message) {
    field.classList.remove('is-valid', 'is-invalid');
    
    const existingFeedback = field.parentElement.querySelector('.field-feedback');
    if (existingFeedback) {
        existingFeedback.remove();
    }
    
    if (!isValid && message) {
        field.classList.add('is-invalid');
        
        const feedback = document.createElement('div');
        feedback.className = 'field-feedback';
        feedback.textContent = message;
        field.parentElement.appendChild(feedback);
    } else if (isValid && field.value) {
        field.classList.add('is-valid');
        
        const feedback = document.createElement('div');
        feedback.className = 'field-feedback valid';
        feedback.textContent = '✓ Valid';
        field.parentElement.appendChild(feedback);
    }
}

function addFormProgress(form) {
    const inputs = form.querySelectorAll('input, textarea, select');
    const totalFields = inputs.length;
    
    const progressBar = document.createElement('div');
    progressBar.className = 'form-progress';
    progressBar.innerHTML = `
        <div class="progress">
            <div class="progress-bar" style="width: 0%"></div>
        </div>
        <small class="progress-text">0% Complete</small>
    `;
    
    form.insertBefore(progressBar, form.firstChild);
    
    inputs.forEach(input => {
        input.addEventListener('input', () => {
            const filledFields = Array.from(inputs).filter(inp => inp.value.trim()).length;
            const progress = (filledFields / totalFields) * 100;
            updateFormProgress(progressBar, progress);
        });
    });
}

function updateFormProgress(progressBar, progress) {
    const bar = progressBar.querySelector('.progress-bar');
    const text = progressBar.querySelector('.progress-text');
    
    bar.style.width = `${progress}%`;
    text.textContent = `${Math.round(progress)}% Complete`;
    
    // Change color based on progress
    bar.className = 'progress-bar';
    if (progress === 100) {
        bar.classList.add('progress-bar-success');
    } else if (progress > 50) {
        bar.classList.add('progress-bar-warning');
    }
}

function addAutoSave(form) {
    const formId = form.id || 'form-' + Date.now();
    let autoSaveTimer;
    
    form.addEventListener('input', () => {
        clearTimeout(autoSaveTimer);
        autoSaveTimer = setTimeout(() => {
            autoSaveForm(form, formId);
        }, 2000);
    });
}

function autoSaveForm(form, formId) {
    const formData = new FormData(form);
    const data = {};
    
    for (let [key, value] of formData.entries()) {
        data[key] = value;
    }
    
    localStorage.setItem(`autosave-${formId}`, JSON.stringify(data));
    
    showNotification('Form auto-saved', 'info');
}

// Enhanced Tables
function initializeEnhancedTables() {
    const tables = document.querySelectorAll('.data-table');
    
    tables.forEach(table => {
        enhanceTable(table);
    });
}

function enhanceTable(table) {
    // Add row selection
    addTableSelection(table);
    
    // Add search functionality
    addTableSearch(table);
    
    // Add export functionality
    addTableExport(table);
    
    // Add sorting indicators
    addTableSorting(table);
}

function addTableSelection(table) {
    const tbody = table.querySelector('tbody');
    const rows = tbody.querySelectorAll('tr');
    
    // Add checkbox column header
    const headerRow = table.querySelector('thead tr');
    const checkboxHeader = document.createElement('th');
    checkboxHeader.innerHTML = '<input type="checkbox" id="selectAllTable">';
    headerRow.insertBefore(checkboxHeader, headerRow.firstChild);
    
    // Add checkboxes to rows
    rows.forEach(row => {
        const checkboxCell = document.createElement('td');
        checkboxCell.innerHTML = '<input type="checkbox" class="row-select">';
        row.insertBefore(checkboxCell, row.firstChild);
    });
    
    // Handle select all functionality
    const selectAll = document.getElementById('selectAllTable');
    if (selectAll) {
        selectAll.addEventListener('change', () => {
            const rowCheckboxes = table.querySelectorAll('.row-select');
            rowCheckboxes.forEach(checkbox => {
                checkbox.checked = selectAll.checked;
            });
        });
    }
}

function addTableSearch(table) {
    const searchContainer = document.createElement('div');
    searchContainer.className = 'table-search-container';
    searchContainer.innerHTML = `
        <input type="text" class="table-search" placeholder="Search table...">
        <button class="btn btn-sm btn-secondary search-clear">Clear</button>
    `;
    
    table.parentElement.insertBefore(searchContainer, table);
    
    const searchInput = searchContainer.querySelector('.table-search');
    const clearButton = searchContainer.querySelector('.search-clear');
    
    searchInput.addEventListener('input', () => {
        filterTable(table, searchInput.value);
    });
    
    clearButton.addEventListener('click', () => {
        searchInput.value = '';
        filterTable(table, '');
    });
}

function filterTable(table, searchTerm) {
    const tbody = table.querySelector('tbody');
    const rows = tbody.querySelectorAll('tr');
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        const matches = text.includes(searchTerm.toLowerCase());
        row.style.display = matches ? '' : 'none';
    });
}

function addTableExport(table) {
    const exportButton = document.createElement('button');
    exportButton.className = 'btn btn-sm btn-secondary table-export';
    exportButton.textContent = 'Export CSV';
    exportButton.addEventListener('click', () => {
        exportTableToCSV(table);
    });
    
    table.parentElement.appendChild(exportButton);
}

function exportTableToCSV(table) {
    const rows = table.querySelectorAll('tr');
    let csv = [];
    
    // Get headers
    const headers = Array.from(table.querySelectorAll('thead th')).map(th => th.textContent.trim());
    csv.push(headers.join(','));
    
    // Get data rows
    rows.forEach(row => {
        const cells = Array.from(row.querySelectorAll('td')).map(td => {
            // Escape quotes and commas
            return `"${td.textContent.trim().replace(/"/g, '""')}"`;
        });
        csv.push(cells.join(','));
    });
    
    const csvContent = csv.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = 'table-export.csv';
    a.click();
    
    URL.revokeObjectURL(url);
}

// Enhanced Modals
function initializeEnhancedModals() {
    const modals = document.querySelectorAll('.modal');
    
    modals.forEach(modal => {
        enhanceModal(modal);
    });
}

function enhanceModal(modal) {
    // Add backdrop click prevention
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            closeModal(modal);
        }
    });
    
    // Add escape key support
    modal.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            closeModal(modal);
        }
    });
    
    // Add focus management
    modal.addEventListener('show', () => {
        const firstInput = modal.querySelector('input, select, textarea, button');
        if (firstInput) {
            firstInput.focus();
        }
    });
}

function openModal(modalId, options = {}) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
        
        // Custom animations
        if (options.animation) {
            modal.classList.add(options.animation);
        }
        
        // Trigger custom event
        modal.dispatchEvent(new CustomEvent('show'));
    }
}

function closeModal(modal) {
    if (modal) {
        modal.classList.remove('show');
        document.body.style.overflow = '';
        
        // Trigger custom event
        modal.dispatchEvent(new CustomEvent('hide'));
    }
}

// Enhanced Notifications
function initializeEnhancedNotifications() {
    createNotificationContainer();
}

function createNotificationContainer() {
    const container = document.createElement('div');
    container.className = 'notification-container';
    container.setAttribute('aria-live', 'polite');
    document.body.appendChild(container);
}

function showNotification(message, type = 'info', duration = 5000, options = {}) {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <div class="notification-message">${message}</div>
            <button class="notification-close" aria-label="Close notification">&times;</button>
        </div>
    `;
    
    // Add custom options
    if (options.persistent) {
        notification.classList.add('notification-persistent');
    }
    
    if (options.action) {
        const actionButton = document.createElement('button');
        actionButton.className = 'notification-action';
        actionButton.textContent = options.action.text;
        actionButton.addEventListener('click', options.action.handler);
        notification.querySelector('.notification-content').appendChild(actionButton);
    }
    
    const container = document.querySelector('.notification-container');
    container.appendChild(notification);
    
    // Auto-remove
    if (!options.persistent) {
        setTimeout(() => {
            removeNotification(notification);
        }, duration);
    }
    
    // Manual close
    const closeButton = notification.querySelector('.notification-close');
    closeButton.addEventListener('click', () => {
        removeNotification(notification);
    });
    
    // Animate in
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
}

function removeNotification(notification) {
    notification.classList.add('hide');
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 300);
}

// Enhanced Search
function initializeEnhancedSearch() {
    // Add global search shortcut
    document.addEventListener('keydown', (e) => {
        if (e.ctrlKey && e.key === 'k') {
            e.preventDefault();
            showGlobalSearch();
        }
    });
}

function showGlobalSearch() {
    showNotification('Global search feature coming soon!', 'info');
}

// Enhanced Accessibility
function initializeEnhancedAccessibility() {
    // Add skip links
    addSkipLinks();
    
    // Add focus indicators
    addFocusIndicators();
    
    // Add keyboard navigation
    addKeyboardNavigation();
}

function addSkipLinks() {
    const skipLinks = document.createElement('div');
    skipLinks.className = 'skip-links';
    skipLinks.innerHTML = `
        <a href="#main-content">Skip to main content</a>
        <a href="#navigation">Skip to navigation</a>
    `;
    document.body.insertBefore(skipLinks, document.body.firstChild);
}

function addFocusIndicators() {
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Tab') {
            document.body.classList.add('keyboard-navigation');
        }
    });
    
    document.addEventListener('mousedown', () => {
        document.body.classList.remove('keyboard-navigation');
    });
}

function addKeyboardNavigation() {
    // Add arrow key navigation for tables
    document.addEventListener('keydown', (e) => {
        const table = document.querySelector('.data-table');
        if (!table) return;
        
        const tbody = table.querySelector('tbody');
        const rows = tbody.querySelectorAll('tr');
        const currentIndex = Array.from(rows).findIndex(row => row.classList.contains('keyboard-selected'));
        
        let newIndex = currentIndex;
        
        switch (e.key) {
            case 'ArrowUp':
                e.preventDefault();
                newIndex = Math.max(0, currentIndex - 1);
                break;
            case 'ArrowDown':
                e.preventDefault();
                newIndex = Math.min(rows.length - 1, currentIndex + 1);
                break;
            case 'Enter':
                if (currentIndex >= 0 && rows[currentIndex]) {
                    e.preventDefault();
                    rows[currentIndex].click();
                }
                break;
        }
        
        if (newIndex !== currentIndex && newIndex >= 0) {
            rows.forEach(row => row.classList.remove('keyboard-selected'));
            rows[newIndex].classList.add('keyboard-selected');
            rows[newIndex].scrollIntoView({ block: 'nearest' });
        }
    });
}

// Enhanced Tooltips
function initializeEnhancedTooltips() {
    const tooltipElements = document.querySelectorAll('[data-tooltip]');
    
    tooltipElements.forEach(element => {
        element.addEventListener('mouseenter', (e) => {
            showTooltip(element, e);
        });
        
        element.addEventListener('mouseleave', () => {
            hideTooltip();
        });
    });
}

function showTooltip(element, event) {
    hideTooltip(); // Remove existing tooltip
    
    const tooltip = document.createElement('div');
    tooltip.className = 'enhanced-tooltip';
    tooltip.textContent = element.getAttribute('data-tooltip');
    
    document.body.appendChild(tooltip);
    
    // Position tooltip
    const rect = element.getBoundingClientRect();
    const tooltipRect = tooltip.getBoundingClientRect();
    
    tooltip.style.left = rect.left + (rect.width / 2) - (tooltipRect.width / 2) + 'px';
    tooltip.style.top = rect.top - tooltipRect.height - 10 + 'px';
    
    // Add animation
    setTimeout(() => {
        tooltip.classList.add('show');
    }, 10);
}

function hideTooltip() {
    const tooltip = document.querySelector('.enhanced-tooltip');
    if (tooltip) {
        tooltip.remove();
    }
}

// Keyboard Shortcuts
function initializeKeyboardShortcuts() {
    const shortcuts = {
        'Ctrl+K': 'Global Search',
        'Ctrl+/': 'Show Help',
        'Escape': 'Close Modal',
        'Ctrl+S': 'Save Form',
        'Ctrl+Enter': 'Submit Form'
    };
    
    document.addEventListener('keydown', (e) => {
        const key = [];
        if (e.ctrlKey) key.push('Ctrl');
        if (e.shiftKey) key.push('Shift');
        if (e.altKey) key.push('Alt');
        key.push(e.key);
        
        const shortcut = key.join('+');
        
        if (shortcuts[shortcut]) {
            handleKeyboardShortcut(shortcut, shortcuts[shortcut]);
        }
    });
}

function handleKeyboardShortcut(shortcut, action) {
    switch (shortcut) {
        case 'Ctrl+S':
            e.preventDefault();
            const form = document.querySelector('form');
            if (form) {
                form.dispatchEvent(new Event('submit'));
            }
            break;
        case 'Ctrl+Enter':
            e.preventDefault();
            const submitButton = document.querySelector('button[type="submit"]');
            if (submitButton) {
                submitButton.click();
            }
            break;
        case 'Escape':
            const modal = document.querySelector('.modal.show');
            if (modal) {
                closeModal(modal);
            }
            break;
    }
}

// Back to Top Button
function createBackToTopButton() {
    const button = document.createElement('button');
    button.className = 'back-to-top';
    button.innerHTML = '↑';
    button.setAttribute('aria-label', 'Back to top');
    button.setAttribute('data-tooltip', 'Back to top');
    
    button.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
    
    document.body.appendChild(button);
    
    // Show/hide based on scroll
    window.addEventListener('scroll', () => {
        if (window.pageYOffset > 300) {
            button.classList.add('show');
        } else {
            button.classList.remove('show');
        }
    });
}

// Enhanced Animations
function initializeAnimations() {
    // Add intersection observer for scroll animations
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    }, {
        threshold: 0.1
    });
    
    document.querySelectorAll('.animate-on-scroll').forEach(el => {
        observer.observe(el);
    });
}

// Global Error Handling
function setupGlobalErrorHandling() {
    window.addEventListener('error', (e) => {
        console.error('Global error:', e.error);
        showNotification('An unexpected error occurred. Please try again.', 'error');
    });
    
    window.addEventListener('unhandledrejection', (e) => {
        console.error('Unhandled promise rejection:', e.reason);
        showNotification('An unexpected error occurred. Please try again.', 'error');
    });
}

// Enhanced Form Submission
function enhanceFormSubmission(form) {
    form.addEventListener('submit', (e) => {
        if (!validateFormEnhanced(form)) {
            e.preventDefault();
            showNotification('Please correct the errors in the form', 'error');
            return false;
        }
        
        showLoading('Submitting...');
        
        // Disable submit button
        const submitButton = form.querySelector('button[type="submit"]');
        if (submitButton) {
            submitButton.disabled = true;
            submitButton.innerHTML = '<span class="spinner"></span> Submitting...';
        }
    });
}

function validateFormEnhanced(form) {
    const inputs = form.querySelectorAll('input[required], textarea[required], select[required]');
    let isValid = true;
    
    inputs.forEach(input => {
        if (!validateFieldEnhanced(input)) {
            isValid = false;
        }
    });
    
    return isValid;
}

// Export enhanced functions for global use
window.EnhancedUI = {
    showLoading,
    hideLoading,
    showNotification,
    openModal,
    closeModal,
    enhanceForm,
    enhanceTable,
    applyTheme,
    exportTableToCSV
};
