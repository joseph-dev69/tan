<?php
/**
 * Approve/Reject user via AJAX
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/functions.php';

header('Content-Type: application/json');

try {
    require_role('admin');

    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
        exit;
    }

    $input = json_decode(file_get_contents('php://input'), true) ?: [];
    $user_id = (int)($input['user_id'] ?? 0);
    $csrf_token = $input['csrf_token'] ?? '';
    $action = $input['action'] ?? 'approve';
    $reason = trim((string)($input['reason'] ?? ''));

    if (!verify_csrf_token($csrf_token)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid CSRF token']);
        exit;
    }

    if ($user_id <= 0 || !in_array($action, ['approve', 'reject'], true)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid request parameters']);
        exit;
    }

    $user = get_single_result("SELECT user_id, status FROM users WHERE user_id = ?", [$user_id]);
    if (!$user) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'User not found']);
        exit;
    }

    if ($action === 'approve') {
        update_record('users', ['status' => 'approved', 'updated_at' => date(DATETIME_FORMAT)], ['user_id' => $user_id]);
        log_audit('USER_APPROVED', 'users', $user_id, ['status' => $user['status']], ['status' => 'approved']);
        echo json_encode(['success' => true, 'message' => 'User approved successfully']);
        exit;
    }

    update_record('users', ['status' => 'rejected', 'updated_at' => date(DATETIME_FORMAT)], ['user_id' => $user_id]);
    log_audit('USER_REJECTED', 'users', $user_id, ['status' => $user['status']], ['status' => 'rejected', 'reason' => $reason ?: 'No reason provided']);
    echo json_encode(['success' => true, 'message' => 'User declined successfully']);
} catch (Exception $e) {
    error_log('approve_user API error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error. Please try again.']);
}
