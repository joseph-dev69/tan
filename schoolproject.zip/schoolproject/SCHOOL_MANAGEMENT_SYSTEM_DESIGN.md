# School Management System Design Document

## 1. System Overview

The School Management System (SMS) is a comprehensive web-based platform designed to streamline and automate various administrative and academic processes within a college or school. It aims to provide a centralized system for managing student information, enrollment, grading, billing, and communication among different stakeholders including Admin, Students, Teachers, Dean/Program Heads, Records Office, Finance Office, and Cashiers. The system emphasizes role-based access control, security, scalability, and user-friendliness to enhance efficiency and transparency in school operations.

### Key Objectives
- Centralize student and academic data management
- Automate enrollment and registration processes
- Streamline grade encoding and academic record management
- Simplify billing and payment processing
- Provide real-time reporting and analytics
- Ensure data security and audit compliance
- Support multiple school years and semesters

### System Architecture
- **Frontend**: Responsive web application supporting desktop and mobile devices
- **Backend**: RESTful API with microservices architecture
- **Database**: Relational database with proper normalization
- **Authentication**: JWT-based authentication with role-based access control
- **File Storage**: Secure file management for documents and reports

## 2. Modules and Features

### A. User Management Module
- **User Registration**: Self-registration for all roles except Admin
- **Admin Approval Workflow**: Review and approve pending registrations
- **Role-Based Access Control**: Granular permissions per role
- **Profile Management**: Update personal information and credentials
- **Password Management**: Secure password reset and change functionality
- **Audit Logging**: Track all user activities and system changes

### B. Dashboard Module
- **Admin Dashboard**: System statistics, pending approvals, user management
- **Student Dashboard**: Enrollment status, subjects, grades, billing info
- **Teacher Dashboard**: Class schedules, student lists, grade encoding
- **Dean/Program Head Dashboard**: Course offerings, subject management, teacher assignments
- **Records Office Dashboard**: Academic records, transcript requests
- **Finance Office Dashboard**: Fee schedules, billing reports, financial summaries
- **Cashier Dashboard**: Payment processing, receipt generation, collection reports

### C. Academic Management Module
- **School Year/Semester Management**: Create and manage academic periods
- **Course Management**: Define academic programs and courses
- **Subject Management**: Create and maintain subject catalog
- **Curriculum Management**: Define course requirements and prerequisites
- **Class Scheduling**: Manage class schedules, rooms, and time slots
- **Teacher Assignment**: Assign teachers to specific subjects and classes

### D. Enrollment Module
- **Student E-Form**: Online enrollment application with validation
- **Enrollment Workflow**: Application → Review → Approval → Registration
- **Subject Selection**: View and select available subjects
- **Add/Drop Subjects**: Manage subject load within defined periods
- **Enrollment Reports**: Generate enrollment statistics and reports

### E. Grade Management Module
- **Grade Encoding**: Secure grade input by authorized teachers
- **Grade Calculation**: Automatic computation of final grades
- **Grade Inquiry**: Students can view their grades online
- **Grade Reports**: Generate grade sheets and transcripts
- **Grade Validation**: Ensure data integrity and validation rules

### F. Billing and Finance Module
- **Fee Structure Management**: Define tuition and miscellaneous fees
- **Student Billing**: Generate individual student accounts
- **Payment Processing**: Record and track student payments
- **Balance Management**: Monitor outstanding balances
- **Financial Reports**: Generate comprehensive financial reports

### G. Reporting Module
- **Academic Reports**: Transcripts, grade sheets, enrollment statistics
- **Financial Reports**: Collection reports, billing summaries
- **Administrative Reports**: User activity, system usage statistics
- **Custom Reports**: Flexible report generation with filters

## 3. Role-Permission Matrix

| Feature | Admin | Student | Teacher | Dean/Program Head | Records Office | Finance Office | Cashier |
|---------|-------|---------|---------|-------------------|----------------|----------------|---------|
| **User Management** |
| View Users | ✓ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ |
| Approve Registrations | ✓ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ |
| Edit User Profiles | ✓ | Self | Self | Self | Self | Self | Self |
| **Academic Management** |
| Manage School Years | ✓ | ✗ | ✗ | ✓ | ✗ | ✗ | ✗ |
| Manage Courses | ✓ | ✗ | View | ✓ | View | View | View |
| Manage Subjects | ✓ | ✗ | View | ✓ | View | View | View |
| Create Class Schedules | ✗ | ✗ | ✗ | ✓ | ✗ | ✗ | ✗ |
| Assign Teachers | ✗ | ✗ | ✗ | ✓ | ✗ | ✗ | ✗ |
| **Enrollment** |
| Apply for Enrollment | ✗ | ✓ | ✗ | ✗ | ✓ | ✗ | ✗ |
| Approve Enrollment | ✓ | ✗ | ✗ | ✓ | ✓ | ✗ | ✗ |
| Add/Drop Subjects | ✗ | ✓ | ✗ | ✗ | ✗ | ✗ | ✗ |
| View Enrollment | ✓ | Own | Own Classes | Department | All | All | All |
| **Grade Management** |
| Encode Grades | ✗ | ✗ | ✓ | ✗ | ✗ | ✗ | ✗ |
| View Grades | ✓ | Own | Own Classes | Department | All | All | All |
| Print Transcripts | ✓ | ✗ | ✗ | ✗ | ✓ | ✗ | ✗ |
| **Billing & Finance** |
| Manage Fee Structure | ✓ | ✗ | ✗ | ✗ | ✗ | ✓ | ✗ |
| Generate Billing | ✗ | ✗ | ✗ | ✗ | ✗ | ✓ | ✗ |
| Receive Payments | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✓ |
| View Financial Reports | ✓ | Own | ✗ | Department | All | All | All |
| **System Settings** |
| Configure System | ✓ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ |
| View Audit Logs | ✓ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ |

## 4. Use Cases

### 4.1 Admin Use Cases
- **UC-ADMIN-001**: User Registration Approval
  - Actor: Admin
  - Description: Review and approve/reject user registration requests
  - Preconditions: User has submitted registration form
  - Postconditions: User account is activated or rejected
  - Flow: View pending registrations → Review user details → Approve/Reject → Send notification

- **UC-ADMIN-002**: System Configuration
  - Actor: Admin
  - Description: Configure system settings and parameters
  - Preconditions: Admin is logged in
  - Postconditions: System settings are updated
  - Flow: Access settings → Modify parameters → Save changes → Log action

### 4.2 Student Use Cases
- **UC-STU-001**: Online Enrollment Application
  - Actor: Student
  - Description: Submit enrollment application through e-form
  - Preconditions: Student account is approved
  - Postconditions: Enrollment application is submitted for review
  - Flow: Fill e-form → Validate fields → Submit application → Receive confirmation

- **UC-STU-002**: Subject Selection
  - Actor: Student
  - Description: Add or drop subjects for current semester
  - Preconditions: Student is enrolled, enrollment period is open
  - Postconditions: Subject load is updated
  - Flow: View available subjects → Select subjects → Validate prerequisites → Confirm changes

### 4.3 Teacher Use Cases
- **UC-TEACH-001**: Grade Encoding
  - Actor: Teacher
  - Description: Encode grades for assigned subjects
  - Preconditions: Teacher is assigned to subject, grading period is open
  - Postconditions: Grades are recorded in system
  - Flow: Select class → View student list → Input grades → Validate → Save

### 4.4 Dean/Program Head Use Cases
- **UC-DEAN-001**: Course Offering Management
  - Actor: Dean/Program Head
  - Description: Create and manage course offerings for semester
  - Preconditions: Academic period is set up
  - Postconditions: Course offerings are defined
  - Flow: Select school year/semester → Define courses → Assign subjects → Schedule classes

### 4.5 Records Office Use Cases
- **UC-REC-001**: Transcript Generation
  - Actor: Records Office
  - Description: Generate and print student transcripts
  - Preconditions: Student has completed academic requirements
  - Postconditions: Transcript is generated and printed
  - Flow: Search student → Verify records → Generate transcript → Print document

### 4.6 Finance Office Use Cases
- **UC-FIN-001**: Student Billing
  - Actor: Finance Office
  - Description: Generate billing statements for students
  - Preconditions: Student is enrolled, fee structure is defined
  - Postconditions: Billing statement is created
  - Flow: Select student → Calculate fees → Apply discounts → Generate bill

### 4.7 Cashier Use Cases
- **UC-CASH-001**: Payment Processing
  - Actor: Cashier
  - Description: Receive and record student payments
  - Preconditions: Student has outstanding balance
  - Postconditions: Payment is recorded, receipt is generated
  - Flow: Search student → View balance → Receive payment → Record transaction → Print receipt

## 5. ERD and Database Schema

### Entity Relationship Diagram Overview

```
[USERS] --(1:M)--> [USER_ROLES]
[USERS] --(1:M)--> [STUDENTS]
[USERS] --(1:M)--> [TEACHERS]

[SCHOOL_YEARS] --(1:M)--> [SEMESTERS]
[SEMESTERS] --(1:M)--> [COURSE_OFFERINGS]
[COURSES] --(1:M)--> [COURSE_OFFERINGS]
[SUBJECTS] --(1:M)--> [SUBJECT_OFFERINGS]
[SEMESTERS] --(1:M)--> [SUBJECT_OFFERINGS]

[STUDENTS] --(1:M)--> [ENROLLMENTS]
[SEMESTERS] --(1:M)--> [ENROLLMENTS]
[COURSE_OFFERINGS] --(1:M)--> [ENROLLMENTS]

[ENROLLMENTS] --(1:M)--> [STUDENT_SUBJECTS]
[SUBJECT_OFFERINGS] --(1:M)--> [STUDENT_SUBJECTS]
[TEACHERS] --(1:M)--> [STUDENT_SUBJECTS]

[STUDENT_SUBJECTS] --(1:M)--> [GRADES]

[STUDENTS] --(1:M)--> [STUDENT_ACCOUNTS]
[SEMESTERS] --(1:M)--> [STUDENT_ACCOUNTS]

[STUDENT_ACCOUNTS] --(1:M)--> [PAYMENTS]
[STUDENT_ACCOUNTS] --(1:M)--> [FEES]

[COURSES] --(1:M)--> [CURRICULUM_SUBJECTS]
[SUBJECTS] --(1:M)--> [CURRICULUM_SUBJECTS]
```

### Key Relationships
- **Users**: Central entity with role-based extensions (Students, Teachers)
- **Academic Structure**: School Years → Semesters → Course/Subject Offerings
- **Enrollment Flow**: Students enroll in course offerings for specific semesters
- **Subject Loading**: Students take subjects from offerings, assigned to teachers
- **Grade Management**: Grades are linked to student-subject relationships
- **Financial**: Student accounts track fees and payments per semester

## 6. SQL Tables

### 6.1 User Management Tables

```sql
CREATE TABLE users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    middle_name VARCHAR(50),
    phone VARCHAR(20),
    address TEXT,
    status ENUM('pending', 'approved', 'rejected', 'inactive') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT,
    INDEX idx_username (username),
    INDEX idx_email (email),
    INDEX idx_status (status)
);

CREATE TABLE user_roles (
    role_id INT PRIMARY KEY AUTO_INCREMENT,
    role_name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE user_role_assignments (
    assignment_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    role_id INT NOT NULL,
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    assigned_by INT,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (role_id) REFERENCES user_roles(role_id),
    UNIQUE KEY unique_user_role (user_id, role_id)
);
```

### 6.2 Academic Management Tables

```sql
CREATE TABLE school_years (
    school_year_id INT PRIMARY KEY AUTO_INCREMENT,
    year_start INT NOT NULL,
    year_end INT NOT NULL,
    status ENUM('upcoming', 'current', 'completed') DEFAULT 'upcoming',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_year (year_start, year_end)
);

CREATE TABLE semesters (
    semester_id INT PRIMARY KEY AUTO_INCREMENT,
    school_year_id INT NOT NULL,
    semester_name ENUM('First', 'Second', 'Summer') NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    status ENUM('upcoming', 'current', 'completed') DEFAULT 'upcoming',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (school_year_id) REFERENCES school_years(school_year_id),
    UNIQUE KEY unique_semester (school_year_id, semester_name)
);

CREATE TABLE courses (
    course_id INT PRIMARY KEY AUTO_INCREMENT,
    course_code VARCHAR(20) UNIQUE NOT NULL,
    course_name VARCHAR(100) NOT NULL,
    description TEXT,
    department VARCHAR(50),
    total_units INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE subjects (
    subject_id INT PRIMARY KEY AUTO_INCREMENT,
    subject_code VARCHAR(20) UNIQUE NOT NULL,
    subject_name VARCHAR(100) NOT NULL,
    description TEXT,
    units INT NOT NULL DEFAULT 3,
    lecture_hours INT DEFAULT 0,
    lab_hours INT DEFAULT 0,
    prerequisite_subject_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (prerequisite_subject_id) REFERENCES subjects(subject_id)
);

CREATE TABLE course_offerings (
    offering_id INT PRIMARY KEY AUTO_INCREMENT,
    course_id INT NOT NULL,
    semester_id INT NOT NULL,
    max_students INT DEFAULT 50,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(course_id),
    FOREIGN KEY (semester_id) REFERENCES semesters(semester_id),
    UNIQUE KEY unique_offering (course_id, semester_id)
);

CREATE TABLE subject_offerings (
    subject_offering_id INT PRIMARY KEY AUTO_INCREMENT,
    subject_id INT NOT NULL,
    semester_id INT NOT NULL,
    teacher_id INT,
    schedule VARCHAR(100),
    room VARCHAR(50),
    max_students INT DEFAULT 50,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id),
    FOREIGN KEY (semester_id) REFERENCES semesters(semester_id),
    FOREIGN KEY (teacher_id) REFERENCES users(user_id)
);
```

### 6.3 Student and Enrollment Tables

```sql
CREATE TABLE students (
    student_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT UNIQUE NOT NULL,
    student_number VARCHAR(20) UNIQUE NOT NULL,
    birth_date DATE,
    gender ENUM('Male', 'Female', 'Other'),
    civil_status VARCHAR(20),
    guardian_name VARCHAR(100),
    guardian_contact VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE teachers (
    teacher_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT UNIQUE NOT NULL,
    employee_number VARCHAR(20) UNIQUE NOT NULL,
    department VARCHAR(50),
    position VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE enrollments (
    enrollment_id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    course_offering_id INT NOT NULL,
    semester_id INT NOT NULL,
    year_level INT NOT NULL,
    status ENUM('pending', 'approved', 'rejected', 'enrolled') DEFAULT 'pending',
    enrollment_date DATE,
    approved_by INT,
    approved_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (course_offering_id) REFERENCES course_offerings(offering_id),
    FOREIGN KEY (semester_id) REFERENCES semesters(semester_id),
    FOREIGN KEY (approved_by) REFERENCES users(user_id),
    UNIQUE KEY unique_enrollment (student_id, semester_id)
);

CREATE TABLE student_subjects (
    student_subject_id INT PRIMARY KEY AUTO_INCREMENT,
    enrollment_id INT NOT NULL,
    subject_offering_id INT NOT NULL,
    status ENUM('enrolled', 'dropped', 'completed') DEFAULT 'enrolled',
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    dropped_at TIMESTAMP NULL,
    FOREIGN KEY (enrollment_id) REFERENCES enrollments(enrollment_id),
    FOREIGN KEY (subject_offering_id) REFERENCES subject_offerings(subject_offering_id),
    UNIQUE KEY unique_student_subject (enrollment_id, subject_offering_id)
);
```

### 6.4 Grade Management Tables

```sql
CREATE TABLE grades (
    grade_id INT PRIMARY KEY AUTO_INCREMENT,
    student_subject_id INT NOT NULL,
    grading_period ENUM('Prelim', 'Midterm', 'Final') NOT NULL,
    grade DECIMAL(5,2),
    remarks VARCHAR(50),
    encoded_by INT NOT NULL,
    encoded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_subject_id) REFERENCES student_subjects(student_subject_id),
    FOREIGN KEY (encoded_by) REFERENCES users(user_id),
    FOREIGN KEY (updated_by) REFERENCES users(user_id),
    UNIQUE KEY unique_grade (student_subject_id, grading_period)
);
```

### 6.5 Financial Management Tables

```sql
CREATE TABLE fee_structures (
    fee_id INT PRIMARY KEY AUTO_INCREMENT,
    fee_name VARCHAR(100) NOT NULL,
    fee_type ENUM('tuition', 'miscellaneous', 'other') NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    per_unit BOOLEAN DEFAULT FALSE,
    course_id INT,
    semester_id INT,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(course_id),
    FOREIGN KEY (semester_id) REFERENCES semesters(semester_id)
);

CREATE TABLE student_accounts (
    account_id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    semester_id INT NOT NULL,
    total_units INT DEFAULT 0,
    tuition_fee DECIMAL(10,2) DEFAULT 0,
    miscellaneous_fee DECIMAL(10,2) DEFAULT 0,
    other_fees DECIMAL(10,2) DEFAULT 0,
    total_amount DECIMAL(10,2) DEFAULT 0,
    total_paid DECIMAL(10,2) DEFAULT 0,
    balance DECIMAL(10,2) DEFAULT 0,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (semester_id) REFERENCES semesters(semester_id),
    UNIQUE KEY unique_account (student_id, semester_id)
);

CREATE TABLE payments (
    payment_id INT PRIMARY KEY AUTO_INCREMENT,
    account_id INT NOT NULL,
    payment_date DATE NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_method ENUM('cash', 'check', 'bank_transfer', 'online') NOT NULL,
    reference_number VARCHAR(50),
    received_by INT NOT NULL,
    or_number VARCHAR(50) UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (account_id) REFERENCES student_accounts(account_id),
    FOREIGN KEY (received_by) REFERENCES users(user_id)
);
```

### 6.6 System Tables

```sql
CREATE TABLE audit_logs (
    log_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    action VARCHAR(100) NOT NULL,
    table_name VARCHAR(50),
    record_id INT,
    old_values JSON,
    new_values JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    INDEX idx_user_action (user_id, action),
    INDEX idx_table_record (table_name, record_id),
    INDEX idx_created_at (created_at)
);

CREATE TABLE system_settings (
    setting_id INT PRIMARY KEY AUTO_INCREMENT,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    description TEXT,
    updated_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (updated_by) REFERENCES users(user_id)
);
```

## 7. API Endpoints

### 7.1 Authentication Endpoints
```
POST /api/auth/login
POST /api/auth/logout
POST /api/auth/register
POST /api/auth/forgot-password
POST /api/auth/reset-password
GET  /api/auth/profile
PUT  /api/auth/profile
```

### 7.2 User Management Endpoints
```
GET    /api/users
GET    /api/users/{id}
POST   /api/users
PUT    /api/users/{id}
DELETE /api/users/{id}
GET    /api/users/pending
PUT    /api/users/{id}/approve
PUT    /api/users/{id}/reject
GET    /api/users/roles
POST   /api/users/roles
```

### 7.3 Academic Management Endpoints
```
GET    /api/school-years
POST   /api/school-years
PUT    /api/school-years/{id}
GET    /api/semesters
POST   /api/semesters
PUT    /api/semesters/{id}
GET    /api/courses
POST   /api/courses
PUT    /api/courses/{id}
GET    /api/subjects
POST   /api/subjects
PUT    /api/subjects/{id}
```

### 7.4 Enrollment Endpoints
```
GET    /api/enrollments
POST   /api/enrollments
PUT    /api/enrollments/{id}
GET    /api/enrollments/student/{studentId}
POST   /api/enrollments/apply
PUT    /api/enrollments/{id}/approve
GET    /api/subject-offerings
POST   /api/subject-offerings
GET    /api/student-subjects
POST   /api/student-subjects
DELETE /api/student-subjects/{id}
```

### 7.5 Grade Management Endpoints
```
GET    /api/grades
POST   /api/grades
PUT    /api/grades/{id}
GET    /api/grades/student/{studentId}
GET    /api/grades/teacher/{teacherId}
GET    /api/transcripts/{studentId}
```

### 7.6 Financial Endpoints
```
GET    /api/student-accounts
POST   /api/student-accounts
GET    /api/student-accounts/student/{studentId}
POST   /api/payments
GET    /api/payments
GET    /api/fee-structures
POST   /api/fee-structures
PUT    /api/fee-structures/{id}
```

### 7.7 Reports Endpoints
```
GET    /api/reports/enrollment
GET    /api/reports/grades
GET    /api/reports/financial
GET    /api/reports/collections
POST   /api/reports/generate
```

## 8. UI Page List

### 8.1 Authentication Pages
- Login Page (`/login`)
- Registration Page (`/register`)
- Forgot Password (`/forgot-password`)
- Reset Password (`/reset-password`)

### 8.2 Dashboard Pages
- Admin Dashboard (`/admin/dashboard`)
- Student Dashboard (`/student/dashboard`)
- Teacher Dashboard (`/teacher/dashboard`)
- Dean Dashboard (`/dean/dashboard`)
- Records Dashboard (`/records/dashboard`)
- Finance Dashboard (`/finance/dashboard`)
- Cashier Dashboard (`/cashier/dashboard`)

### 8.3 User Management Pages
- User List (`/admin/users`)
- User Details (`/admin/users/{id}`)
- Pending Approvals (`/admin/users/pending`)
- Profile Settings (`/profile`)

### 8.4 Academic Management Pages
- School Years (`/admin/academic/school-years`)
- Semesters (`/admin/academic/semesters`)
- Courses (`/admin/academic/courses`)
- Subjects (`/admin/academic/subjects`)
- Course Offerings (`/dean/course-offerings`)
- Subject Offerings (`/dean/subject-offerings`)
- Class Schedules (`/dean/schedules`)

### 8.5 Enrollment Pages
- Enrollment Application (`/student/enrollment/apply`)
- Subject Selection (`/student/enrollment/subjects`)
- My Subjects (`/student/subjects`)
- Enrollment Status (`/student/enrollment/status`)
- Enrollment Management (`/admin/enrollments`)

### 8.6 Grade Management Pages
- Grade Encoding (`/teacher/grades`)
- My Grades (`/student/grades`)
- Grade Inquiry (`/student/grades/inquiry`)
- Transcript Request (`/student/transcripts`)
- Grade Reports (`/records/grades`)

### 8.7 Financial Pages
- Student Account (`/student/account`)
- Billing Statements (`/finance/billing`)
- Fee Management (`/finance/fees`)
- Payment Processing (`/cashier/payments`)
- Payment History (`/student/payments`)
- Financial Reports (`/finance/reports`)

### 8.8 Reports Pages
- Enrollment Reports (`/reports/enrollment`)
- Academic Reports (`/reports/academic`)
- Financial Reports (`/reports/financial`)
- Collection Reports (`/reports/collections`)

## 9. Workflow Processes

### 9.1 Enrollment Workflow

```
1. Student Registration
   └── User registers online → Admin approval → Account activation

2. Enrollment Application
   └── Student logs in → Fills e-form → Submits application

3. Application Review
   └── Records/Dean reviews → Validates requirements → Approves/Rejects

4. Subject Selection
   └── Student views available subjects → Selects subjects → Confirms load

5. Enrollment Confirmation
   └── System generates assessment → Student confirms enrollment

6. Payment Processing
   └── Student pays fees → Cashier records payment → Enrollment finalized
```

### 9.2 Grade Encoding Workflow

```
1. Grade Period Setup
   └── Admin configures grading periods → Sets deadlines

2. Teacher Grade Encoding
   └── Teacher accesses class → Inputs grades → Validates entries

3. Grade Review
   └── Department head reviews → Approves/Requests changes

4. Grade Posting
   └── System posts grades → Students can view online

5. Grade Calculations
   └── System computes final grades → Generates remarks
```

### 9.3 Billing and Payment Workflow

```
1. Fee Structure Setup
   └── Finance defines fees → Sets rates per course/subject

2. Student Assessment
   └── System calculates fees → Generates assessment → Sends notification

3. Billing Generation
   └── Finance creates billing statements → Distributes to students

4. Payment Collection
   └── Student pays → Cashier records → Issues receipt

5. Account Update
   └── System updates balance → Sends payment confirmation
```

### 9.4 Transcript Processing Workflow

```
1. Transcript Request
   └── Student submits request → Pays processing fee

2. Record Verification
   └── Records office verifies completion → Checks grades

3. Document Generation
   └── System generates transcript → Applies digital signature

4. Release Process
   └── Records prints document → Student receives copy
```

## 10. Recommended Tech Stack

### 10.1 Frontend Technology Stack
- **Framework**: React.js 18+ with TypeScript
  - Component-based architecture for maintainability
  - Strong typing for better code quality
  - Large ecosystem and community support
- **UI Library**: Material-UI (MUI) or Ant Design
  - Professional design system
  - Responsive components
  - Accessibility features
- **State Management**: Redux Toolkit with RTK Query
  - Centralized state management
  - Built-in data fetching and caching
  - DevTools support
- **Routing**: React Router v6
  - Declarative routing
  - Route-based code splitting
- **Form Handling**: React Hook Form with Yup validation
  - Performance optimized
  - Easy validation schema
- **Charts**: Chart.js or Recharts
  - Interactive data visualization
  - Customizable components

### 10.2 Backend Technology Stack
- **Runtime**: Node.js 18+ with TypeScript
  - JavaScript ecosystem consistency
  - Strong typing support
  - Large package ecosystem
- **Framework**: Express.js with middleware
  - Lightweight and flexible
  - Extensive middleware support
  - Proven scalability
- **Database**: MySQL 8.0+ with Prisma ORM
  - Relational data integrity
  - ACID compliance
  - Strong performance
  - Prisma for type-safe database access
- **Authentication**: JWT with refresh tokens
  - Stateless authentication
  - Secure token management
  - Role-based access control
- **File Storage**: AWS S3 or local file system
  - Scalable file storage
  - CDN integration
  - Backup capabilities

### 10.3 DevOps and Infrastructure
- **Containerization**: Docker with Docker Compose
  - Environment consistency
  - Easy deployment
  - Service isolation
- **Web Server**: Nginx as reverse proxy
  - Load balancing
  - SSL termination
  - Static file serving
- **Process Manager**: PM2
  - Process monitoring
  - Automatic restarts
  - Cluster mode support
- **CI/CD**: GitHub Actions or GitLab CI
  - Automated testing
  - Deployment pipelines
  - Code quality checks

### 10.4 Additional Technologies
- **Email Service**: Nodemailer with SMTP or SendGrid
  - Transactional emails
  - Template support
  - Delivery tracking
- **PDF Generation**: Puppeteer or PDFKit
  - Report generation
  - Transcript printing
  - Certificate creation
- **Logging**: Winston with ELK stack
  - Structured logging
  - Log aggregation
  - Monitoring capabilities
- **Testing**: Jest + Supertest + React Testing Library
  - Unit testing
  - Integration testing
  - E2E testing capabilities

### 10.5 Security Considerations
- **Input Validation**: Comprehensive validation on all inputs
- **SQL Injection Prevention**: Parameterized queries via ORM
- **XSS Protection**: Content Security Policy and input sanitization
- **CSRF Protection**: CSRF tokens for state-changing operations
- **Rate Limiting**: API rate limiting to prevent abuse
- **Data Encryption**: Sensitive data encryption at rest and in transit
- **Audit Logging**: Comprehensive audit trail for all operations

### 10.6 Scalability and Performance
- **Database Optimization**: Proper indexing and query optimization
- **Caching Strategy**: Redis for session and data caching
- **CDN Integration**: Content delivery for static assets
- **Load Balancing**: Horizontal scaling support
- **Monitoring**: Application performance monitoring
- **Backup Strategy**: Regular database and file backups

This tech stack provides a robust, scalable, and maintainable foundation for the school management system while ensuring security, performance, and user experience.
