<?php
/**
 * Main Entry Point
 * School Information System
 */

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/functions.php';

// Check if user is logged in
if (is_logged_in()) {
    $user_role = get_user_role();
    
    // Redirect to appropriate dashboard
    switch ($user_role) {
        case 'admin':
            redirect('modules/admin/dashboard.php');
        case 'student':
            redirect('modules/student/dashboard.php');
        case 'teacher':
            redirect('modules/teacher/dashboard.php');
        case 'dean':
            redirect('modules/dean/dashboard.php');
        case 'records_officer':
            redirect('modules/records/dashboard.php');
        case 'finance_officer':
            redirect('modules/finance/dashboard.php');
        case 'cashier':
            redirect('modules/cashier/dashboard.php');
        default:
            redirect('modules/auth/login.php');
    }
} else {
    // Redirect to login page
    redirect('modules/auth/login.php');
}
?>
