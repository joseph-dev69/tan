<?php
/**
 * Common Functions
 * School Information System
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';

// Validation Functions
function validate_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function validate_password($password) {
    // Relaxed rule: minimum 4 characters.
    return strlen($password) >= 4;
}

function validate_phone($phone) {
    // Philippine phone number format (accepts spaces/dashes from user input)
    $normalized = preg_replace('/[\s\-()]/', '', $phone);
    return preg_match('/^(09|\+639)\d{9}$/', $normalized);
}

function validate_student_number($student_number) {
    // Format: YYYY-XXXXX (Year + 5-digit number)
    return preg_match('/^\d{4}-\d{5}$/', $student_number);
}

function validate_date($date, $format = DATE_FORMAT) {
    $d = DateTime::createFromFormat($format, $date);
    return $d && $d->format($format) === $date;
}

function validate_required($data, $required_fields) {
    $errors = [];
    foreach ($required_fields as $field) {
        if (empty($data[$field])) {
            $errors[$field] = "Field is required";
        }
    }
    return $errors;
}

// Database Helper Functions
function get_db_connection() {
    try {
        $db = new Database();
        return $db->getConnection();
    } catch (Exception $e) {
        error_log("Database connection helper error: " . $e->getMessage());
        throw new Exception("Database connection failed");
    }
}

function execute_query($sql, $params = []) {
    try {
        $conn = get_db_connection();
        
        $stmt = $conn->prepare($sql);
        $stmt->execute($params);
        
        return $stmt;
    } catch (Exception $e) {
        error_log("Query execution error: " . $e->getMessage());
        throw new Exception("Database operation failed");
    }
}

function get_single_result($sql, $params = []) {
    $stmt = execute_query($sql, $params);
    return $stmt->fetch();
}

function get_multiple_results($sql, $params = []) {
    $stmt = execute_query($sql, $params);
    return $stmt->fetchAll();
}

function get_fixed_semester_names() {
    return ['First Semester', 'Second Semester', 'Summer'];
}

function get_semester_name_by_id($semester_id) {
    $semester_id = (int)$semester_id;
    if ($semester_id <= 0) {
        return '';
    }

    $semester = get_single_result(
        "SELECT semester_name FROM semesters WHERE semester_id = ? LIMIT 1",
        [$semester_id]
    );

    return trim((string)($semester['semester_name'] ?? ''));
}

function get_fixed_semester_options($school_year_id = 0) {
    $school_year_id = (int)$school_year_id;
    $options = [];

    foreach (get_fixed_semester_names() as $semester_name) {
        $params = [$semester_name];
        $sql = "
            SELECT semester_id, semester_name
            FROM semesters
            WHERE semester_name = ?
        ";

        if ($school_year_id > 0) {
            $sql .= " AND school_year_id = ?";
            $params[] = $school_year_id;
        }

        $sql .= " ORDER BY is_current DESC, school_year_id DESC, semester_id DESC LIMIT 1";

        $semester = get_single_result($sql, $params);
        if ($semester) {
            $options[] = [
                'semester_id' => (int)$semester['semester_id'],
                'semester_name' => $semester_name
            ];
        }
    }

    return $options;
}

function resolve_fixed_semester_selection($school_year_id, $selected_semester_id = 0, $fallback_semester_name = '') {
    $options = get_fixed_semester_options($school_year_id);
    $selected_semester_id = (int)$selected_semester_id;
    $selected_semester_name = get_semester_name_by_id($selected_semester_id);

    if ($selected_semester_name === '' && $fallback_semester_name !== '') {
        $selected_semester_name = trim((string)$fallback_semester_name);
    }

    if ($selected_semester_name !== '') {
        foreach ($options as $option) {
            if ($option['semester_name'] === $selected_semester_name) {
                return [
                    'options' => $options,
                    'semester_id' => (int)$option['semester_id'],
                    'semester_name' => $option['semester_name']
                ];
            }
        }
    }

    if (!empty($options)) {
        return [
            'options' => $options,
            'semester_id' => (int)$options[0]['semester_id'],
            'semester_name' => $options[0]['semester_name']
        ];
    }

    return [
        'options' => [],
        'semester_id' => 0,
        'semester_name' => ''
    ];
}

function insert_record($table, $data) {
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        $columns = implode(', ', array_keys($data));
        $placeholders = implode(', ', array_fill(0, count($data), '?'));
        
        $sql = "INSERT INTO $table ($columns) VALUES ($placeholders)";
        $stmt = $conn->prepare($sql);
        $stmt->execute(array_values($data));
        
        return $conn->lastInsertId();
    } catch (Exception $e) {
        error_log("Insert error: " . $e->getMessage());
        throw new Exception("Failed to insert record");
    }
}

function update_record($table, $data, $where, $where_params = null) {
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        $set_clause = [];
        foreach (array_keys($data) as $column) {
            $set_clause[] = "$column = ?";
        }
        $set_clause = implode(', ', $set_clause);
        
        $where_clause = [];
        foreach (array_keys($where) as $column) {
            $where_clause[] = "$column = ?";
        }
        $where_clause = implode(' AND ', $where_clause);
        
        $sql = "UPDATE $table SET $set_clause WHERE $where_clause";
        // Backward-compatible support: when where_params is omitted,
        // use values from the where array.
        if ($where_params === null) {
            $where_values = array_values($where);
        } elseif (is_array($where_params)) {
            $where_values = array_values($where_params);
        } else {
            $where_values = [$where_params];
        }
        $params = array_merge(array_values($data), $where_values);
        
        $stmt = $conn->prepare($sql);
        return $stmt->execute($params);
    } catch (Exception $e) {
        error_log("Update error: " . $e->getMessage());
        throw new Exception("Failed to update record");
    }
}

function delete_record($table, $where, $where_params = null) {
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        $where_clause = [];
        foreach (array_keys($where) as $column) {
            $where_clause[] = "$column = ?";
        }
        $where_clause = implode(' AND ', $where_clause);
        
        $sql = "DELETE FROM $table WHERE $where_clause";
        $stmt = $conn->prepare($sql);
        
        if ($where_params === null) {
            $where_values = array_values($where);
        } elseif (is_array($where_params)) {
            $where_values = array_values($where_params);
        } else {
            $where_values = [$where_params];
        }
        
        return $stmt->execute($where_values);
    } catch (Exception $e) {
        error_log("Delete error: " . $e->getMessage());
        throw new Exception("Failed to delete record");
    }
}

// User Authentication Functions
function hash_password($password) {
    return password_hash($password, HASH_ALGO, ['cost' => HASH_COST]);
}

function verify_password($password, $hash) {
    return password_verify($password, $hash);
}

function login_user($username, $password) {
    $sql = "SELECT u.*, r.role_name FROM users u 
            JOIN roles r ON u.role_id = r.role_id 
            WHERE u.username = ?";
    
    $user = get_single_result($sql, [$username]);
    
    if ($user && $user['status'] === 'approved' && verify_password($password, $user['password_hash'])) {
        // Update last login
        update_record('users', ['last_login' => date(DATETIME_FORMAT)], ['user_id' => $user['user_id']]);
        
        // Set session
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['user'] = [
            'user_id' => $user['user_id'],
            'username' => $user['username'],
            'email' => $user['email'],
            'first_name' => $user['first_name'],
            'last_name' => $user['last_name'],
            'role' => $user['role_name'],
            'role_id' => $user['role_id']
        ];
        
        // Log login
        log_audit('USER_LOGIN', 'users', $user['user_id']);
        
        return true;
    }
    
    return false;
}

function logout_user() {
    if (is_logged_in()) {
        log_audit('USER_LOGOUT', 'users', $_SESSION['user_id']);
    }
    
    session_destroy();
    redirect('index.php');
}

function check_login_attempts($username) {
    $cache_key = "login_attempts_$username";
    $attempts = $_SESSION[$cache_key] ?? ['count' => 0, 'last_attempt' => 0];
    
    // Reset if timeout has passed
    if (time() - $attempts['last_attempt'] > LOGIN_ATTEMPT_TIMEOUT) {
        $attempts = ['count' => 0, 'last_attempt' => 0];
    }
    
    return $attempts;
}

function increment_login_attempts($username) {
    $cache_key = "login_attempts_$username";
    $attempts = check_login_attempts($username);
    
    $attempts['count']++;
    $attempts['last_attempt'] = time();
    
    $_SESSION[$cache_key] = $attempts;
    
    return $attempts['count'];
}

function reset_login_attempts($username) {
    $cache_key = "login_attempts_$username";
    unset($_SESSION[$cache_key]);
}

// Permission Functions
function has_permission($role, $permission) {
    $permissions = [
        'admin' => ['all'],
        'student' => ['view_own_grades', 'view_own_schedule', 'enroll_subjects', 'view_own_billing'],
        'teacher' => ['view_own_schedule', 'grade_students', 'view_class_list'],
        'dean' => ['approve_curriculum', 'view_reports', 'manage_departments'],
        'records_officer' => ['manage_student_records', 'print_transcripts', 'view_all_grades'],
        'finance_officer' => ['manage_billing', 'view_payment_reports', 'manage_fee_schedules'],
        'cashier' => ['process_payments', 'print_receipts', 'view_billing']
    ];
    
    return in_array('all', $permissions[$role] ?? []) || in_array($permission, $permissions[$role] ?? []);
}

function require_role($required_role) {
    if (!is_logged_in()) {
        flash_message('error', 'Please login to continue');
        redirect('modules/auth/login.php');
    }
    
    $current_role = get_user_role();
    
    if ($current_role !== $required_role && !has_permission($current_role, 'all')) {
        flash_message('error', 'Access denied');
        redirect('index.php');
    }
}

function require_permission($permission) {
    if (!is_logged_in()) {
        flash_message('error', 'Please login to continue');
        redirect('modules/auth/login.php');
    }
    
    $current_role = get_user_role();
    
    if (!has_permission($current_role, $permission)) {
        flash_message('error', 'Access denied');
        redirect('index.php');
    }
}

// File Upload Functions
function upload_file($file, $destination_folder = UPLOAD_PATH, $allowed_types = UPLOAD_ALLOWED_TYPES, $max_size = UPLOAD_MAX_SIZE) {
    if (!isset($file['error']) || is_array($file['error'])) {
        throw new Exception('Invalid file upload');
    }
    
    switch ($file['error']) {
        case UPLOAD_ERR_OK:
            break;
        case UPLOAD_ERR_INI_SIZE:
        case UPLOAD_ERR_FORM_SIZE:
            throw new Exception('File size exceeds limit');
        case UPLOAD_ERR_NO_FILE:
            throw new Exception('No file uploaded');
        default:
            throw new Exception('Unknown upload error');
    }
    
    if ($file['size'] > $max_size) {
        throw new Exception('File size exceeds limit');
    }
    
    $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (!in_array($file_extension, $allowed_types)) {
        throw new Exception('File type not allowed');
    }
    
    // Generate unique filename
    $filename = uniqid() . '.' . $file_extension;
    $destination = $destination_folder . $filename;
    
    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        throw new Exception('Failed to move uploaded file');
    }
    
    return $filename;
}

// Pagination Functions
function paginate($query, $page = 1, $per_page = DEFAULT_PAGE_SIZE, $params = []) {
    $offset = ($page - 1) * $per_page;
    
    // Get total count
    $count_query = "SELECT COUNT(*) as total FROM ($query) as subquery";
    $total_result = get_single_result($count_query, $params);
    $total = $total_result['total'];
    
    // Get paginated results
    $paginated_query = $query . " LIMIT $per_page OFFSET $offset";
    $results = get_multiple_results($paginated_query, $params);
    
    return [
        'data' => $results,
        'total' => $total,
        'page' => $page,
        'per_page' => $per_page,
        'total_pages' => ceil($total / $per_page),
        'has_next' => $page < ceil($total / $per_page),
        'has_prev' => $page > 1
    ];
}

// Export Functions
function export_to_csv($data, $filename, $headers = []) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: no-cache, no-store, must-revalidate');
    header('Pragma: no-cache');
    header('Expires: 0');
    
    $output = fopen('php://output', 'w');
    
    // Add BOM for UTF-8
    fwrite($output, "\xEF\xBB\xBF");
    
    // Write headers
    if (!empty($headers)) {
        fputcsv($output, $headers);
    }
    
    // Write data
    foreach ($data as $row) {
        fputcsv($output, $row);
    }
    
    fclose($output);
    exit();
}

// Notification Functions
function send_email($to, $subject, $message, $attachments = []) {
    // This is a placeholder for email functionality
    // In a real implementation, you would use PHPMailer or similar library
    
    error_log("Email sent to: $to, Subject: $subject");
    return true;
}

function send_notification($user_id, $type, $message, $data = []) {
    // This is a placeholder for notification system
    // In a real implementation, you would store notifications in database
    
    error_log("Notification sent to user $user_id: $message");
    return true;
}

// Academic Functions
function calculate_gpa($grades) {
    if (empty($grades)) {
        return 0.00;
    }
    
    $total_quality_points = 0;
    $total_units = 0;
    
    foreach ($grades as $grade) {
        $quality_points = get_quality_points($grade['grade']);
        $total_quality_points += $quality_points * $grade['units'];
        $total_units += $grade['units'];
    }
    
    return $total_units > 0 ? round($total_quality_points / $total_units, 2) : 0.00;
}

function get_quality_points($grade) {
    if ($grade >= 97) return 4.00;
    if ($grade >= 94) return 3.75;
    if ($grade >= 91) return 3.50;
    if ($grade >= 88) return 3.25;
    if ($grade >= 85) return 3.00;
    if ($grade >= 82) return 2.75;
    if ($grade >= 79) return 2.50;
    if ($grade >= 76) return 2.25;
    if ($grade >= 75) return 2.00;
    return 0.00;
}

function get_academic_standing($gpa) {
    if ($gpa >= 3.00) return 'good';
    if ($gpa >= 2.00) return 'warning';
    if ($gpa >= 1.00) return 'probation';
    return 'dismissal';
}

// Utility Functions
function generate_student_number($year = null) {
    $year = $year ?? date('Y');
    $sequence = str_pad(mt_rand(1, 99999), 5, '0', STR_PAD_LEFT);
    return "$year-$sequence";
}

function generate_receipt_number() {
    return 'RCP-' . date('Ymd') . '-' . str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
}

function generate_payment_reference_number() {
    return 'PAY-' . date('Ymd-His') . '-' . str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
}

function format_full_name($first_name, $last_name, $middle_name = '') {
    $name = trim("$first_name $middle_name $last_name");
    return ucwords(strtolower($name));
}

function get_age($birthdate) {
    $today = new DateTime();
    $birth = new DateTime($birthdate);
    return $today->diff($birth)->y;
}

function is_weekend($date) {
    return in_array(date('w', strtotime($date)), [0, 6]); // Sunday or Saturday
}

function add_business_days($date, $days) {
    $date = new DateTime($date);
    
    while ($days > 0) {
        $date->add(new DateInterval('P1D'));
        
        if (!is_weekend($date->format('Y-m-d'))) {
            $days--;
        }
    }
    
    return $date->format('Y-m-d');
}

function normalize_program_text($value) {
    $value = strtoupper((string)$value);
    $value = preg_replace('/[^A-Z0-9\s]/', ' ', $value);
    $value = preg_replace('/\s+/', ' ', $value);
    return trim($value);
}

function get_course_subject_blueprint($course_code, $course_name) {
    $program_text = normalize_program_text($course_code . ' ' . $course_name);

    $blueprints = [
        [
            'keywords' => ['COMPUTER SCIENCE', 'CS', 'BSCS'],
            'subjects' => [
                ['code' => 'PROG1', 'name' => 'Programming Fundamentals', 'units' => 4.0, 'lec' => 2.0, 'lab' => 3.0, 'year' => 1, 'sem' => 'first'],
                ['code' => 'DSA1', 'name' => 'Data Structures', 'units' => 4.0, 'lec' => 2.0, 'lab' => 3.0, 'year' => 1, 'sem' => 'second'],
                ['code' => 'ALGO1', 'name' => 'Algorithms', 'units' => 3.0, 'lec' => 3.0, 'lab' => 0.0, 'year' => 2, 'sem' => 'first'],
                ['code' => 'DBMS1', 'name' => 'Database Systems', 'units' => 3.0, 'lec' => 2.0, 'lab' => 2.0, 'year' => 2, 'sem' => 'second'],
                ['code' => 'OS1', 'name' => 'Operating Systems', 'units' => 3.0, 'lec' => 2.0, 'lab' => 2.0, 'year' => 2, 'sem' => 'second'],
                ['code' => 'SE1', 'name' => 'Software Engineering', 'units' => 3.0, 'lec' => 3.0, 'lab' => 0.0, 'year' => 3, 'sem' => 'first']
            ]
        ],
        [
            'keywords' => ['INFORMATION TECHNOLOGY', 'IT', 'BSIT'],
            'subjects' => [
                ['code' => 'PROG1', 'name' => 'Programming Fundamentals', 'units' => 4.0, 'lec' => 2.0, 'lab' => 3.0, 'year' => 1, 'sem' => 'first'],
                ['code' => 'WEB1', 'name' => 'Web Development', 'units' => 3.0, 'lec' => 2.0, 'lab' => 2.0, 'year' => 1, 'sem' => 'second'],
                ['code' => 'NET1', 'name' => 'Computer Networking', 'units' => 3.0, 'lec' => 2.0, 'lab' => 2.0, 'year' => 2, 'sem' => 'first'],
                ['code' => 'DBMS1', 'name' => 'Database Management Systems', 'units' => 3.0, 'lec' => 2.0, 'lab' => 2.0, 'year' => 2, 'sem' => 'second'],
                ['code' => 'SAD1', 'name' => 'Systems Analysis and Design', 'units' => 3.0, 'lec' => 3.0, 'lab' => 0.0, 'year' => 3, 'sem' => 'first'],
                ['code' => 'CAPS1', 'name' => 'Capstone Project 1', 'units' => 3.0, 'lec' => 1.0, 'lab' => 4.0, 'year' => 4, 'sem' => 'first']
            ]
        ],
        [
            'keywords' => ['BUSINESS ADMINISTRATION', 'BSBA', 'BUSINESS'],
            'subjects' => [
                ['code' => 'ACCT1', 'name' => 'Fundamentals of Accounting', 'units' => 3.0, 'lec' => 3.0, 'lab' => 0.0, 'year' => 1, 'sem' => 'first'],
                ['code' => 'MKTG1', 'name' => 'Principles of Marketing', 'units' => 3.0, 'lec' => 3.0, 'lab' => 0.0, 'year' => 1, 'sem' => 'second'],
                ['code' => 'MGT1', 'name' => 'Human Resource Management', 'units' => 3.0, 'lec' => 3.0, 'lab' => 0.0, 'year' => 2, 'sem' => 'first'],
                ['code' => 'FIN1', 'name' => 'Financial Management', 'units' => 3.0, 'lec' => 3.0, 'lab' => 0.0, 'year' => 2, 'sem' => 'second'],
                ['code' => 'ECON1', 'name' => 'Microeconomics', 'units' => 3.0, 'lec' => 3.0, 'lab' => 0.0, 'year' => 2, 'sem' => 'first'],
                ['code' => 'STRAT1', 'name' => 'Strategic Management', 'units' => 3.0, 'lec' => 3.0, 'lab' => 0.0, 'year' => 4, 'sem' => 'second']
            ]
        ],
        [
            'keywords' => ['ENGINEERING', 'ENGR', 'BSE'],
            'subjects' => [
                ['code' => 'ENGM1', 'name' => 'Engineering Mathematics', 'units' => 4.0, 'lec' => 4.0, 'lab' => 0.0, 'year' => 1, 'sem' => 'first'],
                ['code' => 'PHY1', 'name' => 'Engineering Physics', 'units' => 4.0, 'lec' => 3.0, 'lab' => 2.0, 'year' => 1, 'sem' => 'second'],
                ['code' => 'MECH1', 'name' => 'Engineering Mechanics', 'units' => 3.0, 'lec' => 3.0, 'lab' => 0.0, 'year' => 2, 'sem' => 'first'],
                ['code' => 'THERM1', 'name' => 'Thermodynamics', 'units' => 3.0, 'lec' => 3.0, 'lab' => 0.0, 'year' => 2, 'sem' => 'second'],
                ['code' => 'MAT1', 'name' => 'Engineering Materials', 'units' => 3.0, 'lec' => 2.0, 'lab' => 2.0, 'year' => 2, 'sem' => 'second'],
                ['code' => 'DES1', 'name' => 'Engineering Design Project', 'units' => 3.0, 'lec' => 1.0, 'lab' => 4.0, 'year' => 4, 'sem' => 'first']
            ]
        ]
    ];

    foreach ($blueprints as $blueprint) {
        foreach ($blueprint['keywords'] as $keyword) {
            if (strpos($program_text, $keyword) !== false) {
                return $blueprint['subjects'];
            }
        }
    }

    return [
        ['code' => 'CORE1', 'name' => 'Foundations of the Discipline', 'units' => 3.0, 'lec' => 3.0, 'lab' => 0.0, 'year' => 1, 'sem' => 'first'],
        ['code' => 'CORE2', 'name' => 'Fundamental Concepts and Practices', 'units' => 3.0, 'lec' => 3.0, 'lab' => 0.0, 'year' => 1, 'sem' => 'second'],
        ['code' => 'APPL1', 'name' => 'Applied Methods', 'units' => 3.0, 'lec' => 2.0, 'lab' => 2.0, 'year' => 2, 'sem' => 'first'],
        ['code' => 'RES1', 'name' => 'Research Methods', 'units' => 3.0, 'lec' => 3.0, 'lab' => 0.0, 'year' => 3, 'sem' => 'first']
    ];
}

function auto_generate_subjects_for_course($course_id, $course_code, $course_name) {
    $course_id = (int)$course_id;
    if ($course_id <= 0) {
        return 0;
    }

    $existing_count = get_single_result(
        "SELECT COUNT(*) AS total FROM subjects WHERE course_id = ?",
        [$course_id]
    );

    if ((int)($existing_count['total'] ?? 0) > 0) {
        return 0;
    }

    $course_prefix = strtoupper(preg_replace('/[^A-Z0-9]/', '', (string)$course_code));
    if ($course_prefix === '') {
        $course_prefix = 'CRS';
    }

    $generated_count = 0;
    $subjects = get_course_subject_blueprint($course_code, $course_name);

    foreach ($subjects as $index => $subject) {
        $base_subject_code = $course_prefix . '-' . $subject['code'];
        $subject_code = $base_subject_code;
        $suffix = 1;

        while (get_single_result("SELECT subject_id FROM subjects WHERE subject_code = ? LIMIT 1", [$subject_code])) {
            $suffix++;
            $subject_code = $base_subject_code . '-' . $suffix;
        }

        insert_record('subjects', [
            'subject_code' => $subject_code,
            'subject_name' => $subject['name'],
            'description' => 'Auto-generated for ' . $course_name,
            'units' => $subject['units'],
            'lecture_hours' => $subject['lec'],
            'lab_hours' => $subject['lab'],
            'course_id' => $course_id,
            'year_level' => (int)$subject['year'],
            'semester_type' => $subject['sem']
        ]);
        $generated_count++;
    }

    return $generated_count;
}
?>
