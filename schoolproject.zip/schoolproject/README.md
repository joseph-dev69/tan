# School Information System

A comprehensive PHP-based school management system with role-based access control, academic management, billing, and reporting capabilities.

## Features

### Core Features
- **User Management**: Multi-role system (Admin, Student, Teacher, Dean, Records Officer, Finance Officer, Cashier)
- **Authentication**: Secure login/registration with admin approval workflow
- **Academic Management**: Course catalog, subject offerings, enrollment system
- **Grade Management**: Teacher grading, student grade viewing, GPA calculation
- **Billing System**: Fee management, payment processing, receipt generation
- **Reporting**: Academic records, transcripts, financial reports
- **Audit Logging**: Complete activity tracking for security and compliance

### User Roles
- **Admin**: System administration, user management, approvals
- **Student**: Enrollment, grade viewing, billing, schedule management
- **Teacher**: Grade submission, class management, schedule viewing
- **Dean**: Academic oversight, curriculum management
- **Records Officer**: Student records, transcript processing
- **Finance Officer**: Billing management, financial reporting
- **Cashier**: Payment processing, receipt generation

## System Requirements

### Server Requirements
- PHP 7.4 or higher
- MySQL 5.7 or higher / MariaDB 10.2 or higher
- Apache 2.4 or Nginx 1.18 or higher
- PHP Extensions:
  - PDO MySQL
  - JSON
  - OpenSSL
  - Mbstring
  - GD (for image processing)
  - cURL (for email functionality)

### Development Environment
- XAMPP, WAMP, or MAMP for local development
- Git for version control
- Modern web browser (Chrome, Firefox, Safari, Edge)

## Installation

### 1. Clone/Download the Project
```bash
git clone <repository-url>
cd schoolproject
```

### 2. Database Setup
1. Create a database named `school_management`
2. Import the database schema:
   ```sql
   mysql -u root -p school_management < database_schema.sql
   ```

### 3. Configuration
1. Copy and configure the database settings in `config/config.php`:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_NAME', 'school_management');
   define('DB_USER', 'root');
   define('DB_PASS', '');
   ```

2. Update the application URL:
   ```php
   define('APP_URL', 'http://localhost/schoolproject');
   ```

### 4. Web Server Configuration
#### Apache
Ensure `.htaccess` is enabled and mod_rewrite is loaded:
```apache
<Directory "C:/xampp/htdocs/schoolproject">
    AllowOverride All
    Require all granted
</Directory>
```

#### Nginx
Add to your server block:
```nginx
location /schoolproject {
    try_files $uri $uri/ /schoolproject/index.php?$query_string;
}
```

### 5. File Permissions
Set appropriate permissions:
```bash
chmod 755 -R .
chmod 777 uploads logs cache
```

### 6. Access the Application
Open your browser and navigate to:
```
http://localhost/schoolproject
```

## Default Login
- **Username**: `admin`
- **Password**: `password`

## Project Structure

```
schoolproject/
|-- config/                 # Configuration files
|   |-- database.php       # Database connection class
|   |-- config.php         # Application configuration
|
|-- includes/              # Shared libraries and functions
|   |-- functions.php      # Common functions
|
|-- modules/               # Application modules
|   |-- auth/              # Authentication module
|   |   |-- login.php
|   |   |-- register.php
|   |   |-- logout.php
|   |-- admin/             # Admin module
|   |   |-- dashboard.php
|   |   |-- approvals.php
|   |   |-- users.php
|   |   |-- courses.php
|   |   |-- subjects.php
|   |   |-- departments.php
|   |   |-- academic_years.php
|   |   |-- reports.php
|   |   |-- settings.php
|   |-- student/           # Student module
|   |   |-- dashboard.php
|   |   |-- profile.php
|   |   |-- enrollment.php
|   |   |-- schedule.php
|   |   |-- grades.php
|   |   |-- billing.php
|   |   |-- transcript.php
|   |   |-- settings.php
|   |-- teacher/           # Teacher module
|   |-- dean/              # Dean module
|   |-- records/           # Records officer module
|   |-- finance/           # Finance officer module
|   |-- cashier/           # Cashier module
|
|-- assets/                # Static assets
|   |-- css/               # Stylesheets
|   |   |-- style.css      # Main stylesheet
|   |-- js/                # JavaScript files
|   |   |-- main.js        # Main JavaScript file
|   |-- images/            # Image assets
|
|-- api/                   # API endpoints
|-- uploads/               # File upload directory
|-- logs/                  # Log files
|-- backups/               # Database backups
|-- templates/             # Email templates
|-- cache/                 # Cache files
|
|-- index.php              # Main entry point
|-- database_schema.sql    # Database schema
|-- README.md              # This file
```

## Database Schema

The system uses a normalized database schema with the following main tables:

### Core Tables
- `users` - User accounts and authentication
- `roles` - User roles and permissions
- `audit_logs` - System activity logging

### Academic Tables
- `school_years` - Academic year management
- `semesters` - Semester management
- `departments` - Department information
- `courses` - Course catalog
- `subjects` - Subject catalog
- `subject_prerequisites` - Subject prerequisites
- `students` - Student records
- `teachers` - Teacher records
- `subject_offerings` - Subject offerings per semester
- `schedules` - Class schedules
- `enrollments` - Student enrollments
- `student_subject_loads` - Student subject enrollments
- `grades` - Student grades
- `academic_records` - Academic standing records

### Financial Tables
- `fee_schedules` - Fee definitions
- `billings` - Student billing
- `billing_details` - Billing line items
- `payments` - Payment records
- `receipts` - Payment receipts

### Administrative Tables
- `records_officers` - Records officer accounts
- `finance_officers` - Finance officer accounts
- `cashiers` - Cashier accounts
- `transcript_requests` - Transcript request tracking

## Security Features

### Authentication & Authorization
- Secure password hashing (bcrypt)
- Session management with timeout
- CSRF protection on all forms
- Role-based access control
- Login attempt limiting

### Data Protection
- SQL injection prevention (prepared statements)
- XSS protection (output escaping)
- Input validation and sanitization
- File upload security
- Audit logging for all actions

### Session Security
- Secure session configuration
- HTTP-only session cookies
- Session regeneration on login
- Proper session destruction on logout

## API Endpoints

The system provides RESTful API endpoints for AJAX operations:

### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/logout` - User logout
- `POST /api/auth/register` - User registration

### Admin Operations
- `POST /api/admin/approve_user` - Approve user registration
- `GET /api/admin/users` - List users
- `POST /api/admin/create_user` - Create new user

### Student Operations
- `POST /api/student/enroll` - Process enrollment
- `GET /api/student/grades` - Get student grades
- `GET /api/student/billing` - Get billing information

## Development Guidelines

### Coding Standards
- Follow PSR-12 coding standards
- Use meaningful variable and function names
- Add proper comments and documentation
- Implement error handling and logging

### Database Best Practices
- Use prepared statements for all queries
- Implement proper indexing for performance
- Use transactions for multi-table operations
- Normalize data to reduce redundancy

### Security Best Practices
- Validate all user input
- Escape all output
- Use parameterized queries
- Implement proper error handling
- Log all administrative actions

## Testing

### Unit Testing
Run unit tests with PHPUnit:
```bash
phpunit tests/
```

### Integration Testing
Test database operations and API endpoints:
```bash
php tests/integration/
```

### Browser Testing
Test UI functionality with Selenium or manual testing.

## Deployment

### Production Setup
1. Set `APP_DEBUG` to `false` in `config/config.php`
2. Configure production database credentials
3. Set up SSL certificate
4. Configure email settings
5. Set up regular database backups
6. Configure monitoring and logging

### Performance Optimization
- Enable PHP OPcache
- Use database query caching
- Implement CDN for static assets
- Optimize database indexes
- Use gzip compression

## Maintenance

### Regular Tasks
- Database backups (weekly)
- Log file rotation (monthly)
- Security updates (as needed)
- Performance monitoring (continuous)

### Troubleshooting
- Check error logs in `logs/` directory
- Monitor database performance
- Verify file permissions
- Check email functionality

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Submit a pull request

## Support

For support and questions:
- Check the documentation
- Review error logs
- Contact the system administrator

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Changelog

### Version 1.0.0
- Initial release
- Core functionality implemented
- User management system
- Academic management
- Billing system
- Basic reporting

---

**Note**: This is a comprehensive school management system designed for educational institutions. Ensure proper security measures are in place when deploying to production environments.
