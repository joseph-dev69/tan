-- Departments and Courses normalization migration
-- Run this once in your database.

START TRANSACTION;

CREATE TABLE IF NOT EXISTS departments (
    department_id INT PRIMARY KEY AUTO_INCREMENT,
    department_name VARCHAR(100) NOT NULL,
    department_code VARCHAR(20) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_departments_name (department_name),
    UNIQUE KEY uq_departments_code (department_code)
);

-- Keep legacy columns if they exist, but ensure required constraints are present.
ALTER TABLE departments
    MODIFY department_name VARCHAR(100) NOT NULL,
    MODIFY department_code VARCHAR(20) NOT NULL;

-- Seed core departments safely.
INSERT INTO departments (department_name, department_code)
SELECT 'College of Computer Studies', 'CCS'
WHERE NOT EXISTS (
    SELECT 1 FROM departments WHERE UPPER(department_code) = 'CCS'
);

INSERT INTO departments (department_name, department_code)
SELECT 'College of Education', 'COE'
WHERE NOT EXISTS (
    SELECT 1 FROM departments WHERE UPPER(department_code) = 'COE'
);

INSERT INTO departments (department_name, department_code)
SELECT 'College of Business Administration', 'CBA'
WHERE NOT EXISTS (
    SELECT 1 FROM departments WHERE UPPER(department_code) = 'CBA'
);

INSERT INTO departments (department_name, department_code)
SELECT 'College of Arts and Sciences', 'CAS'
WHERE NOT EXISTS (
    SELECT 1 FROM departments WHERE UPPER(department_code) = 'CAS'
);

-- Ensure courses table has department relation.
ALTER TABLE courses
    MODIFY department_id INT NOT NULL;

-- Add FK only if missing.
SET @fk_exists := (
    SELECT COUNT(*)
    FROM information_schema.KEY_COLUMN_USAGE
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'courses'
      AND COLUMN_NAME = 'department_id'
      AND REFERENCED_TABLE_NAME = 'departments'
);

SET @sql_add_fk := IF(
    @fk_exists = 0,
    'ALTER TABLE courses ADD CONSTRAINT fk_courses_department FOREIGN KEY (department_id) REFERENCES departments(department_id)',
    'SELECT 1'
);
PREPARE stmt_add_fk FROM @sql_add_fk;
EXECUTE stmt_add_fk;
DEALLOCATE PREPARE stmt_add_fk;

COMMIT;
