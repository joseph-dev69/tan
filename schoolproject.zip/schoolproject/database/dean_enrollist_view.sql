-- Dean module integration view: course-based dynamic enrollist
-- Run this once in your database.

CREATE OR REPLACE VIEW dean_course_enrollist_view AS
SELECT
    e.enrollment_id,
    e.school_year_id,
    e.semester_id,
    c.course_id,
    c.course_code,
    c.course_name,
    s.student_id,
    s.student_number AS student_identifier,
    s.year_level,
    CONCAT(u.last_name, ', ', u.first_name) AS student_name
FROM enrollments e
JOIN students s ON s.student_id = e.student_id
JOIN users u ON u.user_id = s.user_id
JOIN courses c ON c.course_id = s.course_id
WHERE e.status = 'enrolled';
