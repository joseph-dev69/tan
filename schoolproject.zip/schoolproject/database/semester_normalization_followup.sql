/*
One-time follow-up script for duplicate logical semester rows.

Goal:
- Keep one canonical semester row per school year + semester_name
- Update related records that still point to duplicate semester_ids

IMPORTANT:
- Review the SELECT statements first before running any UPDATE
- Back up the database before applying changes
- Replace the sample school_year_id / semester ids as needed for your data
*/

/*
1) Inspect duplicate logical semesters
*/
SELECT school_year_id, semester_name, COUNT(*) AS duplicate_count,
       GROUP_CONCAT(semester_id ORDER BY semester_id) AS semester_ids
FROM semesters
GROUP BY school_year_id, semester_name
HAVING COUNT(*) > 1;

/*
2) Example mapping for 2025-2026 / First Semester
   - canonical semester_id = 4
   - duplicate semester_id = 1

   Adjust these values to match your actual database before running updates.
*/
SET @canonical_school_year_id = 3;
SET @canonical_semester_name = 'First Semester';
SET @canonical_semester_id = 4;
SET @duplicate_semester_id = 1;

/*
3) Preview affected rows
*/
SELECT 'subject_offerings' AS source_table, COUNT(*) AS affected_rows
FROM subject_offerings
WHERE school_year_id = @canonical_school_year_id
  AND semester_id = @duplicate_semester_id
UNION ALL
SELECT 'enrollments', COUNT(*)
FROM enrollments
WHERE school_year_id = @canonical_school_year_id
  AND semester_id = @duplicate_semester_id
UNION ALL
SELECT 'billings', COUNT(*)
FROM billings
WHERE school_year_id = @canonical_school_year_id
  AND semester_id = @duplicate_semester_id;

/*
4) Apply normalization
   Uncomment and run only after validation.
*/
/*
START TRANSACTION;

UPDATE subject_offerings
SET semester_id = @canonical_semester_id
WHERE school_year_id = @canonical_school_year_id
  AND semester_id = @duplicate_semester_id;

UPDATE enrollments
SET semester_id = @canonical_semester_id
WHERE school_year_id = @canonical_school_year_id
  AND semester_id = @duplicate_semester_id;

UPDATE billings
SET semester_id = @canonical_semester_id
WHERE school_year_id = @canonical_school_year_id
  AND semester_id = @duplicate_semester_id;

COMMIT;
*/

/*
5) Verify after update
*/
SELECT school_year_id, semester_name, COUNT(*) AS duplicate_count,
       GROUP_CONCAT(semester_id ORDER BY semester_id) AS semester_ids
FROM semesters
GROUP BY school_year_id, semester_name
HAVING COUNT(*) > 1;
