<?php
/**
 * Database Configuration
 * School Information System
 */

require_once __DIR__ . '/config.php';

class Database {
    private $host;
    private $db_name;
    private $username;
    private $password;
    private $port;
    private $charset;
    private $conn;

    public function __construct() {
        $this->host = defined('DB_HOST') ? DB_HOST : 'localhost';
        $this->db_name = defined('DB_NAME') ? DB_NAME : 'school_management';
        $this->username = defined('DB_USER') ? DB_USER : 'root';
        $this->password = defined('DB_PASS') ? DB_PASS : '';
        $this->port = defined('DB_PORT') ? (int) DB_PORT : 3306;
        $this->charset = defined('DB_CHARSET') ? DB_CHARSET : 'utf8mb4';
    }

    public function getConnection() {
        $this->conn = null;
        
        try {
            $dsn = "mysql:host={$this->host};port={$this->port};dbname={$this->db_name};charset={$this->charset}";
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::ATTR_PERSISTENT => true
            ];
            
            $this->conn = new PDO($dsn, $this->username, $this->password, $options);
        } catch(PDOException $exception) {
            // XAMPP on Windows can be sensitive to localhost/socket resolution.
            // Retry once with TCP loopback if localhost was used.
            if (strtolower((string) $this->host) === 'localhost') {
                try {
                    $fallback_dsn = "mysql:host=127.0.0.1;port={$this->port};dbname={$this->db_name};charset={$this->charset}";
                    $this->conn = new PDO($fallback_dsn, $this->username, $this->password, $options);
                    return $this->conn;
                } catch (PDOException $fallback_exception) {
                    error_log("Database connection error: " . $fallback_exception->getMessage());
                    throw new Exception("Database connection failed. Check DB settings in config/config.php and ensure MySQL is running in XAMPP.");
                }
            }

            error_log("Database connection error: " . $exception->getMessage());
            throw new Exception("Database connection failed. Please try again later.");
        }
        
        return $this->conn;
    }
    
    public function testConnection() {
        try {
            $conn = $this->getConnection();
            return $conn ? true : false;
        } catch(Exception $e) {
            return false;
        }
    }
}
?>
