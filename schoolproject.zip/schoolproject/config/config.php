<?php
/**
 * Application Configuration
 * School Information System
 */

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'school_management');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_PORT', 3306);
define('DB_CHARSET', 'utf8mb4');

// Application Settings
define('APP_NAME', 'School Information System');
define('APP_VERSION', '1.0.0');
define('APP_URL', 'http://localhost/schoolproject');
define('APP_DEBUG', true);

// Session Configuration
define('SESSION_LIFETIME', 3600); // 1 hour
define('SESSION_PATH', '/');
define('SESSION_DOMAIN', '');
define('SESSION_SECURE', false);
define('SESSION_HTTPONLY', true);

// Security Settings
define('HASH_ALGO', PASSWORD_DEFAULT);
define('HASH_COST', 12);
define('CSRF_TOKEN_NAME', 'csrf_token');
define('CSRF_TOKEN_LENGTH', 32);
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_ATTEMPT_TIMEOUT', 900); // 15 minutes

// File Upload Settings
define('UPLOAD_MAX_SIZE', 5242880); // 5MB
define('UPLOAD_ALLOWED_TYPES', ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx']);
define('UPLOAD_PATH', 'uploads/');

// Email Settings
define('SMTP_HOST', 'localhost');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', '');
define('SMTP_PASSWORD', '');
define('SMTP_ENCRYPTION', 'tls');
define('EMAIL_FROM', 'noreply@school.edu');
define('EMAIL_FROM_NAME', APP_NAME);

// Pagination
define('DEFAULT_PAGE_SIZE', 20);
define('MAX_PAGE_SIZE', 100);

// Date/Time Settings
define('DATE_FORMAT', 'Y-m-d');
define('TIME_FORMAT', 'H:i:s');
define('DATETIME_FORMAT', 'Y-m-d H:i:s');
define('TIMEZONE', 'Asia/Manila');

// Error Reporting
if (APP_DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// Set timezone
date_default_timezone_set(TIMEZONE);

// Custom error handler
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    if (!(error_reporting() & $errno)) {
        return false;
    }
    
    $error_message = "Error [$errno]: $errstr in $errfile on line $errline";
    error_log($error_message);
    
    if (APP_DEBUG) {
        echo "<div class='alert alert-danger'>$error_message</div>";
    }
    
    return true;
});

// Custom exception handler
set_exception_handler(function($exception) {
    error_log("Uncaught exception: " . $exception->getMessage());
    
    if (APP_DEBUG) {
        echo "<div class='alert alert-danger'>Uncaught exception: " . $exception->getMessage() . "</div>";
    } else {
        echo "<div class='alert alert-danger'>An error occurred. Please try again later.</div>";
    }
});

// Security Headers
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: strict-origin-when-cross-origin');

// CORS Headers (if needed for API)
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    header('Access-Control-Max-Age: 86400');
    exit(0);
}

// Start session
session_start();

// Global functions
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

function generate_csrf_token() {
    if (empty($_SESSION[CSRF_TOKEN_NAME])) {
        $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(CSRF_TOKEN_LENGTH));
    }
    return $_SESSION[CSRF_TOKEN_NAME];
}

function verify_csrf_token($token) {
    return isset($_SESSION[CSRF_TOKEN_NAME]) && hash_equals($_SESSION[CSRF_TOKEN_NAME], $token);
}

function is_logged_in() {
    // Ensure both user_id and user payload exist to avoid partial-session redirect loops
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])
        && isset($_SESSION['user']) && !empty($_SESSION['user']);
}

function get_logged_in_user() {
    if (is_logged_in()) {
        return $_SESSION['user'];
    }
    return null;
}

function get_user_role() {
    if (is_logged_in()) {
        return $_SESSION['user']['role'] ?? null;
    }
    return null;
}

function redirect($url, $status_code = 302) {
    // Normalize app-relative routes so redirects from nested paths still work.
    if (!preg_match('/^(https?:)?\/\//i', $url) && strpos($url, '/') !== 0) {
        $url = rtrim(APP_URL, '/') . '/' . ltrim($url, '/');
    }
    header("Location: $url", true, $status_code);
    exit();
}

function flash_message($type, $message) {
    if (!isset($_SESSION['flash_messages'])) {
        $_SESSION['flash_messages'] = [];
    }
    $_SESSION['flash_messages'][] = ['type' => $type, 'message' => $message];
}

function get_flash_messages() {
    $messages = $_SESSION['flash_messages'] ?? [];
    unset($_SESSION['flash_messages']);
    return $messages;
}

function format_date($date, $format = DATE_FORMAT) {
    return date($format, strtotime($date));
}

function format_currency($amount) {
    return 'PHP ' . number_format($amount, 2);
}

function compute_exam_period_schedule($start_date, $end_date) {
    if (empty($start_date) || empty($end_date)) {
        return [];
    }

    try {
        $start = new DateTime($start_date);
        $end = new DateTime($end_date);
    } catch (Exception $e) {
        return [];
    }

    if ($end < $start) {
        return [];
    }

    $total_days = (int)$start->diff($end)->days + 1;
    $phase_days = max(1, (int)ceil($total_days / 3));

    $prelim_due = clone $start;
    $prelim_due->modify('+' . ($phase_days - 1) . ' days');
    if ($prelim_due > $end) {
        $prelim_due = clone $end;
    }

    $midterm_due = clone $start;
    $midterm_due->modify('+' . (($phase_days * 2) - 1) . ' days');
    if ($midterm_due > $end) {
        $midterm_due = clone $end;
    }

    return [
        'semester_start_date' => $start->format('Y-m-d'),
        'semester_end_date' => $end->format('Y-m-d'),
        'total_days' => $total_days,
        'prelim' => [
            'label' => 'Prelim',
            'due_date' => $prelim_due->format('Y-m-d'),
        ],
        'midterm' => [
            'label' => 'Midterm',
            'due_date' => $midterm_due->format('Y-m-d'),
        ],
        'final' => [
            'label' => 'Final',
            'due_date' => $end->format('Y-m-d'),
        ],
    ];
}

function log_audit($action, $table_name = null, $record_id = null, $old_values = null, $new_values = null) {
    if (!is_logged_in()) {
        return;
    }
    
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        $stmt = $conn->prepare("
            INSERT INTO audit_logs (user_id, action, table_name, record_id, old_values, new_values, ip_address, user_agent)
            VALUES (:user_id, :action, :table_name, :record_id, :old_values, :new_values, :ip_address, :user_agent)
        ");
        
        $stmt->execute([
            ':user_id' => $_SESSION['user_id'],
            ':action' => $action,
            ':table_name' => $table_name,
            ':record_id' => $record_id,
            ':old_values' => $old_values ? json_encode($old_values) : null,
            ':new_values' => $new_values ? json_encode($new_values) : null,
            ':ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
            ':user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null
        ]);
    } catch (Exception $e) {
        error_log("Audit log error: " . $e->getMessage());
    }
}
?>
