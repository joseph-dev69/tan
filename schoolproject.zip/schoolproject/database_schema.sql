-- School Information System Database Schema
-- Generated for PHP-based School Management System

-- Section 10: Database Schema (SQL CREATE TABLE Statements)

-- Drop existing tables if they exist (for development)
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS audit_logs;
DROP TABLE IF EXISTS transcript_requests;
DROP TABLE IF EXISTS academic_records;
DROP TABLE IF EXISTS receipts;
DROP TABLE IF EXISTS payments;
DROP TABLE IF EXISTS billing_details;
DROP TABLE IF EXISTS billings;
DROP TABLE IF EXISTS fee_schedules;
DROP TABLE IF EXISTS grades;
DROP TABLE IF EXISTS student_subject_loads;
DROP TABLE IF EXISTS enrollments;
DROP TABLE IF EXISTS schedules;
DROP TABLE IF EXISTS subject_offerings;
DROP TABLE IF EXISTS subject_prerequisites;
DROP TABLE IF EXISTS cashiers;
DROP TABLE IF EXISTS finance_officers;
DROP TABLE IF EXISTS records_officers;
DROP TABLE IF EXISTS teachers;
DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS subjects;
DROP TABLE IF EXISTS courses;
DROP TABLE IF EXISTS departments;
DROP TABLE IF EXISTS semesters;
DROP TABLE IF EXISTS school_years;
DROP TABLE IF EXISTS roles;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

-- Create roles table
CREATE TABLE roles (
    role_id INT PRIMARY KEY AUTO_INCREMENT,
    role_name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default roles
INSERT INTO roles (role_name, description) VALUES
('admin', 'System Administrator with full access'),
('student', 'Student user with limited access'),
('teacher', 'Teacher with grading and subject management access'),
('dean', 'Academic Dean with oversight capabilities'),
('records_officer', 'Records Officer managing student records'),
('finance_officer', 'Finance Officer managing billing and payments'),
('cashier', 'Cashier processing payments');

-- Create users table
CREATE TABLE users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role_id INT NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    middle_name VARCHAR(50),
    status ENUM('pending', 'approved', 'rejected', 'inactive') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    FOREIGN KEY (role_id) REFERENCES roles(role_id)
);

-- Create school_years table
CREATE TABLE school_years (
    school_year_id INT PRIMARY KEY AUTO_INCREMENT,
    year_name VARCHAR(20) UNIQUE NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    is_current BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create semesters table
CREATE TABLE semesters (
    semester_id INT PRIMARY KEY AUTO_INCREMENT,
    semester_name VARCHAR(20) NOT NULL,
    school_year_id INT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    is_current BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (school_year_id) REFERENCES school_years(school_year_id)
);

-- Create departments table
CREATE TABLE departments (
    department_id INT PRIMARY KEY AUTO_INCREMENT,
    department_name VARCHAR(100) UNIQUE NOT NULL,
    department_code VARCHAR(20) UNIQUE NOT NULL,
    description TEXT,
    head_of_department VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create courses table
CREATE TABLE courses (
    course_id INT PRIMARY KEY AUTO_INCREMENT,
    course_name VARCHAR(100) NOT NULL,
    course_code VARCHAR(20) UNIQUE NOT NULL,
    department_id INT NOT NULL,
    description TEXT,
    duration_years INT NOT NULL DEFAULT 4,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(department_id)
);

-- Create subjects table
CREATE TABLE subjects (
    subject_id INT PRIMARY KEY AUTO_INCREMENT,
    subject_code VARCHAR(20) UNIQUE NOT NULL,
    subject_name VARCHAR(100) NOT NULL,
    description TEXT,
    units DECIMAL(3,1) NOT NULL DEFAULT 1.0,
    lecture_hours DECIMAL(3,1) DEFAULT 0,
    lab_hours DECIMAL(3,1) DEFAULT 0,
    course_id INT NOT NULL,
    year_level INT NOT NULL,
    semester_type ENUM('first', 'second', 'summer') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(course_id)
);

-- Create subject_prerequisites table
CREATE TABLE subject_prerequisites (
    prerequisite_id INT PRIMARY KEY AUTO_INCREMENT,
    subject_id INT NOT NULL,
    prerequisite_subject_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id),
    FOREIGN KEY (prerequisite_subject_id) REFERENCES subjects(subject_id),
    UNIQUE KEY unique_prerequisite (subject_id, prerequisite_subject_id)
);

-- Create students table
CREATE TABLE students (
    student_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT UNIQUE NOT NULL,
    student_number VARCHAR(20) UNIQUE NOT NULL,
    course_id INT NOT NULL,
    year_level INT NOT NULL DEFAULT 1,
    admission_date DATE NOT NULL,
    expected_graduation_date DATE,
    gpa DECIMAL(3,2) DEFAULT 0.00,
    academic_status ENUM('regular', 'irregular', 'probation', 'suspended') DEFAULT 'regular',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (course_id) REFERENCES courses(course_id)
);

-- Create teachers table
CREATE TABLE teachers (
    teacher_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT UNIQUE NOT NULL,
    employee_number VARCHAR(20) UNIQUE NOT NULL,
    department_id INT NOT NULL,
    specialization VARCHAR(100),
    employment_type ENUM('full_time', 'part_time', 'visiting') DEFAULT 'full_time',
    hire_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (department_id) REFERENCES departments(department_id)
);

-- Create records_officers table
CREATE TABLE records_officers (
    records_officer_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT UNIQUE NOT NULL,
    employee_number VARCHAR(20) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Create finance_officers table
CREATE TABLE finance_officers (
    finance_officer_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT UNIQUE NOT NULL,
    employee_number VARCHAR(20) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Create cashiers table
CREATE TABLE cashiers (
    cashier_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT UNIQUE NOT NULL,
    employee_number VARCHAR(20) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Create subject_offerings table
CREATE TABLE subject_offerings (
    offering_id INT PRIMARY KEY AUTO_INCREMENT,
    subject_id INT NOT NULL,
    teacher_id INT NOT NULL,
    semester_id INT NOT NULL,
    school_year_id INT NOT NULL,
    section VARCHAR(20) NOT NULL,
    max_students INT NOT NULL DEFAULT 40,
    current_students INT DEFAULT 0,
    status ENUM('open', 'closed', 'cancelled') DEFAULT 'open',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id),
    FOREIGN KEY (teacher_id) REFERENCES teachers(teacher_id),
    FOREIGN KEY (semester_id) REFERENCES semesters(semester_id),
    FOREIGN KEY (school_year_id) REFERENCES school_years(school_year_id)
);

-- Create schedules table
CREATE TABLE schedules (
    schedule_id INT PRIMARY KEY AUTO_INCREMENT,
    offering_id INT NOT NULL,
    day_of_week ENUM('monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday') NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    room VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (offering_id) REFERENCES subject_offerings(offering_id)
);

-- Create enrollments table
CREATE TABLE enrollments (
    enrollment_id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    semester_id INT NOT NULL,
    school_year_id INT NOT NULL,
    enrollment_date DATE NOT NULL,
    status ENUM('enrolled', 'dropped', 'completed', 'withdrawn') DEFAULT 'enrolled',
    total_units DECIMAL(4,1) DEFAULT 0,
    total_fee DECIMAL(10,2) DEFAULT 0.00,
    paid_amount DECIMAL(10,2) DEFAULT 0.00,
    balance DECIMAL(10,2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (semester_id) REFERENCES semesters(semester_id),
    FOREIGN KEY (school_year_id) REFERENCES school_years(school_year_id),
    UNIQUE KEY unique_enrollment (student_id, semester_id, school_year_id)
);

-- Create student_subject_loads table
CREATE TABLE student_subject_loads (
    load_id INT PRIMARY KEY AUTO_INCREMENT,
    enrollment_id INT NOT NULL,
    offering_id INT NOT NULL,
    status ENUM('enrolled', 'dropped', 'completed', 'failed') DEFAULT 'enrolled',
    final_grade DECIMAL(5,2),
    remarks VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (enrollment_id) REFERENCES enrollments(enrollment_id),
    FOREIGN KEY (offering_id) REFERENCES subject_offerings(offering_id),
    UNIQUE KEY unique_load (enrollment_id, offering_id)
);

-- Create grades table
CREATE TABLE grades (
    grade_id INT PRIMARY KEY AUTO_INCREMENT,
    student_subject_load_id INT NOT NULL,
    grading_period ENUM('prelim', 'midterm', 'prefinal', 'final') NOT NULL,
    grade DECIMAL(5,2) NOT NULL,
    graded_by INT NOT NULL,
    date_graded DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_subject_load_id) REFERENCES student_subject_loads(load_id),
    FOREIGN KEY (graded_by) REFERENCES teachers(teacher_id)
);

-- Create fee_schedules table
CREATE TABLE fee_schedules (
    fee_schedule_id INT PRIMARY KEY AUTO_INCREMENT,
    fee_name VARCHAR(100) NOT NULL,
    fee_type ENUM('tuition', 'miscellaneous', 'laboratory', 'library', 'sports', 'other') NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    applicable_to ENUM('all', 'undergraduate', 'graduate', 'specific_course') DEFAULT 'all',
    course_id INT NULL,
    year_level INT NULL,
    semester_type ENUM('first', 'second', 'summer', 'all') DEFAULT 'all',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(course_id)
);

-- Create billings table
CREATE TABLE billings (
    billing_id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    semester_id INT NOT NULL,
    school_year_id INT NOT NULL,
    billing_date DATE NOT NULL,
    due_date DATE NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    status ENUM('pending', 'partially_paid', 'paid', 'overdue') DEFAULT 'pending',
    paid_amount DECIMAL(10,2) DEFAULT 0.00,
    balance DECIMAL(10,2) GENERATED ALWAYS AS (total_amount - paid_amount) STORED,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (semester_id) REFERENCES semesters(semester_id),
    FOREIGN KEY (school_year_id) REFERENCES school_years(school_year_id)
);

-- Create billing_details table
CREATE TABLE billing_details (
    billing_detail_id INT PRIMARY KEY AUTO_INCREMENT,
    billing_id INT NOT NULL,
    fee_schedule_id INT NOT NULL,
    quantity INT DEFAULT 1,
    unit_cost DECIMAL(10,2) NOT NULL,
    total_cost DECIMAL(10,2) GENERATED ALWAYS AS (quantity * unit_cost) STORED,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (billing_id) REFERENCES billings(billing_id),
    FOREIGN KEY (fee_schedule_id) REFERENCES fee_schedules(fee_schedule_id)
);

-- Create payments table
CREATE TABLE payments (
    payment_id INT PRIMARY KEY AUTO_INCREMENT,
    billing_id INT NOT NULL,
    payment_date DATE NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_method ENUM('cash', 'check', 'bank_transfer', 'credit_card', 'online_payment') NOT NULL,
    reference_number VARCHAR(100),
    processed_by INT NOT NULL,
    status ENUM('pending', 'verified', 'cancelled') DEFAULT 'verified',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (billing_id) REFERENCES billings(billing_id),
    FOREIGN KEY (processed_by) REFERENCES cashiers(cashier_id)
);

-- Create receipts table
CREATE TABLE receipts (
    receipt_id INT PRIMARY KEY AUTO_INCREMENT,
    payment_id INT UNIQUE NOT NULL,
    receipt_number VARCHAR(50) UNIQUE NOT NULL,
    receipt_date DATE NOT NULL,
    printed_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (payment_id) REFERENCES payments(payment_id),
    FOREIGN KEY (printed_by) REFERENCES cashiers(cashier_id)
);

-- Create academic_records table
CREATE TABLE academic_records (
    record_id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    semester_id INT NOT NULL,
    school_year_id INT NOT NULL,
    gpa DECIMAL(3,2),
    total_units DECIMAL(4,1),
    earned_units DECIMAL(4,1),
    academic_standing ENUM('good', 'warning', 'probation', 'dismissal') DEFAULT 'good',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (semester_id) REFERENCES semesters(semester_id),
    FOREIGN KEY (school_year_id) REFERENCES school_years(school_year_id),
    UNIQUE KEY unique_academic_record (student_id, semester_id, school_year_id)
);

-- Create transcript_requests table
CREATE TABLE transcript_requests (
    request_id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    request_date DATE NOT NULL,
    purpose VARCHAR(200) NOT NULL,
    number_of_copies INT NOT NULL DEFAULT 1,
    status ENUM('pending', 'processing', 'ready', 'claimed', 'cancelled') DEFAULT 'pending',
    processing_fee DECIMAL(10,2) DEFAULT 50.00,
    paid BOOLEAN DEFAULT FALSE,
    processed_by INT,
    date_processed DATE,
    date_claimed DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (processed_by) REFERENCES records_officers(records_officer_id)
);

-- Create audit_logs table
CREATE TABLE audit_logs (
    log_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    action VARCHAR(100) NOT NULL,
    table_name VARCHAR(50),
    record_id INT,
    old_values JSON,
    new_values JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Create indexes for better performance
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role_id ON users(role_id);
CREATE INDEX idx_students_user_id ON students(user_id);
CREATE INDEX idx_students_student_number ON students(student_number);
CREATE INDEX idx_teachers_user_id ON teachers(user_id);
CREATE INDEX idx_subject_offerings_subject_id ON subject_offerings(subject_id);
CREATE INDEX idx_subject_offerings_teacher_id ON subject_offerings(teacher_id);
CREATE INDEX idx_subject_offerings_semester_id ON subject_offerings(semester_id);
CREATE INDEX idx_enrollments_student_id ON enrollments(student_id);
CREATE INDEX idx_enrollments_semester_id ON enrollments(semester_id);
CREATE INDEX idx_student_subject_loads_enrollment_id ON student_subject_loads(enrollment_id);
CREATE INDEX idx_student_subject_loads_offering_id ON student_subject_loads(offering_id);
CREATE INDEX idx_grades_student_subject_load_id ON grades(student_subject_load_id);
CREATE INDEX idx_billings_student_id ON billings(student_id);
CREATE INDEX idx_payments_billing_id ON payments(billing_id);
CREATE INDEX idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_timestamp ON audit_logs(timestamp);

-- Create views for common queries
CREATE VIEW student_enrollment_view AS
SELECT 
    s.student_id,
    s.student_number,
    u.first_name,
    u.last_name,
    c.course_name,
    c.course_code,
    s.year_level,
    e.enrollment_id,
    e.total_units,
    e.total_fee,
    e.paid_amount,
    e.balance,
    e.status as enrollment_status,
    sy.year_name,
    sem.semester_name
FROM students s
JOIN users u ON s.user_id = u.user_id
JOIN courses c ON s.course_id = c.course_id
JOIN enrollments e ON s.student_id = e.student_id
JOIN school_years sy ON e.school_year_id = sy.school_year_id
JOIN semesters sem ON e.semester_id = sem.semester_id;

CREATE VIEW teacher_schedule_view AS
SELECT 
    t.teacher_id,
    u.first_name,
    u.last_name,
    sub.subject_code,
    sub.subject_name,
    so.section,
    so.max_students,
    so.current_students,
    sy.year_name,
    sem.semester_name,
    sched.day_of_week,
    sched.start_time,
    sched.end_time,
    sched.room
FROM teachers t
JOIN users u ON t.user_id = u.user_id
JOIN subject_offerings so ON t.teacher_id = so.teacher_id
JOIN subjects sub ON so.subject_id = sub.subject_id
JOIN school_years sy ON so.school_year_id = sy.school_year_id
JOIN semesters sem ON so.semester_id = sem.semester_id
JOIN schedules sched ON so.offering_id = sched.offering_id;

-- Insert sample data for testing
INSERT INTO school_years (year_name, start_date, end_date, is_current) VALUES
('2024-2025', '2024-08-01', '2025-05-31', TRUE),
('2023-2024', '2023-08-01', '2024-05-31', FALSE);

INSERT INTO semesters (semester_name, school_year_id, start_date, end_date, is_current) VALUES
('First Semester', 1, '2024-08-01', '2024-12-20', TRUE),
('Second Semester', 1, '2025-01-06', '2025-05-31', FALSE),
('Summer', 1, '2025-06-01', '2025-07-31', FALSE);

INSERT INTO departments (department_name, department_code, description, head_of_department) VALUES
('College of Computer Studies', 'CCS', 'Offers IT and CS programs', 'Dr. John Smith'),
('College of Business Administration', 'CBA', 'Offers Business and Management programs', 'Dr. Jane Doe'),
('College of Engineering', 'COE', 'Offers Engineering programs', 'Dr. Robert Johnson');

INSERT INTO courses (course_name, course_code, department_id, description, duration_years) VALUES
('Bachelor of Science in Information Technology', 'BSIT', 1, '4-year IT program', 4),
('Bachelor of Science in Computer Science', 'BSCS', 1, '4-year CS program', 4),
('Bachelor of Science in Business Administration', 'BSBA', 2, '4-year Business program', 4);

INSERT INTO subjects (subject_code, subject_name, description, units, lecture_hours, lab_hours, course_id, year_level, semester_type) VALUES
('IT101', 'Introduction to Computing', 'Basic computing concepts', 3.0, 3.0, 0.0, 1, 1, 'first'),
('IT102', 'Programming Fundamentals', 'Introduction to programming', 4.0, 2.0, 3.0, 1, 1, 'first'),
('IT103', 'Discrete Mathematics', 'Mathematical foundations', 3.0, 3.0, 0.0, 1, 1, 'second'),
('IT201', 'Data Structures and Algorithms', 'Advanced programming concepts', 4.0, 2.0, 3.0, 1, 2, 'first');

-- Insert sample admin user
INSERT INTO users (username, email, password_hash, role_id, first_name, last_name, status) VALUES
('admin', 'admin@school.edu', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1, 'System', 'Administrator', 'approved');

-- Insert sample fee schedules
INSERT INTO fee_schedules (fee_name, fee_type, amount, applicable_to, course_id, year_level, semester_type) VALUES
('Tuition Fee per Unit', 'tuition', 1500.00, 'all', NULL, NULL, 'all'),
('Library Fee', 'miscellaneous', 500.00, 'all', NULL, NULL, 'all'),
('Laboratory Fee', 'laboratory', 1000.00, 'undergraduate', NULL, NULL, 'all'),
('Sports Development Fee', 'miscellaneous', 300.00, 'all', NULL, NULL, 'all'),
('Student Handbook', 'miscellaneous', 200.00, 'all', NULL, 1, 'first');
