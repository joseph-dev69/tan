<?php
include '../config/db.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'finance') {
    header("Location: ../auth/login.php");
    exit();
}

$students = $conn->query("SELECT * FROM users WHERE role='student' AND status='approved'");
?>

<!DOCTYPE html>
<html>
<head>
<title>Billing - Finance</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

<style>
body{margin:0;font-family:Arial;display:flex;background:#eef1f5;}
.sidebar{width:250px;height:100vh;background:#1d3557;color:white;padding:20px;}
.sidebar h2{text-align:center;}
.sidebar a{display:block;color:white;padding:12px;margin-top:10px;text-decoration:none;border-radius:8px;}
.sidebar a:hover{background:#457b9d;}
.sidebar a i{margin-right:10px;}
.main{flex:1;}
.topbar{background:white;padding:15px;display:flex;justify-content:space-between;box-shadow:0 2px 5px rgba(0,0,0,0.1);}
.content{padding:25px;}
table{width:100%;background:white;border-collapse:collapse;border-radius:10px;overflow:hidden;}
th,td{padding:14px;border-bottom:1px solid #ddd;text-align:left;}
th{background:#1d3557;color:white;}
.status{color:white;padding:6px 10px;border-radius:6px;}
</style>
</head>

<body>

<div class="sidebar">
    <h2>💰 Finance</h2>
    <a href="dashboard.php"><i class="fa fa-home"></i> Dashboard</a> 
    <a href="../auth/logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
</div>

<div class="main">
    <div class="topbar">
        <div>Billing</div>
        <div><i class="fa fa-money-bill"></i> Finance Officer</div>
    </div>

    <div class="content">
        <h2>Student Billing Summary</h2>

        <table>
            <tr>
                <th>ID</th>
                <th>Student</th>
                <th>Course</th>
                <th>Total Fee</th>
                <th>Paid</th>
                <th>Balance</th>
                <th>Status</th>
            </tr>

            <?php while($row = $students->fetch_assoc()) { 
                $total_fee = 25000;

                $payments = $conn->query("SELECT SUM(amount) AS total_paid 
                                          FROM payments 
                                          WHERE user_id = " . $row['id']);

                $data = $payments->fetch_assoc();
                $paid = $data['total_paid'] ? $data['total_paid'] : 0;

                $balance = $total_fee - $paid;
                $status = ($balance <= 0) ? "Paid" : "Unpaid";
                $color = ($status == "Paid") ? "green" : "orange";
            ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['course']; ?></td>
                <td>₱<?php echo number_format($total_fee, 2); ?></td>
                <td>₱<?php echo number_format($paid, 2); ?></td>
                <td>₱<?php echo number_format($balance, 2); ?></td>
                <td>
                    <span class="status" style="background: <?php echo $color; ?>">
                        <?php echo $status; ?>
                    </span>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>
</div>

</body>
</html>