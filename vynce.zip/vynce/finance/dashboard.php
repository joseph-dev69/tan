<?php
include '../config/db.php';
include '../includes/header.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'finance') {
    header("Location: ../auth/login.php");
    exit();
}

$students = $conn->query("SELECT * FROM users WHERE role='student' AND status='approved'");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Finance Dashboard</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

    <style>
        body {
            margin: 0;
            font-family: Arial;
            display: flex;
            background: #eef1f5;
        }

        .sidebar {
            width: 250px;
            height: 100vh;
            background: #1d3557;
            color: white;
            padding: 20px;
        }

        .sidebar h2 {
            text-align: center;
        }

        .sidebar a {
            display: block;
            color: white;
            padding: 12px;
            margin-top: 10px;
            text-decoration: none;
            border-radius: 8px;
        }

        .sidebar a:hover {
            background: #457b9d;
        }

        .sidebar a i {
            margin-right: 10px;
        }

        .main {
            flex: 1;
        }

        .topbar {
            background: white;
            padding: 15px;
            display: flex;
            justify-content: space-between;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .content {
            padding: 25px;
        }

        .cards {
            display: flex;
            gap: 20px;
            margin-bottom: 25px;
        }

        .card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            flex: 1;
            text-align: center;
            box-shadow: 0 5px 10px rgba(0,0,0,0.1);
        }

        .card i {
            font-size: 30px;
            color: #1d3557;
        }

        table {
            width: 100%;
            background: white;
            border-collapse: collapse;
            border-radius: 10px;
            overflow: hidden;
        }

        th, td {
            padding: 14px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        th {
            background: #1d3557;
            color: white;
        }

        .btn {
            display:inline-block;
            margin-top:10px;
            background: #1d3557;
            color: white;
            padding: 8px 12px;
            text-decoration: none;
            border-radius: 6px;
        }

        .btn:hover {
            background:#16324f;
        }
    </style>
</head>
<body>

<div class="sidebar">
    <h2>💰 Finance</h2>

    <a href="dashboard.php"><i class="fa fa-home"></i> Dashboard</a>
    <a href="../auth/logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
</div>

<div class="main">

    <div class="topbar">
        <div>Finance Dashboard</div>
        <div><i class="fa fa-money-bill"></i> Finance Officer</div>
    </div>

    <div class="content">
        <h2>Welcome, Finance Officer 👋</h2>

        <!-- ✅ UPDATED CARDS WITH BUTTONS -->
        <div class="cards">

            <div class="cards">

    <div class="card">
        <i class="fa fa-users"></i>
        <h3>Student Load</h3>
        <p>View student subjects and total units</p>
        <a href="students.php" class="btn">View</a>
    </div>

    <div class="card">
        <i class="fa fa-file-invoice-dollar"></i>
        <h3>Fee Schedules</h3>
        <p>Tuition fee, misc fee, and other fees</p>
        <a href="billing.php" class="btn">Open</a>
    </div>

    <div class="card">
        <i class="fa fa-money-check-dollar"></i>
        <h3>Student Billing</h3>
        <p>Check exam balances and payable fees</p>
        <a href="billing.php" class="btn">Check</a>
    </div>

</body>
</html>