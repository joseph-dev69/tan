<?php
include '../config/db.php';
if (session_status() == PHP_SESSION_NONE) session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'finance') {
    header("Location: ../auth/login.php");
    exit();
}

$students = $conn->query("SELECT * FROM users WHERE role='student' AND status='approved'");
?>

<!DOCTYPE html>
<html>
<head>
<title>Students - Finance</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

<style>
body{margin:0;font-family:Arial;display:flex;background:#eef1f5;}
.sidebar{width:250px;height:100vh;background:#1d3557;color:white;padding:20px;}
.sidebar h2{text-align:center;}
.sidebar a{display:block;color:white;padding:12px;margin-top:10px;text-decoration:none;border-radius:8px;}
.sidebar a:hover{background:#457b9d;}
.sidebar a i{margin-right:10px;}
.main{flex:1;}
.topbar{background:white;padding:15px;display:flex;justify-content:space-between;box-shadow:0 2px 5px rgba(0,0,0,0.1);}
.content{padding:25px;}
table{width:100%;background:white;border-collapse:collapse;border-radius:10px;overflow:hidden;}
th,td{padding:14px;border-bottom:1px solid #ddd;text-align:left;}
th{background:#1d3557;color:white;}
.btn{display:inline-block;background:#1d3557;color:white;padding:8px 12px;text-decoration:none;border-radius:6px;}
.btn:hover{background:#16324f;}
</style>
</head>

<body>

<div class="sidebar">
    <h2>💰 Finance</h2>
    <a href="dashboard.php"><i class="fa fa-home"></i> Dashboard</a>
    <a href="../auth/logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
</div>

<div class="main">
    <div class="topbar">
        <div>Students</div>
        <div><i class="fa fa-money-bill"></i> Finance Officer</div>
    </div>

    <div class="content">
        <h2>Student Billing Records</h2>

        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Course</th>
                <th>College</th>
                <th>Action</th>
            </tr>

            <?php while($row = $students->fetch_assoc()) { ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['email']; ?></td>
                <td><?php echo $row['course']; ?></td>
                <td><?php echo $row['college']; ?></td>
                <td><a href="billing.php" class="btn">View Billing</a></td>
            </tr>
            <?php } ?>
        </table>
    </div>
</div>

</body>
</html>