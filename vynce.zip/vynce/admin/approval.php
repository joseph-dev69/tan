<?php
include '../config/db.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: ../auth/login.php");
    exit();
}

/* APPROVE USER */
if (isset($_GET['approve'])) {
    $id = $_GET['approve'];
    $conn->query("UPDATE users SET status='approved' WHERE id=$id");
    header("Location: approval.php"); // FIXED
    exit();

}

/* DISAPPROVE USER */
if (isset($_GET['disapprove'])) {
    $id = $_GET['disapprove'];
    $conn->query("UPDATE users SET status='disapproved' WHERE id=$id");
    header("Location: approval.php"); // FIXED
    exit();
}

$result = $conn->query("SELECT * FROM users WHERE status='pending'");
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Approvals</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

    <style>
        body {
            margin: 0;
            font-family: Arial;
            display: flex;
            background: #eef1f5;
        }

        .sidebar {
            width: 250px;
            height: 100vh;
            background: #1d3557;
            color: white;
            padding: 20px;
        }

        .sidebar h2 {
            text-align: center;
        }

        .sidebar a {
            display: block;
            color: white;
            padding: 12px;
            margin-top: 10px;
            text-decoration: none;
            border-radius: 8px;
        }

        .sidebar a:hover {
            background: #457b9d;
        }

        .sidebar a i {
            margin-right: 10px;
        }

        .main {
            flex: 1;
        }

        .topbar {
            background: white;
            padding: 15px;
            display: flex;
            justify-content: space-between;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .content {
            padding: 25px;
        }

        table {
            width: 100%;
            background: white;
            border-collapse: collapse;
            border-radius: 10px;
            overflow: hidden;
        }

        th, td {
            padding: 14px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        th {
            background: #1d3557;
            color: white;
        }

        .approve {
            background: green;
            color: white;
            padding: 8px 12px;
            text-decoration: none;
            border-radius: 6px;
        }

        .disapprove {
            background: red;
            color: white;
            padding: 8px 12px;
            text-decoration: none;
            border-radius: 6px;
        }
    </style>
</head>
<body>

<div class="sidebar">
    <h2>⚙️ Admin</h2>

    <a href="dashboard.php"><i class="fa fa-home"></i> Dashboard</a>
    <a href="approval.php"><i class="fa fa-user-check"></i> Approvals</a>
    <a href="add_subject.php"><i class="fa fa-plus"></i> Add Subject</a>
    <a href="manage_subjects.php"><i class="fa fa-book"></i> Manage Subjects</a>
    <a href="students.php"><i class="fa fa-users"></i> Students</a>
    <a href="../auth/logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
</div>

<div class="main">

    <div class="topbar">
        <div>User Approvals</div>
        <div><i class="fa fa-user-shield"></i> Administrator</div>
    </div>

    <div class="content">
        <h2>Pending User Registrations</h2>

        <table>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Role</th>
                <th>Status</th>
                <th>Action</th>
            </tr>

            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['role']; ?></td>
                    <td><?php echo $row['status']; ?></td>
                    <td>
                        <a class="approve" href="approval.php?approve=<?php echo $row['id']; ?>">Approve</a>
<a class="disapprove" href="approval.php?disapprove=<?php echo $row['id']; ?>">Disapprove</a>
                    </td>
                </tr>
            <?php } ?>
        </table>
    </div>

</div>

</body>
</html>