<?php include '../config/db.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if(isset($_POST['add'])){
    $c = $_POST['code'];
    $t = $_POST['title'];
    $s = $_POST['schedule'];
    $u = $_POST['units'];
    $i = $_POST['instructor'];

    $conn->query("INSERT INTO subjects(code,title,schedule,units,instructor)
    VALUES('$c','$t','$s','$u','$i')");

    echo "<script>alert('Subject added successfully!');</script>";
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Add Subject</title>

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

<style>
body {
    margin:0;
    font-family:Arial;
    display:flex;
    background:#eef1f5;
}

/* SIDEBAR */
.sidebar {
    width:250px;
    height:100vh;
    background:#1d3557;
    color:white;
    padding:20px;
}

.sidebar h2 {
    text-align:center;
}

.sidebar a {
    display:block;
    color:white;
    padding:12px;
    margin-top:10px;
    text-decoration:none;
    border-radius:8px;
}

.sidebar a:hover {
    background:#457b9d;
}

/* MAIN */
.main {
    flex:1;
}

/* TOPBAR */
.topbar {
    background:white;
    padding:15px;
    display:flex;
    justify-content:space-between;
    box-shadow:0 2px 5px rgba(0,0,0,0.1);
}

/* CONTENT */
.content {
    padding:20px;
}

/* FORM CARD */
.form-card {
    width:400px;
    background:white;
    padding:25px;
    border-radius:12px;
    box-shadow:0 5px 10px rgba(0,0,0,0.1);
}

.form-card h3 {
    margin-bottom:15px;
}

/* INPUT */
input {
    width:100%;
    padding:10px;
    margin-bottom:12px;
    border:1px solid #ccc;
    border-radius:6px;
}

/* BUTTON */
.btn {
    width:100%;
    padding:10px;
    background:#1d3557;
    color:white;
    border:none;
    border-radius:8px;
    cursor:pointer;
}

.btn:hover {
    background:#16324f;
}

/* BACK BUTTON */
.back-btn {
    display:inline-block;
    margin-bottom:15px;
    padding:8px 15px;
    background:#1d3557;
    color:white;
    border-radius:8px;
    text-decoration:none;
}
</style>

</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h2>⚙️ Admin</h2>

    <a href="dashboard.php"><i class="fa fa-home"></i> Dashboard</a>
    <a href="approval.php"><i class="fa fa-user-check"></i> Approvals</a>
<a href="add_subject.php"><i class="fa fa-plus"></i> Add Subject</a>
<a href="manage_subjects.php"><i class="fa fa-book"></i> Manage Subjects</a>
<a href="students.php"><i class="fa fa-users"></i> Students</a>
<a href="../auth/logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
</div>

<!-- MAIN -->
<div class="main">

<!-- TOPBAR -->
<div class="topbar">
    <div>Add Subject</div>
    <div><i class="fa fa-user-shield"></i> Admin</div>
</div>

<!-- CONTENT -->
<div class="content">

<a href="dashboard.php" class="back-btn">← Back</a>

<div class="form-card">
    <h3><i class="fa fa-plus-circle"></i> Add New Subject</h3>

    <form method="POST">
        <input name="code" placeholder="Subject Code" required>
        <input name="title" placeholder="Subject Title" required>
        <input name="schedule" placeholder="Schedule (e.g. MWF 8-10AM)" required>
        <input name="units" placeholder="Units" type="number" required>
        <input name="instructor" placeholder="Instructor Name" required>

        <button name="add" class="btn">Add Subject</button>
    </form>
</div>

</div>

</div>

</body>
</html>