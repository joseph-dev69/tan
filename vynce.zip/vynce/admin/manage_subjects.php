    <?php include '../config/db.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

/* DELETE */
if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    $conn->query("DELETE FROM subjects WHERE id='$id'");
    header("Location: manage_subjects.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Manage Subjects</title>

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

<style>
body{margin:0;font-family:Arial;display:flex;background:#eef1f5;}
.sidebar{width:250px;background:#1d3557;color:white;padding:20px;height:100vh;}
.sidebar a{display:block;color:white;padding:10px;margin-top:10px;text-decoration:none;}
.sidebar a:hover{background:#457b9d;}
.main{flex:1;}
.topbar{background:white;padding:15px;box-shadow:0 2px 5px rgba(0,0,0,0.1);}
.content{padding:20px;}

table{
    width:100%;
    background:white;
    border-collapse:collapse;
    box-shadow:0 5px 10px rgba(0,0,0,0.1);
}
th{background:#1d3557;color:white;padding:10px;}
td{padding:10px;text-align:center;border-bottom:1px solid #ddd;}

.btn{padding:6px 10px;border:none;border-radius:5px;cursor:pointer;}
.edit{background:#2a9d8f;color:white;}
.delete{background:#e63946;color:white;}
</style>
</head>

<body>

<div class="sidebar">
<h2>⚙️ Admin</h2>
<a href="dashboard.php"><i class="fa fa-home"></i> Dashboard</a>
<a href="approval.php"><i class="fa fa-user-check"></i> Approvals</a>
<a href="add_subject.php"><i class="fa fa-plus"></i> Add Subject</a>
<a href="manage_subjects.php"><i class="fa fa-book"></i> Manage Subjects</a>
<a href="students.php"><i class="fa fa-users"></i> Students</a>
<a href="../auth/logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
</div>

<div class="main">

<div class="topbar">Manage Subjects</div>

<div class="content">

<h2>Subjects List</h2>

<table>
<tr>
<th>Code</th>
<th>Title</th>
<th>Schedule</th>
<th>Units</th>
<th>Instructor</th>
<th>Action</th>
</tr>

<?php
$res = $conn->query("SELECT * FROM subjects");
while($row = $res->fetch_assoc()):
?>

<tr>
<td><?= $row['code'] ?></td>
<td><?= $row['title'] ?></td>
<td><?= $row['schedule'] ?></td>
<td><?= $row['units'] ?></td>
<td><?= $row['instructor'] ?></td>
<td>
<a href="edit_subject.php?id=<?= $row['id'] ?>">
<button class="btn edit">Edit</button>
</a>

<a href="?delete=<?= $row['id'] ?>" onclick="return confirm('Delete this subject?')">
<button class="btn delete">Delete</button>
</a>
</td>
</tr>

<?php endwhile; ?>

</table>

</div>
</div>
</body>
</html>