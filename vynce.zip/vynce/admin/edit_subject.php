<?php include '../config/db.php';

$id = $_GET['id'];
$data = $conn->query("SELECT * FROM subjects WHERE id='$id'")->fetch_assoc();

if(isset($_POST['update'])){
    $conn->query("UPDATE subjects SET 
    code='{$_POST['code']}',
    title='{$_POST['title']}',
    schedule='{$_POST['schedule']}',
    units='{$_POST['units']}',
    instructor='{$_POST['instructor']}'
    WHERE id='$id'");

    header("Location: manage_subjects.php");
}
?>

<form method="POST">
<input name="code" value="<?= $data['code'] ?>"><br><br>
<input name="title" value="<?= $data['title'] ?>"><br><br>
<input name="schedule" value="<?= $data['schedule'] ?>"><br><br>
<input name="units" value="<?= $data['units'] ?>"><br><br>
<input name="instructor" value="<?= $data['instructor'] ?>"><br><br>
<button name="update">Update</button>
</form>