    <?php include '../config/db.php';
    include '../includes/header.php';

    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    ?>

    <!DOCTYPE html>
    <html>
    <head>
    <title>Admin Panel</title>

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

    <style>
    body {
        margin:0;
        font-family:Arial;
        display:flex;
        background:#eef1f5;
    }

    /* SIDEBAR */
    .sidebar {
        width:250px;
        height:100vh;
        background:#1d3557;
        color:white;
        padding:20px;
    }

    .sidebar h2 {
        text-align:center;
    }

    .sidebar a {
        display:block;
        color:white;
        padding:12px;
        margin-top:10px;
        text-decoration:none;
        border-radius:8px;
    }

    .sidebar a i {
        margin-right:10px;
    }

    .sidebar a:hover {
        background:#457b9d;
    }

    /* MAIN */
    .main {
        flex:1;
    }

    /* TOPBAR */
    .topbar {
        background:white;
        padding:15px;
        display:flex;
        justify-content:space-between;
        align-items:center;
        box-shadow:0 2px 5px rgba(0,0,0,0.1);
    }

    /* CONTENT */
    .content {
        padding:20px;
    }

    /* CARDS */
    .cards {
        display:flex;
        gap:20px;
        margin-top:20px;
    }

    .card {
        flex:1;
        background:white;
        padding:20px;
        border-radius:12px;
        box-shadow:0 5px 10px rgba(0,0,0,0.1);
        text-align:center;
    }

    .card i {
        font-size:30px;
        margin-bottom:10px;
        color:#1d3557;
    }

    /* BUTTON */
    .btn {
        display:inline-block;
        margin-top:10px;
        padding:10px 15px;
        background:#1d3557;
        color:white;
        border-radius:8px;
        text-decoration:none;
    }

    .btn:hover {
        background:#16324f;
    }
    </style>

    </head>

    <body>



    <!-- MAIN -->
    <div class="main">

    <!-- TOPBAR -->
    <div class="topbar">
        <div>Admin Panel</div>
        <div><i class="fa fa-user-shield"></i> Administrator</div>
    </div>

    <!-- CONTENT -->
    <div class="content">

    <h2>Welcome, Admin 👋</h2>

    <div class="cards">

        <div class="card">
            <i class="fa fa-plus-circle"></i>
            <h3>Add Subject</h3>
            <p>Create new subjects for students</p>
            <a href="add_subject.php" class="btn">Go</a>
        </div>

        <div class="card">
            <i class="fa fa-book"></i>
            <h3>Manage Subjects</h3>
            <p>Edit or delete subjects</p>
            <a href="manage_subjects.php" class="btn">Manage</a>
   
        </div>

        <div class="card">
            <i class="fa fa-users"></i>
            <h3>Students</h3>
            <p>View enrolled students</p>
         <a href="students.php" class="btn">View</a>
        </div>

    </div>

    </div>

    </div>

    </body>
    </html>