<?php include '../config/db.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Students</title>

<style>
body{margin:0;font-family:Arial;display:flex;background:#eef1f5;}
.sidebar{width:250px;background:#1d3557;color:white;padding:20px;height:100vh;}
.sidebar a{display:block;color:white;padding:10px;margin-top:10px;text-decoration:none;}
.sidebar a:hover{background:#457b9d;}
.main{flex:1;}
.topbar{background:white;padding:15px;box-shadow:0 2px 5px rgba(0,0,0,0.1);}
.content{padding:20px;}

table{
    width:100%;
    background:white;
    border-collapse:collapse;
    box-shadow:0 5px 10px rgba(0,0,0,0.1);
}
th{background:#1d3557;color:white;padding:10px;}
td{padding:10px;text-align:center;border-bottom:1px solid #ddd;}
</style>
</head>

<body>

<div class="sidebar">
<h2>⚙️ Admin</h2>
<a href="dashboard.php"><i class="fa fa-home"></i> Dashboard</a>
<a href="approval.php"><i class="fa fa-user-check"></i> Approvals</a>
<a href="add_subject.php"><i class="fa fa-plus"></i> Add Subject</a>
<a href="manage_subjects.php"><i class="fa fa-book"></i> Manage Subjects</a>
<a href="students.php"><i class="fa fa-users"></i> Students</a>
<a href="../auth/logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
</div>

<div class="main">

<div class="topbar">Enrolled Students</div>

<div class="content">

<h2>Student Enrollments</h2>

<table>
<tr>
<th>Student Name</th>
<th>Email</th>
<th>Subject</th>
<th>Schedule</th>
</tr>

<?php
$res = $conn->query("
SELECT users.name, users.email, subjects.title, subjects.schedule
FROM enrollments
JOIN users ON users.id = enrollments.user_id
JOIN subjects ON subjects.id = enrollments.subject_id
");

while($row = $res->fetch_assoc()):
?>

<tr>
<td><?= $row['name'] ?></td>
<td><?= $row['email'] ?></td>
<td><?= $row['title'] ?></td>
<td><?= $row['schedule'] ?></td>
</tr>

<?php endwhile; ?>

</table>

</div>
</div>
</body>
</html>