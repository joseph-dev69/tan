<?php
include 'config/db.php';

if(isset($_SESSION['user'])){
    if($_SESSION['role']=='admin'){
        header("Location: admin/dashboard.php");
    } else {
        header("Location: student/dashboard.php");
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>RMCM Portal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #3b0ca3, #4361ee);
            color: white;
        }

        .container {
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .card {
            background: white;
            color: #333;
            padding: 40px;
            border-radius: 15px;
            width: 350px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        .logo {
            font-size: 22px;
            font-weight: bold;
            color: #3b0ca3;
            margin-bottom: 10px;
        }

        .subtitle {
            font-size: 14px;
            margin-bottom: 25px;
            color: #666;
        }

        .btn {
            display: block;
            width: 100%;
            padding: 12px;
            background: #3b0ca3;
            color: white;
            border: none;
            border-radius: 8px;
            margin-top: 10px;
            cursor: pointer;
            font-size: 16px;
        }

        .btn:hover {
            background: #2a0891;
        }

        .footer {
            margin-top: 15px;
            font-size: 12px;
            color: #aaa;
        }

        .school-name {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 18px;
            font-weight: bold;
        }
    </style>
</head>

<body>

<div class="school-name">
    Ramon Magsaysay Memorial Colleges
</div>

<div class="container">
    <div class="card">
        <div class="logo">🎓 RMMC Portal</div>
        <div class="subtitle">Student Information & Enrollment System</div>

        <a href="auth/login.php">
            <button class="btn">Login to Continue</button>
        </a>

        <div class="footer">
            © <?php echo date("Y"); ?> RMMC System
        </div>
    </div>
</div>

</body>
</html>