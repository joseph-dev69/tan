<?php 
include '../config/db.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$error = "";

if(isset($_POST['login'])){
    $login = $_POST['login_input']; // username or email
    $pass = md5($_POST['password']);

    $res = $conn->query("
        SELECT * FROM users 
        WHERE (email='$login' OR name='$login') 
        AND password='$pass'
    ");

    if($res->num_rows > 0){
    $user = $res->fetch_assoc();

    // 🚫 BLOCK IF NOT APPROVED
    if($user['status'] != 'approved'){
        $error = "Your account is waiting for admin approval.";
    } else {

        $_SESSION['user'] = $user['id'];
        $_SESSION['role'] = $user['role'];

        // 🔀 REDIRECT BASED ON ROLE
        if($user['role'] == 'admin'){
            header("Location: ../admin/dashboard.php");
        }
        elseif($user['role'] == 'student'){
            header("Location: ../student/dashboard.php");
        }
        elseif($user['role'] == 'finance'){
            header("Location: ../finance/dashboard.php");
        }
        else {
            header("Location: ../index.php");
        }

        exit();
    }
}
        }

     else {
        $error = "";
    }

?>

<!DOCTYPE html>
<html>
<head>
    <title>Login - RMMC</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <style>
        body {
            margin: 0;
            font-family: Arial;
            background: linear-gradient(135deg, #3b0ca3, #4361ee);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .login-card {
            background: white;
            padding: 35px;
            border-radius: 15px;
            width: 350px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        .title {
            text-align: center;
            font-size: 22px;
            font-weight: bold;
            color: #3b0ca3;
        }

        .subtitle {
            text-align: center;
            font-size: 14px;
            color: #777;
            margin-bottom: 20px;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            border-radius: 8px;
            border: 1px solid #ccc;
        }

        input:focus {
            outline: none;
            border-color: #3b0ca3;
        }

        button {
            width: 100%;
            padding: 12px;
            margin-top: 15px;
            background: #3b0ca3;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }

        button:hover {
            background: #2a0891;
        }

        .error {
            background: #ffdddd;
            color: red;
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 10px;
            text-align: center;
        }

        .footer {
            text-align: center;
            font-size: 12px;
            margin-top: 15px;
            color: #aaa;
        }

        .back {
            position: absolute;
            top: 20px;
            left: 20px;
            color: white;
            text-decoration: none;
            font-size: 14px;
        }
    </style>
</head>

<body>

<a href="../index.php" class="back">← Back</a>

<div class="login-card">
    <div class="title">🎓 RMMC Portal</div>
    <div class="subtitle">Login to your account</div>

    <?php if($error): ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST">
        <input name="login_input" type="text" placeholder="Email or Username" required>
        <input name="password" type="password" placeholder="Enter Password" required>
        <button name="login">Login</button>
    </form>

    <p style="text-align:center;margin-top:10px;">
        No account? <a href="register.php">Register here</a>
    </p>

    <div class="footer">
        © <?php echo date("Y"); ?> RMCM System
    </div>
</div>

</body>
</html>