<?php include '../config/db.php';

if(isset($_POST['register'])){
    $name=$_POST['name'];
    $email=$_POST['email'];
    $pass=md5($_POST['password']);
    $course=$_POST['course'];
    $college=$_POST['college'];

   $role = 'student';

$conn->query("INSERT INTO users(name,email,password,course,college,role,status)
VALUES('$name','$email','$pass','$course','$college','$role','pending')");

    header("Location: login.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Register</title>

<style>
body {
    font-family: 'Segoe UI', sans-serif;
    background: linear-gradient(135deg,#3b0ca3,#4361ee);
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
    margin:0;
}

/* CARD */
.card {
    background:white;
    padding:35px;
    border-radius:15px;
    width:370px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.2);
}

/* TITLE */
h2 {
    text-align:center;
    margin-bottom:20px;
    color:#333;
}

/* INPUTS */
input, select {
    width:100%;
    padding:12px;
    margin-top:12px;
    border-radius:8px;
    border:1px solid #ccc;
    font-size:14px;
    color:#333; /* FIX: makes text visible */
    background:#f9f9f9;
}

/* FOCUS EFFECT */
input:focus, select:focus {
    border-color:#3b0ca3;
    outline:none;
    background:white;
}

/* BUTTON */
button {
    width:100%;
    padding:12px;
    margin-top:18px;
    background:#3b0ca3;
    color:white;
    border:none;
    border-radius:8px;
    font-size:15px;
    cursor:pointer;
}

button:hover {
    background:#2a0891;
}

/* BACK BUTTON */
.back-btn {
    display:block;
    text-align:center;
    margin-top:15px;
    padding:10px;
    background:#adb5bd;
    color:white;
    text-decoration:none;
    border-radius:8px;
}

.back-btn:hover {
    background:#6c757d;
}
</style>

</head>

<body>

<div class="card">
<h2>🎓 Student Registration</h2>

<form method="POST">

<input name="name" placeholder="Full Name" required>

<input name="email" type="email" placeholder="Email Address" required>

<input name="password" type="password" placeholder="Password" required>

<select name="college" required>
<option value="">Select College</option>
<option>College of Information Technology</option>
<option>College of Business Administration</option>
<option>College of Education</option>
<option>College of Engineering</option>
<option>College of Nursing</option>
<option>College of Criminology</option>
</select>

<select name="course" required>
<option value="">Select Course</option>
<option>BSIT</option>
<option>BSCS</option>
<option>BSEd</option>
<option>BSBA</option>
<option>BSN</option>
<option>BS Criminology</option>
</select>

<button name="register">Register</button>

</form>

<a href="javascript:history.back()" class="back-btn">← Back</a>

</div>

</body>
</html>