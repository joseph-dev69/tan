<?php
include '../config/db.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'cashier') {
    header("Location: ../auth/login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Cashier Dashboard</title>

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

    <style>
        body{
            margin:0;
            font-family:Arial;
            display:flex;
            background:#eef1f5;
        }

        .sidebar{
            width:250px;
            height:100vh;
            background:#1d3557;
            color:white;
            padding:20px;
        }

        .sidebar h2{
            text-align:center;
        }

        .sidebar a{
            display:block;
            color:white;
            padding:12px;
            margin-top:10px;
            text-decoration:none;
            border-radius:8px;
        }

        .sidebar a:hover{
            background:#457b9d;
        }

        .sidebar a i{
            margin-right:10px;
        }

        .main{
            flex:1;
        }

        .topbar{
            background:white;
            padding:15px;
            display:flex;
            justify-content:space-between;
            box-shadow:0 2px 5px rgba(0,0,0,0.1);
        }

        .content{
            padding:25px;
        }

        .cards{
            display:flex;
            gap:20px;
            margin-top:20px;
        }

        .card{
            flex:1;
            background:white;
            padding:20px;
            border-radius:12px;
            box-shadow:0 5px 10px rgba(0,0,0,0.1);
            text-align:center;
        }

        .card i{
            font-size:35px;
            color:#1d3557;
            margin-bottom:10px;
        }

        .btn{
            display:inline-block;
            margin-top:10px;
            padding:10px 15px;
            background:#1d3557;
            color:white;
            border-radius:8px;
            text-decoration:none;
        }

        .btn:hover{
            background:#16324f;
        }
    </style>
</head>

<body>

<div class="sidebar">

    <h2>🎓 RMMC</h2>

    <a href="dashboard.php">
        <i class="fa fa-home"></i> Dashboard
    </a>

    <a href="collect_payment.php">
        <i class="fa fa-money-bill"></i> Collect Payment
    </a>

    <a href="payment_history.php">
        <i class="fa fa-clock"></i> Payment History
    </a>

    <a href="print_receipt.php">
        <i class="fa fa-print"></i> Print Receipt
    </a>

    <a href="../auth/logout.php">
        <i class="fa fa-sign-out-alt"></i> Logout
    </a>

</div>

<div class="main">

    <div class="topbar">
        <div>Cashier Dashboard</div>
        <div><i class="fa fa-user"></i> Cashier Officer</div>
    </div>

    <div class="content">

        <h2>Welcome, Cashier 👋</h2>

        <div class="cards">

            <div class="card">
                <i class="fa fa-money-bill-wave"></i>
                <h3>Collect Payment</h3>
                <p>Receive student payments</p>

                <a href="collect_payment.php" class="btn">
                    Open
                </a>
            </div>

            <div class="card">
                <i class="fa fa-clock-rotate-left"></i>
                <h3>Payment History</h3>
                <p>View payment transactions</p>

                <a href="payment_history.php" class="btn">
                    View
                </a>
            </div>

            <div class="card">
                <i class="fa fa-print"></i>
                <h3>Print Receipt</h3>
                <p>Generate exam permit receipt</p>

                <a href="print_receipt.php" class="btn">
                    Print
                </a>
            </div>

        </div>

    </div>

</div>

</body>
</html>