<?php
$conn = new mysqli("localhost","root","","rmmc");

if($conn->connect_error){
    die("Connection Failed");
}
session_start();
?>