<?php
$role = $_SESSION['role'] ?? '';

switch ($role) {

    case 'admin':
        echo '
        <a href="../admin/dashboard.php"><i class="fa fa-home"></i> Dashboard</a>
        <a href="../admin/approval.php"><i class="fa fa-user-check"></i> Approvals</a>
        <a href="../admin/add_subject.php"><i class="fa fa-plus"></i> Add Subject</a>
        <a href="../admin/manage_subjects.php"><i class="fa fa-book"></i> Manage Subjects</a>
        <a href="../admin/students.php"><i class="fa fa-users"></i> Students</a>
        ';
        break;

    case 'finance':
        echo '
        <a href="../finance/dashboard.php"><i class="fa fa-home"></i> Dashboard</a>
        <a href="../finance/student_balance.php"><i class="fa fa-users"></i> Student Balances</a>
        <a href="../finance/fees.php"><i class="fa fa-money-bill"></i> Fee Schedule</a>
        <a href="../finance/billing.php"><i class="fa fa-file-invoice"></i> Billing</a>
        ';
        break;

    case 'cashier':
        echo '
        <a href="../cashier/dashboard.php"><i class="fa fa-home"></i> Dashboard</a>
        <a href="../cashier/collect_payment.php"><i class="fa fa-money-bill"></i> Collect Payment</a>
        <a href="../cashier/payment_history.php"><i class="fa fa-clock"></i> Payment History</a>
        ';
        break;

    case 'student':
        echo '
        <a href="../student/dashboard.php"><i class="fa fa-home"></i> Dashboard</a>
        <a href="../student/subjects.php"><i class="fa fa-book"></i> Subjects</a>
        <a href="../student/my_subjects.php"><i class="fa fa-list"></i> My Subjects</a>
        <a href="../student/soa.php"><i class="fa fa-file-invoice"></i> Statement of Account</a>
        ';
        break;
}
?>