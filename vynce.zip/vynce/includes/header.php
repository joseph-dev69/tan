<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['role'])) {
    header("Location: ../auth/login.php");
    exit();
}

$page_title = $page_title ?? "Dashboard";
$user_role = ucfirst($_SESSION['role']);
?>

<!DOCTYPE html>
<html>
<head>
    <title><?php echo $page_title; ?></title>

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

    <style>
        body {
            margin: 0;
            font-family: Arial;
            display: flex;
            background: #eef1f5;
        }

        .sidebar {
            width: 250px;
            height: 100vh;
            background: #1d3557;
            color: white;
            padding: 20px;
        }

        .sidebar h2 {
            text-align: center;
        }

        .sidebar a {
            display: block;
            color: white;
            padding: 12px;
            margin-top: 10px;
            text-decoration: none;
            border-radius: 8px;
        }

        .sidebar a:hover {
            background: #457b9d;
        }

        .sidebar a i {
            margin-right: 10px;
        }

        .main {
            flex: 1;
        }

        .topbar {
            background: white;
            padding: 15px;
            display: flex;
            justify-content: space-between;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .content {
            padding: 25px;
        }

        .btn {
            background: #1d3557;
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 8px;
            display: inline-block;
        }
    </style>
</head>

<body>

<div class="sidebar">
    <h2>🎓 RMMC</h2>

    <?php include '../includes/sidebar_menu.php'; ?>

    <a href="../auth/logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
</div>

<div class="main">
    <div class="topbar">
        <div><?php echo $page_title; ?></div>
        <div><i class="fa fa-user"></i> <?php echo $user_role; ?></div>
    </div>

    <div class="content">