<?php include '../config/db.php';

$id=$_GET['id'];
$user=$_SESSION['user'];

/* UNIT LIMIT */
$total=$conn->query("
SELECT SUM(subjects.units) as total
FROM enrollments
JOIN subjects ON subjects.id=enrollments.subject_id
WHERE user_id='$user'
")->fetch_assoc()['total'];

$units=$conn->query("SELECT units FROM subjects WHERE id='$id'")
->fetch_assoc()['units'];

if(($total+$units)>21){
    die("Unit limit exceeded!");
}

/* CONFLICT */
$new_sched=$conn->query("SELECT schedule FROM subjects WHERE id='$id'")
->fetch_assoc()['schedule'];

$check=$conn->query("
SELECT * FROM enrollments
JOIN subjects ON subjects.id=enrollments.subject_id
WHERE user_id='$user' AND subjects.schedule='$new_sched'
");

if($check->num_rows>0){
    die("Schedule conflict!");
}

$conn->query("INSERT INTO enrollments(user_id,subject_id) VALUES('$user','$id')");

header("Location: my_subjects.php");