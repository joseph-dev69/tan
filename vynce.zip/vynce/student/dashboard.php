<?php include '../config/db.php';
include '../includes/header.php';

$user_id = $_SESSION['user'];
$user = $conn->query("SELECT * FROM users WHERE id='$user_id'")->fetch_assoc();

/* GET ENROLLED SUBJECTS */
$subjects = $conn->query("
SELECT subjects.* 
FROM enrollments
JOIN subjects ON subjects.id=enrollments.subject_id
WHERE user_id='$user_id'
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Student Dashboard</title>

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

<style>
body {
    margin:0;
    font-family:Arial;
    display:flex;
    background:#eef1f5;
}

/* SIDEBAR */
.sidebar {
    width:250px;
    height:100vh;
    background:#3b0ca3;
    color:white;
    padding:20px;
}

.sidebar h2 {
    text-align:center;
}

.sidebar a {
    display:block;
    color:white;
    padding:12px;
    margin-top:10px;
    text-decoration:none;
    border-radius:8px;
}

.sidebar a i {
    margin-right:10px;
}

.sidebar a:hover {
    background:#4361ee;
}

/* MAIN */
.main {
    flex:1;
}

/* TOPBAR */
.topbar {
    background:white;
    padding:15px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    box-shadow:0 2px 5px rgba(0,0,0,0.1);
}

.profile {
    font-weight:bold;
}

/* CONTENT */
.content {
    padding:20px;
}

/* CARDS */
.cards {
    display:flex;
    gap:15px;
}

.card {
    flex:1;
    background:white;
    padding:20px;
    border-radius:10px;
    box-shadow:0 5px 10px rgba(0,0,0,0.1);
}

/* TABLE */
table {
    width:100%;
    border-collapse:collapse;
    margin-top:20px;
    background:white;
}

th {
    background:#3b0ca3;
    color:white;
    padding:10px;
}

td {
    padding:10px;
    text-align:center;
}

/* BACK BUTTON */
.back-btn {
    display:inline-block;
    margin-bottom:15px;
    padding:8px 15px;
    background:#3b0ca3;
    color:white;
    border-radius:8px;
    text-decoration:none;
}
</style>

</head>

<body>
    

<!-- MAIN -->
<div class="main">

<!-- TOPBAR -->
<div class="topbar">
    <div>Student Portal</div>
    <div class="profile">
        <?= $user['name'] ?>
    </div>
</div>

<!-- CONTENT -->
<div class="content">

<a href="javascript:history.back()" class="back-btn">← Back</a>

<h2>Welcome, <?= $user['name'] ?></h2>

<!-- DASHBOARD CARDS -->
<div class="cards">
    <div class="card">
        <h3><i class="fa fa-user"></i> Profile</h3>
        <p><?= $user['email'] ?></p>
        <p><?= $user['course'] ?></p>
    </div>

    <div class="card">
        <h3><i class="fa fa-school"></i> College</h3>
        <p><?= $user['college'] ?></p>
    </div>

    <div class="card">
        <h3><i class="fa fa-book"></i> Total Subjects</h3>
        <p><?= $subjects->num_rows ?></p>
    </div>
</div>

<!-- SCHEDULE TABLE -->
<h3 style="margin-top:30px;"><i class="fa fa-calendar"></i> My Schedule</h3>

<table>
<tr>
<th>Code</th>
<th>Title</th>
<th>Schedule</th>
<th>Units</th>
<th>Instructor</th>
</tr>

<?php while($row=$subjects->fetch_assoc()): ?>
<tr>
<td><?= $row['code'] ?></td>
<td><?= $row['title'] ?></td>
<td><?= $row['schedule'] ?></td>
<td><?= $row['units'] ?></td>
<td><?= $row['instructor'] ?></td>
</tr>
<?php endwhile; ?>

</table>

</div>

</div>

</body>
</html>