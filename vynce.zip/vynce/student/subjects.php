<?php include '../config/db.php';

$user_id = $_SESSION['user'];
$user = $conn->query("SELECT * FROM users WHERE id='$user_id'")->fetch_assoc();

$res = $conn->query("SELECT * FROM subjects");
?>

<!DOCTYPE html>
<html>
<head>
<title>Subjects</title>

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

<style>
body {
    margin:0;
    font-family:Arial;
    display:flex;
    background:#eef1f5;
}

/* SIDEBAR */
.sidebar {
    width:250px;
    height:100vh;
    background:#3b0ca3;
    color:white;
    padding:20px;
}

.sidebar h2 {
    text-align:center;
}

.sidebar a {
    display:block;
    color:white;
    padding:12px;
    margin-top:10px;
    text-decoration:none;
    border-radius:8px;
}

.sidebar a i {
    margin-right:10px;
}

.sidebar a:hover {
    background:#4361ee;
}

/* MAIN */
.main {
    flex:1;
}

/* TOPBAR */
.topbar {
    background:white;
    padding:15px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    box-shadow:0 2px 5px rgba(0,0,0,0.1);
}

.profile {
    font-weight:bold;
}

/* CONTENT */
.content {
    padding:20px;
}

/* TABLE */
table {
    width:100%;
    border-collapse:collapse;
    margin-top:20px;
    background:white;
    border-radius:10px;
    overflow:hidden;
    box-shadow:0 5px 10px rgba(0,0,0,0.1);
}

th {
    background:#3b0ca3;
    color:white;
    padding:12px;
}

td {
    padding:12px;
    text-align:center;
    border-bottom:1px solid #ddd;
}

tr:hover {
    background:#f1f1f1;
}

/* BUTTON */
.select-btn {
    background:#2a9d8f;
    color:white;
    padding:7px 12px;
    border:none;
    border-radius:6px;
    cursor:pointer;
}

.select-btn:hover {
    background:#21867a;
}

/* BACK BUTTON */
.back-btn {
    display:inline-block;
    margin-bottom:15px;
    padding:8px 15px;
    background:#3b0ca3;
    color:white;
    border-radius:8px;
    text-decoration:none;
}
</style>

</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h2>🎓 RMMC</h2>

    <a href="dashboard.php"><i class="fa fa-home"></i> Dashboard</a>
    <a href="subjects.php"><i class="fa fa-book"></i> Subjects</a>
    <a href="my_subjects.php"><i class="fa fa-list"></i> My Subjects</a>
    <a href="../auth/logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
</div>

<!-- MAIN -->
<div class="main">

<!-- TOPBAR -->
<div class="topbar">
    <div>Student Portal</div>
    <div class="profile">
        <?= $user['name'] ?>
    </div>
</div>

<!-- CONTENT -->
<div class="content">

<a href="javascript:history.back()" class="back-btn">← Back</a>

<h2><i class="fa fa-book"></i> Available Subjects</h2>

<table>
<tr>
<th>Code</th>
<th>Title</th>
<th>Schedule</th>
<th>Units</th>
<th>Action</th>
</tr>

<?php if($res->num_rows > 0): ?>
    <?php while($row=$res->fetch_assoc()): ?>
    <tr>
        <td><?= $row['code'] ?></td>
        <td><?= $row['title'] ?></td>
        <td><?= $row['schedule'] ?></td>
        <td><?= $row['units'] ?></td>
        <td>
            <a href="enroll.php?id=<?= $row['id'] ?>">
                <button class="select-btn">
                    <i class="fa fa-check"></i> Select
                </button>
            </a>
        </td>
    </tr>
    <?php endwhile; ?>
<?php else: ?>
<tr>
    <td colspan="5">No subjects available.</td>
</tr>
<?php endif; ?>

</table>

</div>

</div>

</body>
</html>