<?php include '../config/db.php';

$id=$_GET['id'];
$conn->query("DELETE FROM enrollments WHERE id='$id'");

header("Location: my_subjects.php");